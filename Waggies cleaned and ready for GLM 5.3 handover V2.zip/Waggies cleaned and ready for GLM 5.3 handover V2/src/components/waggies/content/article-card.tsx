"use client";

/**
 * ArticleCard - reusable card for blog, guide, and knowledge base listings.
 *
 * Renders an image, optional category badge, title, excerpt, and metadata.
 * The entire card links to the given href.
 */

import Link from "next/link";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { WaggiesImage } from "@/components/waggies/waggies-image";
import { cn } from "@/lib/utils";

export type ArticleCardProps = {
  href: string;
  title: string;
  excerpt: string;
  imageSrc: string;
  imageAlt?: string;
  category?: string;
  author?: string;
  date?: string;
  readTime?: string;
  /** Larger "featured" variant that spans full width */
  featured?: boolean;
  className?: string;
};

export function ArticleCard({
  href,
  title,
  excerpt,
  imageSrc,
  imageAlt,
  category,
  author,
  date,
  readTime,
  featured = false,
  className,
}: ArticleCardProps) {
  const formattedDate = date
    ? new Date(date).toLocaleDateString("en-NG", {
        year: "numeric",
        month: "short",
        day: "numeric",
      })
    : null;

  return (
    <Link
      href={href}
      className={cn(
        "group block bg-white rounded-xl border border-border-subtle overflow-hidden shadow-xs hover:shadow-md transition-shadow duration-200",
        featured && "md:flex",
        className,
      )}
    >
      {/* Image */}
      <div
        className={cn(
          "relative overflow-hidden",
          featured
            ? "md:w-1/2 md:flex-shrink-0"
            : "aspect-[16/10]",
        )}
      >
        <WaggiesImage
          src={imageSrc}
          alt={imageAlt ?? title}
          fill
          className="group-hover:scale-[1.02] transition-transform duration-300"
          sizes={featured ? "(max-width: 768px) 100vw, 50vw" : undefined}
        />
      </div>

      {/* Content */}
      <div className={cn("p-4 md:p-6 flex flex-col gap-3", featured && "md:flex-1 md:justify-center")}>
        {/* Category badge */}
        {category && (
          <span className="inline-flex self-start items-center rounded-full bg-surface-purple px-3 py-1 text-label text-primary">
            {category}
          </span>
        )}

        <h3
          className={cn(
            "font-serif font-bold text-primary-dark group-hover:text-primary transition-colors line-clamp-2",
            featured ? "text-h3" : "text-h4",
          )}
        >
          {title}
        </h3>

        <p className={cn(
          "text-body-sm line-clamp-3",
          featured && "md:line-clamp-4",
        )}>
          {excerpt}
        </p>

        {/* Metadata */}
        <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-meta mt-auto pt-1">
          {author && (
            <span className="flex items-center gap-1">
              <MaterialSymbol name="person" className="text-sm" />
              {author}
            </span>
          )}
          {formattedDate && (
            <span className="flex items-center gap-1">
              <MaterialSymbol name="calendar_today" className="text-sm" />
              {formattedDate}
            </span>
          )}
          {readTime && (
            <span className="flex items-center gap-1">
              <MaterialSymbol name="schedule" className="text-sm" />
              {readTime}
            </span>
          )}
        </div>
      </div>
    </Link>
  );
}
