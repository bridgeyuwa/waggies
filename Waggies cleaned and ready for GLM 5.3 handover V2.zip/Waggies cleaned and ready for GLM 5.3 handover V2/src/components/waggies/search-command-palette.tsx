"use client";

/**
 * SearchCommandPalette - global search modal triggered by:
 *   • The SearchTrigger button in the navbar (custom `waggies:open-search` event)
 *   • Keyboard shortcut ⌘K / Ctrl+K
 *
 * Architecture:
 *   - The palette is mounted once in the root layout (always in the DOM but
 *     visually hidden when closed via framer-motion AnimatePresence).
 *   - Opening is controlled by listening to a custom window event so the
 *     trigger doesn't need to lift state up to a shared parent.
 *   - On open, focus is moved into the modal via the existing `useFocusTrap`
 *     hook (the same one used by the navbar mobile menu). This traps Tab
 *     and restores focus to the previously-focused element on close.
 *
 * Search flow:
 *   - Input change → 150ms debounce → fetch /api/search?q=... → results list.
 *   - Empty query → show Recent searches + Popular searches (local data).
 *   - Arrow keys cycle the active result; Enter navigates to it via router.push.
 *   - Click outside the modal or the X button closes it.
 *
 * Result row visual:
 *   - Circular MaterialSymbol icon badge colored by item type (see TYPE_STYLES).
 *   - Title (font-medium) + 1-line description.
 *   - Category pill in the top-right.
 *   - Hover and active (keyboard-selected) states.
 *
 * Enhancements (Task 7-b):
 *   - Recent searches: stored in localStorage (max 5), shown with history icon.
 *   - Popular searches: hard-coded trending terms with trending_up icon.
 *   - Search result count: "X results for 'query'" displayed above results.
 *   - Keyboard navigation works across all sections (recent, popular, results).
 *   - Visual polish: dividers, AnimatePresence transitions, icon colors.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { MaterialSymbol } from "./material-symbol";
import { useFocusTrap } from "@/lib/use-focus-trap";
import { cn } from "@/lib/utils";

// ── Result item type (mirrors SearchResultItem from src/lib/search-index) ──
type SearchResultType =
  | "service"
  | "faq"
  | "page";

type SearchResultItem = {
  id: string;
  type: SearchResultType;
  title: string;
  description?: string;
  href: string;
  category?: string;
  icon: string;
  keywords?: string;
  score?: number;
};

// ── Per-type styling for the circular icon badge + category pill ──────────
// Colours avoid blue/indigo per the Waggies design system. Each entry has a
// `badge` (icon background + text colour) and `pill` (category label colours)
// since the same hue works for both, but they can diverge if needed.
const TYPE_STYLES: Record<
  SearchResultType,
  { badge: string; pill: string; label: string }
> = {
  service: {
    badge: "bg-primary/15 text-primary",
    pill: "bg-primary/15 text-primary",
    label: "Service",
  },

  faq: {
    badge: "bg-teal-100 text-teal-700",
    pill: "bg-teal-100 text-teal-700",
    label: "FAQ",
  },
  page: {
    badge: "bg-primary-dark/10 text-primary-dark",
    pill: "bg-primary-dark/10 text-primary-dark",
    label: "Page",
  },
};

// ── Constants ───────────────────────────────────────────────────────────────
const DEBOUNCE_MS = 150;
const MAX_RESULTS = 8;
const RECENT_SEARCHES_KEY = "waggies-recent-searches";
const MAX_RECENT = 5;
const POPULAR_SEARCHES = [
  "Grooming",
  "Vet Care",
  "Boarding prices",
  "Dog training",
  "Pet relocation",
  "Vaccination",
];

// ── localStorage helpers for recent searches ────────────────────────────────
function getRecentSearches(): string[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(RECENT_SEARCHES_KEY);
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    return parsed.filter((v): v is string => typeof v === "string").slice(0, MAX_RECENT);
  } catch {
    return [];
  }
}

function addRecentSearch(query: string): string[] {
  const trimmed = query.trim();
  if (!trimmed) return getRecentSearches();
  const existing = getRecentSearches().filter((s) => s.toLowerCase() !== trimmed.toLowerCase());
  const updated = [trimmed, ...existing].slice(0, MAX_RECENT);
  try {
    localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
  } catch {
    /* localStorage unavailable or full - silently ignore */
  }
  return updated;
}

function clearRecentSearches(): void {
  try {
    localStorage.removeItem(RECENT_SEARCHES_KEY);
  } catch {
    /* ignore */
  }
}

// ── Navigable item types for unified keyboard navigation ────────────────────
type NavigableItem =
  | { kind: "recent"; query: string }
  | { kind: "popular"; query: string }
  | { kind: "result"; item: SearchResultItem };

export function SearchCommandPalette({
  initialOpen = false,
}: {
  /**
   * If true, the palette mounts already-open. Used by LazySearchPalette so
   * that the very first `waggies:open-search` event (which triggers the
   * dynamic import) results in an open palette - without needing a fragile
   * re-dispatch of the event after the import resolves.
   */
  initialOpen?: boolean;
}) {
  const router = useRouter();
  const [open, setOpen] = useState(initialOpen);
  const [query, setQuery] = useState("");
  const [results, setResults] = useState<SearchResultItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  // Refs
  const inputRef = useRef<HTMLInputElement | null>(null);
  const listRef = useRef<HTMLUListElement | null>(null);
  const abortRef = useRef<AbortController | null>(null);
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Focus trap (restores focus to the trigger on close). The trap activates
  // only when the palette is open, so we pass `open` as the active flag.
  const containerRef = useFocusTrap<HTMLDivElement>(open);

  // ── Build navigable items list ─────────────────────────────────────────
  const isQueryEmpty = query.trim().length === 0;
  const navigableItems: NavigableItem[] = isQueryEmpty
    ? [
        ...recentSearches.map((q): NavigableItem => ({ kind: "recent", query: q })),
        ...POPULAR_SEARCHES.map((q): NavigableItem => ({ kind: "popular", query: q })),
      ]
    : results.map((item): NavigableItem => ({ kind: "result", item }));

  const totalNavigable = navigableItems.length;

  // ── Execute a search query (fill input + trigger fetch) ────────────────
  const executeSearch = useCallback((q: string) => {
    setQuery(q);
    setActiveIndex(0);
  }, []);

  // ── Reset state (called from event handlers only, never from effects) ──
  // Resetting here is safe because the call originates from a user-driven
  // event (trigger click or close button) - not a synchronous effect body.
  const resetState = useCallback(() => {
    setQuery("");
    setResults([]);
    setActiveIndex(0);
    setLoading(false);
    setRecentSearches(getRecentSearches());
    if (abortRef.current) {
      abortRef.current.abort();
      abortRef.current = null;
    }
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
      debounceTimerRef.current = null;
    }
  }, []);

  // ── Open / close helpers ────────────────────────────────────────────────
  // openPalette is called from the `waggies:open-search` event listener
  // (set up inside an effect, but the listener callback itself is async  - 
  // so calling setState here is allowed by the react-hooks rule).
  const openPalette = useCallback(() => {
    resetState();
    setOpen(true);
  }, [resetState]);

  const closePalette = useCallback(() => {
    setOpen(false);
    // Don't clear query immediately - preserving it lets the user re-open
    // the palette and continue searching where they left off. State is
    // reset on the next open via `openPalette` (triggered by the
    // SearchTrigger button or the ⌘K shortcut when the palette is closed).
  }, []);

  // ── Listen for the custom open event from SearchTrigger ─────────────────
  useEffect(() => {
    const handler = () => openPalette();
    window.addEventListener("waggies:open-search", handler);
    return () => window.removeEventListener("waggies:open-search", handler);
  }, [openPalette]);

  // ── Navigate to a result ────────────────────────────────────────────────
  const navigateTo = useCallback(
    (item: SearchResultItem) => {
      closePalette();
      router.push(item.href);
    },
    [router, closePalette],
  );

  // ── Activate a navigable item (Enter key or click) ──────────────────────
  const activateNavigable = useCallback(
    (nav: NavigableItem) => {
      if (nav.kind === "result") {
        navigateTo(nav.item);
      } else {
        // recent or popular - fill input and trigger search
        executeSearch(nav.query);
      }
    },
    [navigateTo, executeSearch],
  );

  // ── Global keyboard: ⌘K / Ctrl+K to open, Esc to close ──────────────────
  // Attach at document level so the palette can be opened from anywhere.
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      // Open on ⌘K / Ctrl+K
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setOpen((v) => !v);
        return;
      }
      // Close on Esc
      if (e.key === "Escape" && open) {
        e.preventDefault();
        closePalette();
        return;
      }
      // Arrow navigation when open - only when not actively composing in the
      // input (which would otherwise hijack caret movement on mobile).
      if (!open) return;
      if (e.key === "ArrowDown") {
        e.preventDefault();
        setActiveIndex((i) => Math.min(i + 1, Math.max(0, totalNavigable - 1)));
      } else if (e.key === "ArrowUp") {
        e.preventDefault();
        setActiveIndex((i) => Math.max(0, i - 1));
      } else if (e.key === "Enter") {
        const active = navigableItems[activeIndex];
        if (active) {
          e.preventDefault();
          activateNavigable(active);
        }
      }
    };
    document.addEventListener("keydown", handler);
    return () => document.removeEventListener("keydown", handler);
  }, [open, totalNavigable, activeIndex, navigableItems, closePalette, activateNavigable]);

  // ── When the palette opens: focus input + lock body scroll ────────────
  // Transient query/result state is NOT reset here - preserving the
  // previous query lets users re-open the palette and continue searching
  // where they left off. State is only reset by the SearchTrigger click
  // (via the `openPalette` handler) and by the close button (via
  // `closePalette`), both of which are user-initiated event handlers.
  useEffect(() => {
    if (!open) return;

    // Load recent searches from localStorage on open (deferred via
    // microtask to avoid synchronous setState inside the effect body).
    queueMicrotask(() => setRecentSearches(getRecentSearches()));

    // Lock body scroll while the palette is open.
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    // Move focus to the input on the next frame (after framer-motion paints).
    const raf = requestAnimationFrame(() => {
      inputRef.current?.focus();
      inputRef.current?.select();
    });

    return () => {
      cancelAnimationFrame(raf);
      document.body.style.overflow = prev;
    };
  }, [open]);

  // ── Debounced fetch whenever `query` changes ────────────────────────────
  useEffect(() => {
    if (!open) return;

    // Cancel any in-flight debounce.
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current);
    }

    // Empty query → no fetch needed; recent + popular are shown from local state.
    if (query.trim().length === 0) {
      // Abort any in-flight request.
      if (abortRef.current) {
        abortRef.current.abort();
        abortRef.current = null;
      }
      // Defer setState via microtask so we don't synchronously setState
      // inside the effect body (which the react-hooks rule warns against).
      queueMicrotask(() => {
        setResults([]);
        setLoading(false);
        setActiveIndex(0);
      });
      return;
    }

    // Non-empty query → debounce. setLoading is deferred to the setTimeout
    // callback (which is async, not the effect body) so the linter is happy.
    debounceTimerRef.current = setTimeout(() => {
      setLoading(true);
      if (abortRef.current) {
        abortRef.current.abort();
      }
      const controller = new AbortController();
      abortRef.current = controller;
      const url = `/api/search?q=${encodeURIComponent(query.trim())}`;
      fetch(url, { signal: controller.signal })
        .then((r) => r.json())
        .then((data: { results: SearchResultItem[] }) => {
          const fetched = data.results ?? [];
          setResults(fetched);
          setActiveIndex(0);
          // On successful search with results, add query to recent searches
          if (fetched.length > 0) {
            const updated = addRecentSearch(query.trim());
            setRecentSearches(updated);
          }
        })
        .catch(() => {
          /* swallowed - abort or network error */
        })
        .finally(() => {
          if (abortRef.current === controller) {
            abortRef.current = null;
          }
          setLoading(false);
        });
    }, DEBOUNCE_MS);

    return () => {
      if (debounceTimerRef.current) {
        clearTimeout(debounceTimerRef.current);
        debounceTimerRef.current = null;
      }
    };
  }, [query, open]);

  // ── Track outside clicks on the overlay to close ────────────────────────
  const handleOverlayClick = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      // Only close if the click landed on the overlay itself (not on a child).
      if (e.target === e.currentTarget) {
        closePalette();
      }
    },
    [closePalette],
  );

  // ── Clear recent searches handler ──────────────────────────────────────
  const handleClearRecent = useCallback(() => {
    clearRecentSearches();
    setRecentSearches([]);
    setActiveIndex(0);
  }, []);

  // ── Scroll the active row into view when activeIndex changes ─────────────
  useEffect(() => {
    if (!open) return;
    const list = listRef.current;
    if (!list) return;
    const active = list.children[activeIndex] as HTMLElement | undefined;
    if (active && typeof active.scrollIntoView === "function") {
      active.scrollIntoView({ block: "nearest" });
    }
  }, [activeIndex, open, totalNavigable]);

  const hasResults = results.length > 0;
  const showEmptyState = !loading && query.trim().length > 0 && !hasResults;
  const hasRecent = recentSearches.length > 0;

  // Compute the active index offset for sections
  const recentCount = isQueryEmpty ? recentSearches.length : 0;
  const popularCount = isQueryEmpty ? POPULAR_SEARCHES.length : 0;

  // Section animation variants
  const sectionVariants = {
    initial: { opacity: 0, y: -4 },
    animate: { opacity: 1, y: 0 },
    exit: { opacity: 0, y: -4 },
  };

  return (
    <AnimatePresence>
      {open && (
        <div
          className="fixed inset-0 z-[70] flex items-start justify-center px-4 sm:px-6"
          aria-modal="true"
          role="dialog"
          aria-label="Search the Waggies site"
        >
          {/* ── Overlay ────────────────────────────────────────────────── */}
          <motion.div
            className="absolute inset-0 bg-black/60 backdrop-blur-sm"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.18 }}
            onClick={handleOverlayClick}
            aria-hidden="true"
          />

          {/* ── Modal ──────────────────────────────────────────────────── */}
          <motion.div
            ref={containerRef}
            initial={{ opacity: 0, scale: 0.95, y: -8 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.97, y: -8 }}
            transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            className="relative w-full max-w-2xl mt-[8vh] sm:mt-[12vh] bg-white rounded-2xl shadow-2xl border border-primary/10 overflow-hidden"
          >
            {/* ── Header: search input ─────────────────────────────────── */}
            <div className="relative border-b border-surface-purple">
              {/* Leading search icon (animated on focus) */}
              <span className="absolute left-4 top-1/2 -translate-y-1/2 text-primary-dark/60 pointer-events-none flex items-center justify-center">
                <MaterialSymbol
                  name={loading ? "progress_activity" : "search"}
                  className={cn(
                    "text-2xl transition-transform duration-200",
                    loading && "animate-spin",
                  )}
                  ariaHidden
                />
              </span>

              <input
                ref={inputRef}
                type="search"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search services, articles, products, FAQs…"
                aria-label="Search query"
                aria-autocomplete="list"
                aria-controls="search-results-list"
                autoComplete="off"
                spellCheck={false}
                className="w-full text-lg pl-12 pr-12 py-4 border-0 focus:ring-0 focus:outline-none bg-transparent text-primary-dark placeholder:text-primary-dark/60"
              />

              {/* X close button (top-right) */}
              <button
                type="button"
                onClick={closePalette}
                aria-label="Close search"
                className="absolute right-3 top-1/2 -translate-y-1/2 flex items-center justify-center w-11 h-11 rounded-full hover:bg-surface-purple transition-colors text-primary-dark/70 focus:outline-none focus:ring-2 focus:ring-primary/60"
              >
                <MaterialSymbol name="close" className="text-xl" ariaHidden={false} />
              </button>
            </div>

            {/* ── Results list ────────────────────────────────────────── */}
            <div className="max-h-[60vh] overflow-y-auto p-2">
              {/* ── Empty-query state: Recent + Popular sections ────────── */}
              {isQueryEmpty && !loading && (
                <ul
                  ref={listRef}
                  id="search-results-list"
                  role="listbox"
                  aria-label="Recent and popular searches"
                  className="flex flex-col gap-0.5"
                >
                  {/* ── Recent Searches Section ────────────────────────── */}
                  <AnimatePresence>
                    {hasRecent && (
                      <motion.li
                        key="recent-section"
                        variants={sectionVariants}
                        initial="initial"
                        animate="animate"
                        exit="exit"
                        transition={{ duration: 0.15 }}
                        className="contents"
                      >
                        {/* Section header */}
                        <li className="flex items-center justify-between px-3 pt-2 pb-1" aria-hidden="true">
                          <span className="text-xs font-semibold uppercase tracking-wider text-primary-dark/50">
                            Recent
                          </span>
                          <button
                            type="button"
                            onClick={handleClearRecent}
                            className="text-[10px] font-medium text-primary-dark/60 hover:text-primary transition-colors focus:outline-none focus:ring-1 focus:ring-primary/40 rounded px-1"
                          >
                            Clear recent searches
                          </button>
                        </li>
                        {recentSearches.map((recentQuery, i) => {
                          const globalIndex = i;
                          const isActive = activeIndex === globalIndex;
                          return (
                            <li key={`recent-${recentQuery}`} role="option" aria-selected={isActive}>
                              <button
                                type="button"
                                onMouseEnter={() => setActiveIndex(globalIndex)}
                                onClick={() => executeSearch(recentQuery)}
                                className={cn(
                                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors",
                                  isActive
                                    ? "bg-surface-purple/70 ring-2 ring-primary"
                                    : "hover:bg-surface-purple/50",
                                )}
                              >
                                {/* History icon */}
                                <span className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-primary-dark/8">
                                  <MaterialSymbol
                                    name="history"
                                    className="text-lg text-primary-dark/50"
                                  />
                                </span>
                                {/* Query text */}
                                <span className="flex-1 min-w-0 font-medium text-primary-dark truncate">
                                  {recentQuery}
                                </span>
                                {/* Enter hint on active row */}
                                {isActive ? (
                                  <span
                                    className="shrink-0 hidden sm:flex items-center justify-center w-6 h-6 rounded-md bg-white border border-surface-purple text-primary-dark/60"
                                    aria-hidden="true"
                                  >
                                    <MaterialSymbol name="keyboard_return" className="text-sm" />
                                  </span>
                                ) : null}
                              </button>
                            </li>
                          );
                        })}
                      </motion.li>
                    )}
                  </AnimatePresence>

                  {/* ── Divider between Recent and Popular ──────────────── */}
                  {hasRecent && popularCount > 0 && (
                    <li aria-hidden="true" className="mx-3 my-1 border-t border-primary-dark/8" />
                  )}

                  {/* ── Popular Searches Section ──────────────────────── */}
                  <AnimatePresence>
                    {popularCount > 0 && (
                      <motion.li
                        key="popular-section"
                        variants={sectionVariants}
                        initial="initial"
                        animate="animate"
                        exit="exit"
                        transition={{ duration: 0.15, delay: 0.05 }}
                        className="contents"
                      >
                        {/* Section header */}
                        <li className="px-3 pt-1 pb-1" aria-hidden="true">
                          <span className="text-xs font-semibold uppercase tracking-wider text-primary-dark/50">
                            Popular
                          </span>
                        </li>
                        {POPULAR_SEARCHES.map((popQuery, i) => {
                          const globalIndex = recentCount + i;
                          const isActive = activeIndex === globalIndex;
                          return (
                            <li key={`popular-${popQuery}`} role="option" aria-selected={isActive}>
                              <button
                                type="button"
                                onMouseEnter={() => setActiveIndex(globalIndex)}
                                onClick={() => executeSearch(popQuery)}
                                className={cn(
                                  "w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-left transition-colors",
                                  isActive
                                    ? "bg-surface-purple/70 ring-2 ring-primary"
                                    : "hover:bg-surface-purple/50",
                                )}
                              >
                                {/* Trending icon */}
                                <span className="shrink-0 w-8 h-8 rounded-full flex items-center justify-center bg-primary/15">
                                  <MaterialSymbol
                                    name="trending_up"
                                    className="text-lg text-primary"
                                  />
                                </span>
                                {/* Query text */}
                                <span className="flex-1 min-w-0 font-medium text-primary-dark truncate">
                                  {popQuery}
                                </span>
                                {/* Enter hint on active row */}
                                {isActive ? (
                                  <span
                                    className="shrink-0 hidden sm:flex items-center justify-center w-6 h-6 rounded-md bg-white border border-surface-purple text-primary-dark/60"
                                    aria-hidden="true"
                                  >
                                    <MaterialSymbol name="keyboard_return" className="text-sm" />
                                  </span>
                                ) : null}
                              </button>
                            </li>
                          );
                        })}
                      </motion.li>
                    )}
                  </AnimatePresence>
                </ul>
              )}

              {/* ── Search results (non-empty query) ──────────────────── */}
              {!isQueryEmpty && (
                <>
                  {/* Result count */}
                  {!loading && hasResults && (
                    <motion.div
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      exit={{ opacity: 0 }}
                      transition={{ duration: 0.15 }}
                      className="px-3 pt-2 pb-1"
                    >
                      <span className="text-xs text-primary-dark/50">
                        {results.length} result{results.length !== 1 ? "s" : ""} for &ldquo;{query.trim()}&rdquo;
                      </span>
                    </motion.div>
                  )}

                  {hasResults && (
                    <ul
                      ref={listRef}
                      id="search-results-list"
                      role="listbox"
                      aria-label="Search results"
                      className="flex flex-col gap-0.5"
                    >
                      {results.map((item, i) => {
                        const style = TYPE_STYLES[item.type] ?? TYPE_STYLES.page;
                        const isActive = activeIndex === i;
                        return (
                          <li key={item.id} role="option" aria-selected={isActive}>
                            <button
                              type="button"
                              onMouseEnter={() => setActiveIndex(i)}
                              onClick={() => navigateTo(item)}
                              className={cn(
                                "w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-colors",
                                isActive
                                  ? "bg-surface-purple/70 ring-2 ring-primary"
                                  : "hover:bg-surface-purple/50",
                              )}
                            >
                              {/* Icon badge */}
                              <span
                                className={cn(
                                  "shrink-0 w-9 h-9 rounded-full flex items-center justify-center",
                                  style.badge,
                                )}
                              >
                                <MaterialSymbol name={item.icon} className="text-lg" />
                              </span>

                              {/* Title + description */}
                              <span className="flex-1 min-w-0">
                                <span className="block font-medium text-primary-dark leading-snug truncate">
                                  {item.title}
                                </span>
                                {item.description ? (
                                  <span className="block text-sm text-primary-dark/60 line-clamp-1 leading-snug mt-0.5">
                                    {item.description}
                                  </span>
                                ) : null}
                              </span>

                              {/* Category pill */}
                              <span
                                className={cn(
                                  "shrink-0 inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide",
                                  style.pill,
                                )}
                              >
                                {item.category ?? style.label}
                              </span>

                              {/* Enter hint on active row */}
                              {isActive ? (
                                <span
                                  className="shrink-0 hidden sm:flex items-center justify-center w-6 h-6 rounded-md bg-white border border-surface-purple text-primary-dark/60"
                                  aria-hidden="true"
                                >
                                  <MaterialSymbol name="keyboard_return" className="text-sm" />
                                </span>
                              ) : null}
                            </button>
                          </li>
                        );
                      })}
                    </ul>
                  )}

                  {/* Empty state */}
                  {showEmptyState && (
                    <div className="py-12 px-6 text-center">
                      <div className="mx-auto w-12 h-12 rounded-full bg-surface-purple flex items-center justify-center mb-4">
                        <MaterialSymbol
                          name="search_off"
                          className="text-2xl text-primary-dark/60"
                        />
                      </div>
                      <p className="font-medium text-primary-dark">
                        No results for &ldquo;{query.trim()}&rdquo;
                      </p>
                      <p className="text-sm text-primary-dark/60 mt-1">
                        Try a different keyword, or jump to a popular page:
                      </p>
                      <div className="mt-4 flex flex-wrap items-center justify-center gap-2">
                        {[
                          { label: "Services", href: "/services" },
                          { label: "FAQ", href: "/faq" },
                          { label: "Contact", href: "/contact" },
                        ].map((link) => (
                          <button
                            key={link.href}
                            type="button"
                            onClick={() => {
                              closePalette();
                              router.push(link.href);
                            }}
                            className="px-3 py-1.5 rounded-full bg-surface-purple text-primary text-sm font-medium hover:bg-primary hover:text-white transition-colors"
                          >
                            {link.label}
                          </button>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Loading state for search query */}
                  {loading && !hasResults && !isQueryEmpty && (
                    <div className="py-8 flex items-center justify-center gap-2 text-primary-dark/60">
                      <MaterialSymbol name="progress_activity" className="text-lg animate-spin" />
                      <span className="text-sm">Searching…</span>
                    </div>
                  )}
                </>
              )}
            </div>

            {/* ── Footer: keyboard hints + branding ─────────────────────── */}
            <div className="border-t border-surface-purple px-4 py-3 flex items-center justify-between gap-3 text-xs text-primary-dark/60">
              <div className="flex items-center gap-3 sm:gap-4 flex-wrap">
                <span className="inline-flex items-center gap-1.5">
                  <kbd className="inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded bg-surface-purple border border-primary/10 text-[10px] font-semibold text-primary-dark">
                    ↑
                  </kbd>
                  <kbd className="inline-flex items-center justify-center min-w-[1.25rem] h-5 px-1 rounded bg-surface-purple border border-primary/10 text-[10px] font-semibold text-primary-dark">
                    ↓
                  </kbd>
                  <span className="hidden sm:inline">navigate</span>
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <kbd className="inline-flex items-center justify-center h-5 px-1.5 rounded bg-surface-purple border border-primary/10 text-[10px] font-semibold text-primary-dark">
                    ↵
                  </kbd>
                  <span className="hidden sm:inline">select</span>
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <kbd className="inline-flex items-center justify-center h-5 px-1.5 rounded bg-surface-purple border border-primary/10 text-[10px] font-semibold text-primary-dark">
                    esc
                  </kbd>
                  <span className="hidden sm:inline">close</span>
                </span>
              </div>
              <div className="flex items-center gap-1.5 shrink-0">
                <span className="hidden sm:inline">Powered by</span>
                <span className="inline-flex items-center gap-1 font-semibold text-primary">
                  <span className="inline-flex items-center justify-center w-4 h-4 rounded bg-primary text-white">
                    <MaterialSymbol name="pets" filled className="text-[10px]" />
                  </span>
                  Waggies
                </span>
                <span className="hidden md:inline text-primary-dark/60 ml-1">
                  ⌘K
                </span>
              </div>
            </div>
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}
