"use client";

/**
 * TestimonialsCarousel - horizontal carousel of testimonials.
 *
 * Features:
 *   - Responsive: shows 1 testimonial on mobile, 2 on sm, 3 on lg+
 *   - Auto-advances every 5 seconds (pauses on hover)
 *   - Manual controls: left/right circular arrow buttons (Waggies purple,
 *     MaterialSymbol chevron icons)
 *   - Dot indicators below (active dot is wider and purple, animated via
 *     framer-motion AnimatePresence + layoutId for a sliding pill effect)
 *   - Smooth slide transition via framer-motion + native smooth scrollTo
 *   - CSS scroll-snap fallback: container has scroll-snap-type: x mandatory
 *     and each card has scroll-snap-align: start - so even with JS disabled,
 *     the testimonials remain horizontally scrollable with snap behaviour
 *   - Wrapped in motion.div with whileInView for entrance fade-in
 *
 * Reads the 9 testimonials from src/data/testimonials.ts and renders them
 * using the existing TestimonialCard component.
 */

import { useCallback, useEffect, useRef, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { MaterialSymbol } from "./material-symbol";
import { TestimonialCard } from "./card-testimonial";
import { testimonials } from "@/data/testimonials";
import { cn } from "@/lib/utils";

const AUTO_ADVANCE_MS = 5000;
const TOTAL = testimonials.length;

function calcVisibleCount(width: number): 1 | 2 | 3 {
  if (width >= 1024) return 3;
  if (width >= 640) return 2;
  return 1;
}

export function TestimonialsCarousel() {
  const scrollRef = useRef<HTMLDivElement>(null);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isHovering, setIsHovering] = useState(false);
  const [visibleCount, setVisibleCount] = useState<1 | 2 | 3>(1);
  const shouldReduceMotion = useReducedMotion();

  // Track responsive visible count after mount (avoids SSR hydration mismatch).
  // The initial setState is deferred via rAF so it doesn't fire synchronously
  // inside the effect body (avoids the react-hooks/set-state-in-effect lint).
  useEffect(() => {
    const update = () => setVisibleCount(calcVisibleCount(window.innerWidth));
    const raf = window.requestAnimationFrame(update);
    window.addEventListener("resize", update);
    return () => {
      window.cancelAnimationFrame(raf);
      window.removeEventListener("resize", update);
    };
  }, []);

  const maxIndex = Math.max(0, TOTAL - visibleCount);
  const safeIndex = Math.min(currentIndex, maxIndex);

  const scrollToIndex = useCallback(
    (idx: number) => {
      const container = scrollRef.current;
      if (!container) return;
      const clamped = Math.max(0, Math.min(idx, maxIndex));
      const child = container.children[clamped] as HTMLElement | undefined;
      if (child) {
        container.scrollTo({
          left: child.offsetLeft - container.offsetLeft,
          behavior: "smooth",
        });
      }
      setCurrentIndex(clamped);
    },
    [maxIndex],
  );

  const goNext = useCallback(() => {
    setCurrentIndex((i) => {
      const safe = Math.min(i, maxIndex);
      const next = safe + visibleCount > maxIndex ? 0 : safe + visibleCount;
      scrollToIndex(next);
      return next;
    });
  }, [scrollToIndex, visibleCount, maxIndex]);

  const goPrev = useCallback(() => {
    setCurrentIndex((i) => {
      const safe = Math.min(i, maxIndex);
      const prev =
        safe - visibleCount < 0 ? maxIndex : safe - visibleCount;
      scrollToIndex(prev);
      return prev;
    });
  }, [scrollToIndex, visibleCount, maxIndex]);

  // Auto-advance (deferred slightly so the responsive visibleCount has settled)
  useEffect(() => {
    if (isHovering) return;
    const id = window.setInterval(goNext, AUTO_ADVANCE_MS);
    return () => window.clearInterval(id);
  }, [isHovering, goNext]);

  // Sync currentIndex when user scrolls natively
  const handleScroll = useCallback(() => {
    const container = scrollRef.current;
    if (!container) return;
    const card = container.children[0] as HTMLElement | undefined;
    if (!card) return;
    const cardWidth = card.offsetWidth;
    const gap = 24; // gap-6
    const idx = Math.round(container.scrollLeft / (cardWidth + gap));
    if (idx !== currentIndex && idx >= 0 && idx <= maxIndex) {
      setCurrentIndex(idx);
    }
  }, [currentIndex, maxIndex]);

  // Compute page count for dots
  const pageCount = Math.ceil(TOTAL / visibleCount);
  const activePage = Math.floor(safeIndex / visibleCount);

  // Card width as a fraction of the container, accounting for the gap-6 (24px)
  const cardWidthClass =
    visibleCount === 1
      ? "w-full"
      : visibleCount === 2
        ? "w-[calc(50%-12px)]"
        : "w-[calc(33.333%-16px)]";

  return (
    <motion.div
      initial={shouldReduceMotion ? false : { opacity: 0, y: 24 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-100px" }}
      transition={{ duration: shouldReduceMotion ? 0 : 0.6, ease: [0.25, 0.1, 0.25, 1] }}
      className="relative"
      onMouseEnter={() => setIsHovering(true)}
      onMouseLeave={() => setIsHovering(false)}
    >
      {/* Scroll-snap track (works without JS as a fallback) */}
      <div
        ref={scrollRef}
        onScroll={handleScroll}
        className="hide-scrollbar flex snap-x snap-mandatory gap-6 overflow-x-auto pb-4"
        style={{
          scrollSnapType: "x mandatory",
          WebkitOverflowScrolling: "touch",
        }}
        aria-roledescription="carousel"
        aria-label="Customer testimonials carousel"
      >
        {testimonials.map((t, i) => (
          <div
            key={i}
            className={cn(
              "shrink-0 snap-start",
              cardWidthClass,
              // Make each card fill the row height (so shorter cards align)
              "self-stretch",
            )}
            style={{ scrollSnapAlign: "start" }}
          >
            <div className="h-full">
              <TestimonialCard {...t} fadeDelay={Math.min(i * 0.05, 0.3)} />
            </div>
          </div>
        ))}
      </div>

      {/* Left arrow */}
      <button
        type="button"
        onClick={goPrev}
        aria-label="Previous testimonials"
        className="absolute left-0 top-1/2 z-10 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-primary text-white shadow-soft transition hover:scale-110 hover:bg-primary-dark focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:ring-offset-2 sm:h-12 sm:w-12"
      >
        <MaterialSymbol name="chevron_left" filled className="text-2xl" />
      </button>

      {/* Right arrow */}
      <button
        type="button"
        onClick={goNext}
        aria-label="Next testimonials"
        className="absolute right-0 top-1/2 z-10 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-primary text-white shadow-soft transition hover:scale-110 hover:bg-primary-dark focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:ring-offset-2 sm:h-12 sm:w-12"
      >
        <MaterialSymbol name="chevron_right" filled className="text-2xl" />
      </button>

      {/* Dot indicators (AnimatePresence + layoutId for sliding active pill) */}
      <div
        className="mt-6 flex items-center justify-center gap-2"
        role="tablist"
        aria-label="Testimonial pages"
      >
        <AnimatePresence mode="popLayout">
          {Array.from({ length: pageCount }).map((_, i) => {
            const active = i === activePage;
            return (
              <button
                key={i}
                type="button"
                role="tab"
                aria-selected={active}
                aria-label={`Go to testimonials page ${i + 1}`}
                onClick={() => scrollToIndex(i * visibleCount)}
                className={cn(
                  "relative h-2.5 rounded-full transition-all duration-300",
                  active
                    ? "w-8 bg-primary/15"
                    : "w-2.5 bg-primary/25 hover:bg-primary/50",
                )}
              >
                {active && (
                  <motion.span
                    layoutId="testimonials-active-dot"
                    className="absolute inset-0 rounded-full bg-primary"
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    transition={{
                      type: "spring",
                      stiffness: 400,
                      damping: 35,
                    }}
                  />
                )}
              </button>
            );
          })}
        </AnimatePresence>
      </div>

      {/* Live region for screen readers */}
      <span className="sr-only" aria-live="polite">
        Showing testimonial {safeIndex + 1} of {TOTAL}
      </span>
    </motion.div>
  );
}
