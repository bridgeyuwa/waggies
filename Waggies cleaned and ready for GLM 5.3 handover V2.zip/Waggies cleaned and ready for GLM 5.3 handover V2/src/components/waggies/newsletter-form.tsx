/**
 * Newsletter subscription widget - React port of
 * resources/views/components/newsletter.blade.php.
 *
 * Task 6-c: Rewritten to support three layout variants (card | inline |
 * compact) and two themes (light | dark) for use in the Footer hero strip.
 *
 * Backward-compatibility: when NO `variant` prop is passed, the legacy
 * simple-form layout is rendered. This preserves the existing usages on
 * the blog index, blog post, and blog category pages, which pass the
 * legacy props `title`, `subtitle`, `buttonLabel`.
 *
 * Features:
 *   - Pre-submit regex email validation (no API call) per Task 6-c spec
 *   - POST /api/newsletter with status-code-aware response handling
 *     · 200 → success state
 *     · 422 → inline error from server `errors.email` (or fallback)
 *     · 429 → "Too many attempts. Please try again in a minute."
 *     · other / network → "Something went wrong. Please try again."
 *   - Loading spinner + "Subscribing..." inside the submit button
 *   - AnimatePresence form → success transition (fade + scale 0.95→1)
 *   - whileHover/whileTap micro-interactions on the submit button
 *   - Sonner toast notifications for global feedback (in addition to inline)
 *   - Dark theme variant for use on bg-primary-dark (Footer bottom)
 *   - Accessibility: sr-only label, aria-label, aria-live polite
 *
 * API contract (POST /api/newsletter - see src/app/api/newsletter/route.ts):
 *   - 200 → { success: true }
 *   - 422 → { errors: { email: "..." } }
 *   - 429 → { message: "Too many requests..." }
 */

"use client";

import { type FormEvent, useEffect, useId, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";

import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { cn } from "@/lib/utils";

export type NewsletterFormProps = {
  /** Layout variant. When omitted, renders the legacy simple-form layout. */
  variant?: "card" | "inline" | "compact";
  className?: string;
  /** Visual theme - 'light' on bg-surface-purple, 'dark' on bg-primary-dark. */
  theme?: "light" | "dark";
  /* ── Legacy props (blog index / post / category pages still pass these) ── */
  title?: string;
  subtitle?: string;
  placeholder?: string;
  buttonLabel?: string;
};

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

type Status = "idle" | "loading" | "success" | "error";

export function NewsletterForm({
  variant,
  className,
  theme = "light",
  // Legacy (blog pages):
  title,
  subtitle,
  placeholder = "you@example.com",
  buttonLabel = "Subscribe",
}: NewsletterFormProps) {
  const [email, setEmail] = useState("");
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState("");
  const inputId = useId();

  const isDark = theme === "dark";
  const isLegacy = variant === undefined;

  // Auto-revert after success (legacy behavior, used by blog pages  - 
  // 3s after success, the form re-appears so the user can subscribe again).
  useEffect(() => {
    if (!isLegacy || status !== "success") return;
    const t = setTimeout(() => {
      setStatus("idle");
      setEmail("");
    }, 3000);
    return () => clearTimeout(t);
  }, [isLegacy, status]);

  // ── Submit handler ─────────────────────────────────────────────────
  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    if (status === "loading") return;

    // Pre-submit regex validation (no API call) per Task 6-c spec.
    if (!EMAIL_REGEX.test(email.trim())) {
      setStatus("error");
      setMessage("Please enter a valid email address.");
      return;
    }

    setStatus("loading");
    setMessage("");

    let msg: string;
    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim() }),
      });

      if (res.ok) {
        setStatus("success");
        setMessage("You're subscribed! 🎉 Check your inbox to confirm.");
        toast.success("Subscribed! 🎉");
        return;
      }

      if (res.status === 422) {
        const data = (await res.json().catch(() => ({}))) as {
          errors?: { email?: string };
        };
        msg = data?.errors?.email ?? "Please check the email address.";
      } else if (res.status === 429) {
        msg = "Too many attempts. Please try again in a minute.";
      } else {
        msg = "Something went wrong. Please try again.";
      }
    } catch {
      msg = "Something went wrong. Please try again.";
    }

    setStatus("error");
    setMessage(msg);
    toast.error(msg);
  }

  function handleReset() {
    setEmail("");
    setStatus("idle");
    setMessage("");
  }

  // ══════════════════════════════════════════════════════════════════════
  // LEGACY RENDER - preserves the visual behaviour that blog pages rely on
  // (vertical form, rounded-full purple button, animated
  // SVG checkmark on success, 3s auto-revert).
  // ══════════════════════════════════════════════════════════════════════
  if (isLegacy) {
    return (
      <div className={cn("flex flex-col gap-3", className)}>
        {title ? (
          <p className="font-serif text-lg font-bold text-primary-dark">{title}</p>
        ) : null}
        {subtitle ? (
          <p className="text-sm text-primary-dark/50">{subtitle}</p>
        ) : null}

        <div className="relative min-h-[6.5rem]">
          <AnimatePresence mode="wait" initial={false}>
            {status === "success" ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
                className="flex flex-col items-center justify-center text-center py-4 px-4 bg-success-light/40 border border-success/30 rounded-2xl"
                role="status"
                aria-live="polite"
              >
                <AnimatedCheck />
                <p className="font-serif text-lg font-bold text-primary-dark mt-2">
                  You&apos;re subscribed!
                </p>
                <p className="text-sm text-primary-dark/60">
                  Welcome to the pack - check your inbox for a confirmation.
                </p>
              </motion.div>
            ) : (
              <motion.form
                key="form"
                onSubmit={handleSubmit}
                noValidate
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.25, ease: [0.25, 0.1, 0.25, 1] }}
                aria-live="polite"
              >
                <div className="flex flex-col gap-3">
                  <div className="relative">
                    <MaterialSymbol
                      name="mail"
                      className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-lg text-primary-dark/60"
                    />
                    <Input
                      type="email"
                      required
                      placeholder={placeholder}
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      disabled={status === "loading"}
                      autoComplete="email"
                      aria-label="Email address"
                      aria-invalid={status === "error" || undefined}
                      className="h-12 pl-11 rounded-2xl bg-white/50 border-primary/30 text-primary-dark placeholder:text-primary-dark/50"
                    />
                  </div>

                  {status === "error" && message ? (
                    <p
                      className="text-error text-xs font-medium flex items-center gap-1.5"
                      role="alert"
                    >
                      <MaterialSymbol name="error_outline" className="text-sm" />
                      {message}
                    </p>
                  ) : null}

                  <Button
                    type="submit"
                    disabled={status === "loading"}
                    aria-label="Subscribe to newsletter"
                    className="bg-primary hover:bg-primary-dark text-white py-3 rounded-full font-semibold shadow-sm"
                  >
                    <AnimatePresence mode="wait" initial={false}>
                      {status === "loading" ? (
                        <motion.span
                          key="loading"
                          initial={{ opacity: 0, scale: 0.85 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.85 }}
                          transition={{ duration: 0.15 }}
                          className="inline-flex items-center gap-2"
                        >
                          <Spinner tone="light" />
                          Subscribing…
                        </motion.span>
                      ) : (
                        <motion.span
                          key="idle"
                          initial={{ opacity: 0, scale: 0.85 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0, scale: 0.85 }}
                          transition={{ duration: 0.15 }}
                          className="inline-flex items-center gap-2"
                        >
                          {buttonLabel}
                          <MaterialSymbol name="arrow_forward" className="text-base" />
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </Button>

                  <p className="text-[11px] text-primary-dark/60 text-center flex items-center justify-center gap-1 mt-1">
                    <MaterialSymbol name="lock" className="text-xs" />
                    We respect your privacy. Unsubscribe anytime.
                  </p>
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    );
  }

  // ══════════════════════════════════════════════════════════════════════
  // NEW VARIANT RENDERERS (card | inline | compact)
  // ══════════════════════════════════════════════════════════════════════

  // ── Theme tokens ───────────────────────────────────────────────────
  const inputCls = isDark
    ? "bg-white/10 border-white/10 text-white placeholder:text-white/60 focus-visible:border-white/40 focus-visible:ring-white/25"
    : "bg-white border-primary/10 text-primary-dark placeholder:text-primary-dark/60";
  const iconCls = isDark ? "text-white/60" : "text-primary-dark/60";
  const buttonCls = isDark
    ? "bg-white text-primary-dark hover:bg-white/90 shadow-sm"
    : "bg-primary text-white hover:bg-primary-dark shadow-sm";
  const spinnerTone: "light" | "dark" = isDark ? "dark" : "light";

  const headingCls = isDark ? "text-white" : "text-primary-dark";
  const subTextCls = isDark ? "text-white/70" : "text-primary-dark/70";
  const proofCls = isDark ? "text-white/60" : "text-primary-dark/60";
  const successTextCls = isDark ? "text-white" : "text-primary-dark";
  const resetLinkCls = isDark
    ? "text-secondary hover:text-white underline underline-offset-2"
    : "text-primary hover:text-primary-dark underline underline-offset-2";

  // ── Shared form block (input + button row, error msg, success card) ─
  const formBlock = (
    <AnimatePresence mode="wait" initial={false}>
      {status === "success" ? (
        <motion.div
          key="success"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.95 }}
          transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
          role="status"
          aria-live="polite"
        >
          <div className="flex items-start gap-3">
            <MaterialSymbol
              name="check_circle"
              filled
              className="text-3xl shrink-0 text-success"
            />
            <div className="flex-1">
              <p className={cn("font-semibold text-sm sm:text-base", successTextCls)}>
                You&apos;re subscribed! 🎉 Check your inbox to confirm.
              </p>
              <button
                type="button"
                onClick={handleReset}
                className={cn("text-xs sm:text-sm mt-1.5 transition-colors", resetLinkCls)}
              >
                Subscribe another email
              </button>
            </div>
          </div>
        </motion.div>
      ) : (
        <motion.form
          key="form"
          onSubmit={handleSubmit}
          noValidate
          initial={{ opacity: 0, scale: 0.98 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.98 }}
          transition={{ duration: 0.25, ease: [0.25, 0.1, 0.25, 1] }}
          aria-live="polite"
        >
          <div className="flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <label htmlFor={inputId} className="sr-only">
                Email address
              </label>
              <MaterialSymbol
                name="mail"
                className={cn(
                  "pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-lg",
                  iconCls
                )}
              />
              <Input
                id={inputId}
                type="email"
                required
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={status === "loading"}
                autoComplete="email"
                aria-label="Email address"
                aria-invalid={status === "error" || undefined}
                className={cn("h-11 pl-10 rounded-lg", inputCls)}
              />
            </div>
            <motion.div
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="shrink-0"
            >
              <Button
                type="submit"
                variant="default"
                disabled={status === "loading"}
                aria-label="Subscribe to newsletter"
                className={cn("h-11 px-5 rounded-lg font-semibold w-full sm:w-auto", buttonCls)}
              >
                <AnimatePresence mode="wait" initial={false}>
                  {status === "loading" ? (
                    <motion.span
                      key="loading"
                      initial={{ opacity: 0, scale: 0.85 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.85 }}
                      transition={{ duration: 0.15 }}
                      className="inline-flex items-center gap-2"
                    >
                      <Spinner tone={spinnerTone} />
                      Subscribing...
                    </motion.span>
                  ) : (
                    <motion.span
                      key="idle"
                      initial={{ opacity: 0, scale: 0.85 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.85 }}
                      transition={{ duration: 0.15 }}
                      className="inline-flex items-center gap-2"
                    >
                      <MaterialSymbol name="send" className="text-base" />
                      Subscribe
                    </motion.span>
                  )}
                </AnimatePresence>
              </Button>
            </motion.div>
          </div>

          {status === "error" && message ? (
            <p
              className="mt-2 text-xs sm:text-sm font-medium flex items-center gap-1.5 text-error"
              role="alert"
            >
              <MaterialSymbol name="error_outline" className="text-sm" />
              {message}
            </p>
          ) : null}
        </motion.form>
      )}
    </AnimatePresence>
  );

  // ── Card variant ────────────────────────────────────────────────────
  // Self-contained card with heading + sub-text + form + social proof.
  if (variant === "card") {
    return (
      <div
        className={cn(
          "rounded-2xl p-6 border shadow-sm",
          isDark ? "bg-white/5 border-white/10" : "bg-white border-primary/10",
          className
        )}
      >
        <div className="mb-4">
          <h3 className={cn("font-serif text-xl sm:text-2xl font-bold mb-1.5", headingCls)}>
            Stay in the Loop
          </h3>
          <p className={cn("text-sm", subTextCls)}>
            Get pet care tips, exclusive offers, and Waggies news in your inbox. No spam, unsubscribe anytime.
          </p>
        </div>
        {formBlock}
        <p className={cn("text-xs mt-3 flex items-center gap-1.5", proofCls)}>
          <MaterialSymbol name="groups" className="text-sm" />
          Join 2,500+ pet parents in Abuja ✨
        </p>
      </div>
    );
  }

  // ── Inline variant ──────────────────────────────────────────────────
  // Just the form (horizontal input + button row). The heading and social
  // proof are provided by the parent (e.g. the Footer hero strip).
  if (variant === "inline") {
    return (
      <div className={cn("w-full", className)}>
        {formBlock}
      </div>
    );
  }

  // ── Compact variant ─────────────────────────────────────────────────
  // Form + small privacy note below - for tight spaces.
  return (
    <div className={cn("w-full", className)}>
      {formBlock}
      <p className={cn("text-xs mt-2 flex items-center gap-1.5", proofCls)}>
        <MaterialSymbol name="lock" className="text-xs" />
        No spam. Unsubscribe anytime.
      </p>
    </div>
  );
}

// ── Spinner - framer-motion-driven CSS-only spinner ───────────────────────
// tone="light" → for use on a dark/colored button (white spinner).
// tone="dark"  → for use on a white button (dark spinner).
function Spinner({ tone = "light" }: { tone?: "light" | "dark" }) {
  const borderCls =
    tone === "dark"
      ? "border-primary-dark/40 border-t-primary-dark"
      : "border-white/40 border-t-white";
  return (
    <motion.span
      className={cn("inline-block w-4 h-4 rounded-full border-2", borderCls)}
      animate={{ rotate: 360 }}
      transition={{ duration: 0.7, repeat: Infinity, ease: "linear" }}
      aria-hidden
    />
  );
}

// ── Animated checkmark (SVG path drawing) - used by legacy success state ──
function AnimatedCheck() {
  return (
    <svg
      width="44"
      height="44"
      viewBox="0 0 44 44"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden
    >
      <motion.circle
        cx="22"
        cy="22"
        r="20"
        stroke="#16a34a"
        strokeWidth="2"
        fill="#dcfce7"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
      />
      <motion.path
        d="M14 22 L20 28 L30 16"
        stroke="#16a34a"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.35, delay: 0.25, ease: "easeOut" }}
      />
    </svg>
  );
}
