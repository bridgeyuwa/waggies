"use client";

import { motion } from "framer-motion";

/**
 * FloatingWatermark - animated "404" background watermark for the 404 page.
 *
 * Client component because it uses framer-motion's `motion.div`.
 * Subtle float animation gives the watermark a gentle, premium feel.
 */
export function FloatingWatermark() {
  return (
    <motion.div
      className="absolute inset-0 flex items-center justify-center pointer-events-none select-none overflow-hidden"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeOut" }}
    >
      <motion.span
        className="text-[12rem] sm:text-[16rem] font-serif font-bold text-primary/10"
        animate={{ y: [0, -12, 0] }}
        transition={{
          duration: 6,
          repeat: Infinity,
          ease: "easeInOut",
        }}
      >
        404
      </motion.span>
    </motion.div>
  );
}
