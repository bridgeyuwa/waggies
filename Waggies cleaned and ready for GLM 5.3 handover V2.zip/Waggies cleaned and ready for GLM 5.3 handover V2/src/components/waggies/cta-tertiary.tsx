/**
 * CtaTertiary - React port of resources/views/components/cta/tertiary.blade.php
 *
 * Compact strip: icon circle + heading/body on the left, single CTA on the
 * right. Dark background. Used by the Testimonials page bottom CTA.
 *
 *
 * NOTE: The Laravel testimonials page passes `primaryCta`/`secondaryCta` props
 * to <x-cta.tertiary>, but the component only declares `icon`, `heading`,
 * `body`, `cta_label`, `cta_href`. The unknown props are silently swallowed
 * by Laravel's attribute bag. We reproduce that exact behaviour - this
 * component does NOT accept `primaryCta`/`secondaryCta`.
 */

import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type CtaTertiaryProps = {
  icon?: string;
  heading?: string;
  body?: string;
  ctaLabel?: string;
  ctaHref?: string;
};

export function CtaTertiary({
  icon = "volunteer_activism",
  heading = "Not sure what your pet needs?",
  body = "Our vets will guide you - no commitment required.",
  ctaLabel = "Free Consultation",
  ctaHref = "#",
}: CtaTertiaryProps) {
  return (
    <div className="w-full bg-primary-dark overflow-hidden relative rounded-2xl">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-8 md:py-10 relative">
        {/* Decorative blob */}
        <div
          className="absolute top-[-30%] right-[-3%] w-40 h-40 bg-secondary/10 rounded-full blur-3xl pointer-events-none"
          aria-hidden="true"
        />

        <div className="relative z-10 max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-6">
          {/* Icon + copy */}
          <div className="flex items-center gap-4">
            <div
              className="w-12 h-12 rounded-full bg-secondary/20 flex items-center justify-center shrink-0"
              aria-hidden="true"
            >
              <MaterialSymbol name={icon} filled className="text-secondary text-2xl" />
            </div>
            <div>
              <p className="font-serif font-bold text-white text-lg leading-tight">
                {heading}
              </p>
              <p className="text-white/60 text-sm mt-0.5">{body}</p>
            </div>
          </div>

          {/* CTA */}
          <a
            href={ctaHref}
            className="shrink-0 inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark
                       px-7 py-3 rounded-full font-bold transition shadow-sm whitespace-nowrap
                       focus:outline-none focus:ring-2 focus:ring-secondary/60 focus:ring-offset-2"
          >
            {ctaLabel}
            <MaterialSymbol name="arrow_forward" className="text-base" />
          </a>
        </div>
      </div>
    </div>
  );
}
