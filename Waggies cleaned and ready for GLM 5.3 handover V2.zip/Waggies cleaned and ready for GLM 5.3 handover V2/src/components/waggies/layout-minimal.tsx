/**
 * LayoutMinimal - React port of resources/views/components/layouts/minimal.blade.php
 *
 * Used by legal pages (privacy, terms, cookies). Renders a max-w-3xl
 * content container with breadcrumb + H1 + "Last updated" + prose body.
 *
 */

import { type ReactNode } from "react";
import { Breadcrumb, type Crumb } from "@/components/waggies/breadcrumb";

export type LayoutMinimalProps = {
  title: string;
  description?: string | null;
  lastUpdated?: string | null;
  crumbs: Crumb[];
  children: ReactNode;
};

export function LayoutMinimal({
  title,
  lastUpdated,
  crumbs,
  children,
}: LayoutMinimalProps) {
  return (
    <div className="max-w-3xl mx-auto px-4 md:px-8 py-16 md:py-24">
      <header className="mb-12">
        <div className="mb-6">
          <Breadcrumb crumbs={crumbs} />
        </div>
        <h1 className="font-serif text-4xl font-bold text-primary-dark mb-3">
          {title}
        </h1>
        {lastUpdated ? (
          <p className="text-sm text-primary-dark/50">Last updated: {lastUpdated}</p>
        ) : null}
      </header>

      <div className="prose max-w-none">{children}</div>
    </div>
  );
}
