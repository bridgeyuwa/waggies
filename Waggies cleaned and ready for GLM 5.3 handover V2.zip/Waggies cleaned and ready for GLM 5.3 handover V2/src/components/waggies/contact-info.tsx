/**
 * Contact info block - canonical business information.
 *
 * All values sourced from src/lib/business-info.ts (authoritative).
 */

import { type ReactNode } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { businessInfo } from "@/lib/business-info";

export type ContactInfoProps = {
  address?: string;
  phone?: string;
  email?: string;
  hours?: string;
  children?: ReactNode;
};

export function ContactInfo({
  address = businessInfo.addressFormatted,
  phone = businessInfo.phoneInternational,
  email = businessInfo.email,
  hours = businessInfo.hoursString,
  children,
}: ContactInfoProps) {
  const phoneHref = `tel:${phone.replace(/[^+0-9]/g, "")}`;
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start gap-3">
        <MaterialSymbol
          name="location_on"
          className="text-primary text-xl shrink-0"
          aria-hidden
        />
        <span className="text-sm text-primary-dark/70">{address}</span>
      </div>
      <div className="flex items-start gap-3">
        <MaterialSymbol name="call" className="text-primary text-xl shrink-0" aria-hidden />
        <a
          href={phoneHref}
          className="text-sm text-primary-dark/70 hover:text-primary transition-colors"
        >
          {phone}
        </a>
      </div>
      <div className="flex items-start gap-3">
        <MaterialSymbol name="mail" className="text-primary text-xl shrink-0" aria-hidden />
        <a
          href={`mailto:${email}`}
          className="text-sm text-primary-dark/70 hover:text-primary transition-colors"
        >
          {email}
        </a>
      </div>
      <div className="flex items-start gap-3">
        <MaterialSymbol name="schedule" className="text-primary text-xl shrink-0" aria-hidden />
        <span className="text-sm text-primary-dark/70">{hours}</span>
      </div>
      {children}
    </div>
  );
}
