/**
 * Contact form - client component for the /contact page.
 *
 * Reproduces the form behaviour of the Laravel contact page:
 *   - Three visible fields (name, email, message) + hidden pricing-context fields
 *   - On submit, POSTs JSON to /api/contact
 *   - On success, displays the green "Your message has been sent…" alert
 *   - On validation error (422), displays per-field red error text
 *   - On throttle error (429), displays a top-level error
 *   - Submit button shows disabled state while pending
 *
 * Source: resources/views/pages/contact.blade.php + app/Http/Controllers/ContactController.php
 *         + app/Http/Requests/StoreContactRequest.php
 */

"use client";

import { useState, type FormEvent } from "react";
import { FormInput } from "@/components/waggies/form-input";
import { FormTextarea } from "@/components/waggies/form-textarea";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type ContactFormProps = {
  /** Hidden pricing context (preserved on submit). All optional. */
  service?: string;
  variant?: string;
  tier?: string;
  intent?: string;
  estimateSummary?: string;
  /** Default textarea content (from PricingQuote::buildPrefillMessage). */
  defaultMessage?: string;
};

type FieldErrors = Partial<Record<"name" | "email" | "message", string>>;

export function ContactForm({
  service,
  variant,
  tier,
  intent,
  estimateSummary,
  defaultMessage = "",
}: ContactFormProps) {
  const [errors, setErrors] = useState<FieldErrors>({});
  const [topError, setTopError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setErrors({});
    setTopError(null);
    setSuccess(null);
    setSubmitting(true);

    const formData = new FormData(e.currentTarget);
    const payload: Record<string, string> = {};
    for (const [key, value] of formData.entries()) {
      payload[key] = String(value);
    }

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (res.ok) {
        const data = (await res.json().catch(() => ({}))) as { message?: string };
        setSuccess(
          data.message ?? "Your message has been sent. We'll be in touch soon!",
        );
        // Reset only the visible fields - hidden pricing context should NOT be cleared
        const form = e.currentTarget;
        form.querySelector<HTMLInputElement>('input[name="name"]')!.value = "";
        form.querySelector<HTMLInputElement>('input[name="email"]')!.value = "";
        form.querySelector<HTMLTextAreaElement>('textarea[name="message"]')!.value = "";
        return;
      }

      if (res.status === 422) {
        const data = (await res.json().catch(() => ({}))) as {
          errors?: Record<string, string | string[]>;
          message?: string;
        };
        if (data.errors) {
          const next: FieldErrors = {};
          for (const [field, msg] of Object.entries(data.errors)) {
            if (field === "name" || field === "email" || field === "message") {
              next[field] = Array.isArray(msg) ? msg[0] : msg;
            }
          }
          setErrors(next);
          return;
        }
        setTopError(data.message ?? "Please fix the errors below.");
        return;
      }

      if (res.status === 429) {
        setTopError("Too many submissions. Please wait a minute and try again.");
        return;
      }

      setTopError("Something went wrong. Please try again.");
    } catch {
      setTopError("Network error. Please check your connection and try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div>
      <h2 className="font-serif text-2xl font-bold text-primary-dark mb-6">
        Send Us a Message
      </h2>

      {success ? (
        <div
          className="mb-6 p-4 bg-success/10 border border-success/30 text-success rounded-xl text-sm font-medium"
          role="status"
        >
          {success}
        </div>
      ) : null}

      {topError ? (
        <div
          className="mb-6 p-4 bg-error/10 border border-error/30 text-error rounded-xl text-sm font-medium"
          role="alert"
        >
          {topError}
        </div>
      ) : null}

      <form onSubmit={handleSubmit} className="flex flex-col gap-5" noValidate>
        {service ? <input type="hidden" name="service" value={service} /> : null}
        {variant ? <input type="hidden" name="variant" value={variant} /> : null}
        {tier ? <input type="hidden" name="tier" value={tier} /> : null}
        {intent ? <input type="hidden" name="intent" value={intent} /> : null}
        {estimateSummary ? (
          <input type="hidden" name="estimate_summary" value={estimateSummary} />
        ) : null}

        <FormInput
          label="Your Name"
          name="name"
          placeholder="Adaeze Okafor"
          required
          error={errors.name}
          autoComplete="name"
        />

        <FormInput
          label="Email Address"
          name="email"
          type="email"
          placeholder="you@example.com"
          required
          error={errors.email}
          autoComplete="email"
        />

        <FormTextarea
          label="Message"
          name="message"
          placeholder="Tell us about your pet and how we can help…"
          rows={5}
          required
          error={errors.message}
          defaultValue={defaultMessage}
        />

        <button
          type="submit"
          disabled={submitting}
          className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-white
                     px-8 py-4 rounded-full font-bold transition shadow-sm
                     focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2
                     disabled:opacity-60 disabled:hover:translate-y-0 disabled:cursor-not-allowed"
        >
          {submitting ? "Sending…" : "Send Message"}
          <MaterialSymbol name="send" />
        </button>
      </form>
    </div>
  );
}
