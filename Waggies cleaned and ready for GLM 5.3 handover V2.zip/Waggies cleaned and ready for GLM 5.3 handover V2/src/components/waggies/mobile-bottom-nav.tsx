"use client";

import { useState, useEffect } from "react";
import { usePathname } from "next/navigation";
import Link from "next/link";
import { motion, AnimatePresence, useScroll, useMotionValueEvent, useReducedMotion } from "framer-motion";
import { House, PawPrint, Question, Envelope } from "@phosphor-icons/react/dist/ssr";

/**
 * MobileBottomNav - a native-app-like bottom navigation bar for mobile.
 *
 * - Only visible on mobile (md:hidden)
 * - Fixed at bottom, z-40
 * - 4 icon buttons: Home, Services, FAQ, Contact
 * - Active state based on pathname
 * - Waggies purple active indicator with smooth transition
 * - Safe area padding for iOS
 * - Hides when scrolling down, shows when scrolling up
 */

const NAV_ITEMS = [
  { href: "/", label: "Home", Icon: House },
  { href: "/services", label: "Services", Icon: PawPrint },
  { href: "/faq", label: "FAQ", Icon: Question },
  { href: "/contact", label: "Contact", Icon: Envelope },
] as const;

export function MobileBottomNav() {
  const pathname = usePathname();
  const [hidden, setHidden] = useState(false);
  const { scrollY } = useScroll();
  const shouldReduceMotion = useReducedMotion();

  // Track scroll direction to show/hide the bottom nav
  useMotionValueEvent(scrollY, "change", (current) => {
    const previous = scrollY.getPrevious() ?? 0;
    const diff = current - previous;

    // Only hide/show if we've scrolled enough to avoid jitter
    if (diff > 5) {
      setHidden(true);
    } else if (diff < -5) {
      setHidden(false);
    }

    // Always show at top of page
    if (current < 100) {
      setHidden(false);
    }
  });

  // Determine which nav item is active
  function isActive(href: string): boolean {
    if (href === "/") return pathname === "/";
    return pathname.startsWith(href);
  }

  return (
    <AnimatePresence>
      {!hidden && (
        <motion.nav
          initial={{ y: 0 }}
          animate={{ y: 0 }}
          exit={shouldReduceMotion ? undefined : { y: "100%" }}
          transition={{ type: "spring", damping: 25, stiffness: 300, duration: shouldReduceMotion ? 0 : undefined }}
          className="fixed bottom-0 left-0 right-0 z-40 md:hidden border-t border-surface-purple bg-surface/95 backdrop-blur-md"
          style={{
            paddingBottom: "env(safe-area-inset-bottom, 0px)",
          }}
          aria-label="Mobile navigation"
        >
          <div className="flex items-center justify-around h-16">
            {NAV_ITEMS.map((item) => {
              const active = isActive(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className="relative flex flex-col items-center justify-center gap-0.5 min-w-[56px] min-h-[44px] select-none"
                  aria-current={active ? "page" : undefined}
                >
                  <motion.div
                    whileTap={shouldReduceMotion ? undefined : { scale: 0.85 }}
                    transition={{ type: "spring", damping: 20, stiffness: 400 }}
                    className="flex flex-col items-center justify-center gap-0.5"
                  >
                    <item.Icon
                      size={22}
                      weight={active ? "fill" : "regular"}
                      className={`transition-colors duration-200 ${
                        active ? "text-waggies-primary" : "text-primary-dark/50"
                      }`}
                    />
                    <span
                      className={`text-[10px] font-medium leading-none transition-colors duration-200 ${
                        active ? "text-waggies-primary" : "text-primary-dark/50"
                      }`}
                    >
                      {item.label}
                    </span>
                  </motion.div>

                  {/* Active indicator dot */}
                  {active && (
                    <motion.div
                      layoutId="mobile-nav-indicator"
                      className="absolute -top-px left-1/2 -translate-x-1/2 h-[3px] w-8 rounded-full bg-waggies-primary"
                      transition={{ type: "spring", damping: 25, stiffness: 350, duration: shouldReduceMotion ? 0 : undefined }}
                    />
                  )}
                </Link>
              );
            })}
          </div>
        </motion.nav>
      )}
    </AnimatePresence>
  );
}
