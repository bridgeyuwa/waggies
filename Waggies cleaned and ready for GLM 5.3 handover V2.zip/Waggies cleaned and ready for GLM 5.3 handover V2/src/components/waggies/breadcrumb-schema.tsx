/**
 * BreadcrumbSchema - reusable JSON-LD BreadcrumbList component.
 *
 * Accepts an array of {name, path} items, auto-prepends "Home" (/),
 * and renders the BreadcrumbList JSON-LD <script> tag for SEO.
 *
 * Usage:
 *   <BreadcrumbSchema items={[{ name: "Services", path: "/services" }]} />
 *   // Renders: Home > Services
 *
 *   <BreadcrumbSchema items={[
 *     { name: "Blog", path: "/blog" },
 *     { name: "Post Title", path: "/blog/slug" },
 *   ]} />
 *   // Renders: Home > Blog > Post Title
 */

import { JsonLd, breadcrumbListSchema } from "./json-ld";

export type BreadcrumbItem = { name: string; path: string };

export type BreadcrumbSchemaProps = {
  /** Breadcrumb items AFTER Home. Home is always auto-prepended. */
  items: BreadcrumbItem[];
};

export function BreadcrumbSchema({ items }: BreadcrumbSchemaProps) {
  const allItems: BreadcrumbItem[] = [
    { name: "Home", path: "/" },
    ...items,
  ];

  return <JsonLd data={breadcrumbListSchema(allItems)} />;
}
