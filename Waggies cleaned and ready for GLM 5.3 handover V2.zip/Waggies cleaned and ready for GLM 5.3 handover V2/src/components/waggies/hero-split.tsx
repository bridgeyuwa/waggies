/**
 * HeroSplit — Asymmetric split hero component.
 *
 * Supports two layouts:
 * - "editorial": Image-dominant (58% on desktop), magazine-like feel. Used on homepage.
 * - "default":   Equal split with optional rating badge. Used on inner pages.
 *
 * Server component — data flows in via props.
 */

import { type ReactNode } from "react";
import Link from "next/link";
import { ArrowRight, ShieldCheck } from "@phosphor-icons/react/dist/ssr";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { BadgeStat } from "@/components/waggies/badge-stat";
import { WaggiesImage } from "@/components/waggies/waggies-image";

export type HeroSplitProps = {
  /** "editorial" (image-dominant) or "default" (equal split with badge). */
  layout?: "editorial" | "default";
   /* ── Common ── */
  title: string;
  subtitle?: string | null;
  imageSrc?: string | null;
  imageAlt?: string | null;
  primaryLabel?: string | null;
  primaryHref?: string;
  secondaryLabel?: string | null;
  secondaryHref?: string;
  children?: ReactNode;
  /* ── Default-layout only ── */
  eyebrow?: string | null;
  eyebrowIcon?: string | null;
  rating?: string;
  reviewCount?: string;
  primaryIcon?: string;
  secondaryIcon?: string | null;
};

export function HeroSplit({
  layout = "default",
  title,
  subtitle,
  imageSrc,
  imageAlt,
  primaryLabel,
  primaryHref = "#",
  secondaryLabel,
  secondaryHref = "#",
  children,
  /* default-layout props */
  eyebrow,
  eyebrowIcon,
  rating = "4.9",
  reviewCount = "500+",
  primaryIcon = "arrow_forward",
  secondaryIcon,
}: HeroSplitProps) {
  if (layout === "editorial") {
    return <EditorialHero {...{ title, subtitle, imageSrc, imageAlt, primaryLabel, primaryHref, secondaryLabel, secondaryHref, eyebrow, children }} />;
  }

  /* ── Default layout (inner pages) ─────────────────────────────────────── */
  const alt = imageAlt ?? title.replace(/<[^>]*>/g, "");

  return (
    <section className="w-full relative bg-surface-purple overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16 py-16 md:py-24">
          {/* LEFT: text content */}
          <div className="flex flex-col gap-6 max-w-md flex-1">
            {eyebrow || eyebrowIcon ? (
              <span
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full w-fit
                           bg-white/20 border border-white/30 text-primary-dark
                           text-xs font-bold uppercase tracking-widest"
              >
                {eyebrowIcon ? (
                  <PhosphorIcon
                    name={eyebrowIcon}
                    weight="fill"
                    className="text-sm text-secondary"
                  />
                ) : null}
                {eyebrow}
              </span>
            ) : null}

            <BadgeStat rating={rating} reviewCount={reviewCount} />

            <h1
              className="font-serif text-4xl md:text-5xl font-bold text-primary-dark leading-tight"
              dangerouslySetInnerHTML={{ __html: title }}
            />

            {subtitle ? (
              <p className="text-primary-dark/60 text-base leading-relaxed">
                {subtitle}
              </p>
            ) : null}

            {primaryLabel || secondaryLabel ? (
              <div className="flex flex-col items-start gap-3 ml-1">
                {primaryLabel ? (
                  <a
                    href={primaryHref}
                    className="inline-flex items-center gap-2
                               bg-primary hover:bg-primary-dark text-white
                               px-8 py-4 rounded-full font-bold
                               transition shadow-sm
                               focus:outline-none focus:ring-2 focus:ring-primary/60"
                  >
                    {primaryLabel}
                    <ArrowRight className="text-base" aria-hidden="true" />
                  </a>
                ) : null}

                {secondaryLabel && secondaryHref ? (
                  <a
                    href={secondaryHref}
                    className="inline-flex items-center gap-2
                               border border-primary/30 text-primary-dark
                               px-8 py-4 rounded-full font-semibold
                               hover:bg-white/50 transition
                               focus:outline-none focus:ring-2 focus:ring-primary/40"
                  >
                    {secondaryIcon ? (
                      <PhosphorIcon name={secondaryIcon} className="text-base" />
                    ) : null}
                    {secondaryLabel}
                  </a>
                ) : null}
              </div>
            ) : null}
          </div>

          {/* RIGHT: image */}
          <div className="flex-1 w-full max-w-lg lg:max-w-none">
            <div className="relative aspect-[4/3] lg:aspect-[5/4] rounded-2xl overflow-hidden shadow-lg">
              {imageSrc ? (
                <img
                  src={imageSrc}
                  alt={alt}
                  className="absolute inset-0 w-full h-full object-cover"
                  loading="lazy"
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  {children}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ═══════════════════════════════════════════════════════════════════════════════
   EDITORIAL HERO — image-dominant asymmetric split for homepage.
   ═══════════════════════════════════════════════════════════════════════════════ */

type EditorialProps = {
  title: string;
  subtitle?: string | null;
  imageSrc?: string | null;
  imageAlt?: string | null;
  primaryLabel?: string | null;
  primaryHref?: string;
  secondaryLabel?: string | null;
  secondaryHref?: string;
  eyebrow?: string | null;
  children?: ReactNode;
};

function EditorialHero({
  title,
  subtitle,
  imageSrc,
  imageAlt,
  primaryLabel,
  primaryHref = "#",
  secondaryLabel,
  secondaryHref = "#",
  eyebrow,
  children,
}: EditorialProps) {
  const alt = imageAlt ?? title;

  return (
    <section className="relative bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-10 md:py-0">
        <div className="flex flex-col-reverse lg:flex-row items-stretch gap-8 lg:gap-0 lg:min-h-[88vh]">
          {/* ── TEXT SIDE (right on desktop, below image on mobile) ── */}
          <div className="flex flex-col justify-center lg:w-[40%] lg:pl-12 xl:pl-16 py-4">
            {eyebrow ? (
              <span className="inline-block mb-5 text-xs font-bold uppercase tracking-[0.2em] text-primary/70">
                {eyebrow}
              </span>
            ) : null}

            <h1 className="text-display mb-0 text-primary-dark">
              {title}
            </h1>

            <p className="flex items-center gap-2 text-sm text-primary-dark/50 mb-6">
              <ShieldCheck size={16} weight="fill" className="text-primary" />
              <span>PCSA Certified · On-Site Vet · 24/7 Supervision</span>
            </p>

            {subtitle ? (
              <p className="text-body mb-8">
                {subtitle}
              </p>
            ) : null}

            {(primaryLabel || secondaryLabel) ? (
              <div className="flex flex-wrap gap-3">
                {primaryLabel ? (
                  <Link
                    href={primaryHref}
                    className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-7 py-3.5 rounded-full font-bold transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
                  >
                    {primaryLabel}
                    <ArrowRight weight="bold" className="text-base" aria-hidden="true" />
                  </Link>
                ) : null}

                {secondaryLabel ? (
                  <Link
                    href={secondaryHref}
                    className="inline-flex items-center gap-2 border-2 border-primary/25 text-primary-dark px-7 py-3.5 rounded-full font-semibold hover:bg-surface-purple transition-colors focus:outline-none focus:ring-2 focus:ring-primary/40 focus:ring-offset-2"
                  >
                    {secondaryLabel}
                  </Link>
                ) : null}
              </div>
            ) : null}
          </div>

          {/* ── IMAGE SIDE (left on desktop, above text on mobile) ── */}
          <div className="lg:w-[60%] relative">
            <div className="relative w-full aspect-[4/3] lg:aspect-auto lg:h-full overflow-hidden">
              {imageSrc ? (
                <WaggiesImage
                  src={imageSrc}
                  alt={alt}
                  fill
                  sizes="(max-width: 1024px) 100vw, 60vw"
                  priority
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  {children}
                </div>
              )}

              {/* Subtle warm-tinted overlay: bottom-left, transparent → hint of primary-dark */}
              <div
                className="pointer-events-none absolute inset-0 lg:bg-gradient-to-tr lg:from-primary-dark/15 lg:via-transparent lg:to-transparent"
                aria-hidden="true"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
