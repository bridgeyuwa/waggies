"use client";

/**
 * BackToTopLink - a small client component for the footer's "Back to top" link.
 * Extracted so that the Footer server component doesn't need to become a client component.
 */

import { MaterialSymbol } from "./material-symbol";

export function BackToTopLink({ className = "", textClassName = "" }: { className?: string; textClassName?: string }) {
  function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <button
      onClick={scrollToTop}
      className={`flex items-center gap-1.5 transition-colors hover:underline focus:outline-none focus:ring-2 focus:ring-primary/50 rounded-sm ${className}`}
      aria-label="Back to top"
    >
      <MaterialSymbol name="keyboard_arrow_up" className="text-base" />
      Back to top
    </button>
  );
}
