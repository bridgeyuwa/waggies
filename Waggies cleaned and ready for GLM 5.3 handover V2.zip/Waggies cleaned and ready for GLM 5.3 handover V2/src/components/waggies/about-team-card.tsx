"use client";

/**
 * AboutTeamCard - Centered team profile card for the About page.
 *
 * Renders: 1:1 rounded portrait, name (serif bold), role, optional
 * responsibility line. Verified staff get a subtle badge; placeholders
 * get a dashed border.
 */

import { WaggiesImage } from "@/components/waggies/waggies-image";

export type AboutTeamCardProps = {
  name: string;
  role: string;
  imageSrc: string;
  imageAlt: string;
  responsibility?: string;
  verifiedStaff: boolean;
  placeholder: boolean;
};

export function AboutTeamCard({
  name,
  role,
  imageSrc,
  imageAlt,
  responsibility,
  verifiedStaff,
  placeholder = false,
}: AboutTeamCardProps) {
  return (
    <div
      className={`
        bg-white rounded-xl p-6 flex flex-col items-center text-center
        ${placeholder ? "border-2 border-dashed border-primary/20" : "border border-primary/5"}
        shadow-sm hover:shadow-soft transition-shadow
      `}
    >
      {/* Portrait - 1:1 aspect ratio, rounded */}
      <div className="w-28 h-28 sm:w-32 sm:h-32 rounded-full overflow-hidden bg-surface-purple shrink-0">
        {imageSrc ? (
          <WaggiesImage
            src={imageSrc}
            alt={imageAlt}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 25vw, 150px"
          />
        ) : (
          <div
            className="w-full h-full flex items-center justify-center"
            role="img"
            aria-label={imageAlt}
          >
            <span className="text-primary/20 text-4xl select-none">⟘</span>
          </div>
        )}
      </div>

      {/* Text content */}
      <div className="mt-4 space-y-1">
        <div className="flex items-center justify-center gap-2">
          <h3 className="font-serif text-base sm:text-lg font-bold text-primary-dark leading-tight">
            {name}
          </h3>
          {verifiedStaff && (
            <svg
              className="w-4 h-4 text-primary shrink-0"
              fill="currentColor"
              viewBox="0 0 20 20"
              aria-label="Verified staff member"
            >
              <path
                fillRule="evenodd"
                d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.857-9.809a.75.75 0 00-1.214-.882l-3.483 4.79-1.88-1.88a.75.75 0 10-1.06 1.06l2.5 2.5a.75.75 0 001.137-.089l4-5.5z"
                clipRule="evenodd"
              />
            </svg>
          )}
        </div>

        <p className="text-label text-primary font-medium">{role}</p>

        {responsibility && (
          <p className="text-meta text-primary-dark/60 leading-relaxed pt-1">
            {responsibility}
          </p>
        )}
      </div>
    </div>
  );
}
