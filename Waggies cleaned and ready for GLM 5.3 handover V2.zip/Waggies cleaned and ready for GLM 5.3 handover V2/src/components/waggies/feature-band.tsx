"use client";

/**
 * Feature band - dark CTA section with feature list.
 *
 * Faithful React reproduction of resources/views/components/feature-band.blade.php.
 * Enhanced with staggered fade-in.
 */

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { MaterialSymbol } from "./material-symbol";

export type FeatureBandFeature = {
  icon: string;
  title: string;
  description: string;
};

export type FeatureBandProps = {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  features?: FeatureBandFeature[];
  cta?: { label: string; href: string };
  /** Optional slot content (replaces features list when present). */
  children?: React.ReactNode;
};

/* Staggered entrance variants for the whole section */
const sectionVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.08, delayChildren: 0.15 },
  },
};

const fadeUpVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as const },
  },
};

/* Feature item variants with more stagger */
const featureItemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function FeatureBand({
  eyebrow,
  title,
  subtitle,
  features = [],
  cta,
  children,
}: FeatureBandProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const isInView = useInView(sectionRef, { once: true, margin: "-80px" });

  return (
    <section
      ref={sectionRef}
      className="w-full bg-primary-dark text-white py-24"
    >
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center"
          variants={sectionVariants}
          initial="hidden"
          animate={isInView ? "visible" : "hidden"}
        >
          {/* LEFT */}
          <div className="flex flex-col gap-6 max-w-xl">
            {eyebrow ? (
              <motion.p
                variants={fadeUpVariants}
                className="text-secondary font-bold tracking-widest uppercase text-xs"
              >
                {eyebrow}
              </motion.p>
            ) : null}

            <motion.h2
              variants={fadeUpVariants}
              className="font-serif text-3xl md:text-4xl font-bold leading-tight"
              dangerouslySetInnerHTML={{ __html: title }}
            />

            {subtitle ? (
              <motion.p
                variants={fadeUpVariants}
                className="text-white/70 leading-relaxed text-base"
              >
                {subtitle}
              </motion.p>
            ) : null}

            {cta ? (
              <motion.div variants={fadeUpVariants} className="pt-2">
                <a
                  href={cta.href}
                  className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark font-bold px-8 py-3.5 rounded-full transition focus:outline-none focus:ring-2 focus:ring-secondary/60 focus:ring-offset-2 focus:ring-offset-primary-dark"
                >
                  {cta.label}
                  <MaterialSymbol name="arrow_forward" className="text-base" />
                </a>
              </motion.div>
            ) : null}
          </div>

          {/* RIGHT */}
          <div className="flex flex-col gap-5">
            {children ? (
              children
            ) : (
              features.map((feature, i) => (
                <motion.div
                  key={i}
                  variants={featureItemVariants}
                  className="flex items-start gap-4 p-5 rounded-2xl bg-white/[0.03] hover:bg-white/[0.06] border border-white/10 transition cursor-default"
                >
                  <div className="size-12 rounded-full bg-white/10 flex items-center justify-center text-secondary shrink-0">
                    <MaterialSymbol name={feature.icon} className="text-lg" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-white text-lg">
                      {feature.title}
                    </h3>
                    <p className="text-white/60 text-sm mt-1 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </motion.div>
              ))
            )}
          </div>
        </motion.div>
      </div>
    </section>
  );
}
