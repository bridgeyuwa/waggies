/**
 * CTA button group - shared by hero variants.
 *
 * Faithful React reproduction of resources/views/components/ui/cta-buttons.blade.php.
 *
 * Two variants:
 *   - overlay: cream primary button (used on image heroes)
 *   - plain:   purple primary button (used on light backgrounds)
 */

import { MaterialSymbol } from "./material-symbol";
import type { HeroCta } from "./hero-image";

export type CtaButtonsProps = {
  primary?: HeroCta;
  secondary?: HeroCta;
  variant?: "overlay" | "plain";
  className?: string;
};

export function CtaButtons({
  primary,
  secondary,
  variant = "overlay",
  className = "",
}: CtaButtonsProps) {
  const primaryClasses =
    variant === "overlay"
      ? "bg-secondary hover:bg-secondary-hover text-primary-dark shadow-sm focus:ring-secondary/60 focus:ring-offset-2"
      : "bg-primary hover:bg-primary-dark text-white shadow-sm focus:ring-primary/60 focus:ring-offset-2";

  const secondaryClasses =
    variant === "overlay"
      ? "border border-white/30 text-white hover:bg-white/10 focus:ring-white/60 focus:ring-offset-2"
      : "border border-primary/30 text-primary-dark hover:bg-primary/5 focus:ring-primary/40";

  return (
    <div className={`flex flex-wrap gap-3 ${className}`}>
      {primary ? (
        <a
          href={primary.href ?? "#"}
          className={`inline-flex items-center gap-2 font-bold px-8 py-3.5 rounded-full transition focus:outline-none focus:ring-2 ${primaryClasses}`}
        >
          {primary.label}
          {primary.icon ? (
            <MaterialSymbol name={primary.icon} className="text-base" ariaHidden />
          ) : null}
        </a>
      ) : null}

      {secondary ? (
        <a
          href={secondary.href ?? "#"}
          className={`inline-flex items-center gap-2 px-8 py-3.5 rounded-full font-semibold transition focus:outline-none focus:ring-2 ${secondaryClasses}`}
        >
          {secondary.iconBefore ? (
            <MaterialSymbol name={secondary.iconBefore} className="text-base" ariaHidden />
          ) : null}
          {secondary.label}
        </a>
      ) : null}
    </div>
  );
}
