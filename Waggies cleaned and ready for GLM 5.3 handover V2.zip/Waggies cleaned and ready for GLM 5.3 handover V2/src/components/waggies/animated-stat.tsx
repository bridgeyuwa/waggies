"use client";

import { useRef, useEffect, useState } from "react";
import { useInView, useReducedMotion } from "framer-motion";
import { MaterialSymbol } from "./material-symbol";

/**
 * AnimatedStat - an animated counter/stat component.
 *
 * Displays a number that counts up from 0 when scrolled into view.
 * Uses framer-motion useInView to trigger the counting animation.
 *
 * - Large serif font (Cormorant Garamond) for the number, Waggies purple
 * - Label below in smaller DM Sans
 * - Optional MaterialSymbol icon above the number
 *
 * Example usage:
 * <AnimatedStat value={500} suffix="+" label="Happy Pets" icon="pets" />
 */

export function AnimatedStat({
  value,
  suffix = "",
  prefix = "",
  label,
  icon,
}: {
  value: number;
  suffix?: string;
  prefix?: string;
  label: string;
  icon?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  const shouldReduceMotion = useReducedMotion();
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isInView) return;
    if (shouldReduceMotion) {
      requestAnimationFrame(() => setCount(value));
      return;
    }

    const duration = 2000; // 2 seconds
    const startTime = performance.now();

    function step(now: number) {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      // Ease-out cubic for nice deceleration
      const eased = 1 - Math.pow(1 - progress, 3);
      setCount(Math.round(eased * value));
      if (progress < 1) {
        requestAnimationFrame(step);
      }
    }

    requestAnimationFrame(step);
  }, [isInView, value]);

  return (
    <div ref={ref} className="flex flex-col items-center text-center gap-2">
      {icon && (
        <MaterialSymbol
          name={icon}
          className="text-3xl text-waggies-primary-light"
        />
      )}
      <span className="font-serif text-4xl sm:text-5xl font-bold text-waggies-primary tabular-nums">
        {prefix}
        {count}
        {suffix}
      </span>
      <span className="text-sm sm:text-base text-primary-dark/60 font-medium max-w-[200px]">
        {label}
      </span>
    </div>
  );
}
