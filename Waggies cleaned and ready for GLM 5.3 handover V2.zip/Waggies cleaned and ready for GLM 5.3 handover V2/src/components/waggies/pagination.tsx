/**
 * Pagination - React port of Laravel's default paginator view.
 *
 * The Laravel Blade renders `$posts->links()` which uses the default Tailwind
 * pagination view (vendor/pagination/tailwind.blade.php). This component
 * reproduces that markup exactly:
 *
 *   <nav role="navigation" aria-label="Pagination Navigation"
 *        class="flex items-center justify-between gap-4 flex-wrap">
 *     <!-- Mobile group: « Previous / Next » -->
 *     <div class="flex items-center gap-2 sm:hidden">…</div>
 *     <!-- Desktop group: "Showing X-Y of Z results" + page buttons -->
 *     <div class="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between gap-4 flex-wrap">
 *       <p class="text-sm text-gray-500">Showing … results</p>
 *       <div class="flex items-center gap-1">… w-9 h-9 rounded-full …</div>
 *     </div>
 *   </nav>
 *
 * Source: vendor/pagination/tailwind.blade.php (default Laravel paginator view)
 *         + dist/{blog,guides,knowledge-base}/[slug]/index.html captured reference
 */

export type PaginationProps = {
  /** Current page number (1-indexed). */
  currentPage: number;
  /** Total number of pages. */
  totalPages: number;
  /** Base URL (without query string). Pagination links go to `${baseUrl}?page=N`. */
  baseUrl: string;
  /** Existing query params to preserve (excluding `page`). */
  preserveParams?: Record<string, string | undefined>;
  /** Total item count (for "Showing X-Y of Z results" text). */
  totalItems?: number;
  /** Items per page (for "Showing X-Y of Z results" text). */
  perPage?: number;
};

function pageHref(baseUrl: string, page: number, preserve?: Record<string, string | undefined>): string {
  const params = new URLSearchParams();
  if (preserve) {
    for (const [k, v] of Object.entries(preserve)) {
      if (v !== undefined && v !== null && v !== "") params.set(k, v);
    }
  }
  if (page > 1) {
    params.set("page", String(page));
  }
  const qs = params.toString();
  return qs ? `${baseUrl}?${qs}` : baseUrl;
}

// Heroicon-style SVG paths matching Laravel's default pagination view
const CHEVRON_LEFT_PATH =
  "M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z";
const CHEVRON_RIGHT_PATH =
  "M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z";

function ChevronLeft() {
  return (
    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
      <path fillRule="evenodd" d={CHEVRON_LEFT_PATH} clipRule="evenodd"></path>
    </svg>
  );
}

function ChevronRight() {
  return (
    <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20" aria-hidden="true">
      <path fillRule="evenodd" d={CHEVRON_RIGHT_PATH} clipRule="evenodd"></path>
    </svg>
  );
}

export function Pagination({
  currentPage,
  totalPages,
  baseUrl,
  preserveParams,
  totalItems,
  perPage = 12,
}: PaginationProps) {
  if (totalPages <= 1) return null;

  // Laravel's default paginator shows a window of 3 pages on each side of the
  // current page, plus first/last with ellipsis when needed.
  const windowSize = 3;
  const pages: number[] = [];
  const start = Math.max(1, currentPage - windowSize);
  const end = Math.min(totalPages, currentPage + windowSize);
  for (let i = start; i <= end; i++) pages.push(i);

  const showFirstDots = start > 1;
  const showLastDots = end < totalPages;

  // Compute "Showing X-Y of Z results" range
  const rangeStart = (currentPage - 1) * perPage + 1;
  const rangeEnd = Math.min(currentPage * perPage, totalItems ?? currentPage * perPage);

  const mobilePrevClass =
    "inline-flex items-center px-4 py-2 text-sm font-medium text-gray-400 bg-white border border-gray-200 rounded-full cursor-not-allowed";
  const mobilePrevLinkClass =
    "inline-flex items-center px-4 py-2 text-sm font-medium text-primary bg-white border border-primary/30 rounded-full hover:bg-primary/5 transition";
  const mobileNextClass = mobilePrevClass; // same disabled style
  const mobileNextLinkClass = mobilePrevLinkClass; // same enabled style

  const pageLinkClass =
    "inline-flex items-center justify-center w-9 h-9 text-sm font-medium text-primary rounded-full hover:bg-primary/10 transition";
  const pageActiveClass =
    "inline-flex items-center justify-center w-9 h-9 text-sm font-semibold text-white bg-primary rounded-full shadow-sm";
  const pageDisabledClass =
    "inline-flex items-center justify-center w-9 h-9 text-gray-300 rounded-full cursor-not-allowed";

  return (
    <nav
      role="navigation"
      aria-label="Pagination Navigation"
      className="flex items-center justify-between gap-4 flex-wrap"
    >
      {/* Mobile group: only « Previous / Next » */}
      <div className="flex items-center gap-2 sm:hidden">
        {currentPage > 1 ? (
          <a
            href={pageHref(baseUrl, currentPage - 1, preserveParams)}
            rel="prev"
            className={mobilePrevLinkClass}
          >
            « Previous
          </a>
        ) : (
          <span className={mobilePrevClass} aria-disabled="true">
            « Previous
          </span>
        )}
        {currentPage < totalPages ? (
          <a
            href={pageHref(baseUrl, currentPage + 1, preserveParams)}
            rel="next"
            className={mobileNextLinkClass}
          >
            Next »
          </a>
        ) : (
          <span className={mobileNextClass} aria-disabled="true">
            Next »
          </span>
        )}
      </div>

      {/* Desktop group: "Showing X-Y of Z results" + numbered buttons */}
      <div className="hidden sm:flex sm:flex-1 sm:items-center sm:justify-between gap-4 flex-wrap">
        {totalItems !== undefined ? (
          <p className="text-sm text-gray-500">
            Showing <span className="font-semibold text-gray-700">{rangeStart}</span>
            {" - "}
            <span className="font-semibold text-gray-700">{rangeEnd}</span>
            {" of "}
            <span className="font-semibold text-gray-700">{totalItems}</span> results
          </p>
        ) : null}

        <div className="flex items-center gap-1">
          {currentPage > 1 ? (
            <a
              href={pageHref(baseUrl, currentPage - 1, preserveParams)}
              rel="prev"
              className={pageLinkClass}
              aria-label="Previous page"
            >
              <ChevronLeft />
            </a>
          ) : (
            <span className={pageDisabledClass} aria-disabled="true">
              <ChevronLeft />
            </span>
          )}

          {showFirstDots ? (
            <>
              <a
                href={pageHref(baseUrl, 1, preserveParams)}
                className={pageLinkClass}
                aria-label="Go to page 1"
              >
                1
              </a>
              <span className="px-2 text-primary-dark/60">…</span>
            </>
          ) : null}

          {pages.map((p) =>
            p === currentPage ? (
              <span key={p} className={pageActiveClass} aria-current="page">
                {p}
              </span>
            ) : (
              <a
                key={p}
                href={pageHref(baseUrl, p, preserveParams)}
                className={pageLinkClass}
                aria-label={`Go to page ${p}`}
              >
                {p}
              </a>
            ),
          )}

          {showLastDots ? (
            <>
              <span className="px-2 text-primary-dark/60">…</span>
              <a
                href={pageHref(baseUrl, totalPages, preserveParams)}
                className={pageLinkClass}
                aria-label={`Go to page ${totalPages}`}
              >
                {totalPages}
              </a>
            </>
          ) : null}

          {currentPage < totalPages ? (
            <a
              href={pageHref(baseUrl, currentPage + 1, preserveParams)}
              rel="next"
              className={pageLinkClass}
              aria-label="Next »"
            >
              <ChevronRight />
            </a>
          ) : (
            <span className={pageDisabledClass} aria-disabled="true">
              <ChevronRight />
            </span>
          )}
        </div>
      </div>
    </nav>
  );
}
