"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { MaterialSymbol } from "./material-symbol";
import { cookieStorageKey } from "@/lib/site";

/**
 * Waggies Cookie Banner - faithful React reproduction of
 * resources/views/components/cookie-banner.blade.php.
 *
 * Behavior:
 *   - On mount, check localStorage for the `waggies-cookies` key.
 *   - If absent, show the banner after a 50ms delay (matches the Alpine
 *     `setTimeout(() => this.show = true, 50)`).
 *   - If present, never show the banner.
 *   - "Essential only" writes `'essential'` to localStorage.
 *   - "Accept All" writes `'all'` to localStorage.
 *   - Either action hides the banner immediately.
 *
 * The localStorage key is `waggies-cookies` exactly - preserved from the
 * Laravel source. No third-party cookie management is introduced.
 */
export function CookieBanner() {
  const [show, setShow] = useState(false);

  useEffect(() => {
    // SSR guard - match Alpine's behavior of only running client-side.
    if (typeof window === "undefined") return;
    if (!localStorage.getItem(cookieStorageKey)) {
      const t = setTimeout(() => setShow(true), 50);
      return () => clearTimeout(t);
    }
  }, []);

  const accept = (type: "essential" | "all") => {
    try {
      localStorage.setItem(cookieStorageKey, type);
    } catch {
      // localStorage may be unavailable (private mode, etc.) - fail silently
      // to match Alpine's lack of error handling.
    }
    setShow(false);
  };

  return (
    <div
      className={cn(
        "fixed bottom-0 left-0 right-0 z-[9998] px-4 py-3 md:px-8 md:py-4 transition duration-500 ease-out",
        show ? "translate-y-0" : "translate-y-full pointer-events-none",
      )}
      aria-hidden={!show}
    >
      <div className="max-w-5xl mx-auto bg-primary-dark rounded-2xl shadow-2xl px-6 py-4 flex flex-col sm:flex-row items-start sm:items-center gap-4">
        <div className="flex items-start gap-3 flex-1">
          <MaterialSymbol name="cookie" className="text-secondary text-2xl shrink-0 mt-0.5" />
          <p className="text-white/80 text-sm leading-relaxed">
            We use cookies to personalise content, improve your experience, and analyse our traffic.{" "}
            <Link
              href="/cookies-policy"
              className="text-secondary underline hover:text-secondary-hover transition-colors"
            >
              Learn more
            </Link>
          </p>
        </div>
        <div className="flex items-center gap-3 shrink-0">
          <button
            type="button"
            onClick={() => accept("essential")}
            className="border border-white/30 text-white px-5 py-2.5 rounded-full text-xs font-semibold hover:bg-white/10 transition-colors focus:outline-none focus:ring-2 focus:ring-white/40 min-h-[44px]"
          >
            Essential only
          </button>
          <button
            type="button"
            onClick={() => accept("all")}
            className="bg-secondary text-primary-dark px-5 py-2.5 rounded-full text-xs font-semibold hover:bg-secondary-hover transition-colors focus:outline-none focus:ring-2 focus:ring-secondary/60 min-h-[44px]"
          >
            Accept All
          </button>
        </div>
      </div>
    </div>
  );
}
