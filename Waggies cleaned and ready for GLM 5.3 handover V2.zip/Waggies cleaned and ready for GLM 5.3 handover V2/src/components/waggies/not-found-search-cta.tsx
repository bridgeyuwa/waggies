"use client";

import { MaterialSymbol } from "./material-symbol";

/**
 * NotFoundSearchCTA - prominent search call-to-action for the 404 page.
 *
 * Renders a large search-bar-styled button that opens the global search
 * command palette by dispatching `waggies:open-search` on window.
 */
export function NotFoundSearchCTA() {
  const handleClick = () => {
    if (typeof window === "undefined") return;
    window.dispatchEvent(new CustomEvent("waggies:open-search"));
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label="Search the site"
      className="w-full max-w-lg mx-auto flex items-center gap-3 px-6 py-4 rounded-2xl border-2 border-primary/20 bg-white hover:bg-surface-purple/30 transition cursor-pointer text-lg group"
    >
      <MaterialSymbol
        name="search"
        className="text-2xl text-primary group-hover:scale-110 transition-transform"
        ariaHidden={false}
      />
      <span className="flex-1 text-left text-primary-dark/60">
        Search for services, blog posts, products…
      </span>
      <kbd
        className="hidden sm:inline-flex items-center gap-0.5 px-2 py-0.5 rounded-md bg-surface-purple text-xs font-medium text-primary-dark/50 uppercase tracking-wide border border-primary/10"
        aria-hidden="true"
      >
        ⌘K
      </kbd>
    </button>
  );
}
