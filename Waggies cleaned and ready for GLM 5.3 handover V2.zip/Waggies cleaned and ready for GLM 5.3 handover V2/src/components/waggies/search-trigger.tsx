"use client";

/**
 * SearchTrigger - navbar button that opens the global search command palette.
 *
 * The trigger and the palette communicate via a custom window event so that
 * the trigger doesn't need to lift state up to a shared parent. Clicking
 * dispatches `window.dispatchEvent(new CustomEvent("waggies:open-search"))`,
 * which the SearchCommandPalette component listens for.
 *
 * Renders two flavours via the `variant` prop:
 *   • "icon"   - round icon-only button (used in the desktop navbar; sits
 *                between ThemeToggle and "Get a Quote")
 *   • "row"    - full-width row with leading search icon + ⌘K hint + label
 *                (used at the top of the mobile menu)
 *
 * Keyboard hint "⌘K" is shown on the desktop chip (recognised by both Mac
 * and Windows/Linux users since ⌘/Ctrl+K both open the palette). Hidden on
 * the icon variant on mobile (lg:block).
 */

import { MaterialSymbol } from "./material-symbol";
import { cn } from "@/lib/utils";

type SearchTriggerProps = {
  /** Visual flavour of the trigger. */
  variant?: "icon" | "row";
  /** Extra classes on the root button. */
  className?: string;
  /** Optional callback fired when the trigger is activated (alongside the
   *  custom `waggies:open-search` event). Use this to close menus / drawers
   *  that may be open underneath the palette. */
  onOpen?: () => void;
};

/** Open the global search palette by dispatching a custom window event. */
function openSearchPalette() {
  if (typeof window === "undefined") return;
  window.dispatchEvent(new CustomEvent("waggies:open-search"));
}

export function SearchTrigger({
  variant = "icon",
  className,
  onOpen,
}: SearchTriggerProps) {
  const handleClick = () => {
    openSearchPalette();
    onOpen?.();
  };

  if (variant === "row") {
    return (
      <button
        type="button"
        onClick={handleClick}
        aria-label="Search the site"
        className={cn(
          "w-full flex items-center gap-3 px-3 py-3 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-xl transition-colors",
          className,
        )}
      >
        <MaterialSymbol name="search" className="text-base text-primary-dark/70" />
        <span className="flex-1 text-left">Search the site</span>
        <kbd
          className="hidden sm:inline-flex items-center gap-1 px-2 py-0.5 rounded-md bg-white border border-surface-purple text-[10px] font-medium text-primary-dark/60 uppercase tracking-wide"
          aria-hidden="true"
        >
          ⌘K
        </kbd>
      </button>
    );
  }

  return (
    <button
      type="button"
      onClick={handleClick}
      aria-label="Search the site"
      title="Search the site (⌘K / Ctrl+K)"
      className={cn(
        "relative flex items-center justify-center w-9 h-9 rounded-full hover:bg-surface-purple transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2 group",
        className,
      )}
    >
      <MaterialSymbol
        name="search"
        className="text-xl text-primary-dark transition-transform group-hover:scale-110"
        ariaHidden={false}
      />
      {/* Keyboard hint chip - desktop only. */}
      <kbd
        className="hidden lg:inline-flex absolute -bottom-1.5 -right-1.5 items-center gap-0.5 px-1.5 py-0.5 rounded-md bg-surface-purple text-primary-dark/70 text-[9px] font-bold uppercase tracking-wide border border-primary/10"
        aria-hidden="true"
      >
        ⌘K
      </kbd>
    </button>
  );
}
