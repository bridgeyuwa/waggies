/**
 * LayoutListing - React port of resources/views/components/layouts/listing.blade.php
 *
 * Used by blog/guides/kb index + category pages. Renders hero + breadcrumb +
 * main content (left column with optional pagination) + optional sidebar.
 *
 */

import { type ReactNode } from "react";
import { Breadcrumb, BreadcrumbStrip, type Crumb } from "@/components/waggies/breadcrumb";

export type LayoutListingProps = {
  /** Hero element rendered full-bleed above the breadcrumb+content. */
  hero?: ReactNode;
  /** Breadcrumb crumbs. If omitted, no breadcrumb strip is rendered. */
  crumbs?: Crumb[];
  /** Main body content (article cards, featured story, etc.). */
  children: ReactNode;
  /** Optional sidebar (categories list, newsletter widget, etc.). */
  sidebar?: ReactNode;
  /** Optional pagination element below the body. */
  pagination?: ReactNode;
  /** Optional header rendered when no hero is provided. */
  header?: ReactNode;
};

export function LayoutListing({
  hero,
  crumbs,
  children,
  sidebar,
  pagination,
  header,
}: LayoutListingProps) {
  return (
    <>
      {hero ? (
        <>
          {/* Laravel's listing.blade.php: when no custom $breadcrumb slot is
              passed, it renders <x-breadcrumb.strip class="bg-white border-b
              border-primary/5" /> which produces ONE div with merged classes:
                max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-4 bg-white border-b border-primary/5
              We always pass `crumbs` (never a custom breadcrumb slot), so we
              always use the merged-class form. */}
          <BreadcrumbStrip
            className="bg-white border-b border-primary/5"
            crumbs={crumbs ?? []}
          />
          {hero}
        </>
      ) : (
        <div className="bg-surface-purple border-b border-primary/10">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-16">
            <div className="mb-6">
              {crumbs && crumbs.length > 0 ? (
                <Breadcrumb crumbs={crumbs} />
              ) : null}
            </div>
            {header}
          </div>
        </div>
      )}

      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-16">
        <div className="flex flex-col lg:flex-row gap-12">
          <div className="flex-1 min-w-0">
            {children}
            {pagination ? <div className="mt-10">{pagination}</div> : null}
          </div>

          {sidebar ? (
            <aside className="w-full lg:w-72 xl:w-80 shrink-0 flex flex-col gap-6">
              {sidebar}
            </aside>
          ) : null}
        </div>
      </div>
    </>
  );
}
