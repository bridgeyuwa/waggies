/**
 * Gradient hero - split layout with rating badge.
 *
 * Faithful React reproduction of resources/views/components/hero/gradient.blade.php.
 */

import { BadgeStat } from "./badge-stat";
import type { HeroCta } from "./hero-image";

export type HeroGradientProps = {
  rating?: string;
  reviewCount?: string;
  imageSrc?: string | null;
   title: string;
  subtitle?: string;
  primaryCta?: HeroCta | null;
  secondaryCta?: HeroCta | null;
  headingLevel?: "h1" | "h2";
  eyebrow?: string;
};

const TITLE_CLASS =
  "font-serif text-4xl md:text-5xl font-bold text-primary-dark leading-tight text-balance";

export function HeroGradient({
  rating = "4.9",
  reviewCount = "500+",
  imageSrc = null,
  title,
  subtitle,
  primaryCta,
  secondaryCta,
  headingLevel = "h1",
  // `eyebrow` accepted for Blade parity but not rendered in split layout.
  eyebrow: _eyebrow,
}: HeroGradientProps) {
  return (
    <section className="w-full bg-surface-purple">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16 py-16 md:py-24">
          {/* LEFT CONTENT */}
          <div className="flex flex-col gap-6 max-w-md flex-1">
            <BadgeStat rating={rating} reviewCount={reviewCount} />

            {headingLevel === "h1" ? (
              <h1
                className={TITLE_CLASS}
                dangerouslySetInnerHTML={{ __html: title }}
              />
            ) : (
              <h2
                className={TITLE_CLASS}
                dangerouslySetInnerHTML={{ __html: title }}
              />
            )}

            {subtitle ? (
              <p className="text-primary-dark/60 text-base leading-relaxed">
                {subtitle}
              </p>
            ) : null}

            {primaryCta || secondaryCta ? (
              <div className="flex flex-col items-start gap-3 ml-1">
                {primaryCta ? (
                  <a
                    href={primaryCta.href}
                    className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-8 py-4 rounded-full font-bold transition"
                  >
                    {primaryCta.label}
                  </a>
                ) : null}
                {secondaryCta ? (
                  <a
                    href={secondaryCta.href}
                    className="inline-flex items-center gap-2 border border-primary/30 text-primary-dark px-8 py-4 rounded-full font-semibold hover:bg-white/50 transition"
                  >
                    {secondaryCta.label}
                  </a>
                ) : null}
              </div>
            ) : null}
          </div>

          {/* RIGHT SLOT */}
          <div className="flex-1 w-full max-w-lg lg:max-w-none">
            {imageSrc ? (
              <img
                src={imageSrc}
                alt={title.replace(/<[^>]*>/g, "")}
                className="w-full h-full object-cover rounded-2xl shadow-lg"
                loading="lazy"
              />
            ) : null}
          </div>
        </div>
      </div>
    </section>
  );
}
