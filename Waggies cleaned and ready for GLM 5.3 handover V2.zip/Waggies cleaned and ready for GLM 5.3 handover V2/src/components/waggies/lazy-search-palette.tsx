"use client";

/**
 * LazySearchPalette - defers loading of the SearchCommandPalette bundle.
 *
 * The SearchCommandPalette is a heavy client component (focus trap, debounced
 * search, framer-motion modal, etc.) that's only useful when the user opens
 * search. Mounting it eagerly on every page navigation wastes bandwidth and
 * main-thread time.
 *
 * Strategy:
 *   1. Listen for the FIRST `waggies:open-search` window event (dispatched by
 *      the SearchTrigger button in the navbar, the not-found CTA, or the ⌘K
 *      keyboard shortcut - though the latter is only useful after the palette
 *      has loaded, so the first invocation must come from a UI trigger).
 *   2. On that first event: set `shouldLoad = true` AND `openOnLoad = true`.
 *      The dynamic SearchCommandPalette receives `openOnLoad` as an initial
 *      `open` prop, so it mounts already-open - no fragile re-dispatch needed.
 *   3. The `{ once: true }` flag auto-removes the listener after the first
 *      invocation - subsequent `waggies:open-search` events are handled
 *      directly by the inner SearchCommandPalette (already mounted).
 *
 * This replaces the previous 50ms re-dispatch approach, which was racy: if
 * the dynamic import took longer than 50ms (common on slow connections or
 * cold caches), the re-dispatched event was missed and the user had to
 * click the trigger again. Passing `openOnLoad` as a prop eliminates the
 * race entirely.
 */

import { useEffect, useState } from "react";
import dynamic from "next/dynamic";

// ── Dynamic import of the real SearchCommandPalette ──────────────────────
// `ssr: false` keeps the focus-trap + framer-motion code out of the server
// bundle. The palette is invisible by default (closed), so no skeleton is
// needed - rendering null before load is fine.
const SearchCommandPalette = dynamic(
  () =>
    import("./search-command-palette").then((m) => ({
      default: m.SearchCommandPalette,
    })),
  { ssr: false },
);

// ── Component ────────────────────────────────────────────────────────────
export function LazySearchPalette() {
  const [shouldLoad, setShouldLoad] = useState(false);
  const [openOnLoad, setOpenOnLoad] = useState(false);

  useEffect(() => {
    if (shouldLoad) return; // already loaded - inner palette handles events

    const handler = () => {
      setShouldLoad(true);
      setOpenOnLoad(true);
    };

    // `{ once: true }` ensures the listener auto-removes after the first
    // invocation. Once loaded, the inner palette handles all future events.
    window.addEventListener("waggies:open-search", handler, { once: true });
    return () => window.removeEventListener("waggies:open-search", handler);
  }, [shouldLoad]);

  // Render nothing until the user triggers search. Once shouldLoad is true,
  // the dynamic SearchCommandPalette mounts with `initialOpen={openOnLoad}`
  // so it appears already-open - no second event needed.
  return shouldLoad ? (
    <SearchCommandPalette initialOpen={openOnLoad} />
  ) : null;
}
