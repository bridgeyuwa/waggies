"use client";

/**
 * WaggiesImage - lazy-loaded image with placeholder and fade-in.
 */

import { useState, useCallback } from "react";
import Image from "next/image";
import { MaterialSymbol } from "./material-symbol";

export type WaggiesImageProps = {
  src: string;
  alt: string;
  width?: number;
  height?: number;
  className?: string;
  priority?: boolean;
  fill?: boolean;
  sizes?: string;
  aspectRatio?: string;
  quality?: number;
  objectFit?: "cover" | "contain" | "fill" | "none";
};

export function WaggiesImage({
  src,
  alt,
  width,
  height,
  className = "",
  priority = false,
  fill = false,
  sizes = "(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw",
  quality = 85,
  objectFit = "cover",
}: WaggiesImageProps) {
  const [loaded, setLoaded] = useState(false);
  const [error, setError] = useState(false);

  const handleLoad = useCallback(() => setLoaded(true), []);
  const handleError = useCallback(() => setError(true), []);

  const fitClass =
    objectFit === "cover"
      ? "object-cover"
      : objectFit === "contain"
        ? "object-contain"
        : objectFit === "fill"
          ? "object-fill"
          : "object-none";

  /* Skip rendering if no valid src provided (TODO/client asset pending) */
  if (!src) {
    return (
      <div
        className={`${fill ? "absolute inset-0" : "relative overflow-hidden"} flex items-center justify-center bg-surface-purple ${className}`}
        style={!fill ? { width, height } : undefined}
        role="img"
        aria-label={alt || "Image pending"}
      >
        <MaterialSymbol name="photo_camera" className="text-primary/20 text-4xl" />
      </div>
    );
  }

  if (fill) {
    return (
      <div className={`relative w-full h-full ${className}`}>
        {!loaded && !error && (
          <div className="absolute inset-0 bg-surface-purple animate-pulse" aria-hidden="true" />
        )}
        {error && (
          <div className="absolute inset-0 flex items-center justify-center bg-surface-purple">
            <MaterialSymbol name="image_not_supported" className="text-primary/30 text-4xl" />
          </div>
        )}
        <Image
          src={src}
          alt={alt}
          fill
          sizes={sizes}
          quality={quality}
          priority={priority}
          loading={priority ? "eager" : "lazy"}
          onLoad={handleLoad}
          onError={handleError}
          className={`${fitClass} transition-opacity duration-300 ${loaded && !error ? "opacity-100" : "opacity-0"}`}
        />
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden ${className}`} style={{ width, height }}>
      {!loaded && !error && (
        <div className="absolute inset-0 bg-surface-purple animate-pulse" aria-hidden="true" />
      )}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center bg-surface-purple">
          <MaterialSymbol name="image_not_supported" className="text-primary/30 text-4xl" />
        </div>
      )}
      <Image
        src={src}
        alt={alt}
        width={width ?? 800}
        height={height ?? 600}
        sizes={sizes}
        quality={quality}
        priority={priority}
        loading={priority ? "eager" : "lazy"}
        onLoad={handleLoad}
        onError={handleError}
        className={`${fitClass} transition-opacity duration-300 ${loaded && !error ? "opacity-100" : "opacity-0"}`}
      />
    </div>
  );
}
