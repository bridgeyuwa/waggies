"use client";

/**
 * AnimatedDivider - decorative section divider with animated SVG elements.
 *
 * Features subtle animated dots/circles in Waggies purple that drift
 * horizontally, used between major homepage sections for visual polish.
 *
 * Props:
 * - variant: 'dots' | 'waves' | 'circles' (default: 'dots')
 * - className: additional classes
 */

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { cn } from "@/lib/utils";

export type AnimatedDividerProps = {
  variant?: "dots" | "waves" | "circles";
  className?: string;
};

export function AnimatedDivider({
  variant = "dots",
  className = "",
}: AnimatedDividerProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  return (
    <div
      ref={ref}
      className={cn("relative w-full overflow-hidden h-[40px] md:h-[48px]", className)}
      aria-hidden="true"
    >
      {variant === "dots" && (
        <motion.svg
          viewBox="0 0 1440 48"
          preserveAspectRatio="none"
          className="block w-full h-full"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <defs>
            <linearGradient id="dot-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="var(--color-primary, #6B2C91)" stopOpacity="0.12" />
              <stop offset="50%" stopColor="var(--color-primary, #6B2C91)" stopOpacity="0.20" />
              <stop offset="100%" stopColor="var(--color-primary, #6B2C91)" stopOpacity="0.12" />
            </linearGradient>
          </defs>
          {/* Row of animated dots */}
          {Array.from({ length: 24 }, (_, i) => {
            const cx = 30 + i * 60;
            const cy = 24;
            const r = 3 + (i % 3);
            return (
              <motion.circle
                key={i}
                cx={cx}
                cy={cy}
                r={r}
                fill="url(#dot-gradient)"
                initial={{ opacity: 0, scale: 0 }}
                animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0 }}
                transition={{
                  duration: 0.4,
                  delay: i * 0.04,
                  ease: "easeOut",
                }}
              />
            );
          })}
        </motion.svg>
      )}

      {variant === "waves" && (
        <motion.svg
          viewBox="0 0 1440 48"
          preserveAspectRatio="none"
          className="block w-full h-full"
          initial={{ opacity: 0, scaleX: 0.3 }}
          animate={isInView ? { opacity: 1, scaleX: 1 } : { opacity: 0, scaleX: 0.3 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        >
          <defs>
            <linearGradient id="wave-divider-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="var(--color-primary, #6B2C91)" stopOpacity="0.10" />
              <stop offset="50%" stopColor="var(--color-primary, #6B2C91)" stopOpacity="0.18" />
              <stop offset="100%" stopColor="var(--color-primary, #6B2C91)" stopOpacity="0.10" />
            </linearGradient>
          </defs>
          <path
            d="M0,24 C240,48 480,0 720,24 C960,48 1200,0 1440,24"
            fill="none"
            stroke="url(#wave-divider-gradient)"
            strokeWidth="2"
          />
          <path
            d="M0,30 C360,6 720,42 1080,18 C1260,10 1380,34 1440,28"
            fill="none"
            stroke="url(#wave-divider-gradient)"
            strokeWidth="1.5"
            opacity="0.6"
          />
        </motion.svg>
      )}

      {variant === "circles" && (
        <motion.svg
          viewBox="0 0 1440 48"
          preserveAspectRatio="none"
          className="block w-full h-full"
          initial={{ opacity: 0 }}
          animate={isInView ? { opacity: 1 } : { opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <defs>
            <linearGradient id="circle-divider-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="var(--color-primary, #6B2C91)" stopOpacity="0.08" />
              <stop offset="50%" stopColor="var(--color-primary, #6B2C91)" stopOpacity="0.15" />
              <stop offset="100%" stopColor="var(--color-primary, #6B2C91)" stopOpacity="0.08" />
            </linearGradient>
          </defs>
          {Array.from({ length: 8 }, (_, i) => {
            const cx = 90 + i * 180;
            const cy = 24;
            const r = 12 + (i % 3) * 4;
            return (
              <motion.circle
                key={i}
                cx={cx}
                cy={cy}
                r={r}
                fill="none"
                stroke="url(#circle-divider-gradient)"
                strokeWidth="1.5"
                initial={{ opacity: 0, scale: 0 }}
                animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0 }}
                transition={{
                  duration: 0.5,
                  delay: i * 0.06,
                  ease: "easeOut",
                }}
              />
            );
          })}
        </motion.svg>
      )}
    </div>
  );
}
