/**
 * Pricing tier card - renders a CardPricing from a tier config object.
 *
 * Faithful React reproduction of
 * resources/views/components/pricing/tier-card.blade.php.
 *
 * Computes the price display string and CTA label from the tier type:
 *   - fixed    → ₦X
 *   - estimate → ₦X - ₦Y
 *   - quote    → "Quote"
 *
 * CTA label is "Get Estimate" for all types (matches Blade logic).
 */

import { CardPricing } from "./card-pricing";
import {
  formatNaira,
  estimateUrl,
  type PricingTier,
} from "@/data/pricing";

export type PricingTierCardProps = {
  tier: PricingTier;
  unit?: string;
  /** Service key for building the estimate URL. */
  serviceKey: string;
  /** Variant key (only for variant-based services like boarding). */
  variantKey?: string | null;
  /** Tier key. */
  tierKey: string;
};

export function PricingTierCard({
  tier,
  unit = "",
  serviceKey,
  variantKey = null,
  tierKey,
}: PricingTierCardProps) {
  const priceDisplay = (() => {
    switch (tier.type) {
      case "estimate":
        // Match Alpine's `tier.amount_max || tier.amount` (waggies.js line 129).
        return `${formatNaira(tier.amount)} - ${formatNaira(tier.amount_max || tier.amount)}`;
      case "quote":
        return "Quote";
      default:
        return formatNaira(tier.amount);
    }
  })();

  // The Blade hardcodes ctaLabel = 'Get Estimate' for ALL tier types.
  const ctaLabel = "Get Estimate";
  const href = estimateUrl(serviceKey, variantKey, tierKey);

  return (
    <CardPricing
      variant={tier.featured ? "featured" : "standard"}
      tierLabel={tier.label}
      badgeLabel={tier.badge ?? "Most Popular"}
      price={priceDisplay}
      unit={unit}
      features={tier.features}
      ctaLabel={ctaLabel}
      ctaHref={href}
    />
  );
}
