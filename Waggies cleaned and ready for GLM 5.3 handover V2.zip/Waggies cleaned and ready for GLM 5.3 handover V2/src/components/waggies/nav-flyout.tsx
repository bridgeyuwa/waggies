"use client";

import Link from "next/link";
import { type RefObject, useEffect } from "react";
import { cn } from "@/lib/utils";
import { type MegaLink } from "@/lib/site";
import { PhosphorIcon } from "@/lib/phosphor-icons";

/**
 * NavFlyout — reusable single-column stacked flyout panel.
 *
 * Used for About, Tools, and Resources desktop flyouts which share
 * an identical structure (gradient header + stacked MegaLink rows).
 */
export function NavFlyout({
  links,
  isOpen,
  onClose,
  triggerRef,
  panelRef,
  align = "left",
  label,
}: {
  links: MegaLink[];
  isOpen: boolean;
  onClose: () => void;
  triggerRef: RefObject<HTMLElement | null>;
  panelRef: RefObject<HTMLDivElement | null>;
  align?: "left" | "right";
  /** Header label shown in the gradient bar. */
  label: string;
}) {
  const ref = panelRef;

  // Escape key + ArrowUp/ArrowDown keyboard handling.
  useEffect(() => {
    if (!isOpen) return;
    const el = ref.current;
    if (!el) return;

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        triggerRef.current?.focus();
        return;
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        const items = Array.from(el.querySelectorAll<HTMLElement>("[role=\"menuitem\"]"));
        if (items.length === 0) return;
        const idx = items.indexOf(document.activeElement as HTMLElement);
        const dir = e.key === "ArrowDown" ? 1 : -1;
        let next = idx + dir;
        if (next < 0) next = items.length - 1;
        if (next >= items.length) next = 0;
        items[next]?.focus();
      }
    };

    el.addEventListener("keydown", handleKey);
    return () => el.removeEventListener("keydown", handleKey);
  }, [isOpen, onClose, triggerRef, ref]);

  return (
    <div
      ref={ref}
      role="menu"
      aria-label={`${label} menu`}
      className={cn(
        "nav-dropdown nav-dropdown--stacked absolute top-full mt-1 transition ease-out duration-150",
        align === "left" ? "left-1/2 -translate-x-1/2" : "right-0",
        isOpen
          ? "opacity-100 translate-y-0"
          : "opacity-0 -translate-y-1 pointer-events-none",
      )}
      style={{ display: isOpen ? "block" : "none" }}
    >
      <div className="nav-dropdown__header">
        <p className="text-white/80 text-xs font-bold uppercase tracking-widest">
          {label}
        </p>
      </div>
      <div className="p-3 flex flex-col gap-0.5">
        {links.map((link) => (
          <NavFlyoutLink
            key={link.href}
            href={link.href}
            icon={link.icon}
            title={link.title}
            subtitle={link.subtitle}
          />
        ))}
      </div>
    </div>
  );
}

/**
 * Single link row inside a NavFlyout panel.
 * Identical to the MegaLink sub-component in navbar.tsx.
 */
function NavFlyoutLink({
  href,
  icon,
  title,
  subtitle,
}: {
  href: string;
  icon: string;
  title: string;
  subtitle: string;
}) {
  return (
    <Link
      href={href}
      role="menuitem"
      tabIndex={-1}
      className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-surface-purple transition-colors group focus-visible:outline-2 focus-visible:outline-primary focus-visible:outline-offset-2"
    >
      <div className="w-9 h-9 rounded-lg bg-surface-purple group-hover:bg-primary group-hover:text-white flex items-center justify-center text-primary transition-colors shrink-0">
        <PhosphorIcon name={icon} />
      </div>
      <div className="min-w-0">
        <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors leading-snug">
          {title}
        </p>
        {subtitle ? (
          <p className="text-xs text-primary-dark/50 leading-snug mt-0.5">
            {subtitle}
          </p>
        ) : null}
      </div>
    </Link>
  );
}
