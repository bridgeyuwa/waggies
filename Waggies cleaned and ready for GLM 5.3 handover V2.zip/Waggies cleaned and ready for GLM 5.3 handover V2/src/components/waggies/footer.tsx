/**
 * Waggies Footer — redesigned with full-width brand block,
 * separator, and 5-column responsive navigation grid.
 *
 * Structure:
 *   1. Newsletter strip (full width)
 *   2. Brand block (full width: logo, tagline, Follow Us)
 *   3. Separator line
 *   4. Navigation columns (2/3/5 responsive grid)
 *   5. Bottom bar (copyright + back-to-top)
 */

import Link from "next/link";
import {
  InstagramLogo,
  FacebookLogo,
  XLogo,
  TiktokLogo,
  YoutubeLogo,
  PawPrint,
} from "@phosphor-icons/react/dist/ssr";
import { BackToTopLink } from "./back-to-top-link";
import { NewsletterForm } from "./newsletter-form";
import {
  footerCopyright,
  footerLinkColumns,
  footerTagline,
} from "@/lib/site";
import { businessInfo } from "@/lib/business-info";

/** Social links using real URLs from businessInfo. */
const SOCIALS: {
  label: string;
  href: string;
  icon: typeof InstagramLogo;
}[] = [
  { label: "Instagram", href: businessInfo.socials.instagram, icon: InstagramLogo },
  { label: "Facebook", href: businessInfo.socials.facebook, icon: FacebookLogo },
  { label: "X (Twitter)", href: businessInfo.socials.x, icon: XLogo },
  { label: "TikTok", href: businessInfo.socials.tiktok, icon: TiktokLogo },
  { label: "YouTube", href: businessInfo.socials.youtube, icon: YoutubeLogo },
];

/** Check if a URL is external (not a relative path). */
function isExternal(href: string): boolean {
  return href.startsWith("http://") || href.startsWith("https://") || href.startsWith("tel:");
}

export function Footer() {
  return (
    <footer className="bg-primary-dark border-t border-white/10 mt-auto">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 pt-12 pb-8 sm:pt-16 lg:px-8 lg:pt-20">
        {/* ── Newsletter strip ──────────────────────────────── */}
        <div className="mb-10 lg:mb-12 rounded-2xl p-6 sm:p-8 border bg-white/5 border-white/10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 items-center">
            <div>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold mb-2 text-secondary">
                Newsletter
              </h3>
              <p className="text-sm sm:text-base max-w-md text-white/70">
                Pet care tips and updates from Waggies. No spam, unsubscribe
                anytime.
              </p>
            </div>
            <div>
              <NewsletterForm variant="inline" theme="dark" />
            </div>
          </div>
        </div>

        {/* ── Brand block (full width) ──────────────────────── */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
          <div className="flex flex-col sm:flex-row sm:items-center gap-4 sm:gap-6">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center">
                <PawPrint size={20} weight="fill" className="text-white" />
              </div>
              <span className="font-serif font-bold text-white text-xl">
                Waggies
              </span>
            </Link>

            <p className="text-sm text-white/70 max-w-md">
              {footerTagline}
            </p>
          </div>

          {/* Follow Us social icons */}
          <div className="flex items-center gap-4">
            <span className="text-label text-secondary whitespace-nowrap">
              Follow Us
            </span>
            <div className="flex gap-x-3">
              {SOCIALS.map((social) => {
                const Icon = social.icon;
                return (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-9 h-9 rounded-full bg-white/10 border border-white/10 text-white/70 hover:bg-primary hover:text-white hover:border-primary transition-colors flex items-center justify-center"
                    aria-label={social.label}
                  >
                    <Icon className="text-lg" weight="fill" />
                  </a>
                );
              })}
            </div>
          </div>
        </div>

        {/* ── Separator ─────────────────────────────────────── */}
        <div className="border-t border-white/10 my-10 lg:my-12" />

        {/* ── Navigation columns (responsive 2/3/5 grid) ──── */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-8 lg:gap-6">
          {footerLinkColumns.map((column, colIndex) => {
            const isBulleted = column.variant === "bulleted";
            const isSupport = column.heading === "Support";

            return (
              <div key={column.heading}>
                <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
                  {column.heading}
                </h3>
                <ul className="space-y-3">
                  {column.links.map((link) => {
                    const external = isExternal(link.href);

                    return (
                      <li key={link.href}>
                        {external ? (
                          <a
                            href={link.href}
                            target="_blank"
                            rel="noopener noreferrer"
                            className={
                              isBulleted
                                ? "flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                                : "text-sm text-white/60 hover:text-white transition-colors"
                            }
                          >
                            {isBulleted && (
                              <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                            )}
                            {link.label}
                          </a>
                        ) : (
                          <Link
                            href={link.href}
                            className={
                              isBulleted
                                ? "flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                                : "text-sm text-white/60 hover:text-white transition-colors"
                            }
                          >
                            {isBulleted && (
                              <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                            )}
                            {link.label}
                          </Link>
                        )}
                      </li>
                    );
                  })}
                </ul>

                {/* Support column: compact hours summary after links */}
                {isSupport && (
                  <div className="mt-5 pt-4 border-t border-white/10 space-y-1.5">
                    <p className="text-xs text-white/60">
                      <span className="font-medium text-white/60">
                        Mon-Fri:
                      </span>{" "}
                      9:00 AM - 5:00 PM
                    </p>
                    <p className="text-xs text-white/60">
                      <span className="font-medium text-white/60">
                        Sat-Sun:
                      </span>{" "}
                      10:00 AM - 2:00 PM
                    </p>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* ── Bottom bar ─────────────────────────────────────── */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs sm:text-sm/6 text-white/60">
            {footerCopyright}
          </p>
          <BackToTopLink className="text-xs sm:text-sm text-white/60 hover:text-white" />
        </div>
      </div>
    </footer>
  );
}
