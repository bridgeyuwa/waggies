"use client";

import { useRef } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";

type Direction = "left" | "right";

const directionOffsets: Record<Direction, number> = {
  left: -48,
  right: 48,
};

export type SlideInProps = {
  children: React.ReactNode;
  direction?: Direction;
  delay?: number;
  duration?: number;
  className?: string;
  amount?: number;
};

export function SlideIn({
  children,
  direction = "left",
  delay = 0,
  duration = 0.6,
  className,
  amount = 0.2,
}: SlideInProps) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, amount });
  const shouldReduceMotion = useReducedMotion();

  const x = directionOffsets[direction];

  return (
    <motion.div
      ref={ref}
      className={className}
      initial={shouldReduceMotion ? false : { opacity: 0, x }}
      animate={isInView ? { opacity: 1, x: 0 } : shouldReduceMotion ? { opacity: 1, x: 0 } : { opacity: 0, x }}
      transition={{
        duration: shouldReduceMotion ? 0 : duration,
        delay: shouldReduceMotion ? 0 : delay,
        ease: [0.25, 0.1, 0.25, 1],
      }}
    >
      {children}
    </motion.div>
  );
}
