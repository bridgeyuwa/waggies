"use client";

/**
 * Section heading block (B3).
 *
 * Faithful React reproduction of resources/views/components/section-heading.blade.php.
 *
 * Renders an eyebrow (small uppercase label), an h2 title (supports inline
 * HTML for `<br/>` and styled spans), and an optional subtitle paragraph.
 *
 * Wrapped in FadeIn for scroll-triggered animation.
 */

import { FadeIn } from "./motion";

export type SectionHeadingProps = {
  eyebrow?: string;
  title: string;
  subtitle?: string | null;
  /** Tailwind margin-bottom class. Default `mb-16`. */
  spacing?: string;
  /** Optional alignment override - Laravel component is always centered. */
  className?: string;
};

export function SectionHeading({
  eyebrow,
  title,
  subtitle,
  spacing = "mb-16",
  className = "",
}: SectionHeadingProps) {
  return (
    <FadeIn duration={0.4}>
      <div className={`text-center ${spacing} ${className}`}>
        {eyebrow ? (
          <span className="text-primary font-bold tracking-widest uppercase text-xs mb-3 block">
            {eyebrow}
          </span>
        ) : null}

        <h2
          className="font-serif text-3xl md:text-4xl font-bold text-primary-dark leading-tight mb-4"
          dangerouslySetInnerHTML={{ __html: title }}
        />

        {subtitle ? (
          <div className="text-primary-dark/50 max-w-2xl mx-auto">{subtitle}</div>
        ) : null}
      </div>
    </FadeIn>
  );
}
