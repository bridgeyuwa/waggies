/**
 * Day-in-the-life section: timeline + photo mosaic.
 *
 * Faithful React reproduction of
 * resources/views/components/boarding/day-in-life.blade.php.
 */

import { MaterialSymbol } from "./material-symbol";

export type DayInLifeStep = {
  icon: string;
  title: string;
  description: string;
};

export type DayInLifeImage = {
  src: string;
  alt: string;
  loading: "eager" | "lazy";
};

export type BoardingDayInLifeProps = {
  headingId?: string;
  heading?: string;
  subtitle?: string;
  schedule?: DayInLifeStep[];
  images?: DayInLifeImage[];
};

export function BoardingDayInLife({
  headingId = "daily-heading",
  heading = "A Day in the Life at Waggies",
  subtitle = "",
  schedule = [],
  images = [],
}: BoardingDayInLifeProps) {
  return (
    <section aria-labelledby={headingId} className="py-20 w-full bg-surface-purple">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <div className="flex flex-col lg:flex-row gap-12 items-center">
          <div className="flex-1 space-y-8">
            <div>
              <h2
                id={headingId}
                className="font-serif text-3xl md:text-4xl font-bold text-primary-dark leading-tight mb-4"
              >
                {heading}
              </h2>
              {subtitle ? (
                <p className="text-primary-dark/60 text-lg max-w-prose">
                  {subtitle}
                </p>
              ) : null}
            </div>

            <ol className="space-y-6" aria-label="Daily schedule">
              {schedule.map((step, index) => {
                const isFirst = index === 0;
                const isLast = index === schedule.length - 1;
                return (
                  <li
                    key={index}
                    className="grid grid-cols-[32px_1fr] gap-4 items-start"
                  >
                    <div
                      className={`flex items-center justify-center w-8 h-8 rounded-full ${isFirst || isLast ? "bg-primary" : "bg-primary/80"} border-4 border-white`}
                    >
                      <MaterialSymbol name={step.icon} className="text-sm text-white" />
                    </div>
                    <div>
                      <h3 className="font-serif font-bold text-primary-dark">
                        {step.title}
                      </h3>
                      <p className="text-sm text-primary-dark/60">
                        {step.description}
                      </p>
                    </div>
                  </li>
                );
              })}
            </ol>
          </div>

          {images.length >= 4 ? (
            <div className="flex-1 w-full" aria-hidden="true">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-4 pt-8">
                  { }
                  <img
                    loading={images[0].loading ?? "lazy"}
                    decoding="async"
                    className="rounded-2xl w-full h-48 object-cover shadow-[var(--shadow-soft)]"
                    alt={images[0].alt}
                    src={images[0].src}
                  />
                  { }
                  <img
                    loading={images[1].loading ?? "lazy"}
                    decoding="async"
                    className="rounded-2xl w-full h-64 object-cover shadow-[var(--shadow-soft)]"
                    alt={images[1].alt}
                    src={images[1].src}
                  />
                </div>
                <div className="space-y-4">
                  { }
                  <img
                    loading={images[2].loading ?? "lazy"}
                    decoding="async"
                    className="rounded-2xl w-full h-64 object-cover shadow-[var(--shadow-soft)]"
                    alt={images[2].alt}
                    src={images[2].src}
                  />
                  { }
                  <img
                    loading={images[3].loading ?? "lazy"}
                    decoding="async"
                    className="rounded-2xl w-full h-48 object-cover shadow-[var(--shadow-soft)]"
                    alt={images[3].alt}
                    src={images[3].src}
                  />
                </div>
              </div>
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
}
