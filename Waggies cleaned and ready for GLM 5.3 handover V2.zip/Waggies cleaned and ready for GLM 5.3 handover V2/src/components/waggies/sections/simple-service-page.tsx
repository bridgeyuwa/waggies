/**
 * Shared layout for the simple service pages (grooming, vet-care, training,
 * transport, relocation import/export) that all follow the same pattern:
 *
 *   <breadcrumb strip>
 *   <hero image>
 *   <section: feature grid (purple cards)>
 *   <feature band>
 *   <FAQ accordion (active FAQs for this category, with subcategory filter)>
 *   <JSON-LD Service schema>
 *
 * Each page is page-specific (different hero copy, different feature list,
 * different FAQ category) but the structural skeleton is shared. This
 * component encodes that skeleton so the page files stay readable.
 */

import type { ReactNode } from "react";
import type { Metadata } from "next";
import { HeroImage, type HeroCta } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ServiceFeatureGrid, type BoardingFeature } from "@/components/waggies/boarding-feature-grid";
import { FeatureBand, type FeatureBandFeature } from "@/components/waggies/feature-band";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { BreadcrumbStrip, type Crumb } from "@/components/waggies/breadcrumb";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import { getFaqsForService, type FaqCategory } from "@/data/faqs";

export type SimpleServicePageProps = {
  /** Page title for metadata. */
  title: string;
  description: string;
  canonical: string;
  ogTitle: string;
  ogDescription: string;

  /** Breadcrumb crumbs (excluding the implicit Home icon). */
  crumbs: Crumb[];

  /** Hero props. */
  hero: {
    imageSrc: string;
    eyebrow: string;
    title: string;
    subtitle: string;
    primaryCta: HeroCta;
    secondaryCta?: HeroCta;
  };

  /** Section heading above the feature grid. */
  featureSectionHeading: {
    eyebrow: string;
    title: string;
    subtitle?: string;
  };

  /** The 6-card feature grid (purple cards). */
  features: BoardingFeature[];

  /** Feature band (dark section). */
  featureBand: {
    eyebrow: string;
    title: string;
    subtitle: string;
    cta: { label: string; href: string };
    features: FeatureBandFeature[];
  };

  /** FAQ category to pull from the dataset. */
  faqCategory: FaqCategory;
  /** Optional subcategory filter (e.g. "import" or "export" for relocation). */
  faqSubcategory?: string | null;

  /** JSON-LD schema name. */
  schemaName: string;
  schemaDescription: string;
  schemaUrl: string;
  schemaAreaServed?: string;

  /** Optional extra sections inserted before the FAQ accordion. */
  children?: ReactNode;
};

export function SimpleServicePage({
  title,
  description,
  canonical,
  ogTitle,
  ogDescription,
  crumbs,
  hero,
  featureSectionHeading,
  features,
  featureBand,
  faqCategory,
  faqSubcategory = null,
  schemaName,
  schemaDescription,
  schemaUrl,
  schemaAreaServed = "Abuja, Nigeria",
  children,
}: SimpleServicePageProps) {
  const faqs = getFaqsForService(faqCategory, faqSubcategory);

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={crumbs}
      />

      <HeroImage {...hero} />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading {...featureSectionHeading} />
          <ServiceFeatureGrid features={features} />
        </div>
      </section>

      <FeatureBand {...featureBand} />

      {children}

      {faqs.length > 0 ? (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              spacing="mb-8"
            />
            <FaqAccordion
              faqs={faqs.map((f) => ({ question: f.question, answer: f.answer }))}
            />
            <p className="mt-6 text-sm text-primary-dark/50">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      ) : null}

      <JsonLd
        data={serviceSchema(schemaName, schemaDescription, schemaUrl, schemaAreaServed)}
      />
    </>
  );
}

// Re-export Metadata type for convenience so page files can declare
// `export const metadata: Metadata = ...` without an extra import.
export type { Metadata };
