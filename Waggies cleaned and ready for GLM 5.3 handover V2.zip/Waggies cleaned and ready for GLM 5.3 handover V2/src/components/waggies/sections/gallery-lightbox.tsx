/**
 * Gallery lightbox - interactive masonry-style image gallery with a
 * full-screen lightbox modal.
 *
 * Features:
 *   - CSS columns masonry layout (1 / 2 / 3 cols responsive)
 *   - Category filter pills (All + group eyebrows from the data)
 *   - Staggered entrance animation (framer-motion)
 *   - Hover overlay with zoom icon
 *   - Full-screen lightbox modal (z-[100])
 *   - Previous / Next navigation arrows
 *   - Image counter ("3 / 20")
 *   - Caption / category below image
 *   - Keyboard nav: Escape, Arrow Left, Arrow Right
 *   - Click backdrop to close
 *   - Touch swipe support (basic left/right)
 *   - AnimatePresence for open/close + slide transitions
 *
 * Waggies purple theme (#6B2C91) throughout.
 */

"use client";

import {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
  type PointerEvent as ReactPointerEvent,
} from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { useFocusTrap } from "@/lib/use-focus-trap";
import type { GalleryImageItem, GalleryGroup } from "@/data/gallery";

// ── Types ─────────────────────────────────────────────────────────────────

type GalleryImage = {
  src: string;
  alt: string;
  category: string;
  /** Original group title - used for the lightbox caption. */
  groupTitle: string;
  /** @internal Whether this image is a temporary stock placeholder. */
  _temporary: boolean;
};

export type GalleryLightboxProps = {
  groups: GalleryGroup[];
};

// ── Helpers ───────────────────────────────────────────────────────────────

function flattenGroups(groups: GalleryGroup[]): GalleryImage[] {
  return groups.flatMap((group) =>
    group.images.map((img: GalleryImageItem) => ({
      src: img.src,
      alt: img.alt,
      category: group.eyebrow,
      groupTitle: group.title,
      _temporary: img._temporary ?? group._temporary ?? false,
    })),
  );
}

// Pick a "tall" or "regular" height class for visual masonry rhythm.
function cellAspect(idx: number): string {
  // Cycle through varying heights so the columns layout looks organic.
  const cycle = idx % 5;
  switch (cycle) {
    case 0:
      return "aspect-[4/5]";
    case 1:
      return "aspect-square";
    case 2:
      return "aspect-[3/4]";
    case 3:
      return "aspect-[4/3]";
    default:
      return "aspect-[5/6]";
  }
}

// ── Component ─────────────────────────────────────────────────────────────

export function GalleryLightbox({ groups }: GalleryLightboxProps) {
  const shouldReduceMotion = useReducedMotion();
  const allImages = useMemo(() => flattenGroups(groups), [groups]);
  const categories = useMemo(() => {
    const seen = new Set<string>();
    const out: string[] = [];
    for (const g of groups) {
      if (!seen.has(g.eyebrow)) {
        seen.add(g.eyebrow);
        out.push(g.eyebrow);
      }
    }
    return out;
  }, [groups]);

  const [activeCategory, setActiveCategory] = useState<string>("All");
  const [lightboxIndex, setLightboxIndex] = useState<number | null>(null);

  const visibleImages = useMemo(() => {
    if (activeCategory === "All") return allImages;
    return allImages.filter((img) => img.category === activeCategory);
  }, [allImages, activeCategory]);

  const open = lightboxIndex !== null;

  const closeLightbox = useCallback(() => setLightboxIndex(null), []);
  const goNext = useCallback(() => {
    setLightboxIndex((curr) => {
      if (curr === null) return curr;
      return (curr + 1) % visibleImages.length;
    });
  }, [visibleImages.length]);
  const goPrev = useCallback(() => {
    setLightboxIndex((curr) => {
      if (curr === null) return curr;
      return (curr - 1 + visibleImages.length) % visibleImages.length;
    });
  }, [visibleImages.length]);

  // Keyboard navigation.
  useEffect(() => {
    if (!open) return;
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") closeLightbox();
      else if (e.key === "ArrowRight") goNext();
      else if (e.key === "ArrowLeft") goPrev();
    }
    window.addEventListener("keydown", onKey);
    // Lock body scroll while lightbox is open.
    const prevOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = prevOverflow;
    };
  }, [open, closeLightbox, goNext, goPrev]);

  const currentImage =
    lightboxIndex !== null ? visibleImages[lightboxIndex] : null;

  return (
    <div>
      {/* Filter pills */}
      <div className="flex flex-wrap items-center justify-center gap-2 mb-10">
        {["All", ...categories].map((cat) => {
          const active = activeCategory === cat;
          return (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={`relative px-5 py-2.5 rounded-full text-sm font-semibold transition-colors min-h-[44px] ${
                active
                  ? "text-white"
                  : "text-primary-dark/70 hover:text-primary-dark hover:bg-surface-purple/60"
              }`}
            >
              {active ? (
                <motion.span
                  layoutId="gallery-pill"
                  className="absolute inset-0 rounded-full bg-primary shadow-sm"
                  transition={{ type: "spring", damping: 26, stiffness: 320, duration: shouldReduceMotion ? 0 : undefined }}
                />
              ) : null}
              <span className="relative z-10">{cat}</span>
            </button>
          );
        })}
      </div>

      {/* Masonry grid via CSS columns */}
      <motion.div
        layout
        className="columns-1 sm:columns-2 lg:columns-3 gap-4 [column-fill:_balance]"
      >
        <AnimatePresence mode="popLayout">
          {visibleImages.map((img, i) => (
            <motion.button
              key={`${img.src}-${i}`}
              type="button"
              layout
              initial={shouldReduceMotion ? false : { opacity: 0, y: 24, scale: 0.96 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={shouldReduceMotion ? undefined : { opacity: 0, scale: 0.96 }}
              transition={{
                duration: shouldReduceMotion ? 0 : 0.45,
                delay: shouldReduceMotion ? 0 : Math.min(i * 0.04, 0.4),
                ease: [0.25, 0.1, 0.25, 1],
              }}
              onClick={() => setLightboxIndex(i)}
              className="group relative block w-full mb-4 break-inside-avoid rounded-xl overflow-hidden bg-surface-purple shadow-sm hover:shadow-[0_20px_40px_-15px_rgba(107,44,145,0.4)] transition-shadow cursor-zoom-in"
              aria-label={`Open ${img.alt} in lightbox`}
            >
              { }
              <img
                src={img.src}
                alt={img.alt}
                loading="lazy"
                className={`w-full ${cellAspect(i)} object-cover transition-transform duration-500 group-hover:scale-[1.05]`}
              />
              {/* Hover overlay */}
              <div className="absolute inset-0 bg-gradient-to-t from-primary-dark/70 via-primary/10 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end p-4">
                <div className="flex items-center gap-2 text-white">
                  <span className="grid place-items-center w-9 h-9 rounded-full bg-white/20 backdrop-blur-sm border border-white/40">
                    <MaterialSymbol name="zoom_in" className="text-lg" />
                  </span>
                  <div className="flex flex-col leading-tight">
                    <span className="text-[10px] uppercase tracking-wide opacity-80">
                      {img.category}
                    </span>
                    <span className="text-sm font-semibold">{img.alt}</span>
                  </div>
                </div>
              </div>
              {/* Category chip (always visible) */}
              <span className="absolute top-3 left-3 px-2.5 py-1 rounded-full bg-white/85 backdrop-blur-sm text-[10px] font-semibold uppercase tracking-wide text-primary-dark">
                {img.category}
              </span>
            </motion.button>
          ))}
        </AnimatePresence>
      </motion.div>

      {/* Lightbox modal */}
      <AnimatePresence>
        {open && currentImage ? (
          <LightboxModal
            key="lightbox"
            image={currentImage}
            index={lightboxIndex ?? 0}
            total={visibleImages.length}
            onClose={closeLightbox}
            onNext={goNext}
            onPrev={goPrev}
          />
        ) : null}
      </AnimatePresence>
    </div>
  );
}

// ── Lightbox modal ───────────────────────────────────────────────────────

function LightboxModal({
  image,
  index,
  total,
  onClose,
  onNext,
  onPrev,
}: {
  image: GalleryImage;
  index: number;
  total: number;
  onClose: () => void;
  onNext: () => void;
  onPrev: () => void;
}) {
  // Focus trap for the lightbox dialog
  const containerRef = useFocusTrap<HTMLDivElement>(true);
  // Touch/pointer swipe handling - basic left/right.
  const pointerStartX = useRef<number | null>(null);
  const pointerStartY = useRef<number | null>(null);

  function handlePointerStart(e: ReactPointerEvent<HTMLDivElement>) {
    pointerStartX.current = e.clientX;
    pointerStartY.current = e.clientY;
  }
  function handlePointerEnd(e: ReactPointerEvent<HTMLDivElement>) {
    if (pointerStartX.current === null || pointerStartY.current === null) return;
    const dx = e.clientX - pointerStartX.current;
    const dy = e.clientY - pointerStartY.current;
    pointerStartX.current = null;
    pointerStartY.current = null;
    // Horizontal-dominant swipe with a minimum threshold.
    if (Math.abs(dx) < 50 || Math.abs(dx) < Math.abs(dy)) return;
    if (dx < 0) onNext();
    else onPrev();
  }

  function handleBackdropClick(e: React.MouseEvent<HTMLDivElement>) {
    if (e.target === e.currentTarget) onClose();
  }

  // Slide direction is handled implicitly - we just key the motion.img on
  // the current image src so it re-mounts and plays the slide animation.
  return (
    <motion.div
      ref={containerRef}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
      className="fixed inset-0 z-[100] bg-primary-dark/95 backdrop-blur-sm flex flex-col"
      role="dialog"
      aria-modal="true"
      aria-label={`Image lightbox ${index + 1} of ${total}`}
      onClick={handleBackdropClick}
    >
      {/* Top bar: counter + close */}
      <div className="flex items-center justify-between px-4 sm:px-8 py-4 text-white/80 text-sm">
        <span className="font-semibold tracking-wide">
          {index + 1} <span className="text-white/40">/</span> {total}
        </span>
        <button
          type="button"
          onClick={onClose}
          className="grid place-items-center w-11 h-11 rounded-full bg-white/10 hover:bg-white/20 backdrop-blur-sm border border-white/15 text-white transition"
          aria-label="Close lightbox"
        >
          <MaterialSymbol name="close" className="text-xl" />
        </button>
      </div>

      {/* Image stage */}
      <div
        className="relative flex-1 flex items-center justify-center px-4 sm:px-20 pb-6"
        onPointerDown={handlePointerStart}
        onPointerUp={handlePointerEnd}
      >
        {/* Prev arrow */}
        <NavArrow direction="prev" onClick={onPrev} />

        <AnimatePresence mode="wait">
          <motion.figure
            key={image.src}
            initial={false}
            animate={{ opacity: 1, x: 0, scale: 1 }}
            transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
            className="flex flex-col items-center max-w-[90vw] max-h-[80vh]"
          >
            { }
            <img
              src={image.src}
              alt={image.alt}
              className="max-h-[78vh] max-w-full object-contain rounded-lg shadow-[0_30px_80px_-20px_rgba(0,0,0,0.6)]"
            />
            <figcaption className="mt-4 text-center text-white/85">
              <span className="text-[11px] uppercase tracking-wider text-primary-light font-semibold">
                {image.category}
              </span>
              <span className="mx-2 text-white/30">·</span>
              <span className="text-sm">{image.groupTitle}</span>
            </figcaption>
          </motion.figure>
        </AnimatePresence>

        {/* Next arrow */}
        <NavArrow direction="next" onClick={onNext} />
      </div>

      {/* Hint footer (mobile) */}
      <div className="pb-4 text-center text-[11px] text-white/40 sm:hidden">
        Swipe to navigate · tap outside to close
      </div>
    </motion.div>
  );
}

// ── Nav arrow button ──────────────────────────────────────────────────────

function NavArrow({
  direction,
  onClick,
}: {
  direction: "prev" | "next";
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`absolute top-1/2 -translate-y-1/2 ${
        direction === "prev" ? "left-2 sm:left-6" : "right-2 sm:right-6"
      } grid place-items-center w-12 h-12 sm:w-14 sm:h-14 rounded-full bg-white/10 hover:bg-white/25 backdrop-blur-md border border-white/15 text-white transition group`}
      aria-label={direction === "prev" ? "Previous image" : "Next image"}
    >
      <MaterialSymbol
        name={direction === "prev" ? "chevron_left" : "chevron_right"}
        className="text-2xl group-hover:scale-110 transition-transform"
      />
    </button>
  );
}
