"use client";

/**
 * ServicePageEnhanced - rich, animated service detail page wrapper.
 *
 * Provides:
 *   - Hero section with parallax image background (framer-motion useScroll/useTransform)
 *   - Staggered FadeIn animation for content blocks
 *   - Features grid (2×3 on desktop, 1 col mobile) with check icons
 *   - Benefits section with alternating left/right layout
 *   - Optional pricing packages section
 *   - Optional FAQ accordion
 *   - CTA section with pulse-glow animation on button
 *
 * All sections use the existing motion components (FadeIn, StaggerChildren, SlideIn).
 */

import { useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { FadeIn, StaggerChildren, staggerItemVariants } from "@/components/waggies/motion";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { WaggiesImage } from "@/components/waggies/waggies-image";

export type ServicePackage = {
  name: string;
  price: string;
  duration?: string;
  features: string[];
  popular?: boolean;
};

export type ServicePageEnhancedProps = {
  /** Page title */
  title: string;
  /** Short subtitle shown in hero */
  subtitle: string;
  /** Longer description shown below hero */
  description?: string;
  /** Feature list items */
  features: string[];
  /** Benefits list items */
  benefits: string[];
  /** Hero image src */
  imageSrc: string;
  /** Hero image alt */
  imageAlt: string;
  /** CTA button text */
  ctaText: string;
  /** CTA button href */
  ctaHref: string;
  /** Optional pricing packages */
  packages?: ServicePackage[];
  /** Optional FAQ items */
  faqItems?: Array<{ question: string; answer: string }>;
  /** Optional eyebrow text for hero */
  eyebrow?: string;
};

export function ServicePageEnhanced({
  title,
  subtitle,
  description,
  features,
  benefits,
  imageSrc,
  imageAlt,
  ctaText,
  ctaHref,
  packages,
  faqItems,
  eyebrow,
}: ServicePageEnhancedProps) {
  const heroRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"],
  });

  // Parallax: background image shifts up slightly as user scrolls
  const bgY = useTransform(scrollYProgress, [0, 1], ["0%", "15%"]);

  return (
    <>
      {/* ── Hero Section with Parallax ──────────────────────────────────── */}
      <section
        ref={heroRef}
        className="relative flex flex-col justify-end overflow-hidden"
        style={{ minHeight: "480px" }}
        aria-label={title}
        role="img"
        aria-roledescription="hero"
      >
        {/* Parallax background image */}
        <motion.div
          className="absolute inset-0"
          style={{ y: bgY, scale: 1.08 }}
        >
          <WaggiesImage
            src={imageSrc}
            alt={imageAlt}
            fill
            priority
            sizes="100vw"
            className="absolute inset-0"
          />
        </motion.div>

        {/* Gradient overlay */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.65) 100%)",
          }}
        />

        {/* Content */}
        <div className="max-w-7xl mx-auto w-full px-4 md:px-10 lg:px-12 py-12 md:py-16 relative z-10">
          <motion.div
            className="max-w-xl"
            initial="hidden"
            animate="visible"
            variants={{
              hidden: {},
              visible: { transition: { staggerChildren: 0.12, delayChildren: 0.1 } },
            }}
          >
            {eyebrow && (
              <motion.span
                variants={{
                  hidden: { opacity: 0, y: 20 },
                  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const } },
                }}
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-4 bg-white/15 border border-white/25 text-white text-xs font-bold uppercase tracking-widest backdrop-blur-sm"
              >
                <MaterialSymbol name="star" filled className="text-sm text-secondary" />
                {eyebrow}
              </motion.span>
            )}

            <motion.h1
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const } },
              }}
              className="font-serif text-4xl md:text-5xl font-bold text-white leading-tight mb-4"
            >
              {title}
            </motion.h1>

            <motion.p
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const } },
              }}
              className="text-white/75 text-base mb-6 leading-relaxed"
            >
              {subtitle}
            </motion.p>

            <motion.div
              variants={{
                hidden: { opacity: 0, y: 20 },
                visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const } },
              }}
            >
              <a
                href={ctaHref}
                className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white font-bold px-8 py-3.5 rounded-full transition"
              >
                {ctaText}
                <MaterialSymbol name="arrow_forward" className="text-base" />
              </a>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* ── Description ─────────────────────────────────────────────────── */}
      {description && (
        <FadeIn className="py-12 bg-white">
          <div className="max-w-3xl mx-auto px-4 md:px-10 lg:px-12 text-center">
            <p className="text-primary-dark/70 text-lg leading-relaxed">
              {description}
            </p>
          </div>
        </FadeIn>
      )}

      {/* ── Features Grid ───────────────────────────────────────────────── */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <FadeIn>
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark text-center mb-4">
              What&apos;s Included
            </h2>
            <p className="text-primary-dark/60 text-center mb-12 max-w-2xl mx-auto">
              Every service is delivered with care, professionalism, and attention to detail.
            </p>
          </FadeIn>

          <StaggerChildren
            staggerDelay={0.06}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          >
            {features.map((feature, i) => (
              <motion.div
                key={i}
                variants={staggerItemVariants}
                className="bg-surface-purple rounded-2xl p-6 flex gap-4 hover:shadow-soft transition-shadow"
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <MaterialSymbol
                    name="check_circle"
                    filled
                    className="text-primary"
                  />
                </div>
                <p className="text-primary-dark/80 leading-relaxed font-medium">
                  {feature}
                </p>
              </motion.div>
            ))}
          </StaggerChildren>
        </div>
      </section>

      {/* ── Benefits Section (alternating layout) ───────────────────────── */}
      <section className="py-20 bg-surface-purple/40">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <FadeIn>
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark text-center mb-4">
              Why Choose Us
            </h2>
            <p className="text-primary-dark/60 text-center mb-12 max-w-2xl mx-auto">
              Trusted by hundreds of pet owners across Abuja.
            </p>
          </FadeIn>

          <StaggerChildren
            staggerDelay={0.08}
            className="flex flex-col gap-8"
          >
            {benefits.map((benefit, i) => {
              const isEven = i % 2 === 0;
              return (
                <motion.div
                  key={i}
                  variants={staggerItemVariants}
                  className={`flex flex-col md:flex-row items-center gap-6 md:gap-10 ${
                    isEven ? "" : "md:flex-row-reverse"
                  }`}
                >
                  <div className="flex-1 flex items-start gap-4">
                    <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                      <MaterialSymbol
                        name={isEven ? "verified" : "favorite"}
                        filled
                        className="text-primary text-xl"
                      />
                    </div>
                    <p className="text-primary-dark/80 leading-relaxed text-lg">
                      {benefit}
                    </p>
                  </div>
                  {/* Decorative divider dot */}
                  <div className="hidden md:block w-3 h-3 rounded-full bg-primary/20 shrink-0" />
                  <div className="flex-1" />
                </motion.div>
              );
            })}
          </StaggerChildren>
        </div>
      </section>

      {/* ── Pricing Packages ────────────────────────────────────────────── */}
      {packages && packages.length > 0 && (
        <section className="py-20 bg-white">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <FadeIn>
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark text-center mb-4">
                Packages &amp; Pricing
              </h2>
              <p className="text-primary-dark/60 text-center mb-12 max-w-2xl mx-auto">
                Choose the package that best suits your pet&apos;s needs.
              </p>
            </FadeIn>

            <StaggerChildren
              staggerDelay={0.08}
              className="grid grid-cols-1 md:grid-cols-3 gap-8"
            >
              {packages.map((pkg, i) => (
                <motion.div
                  key={i}
                  variants={staggerItemVariants}
                  className={`relative bg-white border rounded-2xl p-8 flex flex-col gap-4 transition-shadow hover:shadow-soft ${
                    pkg.popular
                      ? "border-primary shadow-sm"
                      : "border-surface-purple"
                  }`}
                >
                  {pkg.popular && (
                    <span className="absolute -top-3 left-1/2 -translate-x-1/2 bg-primary text-white text-[10px] font-bold px-4 py-1 rounded-full uppercase tracking-wider">
                      Most Popular
                    </span>
                  )}

                  <h3 className="font-serif text-xl font-bold text-primary-dark">
                    {pkg.name}
                  </h3>

                  {pkg.duration && (
                    <p className="text-xs text-primary-dark/50 uppercase tracking-wider font-medium">
                      {pkg.duration}
                    </p>
                  )}

                  <p className="font-serif text-3xl font-bold text-primary">
                    {pkg.price}
                  </p>

                  <ul className="flex flex-col gap-2 mt-2">
                    {pkg.features.map((f, j) => (
                      <li
                        key={j}
                        className="flex items-start gap-2 text-sm text-primary-dark/70"
                      >
                        <MaterialSymbol
                          name="check_circle"
                          filled
                          className="text-primary text-base shrink-0 mt-0.5"
                        />
                        {f}
                      </li>
                    ))}
                  </ul>

                  <a
                    href={ctaHref}
                    className={`mt-auto inline-flex items-center justify-center gap-2 py-3 rounded-full font-semibold text-sm transition ${
                      pkg.popular
                        ? "bg-primary hover:bg-primary-dark text-white"
                        : "border-2 border-primary text-primary hover:bg-primary hover:text-white"
                    }`}
                  >
                    {ctaText}
                    <MaterialSymbol name="arrow_forward" className="text-sm" />
                  </a>
                </motion.div>
              ))}
            </StaggerChildren>
          </div>
        </section>
      )}

      {/* ── FAQ Accordion ───────────────────────────────────────────────── */}
      {faqItems && faqItems.length > 0 && (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <FadeIn>
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark text-center mb-8">
                Frequently Asked Questions
              </h2>
            </FadeIn>
            <FaqAccordion faqs={faqItems} />
            <p className="mt-6 text-sm text-primary-dark/50 text-center">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      )}

      {/* ── CTA Section ─────────────────────────────────────────────────── */}
      <section className="py-16 bg-primary-dark">
        <FadeIn>
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h2 className="font-serif text-2xl md:text-3xl font-bold text-white mb-2">
                Ready to Get Started?
              </h2>
              <p className="text-white/70">
                Book your {title.toLowerCase()} appointment today and give your pet the care they deserve.
              </p>
            </div>
            <a
              href={ctaHref}
              className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark font-bold px-8 py-3.5 rounded-full transition shrink-0"
            >
              {ctaText}
              <MaterialSymbol name="arrow_forward" className="text-base" />
            </a>
          </div>
        </FadeIn>
      </section>
    </>
  );
}
