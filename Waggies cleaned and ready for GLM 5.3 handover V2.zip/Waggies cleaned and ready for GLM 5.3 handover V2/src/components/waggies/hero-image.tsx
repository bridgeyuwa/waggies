"use client";

/**
 * Hero - full-bleed background image with gradient overlay.
 *
 * Simplified: gradient overlay + vignette + staggered text entrance.
 */

import { useRef } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { MaterialSymbol } from "./material-symbol";
import { CtaButtons } from "./cta-buttons";

export type HeroCta = {
  label: string;
  href: string;
  icon?: string;
  iconBefore?: string;
};

export type HeroImageProps = {
  imageSrc: string;
  imageAlt?: string | null;
  eyebrow?: string;
  eyebrowIcon?: string;
  title: string;
  subtitle?: string;
  primaryCta?: HeroCta | null;
  secondaryCta?: HeroCta | null;
  minHeight?: string;
  variant?: "bottom" | "center";
  overlay?: "light" | "dark";
  children?: React.ReactNode;
};

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.12, delayChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function HeroImage({
  imageSrc,
  imageAlt,
  eyebrow,
  eyebrowIcon = "star",
  title,
  subtitle,
  primaryCta,
  secondaryCta,
  minHeight = "560px",
  variant = "bottom",
  overlay = "dark",
  children,
}: HeroImageProps) {
  const sectionRef = useRef<HTMLElement>(null);
  const shouldReduceMotion = useReducedMotion();

  const gradient =
    overlay === "light"
      ? "linear-gradient(rgba(62,26,87,0.10) 0%, rgba(62,26,87,0.80) 100%)"
      : "linear-gradient(rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.65) 100%)";

  const alt = imageAlt ?? title.replace(/<[^>]*>/g, "");

  return (
    <section
      ref={sectionRef}
      className={`relative flex flex-col overflow-hidden ${
        variant === "center" ? "justify-center" : "justify-end"
      }`}
      style={{ minHeight }}
      aria-label={title.replace(/<[^>]*>/g, "")}
      role="img"
      aria-roledescription="hero"
    >
      <div
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url('${imageSrc}')` }}
      />

      <div className="absolute inset-0" style={{ background: gradient }} />

      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 70% 60% at 50% 50%, transparent 50%, rgba(0,0,0,0.3) 100%)",
        }}
      />

      <div className="max-w-7xl mx-auto w-full px-4 md:px-10 lg:px-12 py-12 md:py-16 relative z-10">
        <motion.div
          className="relative z-10 max-w-xl"
          variants={shouldReduceMotion ? undefined : containerVariants}
          initial={shouldReduceMotion ? false : "hidden"}
          animate={shouldReduceMotion ? false : "visible"}
        >
          {eyebrow ? (
            <motion.span
              variants={itemVariants}
              className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-4 bg-white/15 border border-white/25 text-white text-xs font-bold uppercase tracking-widest backdrop-blur-sm"
            >
              <MaterialSymbol
                name={eyebrowIcon}
                filled
                className="text-sm text-secondary"
              />
              {eyebrow}
            </motion.span>
          ) : null}

          <motion.h1
            variants={itemVariants}
            className="font-serif text-4xl md:text-5xl font-bold text-white leading-tight mb-4 text-balance"
            dangerouslySetInnerHTML={{ __html: title }}
          />

          {subtitle ? (
            <motion.p
              variants={itemVariants}
              className="text-white/75 text-base mb-6 leading-relaxed"
            >
              {subtitle}
            </motion.p>
          ) : null}

          {primaryCta || secondaryCta || children ? (
            children ? (
              <motion.div variants={itemVariants} className="flex flex-wrap gap-3">
                {children}
              </motion.div>
            ) : (
              <motion.div variants={itemVariants}>
                <CtaButtons
                  primary={primaryCta ?? undefined}
                  secondary={secondaryCta ?? undefined}
                  variant="overlay"
                />
              </motion.div>
            )
          ) : null}
        </motion.div>
      </div>

      <span className="sr-only">{alt}</span>
    </section>
  );
}
