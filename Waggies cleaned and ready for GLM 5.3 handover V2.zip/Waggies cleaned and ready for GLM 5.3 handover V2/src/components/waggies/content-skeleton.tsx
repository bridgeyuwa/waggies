/**
 * Content Skeleton - beautiful loading states for cards.
 *
 * Provides shimmer-animated skeleton placeholders that match the visual
 * structure of ServiceCard, CardBlog, and ProductCard. Uses a purple-tinted
 * shimmer sweep (left-to-right gradient) for brand consistency.
 *
 * Exports: ServiceCardSkeleton, BlogCardSkeleton, ProductCardSkeleton
 */

export function ServiceCardSkeleton() {
  return (
    <div className="bg-white rounded-2xl overflow-hidden shadow-sm">
      {/* Image skeleton */}
      <div className="h-48 shimmer rounded-none" />

      {/* Body skeleton */}
      <div className="p-6 space-y-4">
        {/* Title */}
        <div className="h-6 w-3/4 shimmer rounded-lg" />
        {/* Description (2 lines) */}
        <div className="space-y-2">
          <div className="h-4 w-full shimmer rounded-lg" />
          <div className="h-4 w-2/3 shimmer rounded-lg" />
        </div>
        {/* CTA */}
        <div className="h-4 w-24 shimmer rounded-lg" />
      </div>
    </div>
  );
}

export function BlogCardSkeleton() {
  return (
    <div className="bg-white border border-surface-purple rounded-2xl overflow-hidden">
      {/* Image skeleton */}
      <div className="h-52 w-full shimmer rounded-none" />

      {/* Body skeleton */}
      <div className="p-6 flex flex-col flex-1 gap-3">
        {/* Meta row */}
        <div className="flex items-center gap-2 mb-1">
          <div className="h-5 w-16 shimmer rounded-full" />
          <div className="h-4 w-12 shimmer rounded-lg" />
        </div>
        {/* Title */}
        <div className="h-6 w-4/5 shimmer rounded-lg" />
        {/* Excerpt (2 lines) */}
        <div className="space-y-2">
          <div className="h-4 w-full shimmer rounded-lg" />
          <div className="h-4 w-3/5 shimmer rounded-lg" />
        </div>
        {/* Footer */}
        <div className="flex items-center justify-between mt-4 pt-4 border-t border-surface-purple">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full shimmer" />
            <div className="space-y-1">
              <div className="h-3 w-16 shimmer rounded" />
              <div className="h-2 w-20 shimmer rounded" />
            </div>
          </div>
          <div className="h-4 w-12 shimmer rounded-lg" />
        </div>
      </div>
    </div>
  );
}

export function ProductCardSkeleton() {
  return (
    <div className="bg-white border border-surface-purple rounded-2xl overflow-hidden flex flex-col shadow-soft">
      {/* Image skeleton */}
      <div className="h-44 bg-surface-purple shimmer rounded-none relative">
        {/* Wishlist placeholder */}
        <div className="absolute top-3 right-3 w-9 h-9 rounded-full bg-white/80 shimmer" />
      </div>

      {/* Body skeleton */}
      <div className="p-4 flex flex-col flex-1 gap-3">
        {/* Category */}
        <div className="h-3 w-14 shimmer rounded" />
        {/* Title */}
        <div className="h-4 w-full shimmer rounded-lg" />
        {/* Rating */}
        <div className="flex items-center gap-1.5">
          <div className="h-4 w-4 shimmer rounded-full" />
          <div className="h-3 w-8 shimmer rounded" />
          <div className="h-3 w-12 shimmer rounded" />
        </div>
        {/* Price */}
        <div className="flex items-center gap-2 mt-auto">
          <div className="h-6 w-20 shimmer rounded-lg" />
        </div>
        {/* CTA button */}
        <div className="h-10 w-full shimmer rounded-full" />
      </div>
    </div>
  );
}
