/**
 * HeroPlain - React port of resources/views/components/hero/plain.blade.php
 *
 * Light-background hero with eyebrow + h1 + subtitle + optional CTAs +
 * optional centered image. Used by the Contact page (and possibly others).
 *
 * DO NOT confuse with HeroImage (full-bleed background image hero).
 *
 */

import { type ReactNode } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { CtaButtons } from "@/components/waggies/cta-buttons";
import { type HeroCta } from "@/components/waggies/hero-image";

export type HeroPlainProps = {
  eyebrow?: string | null;
  /** Either a Material Symbol name string, or a ReactNode for custom icons (e.g. Phosphor) */
  eyebrowIcon?: string | ReactNode | null;
  title: string;
  subtitle?: string | null;
  align?: "center" | "left";
  imageSrc?: string | null;
  imageAlt?: string | null;
  primaryCta?: HeroCta | null;
  secondaryCta?: HeroCta | null;
  children?: ReactNode;
};

export function HeroPlain({
  eyebrow,
  eyebrowIcon,
  title,
  subtitle,
  align = "center",
  imageSrc,
  imageAlt,
  primaryCta,
  secondaryCta,
  children,
}: HeroPlainProps) {
  const isLeft = align === "left";
  const alt = imageAlt ?? title.replace(/<[^>]*>/g, "");

  return (
    <section className="w-full py-20 md:py-28 bg-white">
      <div className="max-w-4xl mx-auto px-4 md:px-6">
        <div
          className={`flex flex-col gap-6 ${isLeft ? "text-left items-start" : "text-center items-center"}`}
        >
          {eyebrow || eyebrowIcon ? (
            <span className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-primary/60">
              {eyebrowIcon
                ? typeof eyebrowIcon === "string"
                  ? <MaterialSymbol name={eyebrowIcon} className="text-sm text-secondary" />
                  : eyebrowIcon
                : null}
              {eyebrow}
            </span>
          ) : null}

          <h1
            className="font-serif text-3xl md:text-4xl lg:text-5xl font-bold text-primary-dark leading-tight text-balance"
            dangerouslySetInnerHTML={{ __html: title }}
          />

          {subtitle ? (
            <p className="text-primary-dark/60 text-base leading-relaxed max-w-2xl">
              {subtitle}
            </p>
          ) : null}

          {primaryCta || secondaryCta || children ? (
            children ? (
              <div className={`flex flex-wrap gap-3 ${isLeft ? "sm:justify-start" : "sm:justify-center"} mt-4`}>
                {children}
              </div>
            ) : (
              <CtaButtons
                primary={primaryCta ?? undefined}
                secondary={secondaryCta ?? undefined}
                variant="plain"
                className={`${isLeft ? "sm:justify-start" : "sm:justify-center"} mt-4`}
              />
            )
          ) : null}

          {imageSrc ? (
            <div className="mt-10 w-full flex justify-center">
              <img
                src={imageSrc}
                alt={alt}
                className="w-full max-w-md md:max-w-lg rounded-2xl shadow-md object-cover"
                loading="lazy"
              />
            </div>
          ) : null}
        </div>
      </div>
    </section>
  );
}
