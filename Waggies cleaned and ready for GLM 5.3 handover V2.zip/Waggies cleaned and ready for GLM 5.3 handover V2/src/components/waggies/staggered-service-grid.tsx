"use client";

/**
 * StaggeredServiceGrid - client component that renders service cards
 * with staggered animation using framer-motion.
 *
 * Extracted from the server-side page.tsx so that motion.div can
 * run on the client without RSC boundary violations.
 */

import { motion } from "framer-motion";
import { ServiceCard, type ServiceCardProps } from "@/components/waggies/card-service";

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.1 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 30 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.16, 1, 0.3, 1] as const },
  },
};

export function StaggeredServiceGrid({
  cards,
}: {
  cards: ServiceCardProps[];
}) {
  return (
    <motion.div
      className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-50px" }}
    >
      {cards.map((card, i) => (
        <motion.div key={i} variants={itemVariants}>
          <ServiceCard {...card} />
        </motion.div>
      ))}
    </motion.div>
  );
}
