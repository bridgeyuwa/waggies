"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { useCartStore } from "@/store/cart-store";
import { ProductCard, formatPrice } from "./product-card";
import { RecentlyViewed } from "./recently-viewed";
import type { Product } from "@/data/shop-data";

export type ProductDetailClientProps = {
  product: Product;
  relatedProducts: Product[];
};

export function ProductDetailClient({
  product,
  relatedProducts,
}: ProductDetailClientProps) {
  const [quantity, setQuantity] = useState(1);
  const addItem = useCartStore((s) => s.addItem);

  // Track recently viewed
  useEffect(() => {
    if (typeof window === "undefined") return;
    try {
      const raw = localStorage.getItem("waggies-recently-viewed");
      const viewed: string[] = raw ? JSON.parse(raw) : [];
      const filtered = viewed.filter((id) => id !== product.id);
      filtered.unshift(product.id);
      localStorage.setItem(
        "waggies-recently-viewed",
        JSON.stringify(filtered.slice(0, 10)),
      );
      window.dispatchEvent(new Event("waggies-recently-viewed-change"));
    } catch {
      // ignore localStorage errors
    }
  }, [product.id]);

  const handleAddToCart = () => {
    for (let i = 0; i < quantity; i++) {
      addItem({
        productId: product.id,
        name: product.name,
        price: product.price,
        imageSrc: product.imageSrc,
      });
    }
  };

  return (
    <>
      <section className="bg-surface pb-16 md:pb-24">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-10 md:gap-16">
            {/* Image */}
            <div className="relative aspect-square rounded-2xl overflow-hidden bg-white">
              <img
                src={product.imageSrc}
                alt={product.name}
                className="w-full h-full object-cover"
              />
              {product.badge ? (
                <span className="absolute top-4 left-4 bg-primary text-white text-xs font-bold uppercase tracking-wider px-3 py-1.5 rounded-full">
                  {product.badge}
                </span>
              ) : null}
            </div>

            {/* Details */}
            <div className="flex flex-col gap-5">
              <div>
                <p className="text-xs font-medium text-primary/60 uppercase tracking-wider mb-2">
                  {product.category}
                </p>
                <h1 className="font-serif text-2xl md:text-3xl font-bold text-primary-dark leading-tight">
                  {product.name}
                </h1>
              </div>

              <p className="text-2xl font-bold text-primary-dark">
                {formatPrice(product.price)}
              </p>

              <p className="text-primary-dark/60 text-sm leading-relaxed">
                {product.description}
              </p>

              {/* Features list */}
              {product.features.length > 0 ? (
                <ul className="flex flex-col gap-2">
                  {product.features.map((feature, i) => (
                    <li
                      key={i}
                      className="flex items-start gap-2 text-sm text-primary-dark/70"
                    >
                      <MaterialSymbol
                        name="check_circle"
                        className="text-base text-primary mt-0.5 shrink-0"
                        ariaHidden={false}
                      />
                      {feature}
                    </li>
                  ))}
                </ul>
              ) : null}

              {/* Quantity + Add to cart */}
              <div className="flex flex-wrap items-center gap-4 mt-2">
                <div className="flex items-center border border-primary/10 rounded-full overflow-hidden">
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                    aria-label="Decrease quantity"
                    className="w-11 h-11 flex items-center justify-center text-primary-dark hover:bg-surface-purple transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60"
                  >
                    <MaterialSymbol name="remove" className="text-lg" ariaHidden={false} />
                  </button>
                  <span
                    className="w-10 text-center font-semibold text-primary-dark text-sm select-none"
                    aria-live="polite"
                    aria-label={`Quantity: ${quantity}`}
                  >
                    {quantity}
                  </span>
                  <button
                    type="button"
                    onClick={() => setQuantity((q) => q + 1)}
                    aria-label="Increase quantity"
                    className="w-11 h-11 flex items-center justify-center text-primary-dark hover:bg-surface-purple transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60"
                  >
                    <MaterialSymbol name="add" className="text-lg" ariaHidden={false} />
                  </button>
                </div>

                <button
                  type="button"
                  onClick={handleAddToCart}
                  className="flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-8 py-3 rounded-full font-semibold text-sm transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
                >
                  <MaterialSymbol name="add_shopping_cart" className="text-base" ariaHidden={false} />
                  Add to Cart
                </button>
              </div>

              {/* Back link */}
              <Link
                href="/shop"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary-dark transition-colors mt-4"
              >
                <MaterialSymbol name="arrow_back" className="text-base" />
                Back to Shop
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* You may also like */}
      {relatedProducts.length > 0 ? (
        <section className="bg-white pb-20 md:pb-28">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <h2 className="font-serif text-2xl md:text-3xl font-bold text-primary-dark text-center mb-10">
              You May Also Like
            </h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {relatedProducts.map((p) => (
                <ProductCard key={p.id} product={p} />
              ))}
            </div>
          </div>
        </section>
      ) : null}

      {/* Recently viewed */}
      <RecentlyViewed currentProductId={product.id} />
    </>
  );
}
