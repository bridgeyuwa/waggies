"use client";

import { useState, useMemo } from "react";
import { cn } from "@/lib/utils";
import { PRODUCT_CATEGORIES, type Product, type ProductCategory } from "@/data/shop-data";
import { ProductCard } from "./product-card";

export type ShopPageClientProps = {
  products: readonly Product[];
};

export function ShopPageClient({ products }: ShopPageClientProps) {
  const [activeCategory, setActiveCategory] = useState<"All" | ProductCategory>(
    "All",
  );

  const filtered = useMemo(() => {
    if (activeCategory === "All") return products;
    return products.filter((p) => p.category === activeCategory);
  }, [products, activeCategory]);

  const allTabs: Array<"All" | ProductCategory> = [
    "All",
    ...PRODUCT_CATEGORIES,
  ];

  return (
    <section className="bg-surface pb-20 md:pb-28">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        {/* Category filter pills */}
        <div className="flex flex-wrap gap-2 mb-10 justify-center">
          {allTabs.map((tab) => {
            const isActive = activeCategory === tab;
            return (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveCategory(tab)}
                aria-pressed={isActive}
                className={cn(
                  "px-5 py-2.5 rounded-full text-sm font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2",
                  isActive
                    ? "bg-primary text-white"
                    : "bg-white text-primary-dark/60 border border-primary/10 hover:bg-surface-purple hover:text-primary-dark",
                )}
              >
                {tab}
              </button>
            );
          })}
        </div>

        {/* Product grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <MaterialIcon name="search_off" />
            <p className="text-primary-dark/50 text-sm mt-3">
              No products found in this category.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

function MaterialIcon({ name }: { name: string }) {
  return (
    <span className="material-symbols-outlined text-4xl text-primary-dark/20">
      {name}
    </span>
  );
}
