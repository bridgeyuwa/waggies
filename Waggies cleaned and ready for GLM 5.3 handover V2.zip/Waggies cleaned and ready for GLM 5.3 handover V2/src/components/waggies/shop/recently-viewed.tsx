"use client";

import { useSyncExternalStore } from "react";
import { ProductCard } from "./product-card";
import { getProductById } from "@/data/shop-data";
import type { Product } from "@/data/shop-data";

const STORAGE_KEY = "waggies-recently-viewed";
const CUSTOM_EVENT = "waggies-recently-viewed-change";

function subscribe(callback: () => void) {
  window.addEventListener("storage", callback);
  window.addEventListener(CUSTOM_EVENT, callback);
  return () => {
    window.removeEventListener("storage", callback);
    window.removeEventListener(CUSTOM_EVENT, callback);
  };
}

function getSnapshot(): string {
  try {
    return localStorage.getItem(STORAGE_KEY) ?? "[]";
  } catch {
    return "[]";
  }
}

function getServerSnapshot(): string {
  return "[]";
}

export type RecentlyViewedProps = {
  currentProductId: string;
};

export function RecentlyViewed({ currentProductId }: RecentlyViewedProps) {
  const raw = useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);

  const products: Product[] = (() => {
    try {
      const ids: string[] = JSON.parse(raw);
      return ids
        .filter((id) => id !== currentProductId)
        .slice(0, 6)
        .map((id) => getProductById(id))
        .filter((p): p is Product => p !== undefined);
    } catch {
      return [];
    }
  })();

  if (products.length === 0) return null;

  return (
    <section className="bg-surface pb-20 md:pb-28">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <h2 className="font-serif text-2xl font-bold text-primary-dark mb-8">
          Recently Viewed
        </h2>
        <div className="flex gap-6 overflow-x-auto pb-4 scrollbar-thin">
          {products.map((product) => (
            <div key={product.id} className="shrink-0 w-64">
              <ProductCard product={product} />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
