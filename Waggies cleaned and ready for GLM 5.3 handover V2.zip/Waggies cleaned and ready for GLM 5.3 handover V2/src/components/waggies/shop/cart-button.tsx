"use client";

import { useCartStore } from "@/store/cart-store";

export function CartButton() {
  const open = useCartStore((s) => s.open);
  const count = useCartStore((s) => s.items.reduce((sum, i) => sum + i.quantity, 0));

  return (
    <button
      type="button"
      onClick={open}
      aria-label={`Open cart${count > 0 ? `, ${count} item${count === 1 ? "" : "s"}` : ""}`}
      className="relative flex items-center justify-center w-10 h-10 rounded-lg hover:bg-surface-purple transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60"
    >
      <span className="material-symbols-outlined text-primary-dark text-xl" aria-hidden>
        shopping_cart
      </span>
      {count > 0 ? (
        <span className="absolute -top-1 -right-1 bg-primary text-white text-[10px] font-bold min-w-[18px] h-[18px] flex items-center justify-center rounded-full leading-none px-1">
          {count > 99 ? "99+" : count}
        </span>
      ) : null}
    </button>
  );
}
