/**
 * Hub hero - full-bleed image hero for content section landing pages.
 *
 * Faithful React reproduction of
 * resources/views/components/hero/hub.blade.php.
 *
 * Uses preset copy & imagery based on the `type` prop (blog | guide | kb |
 * faq | checklist). All presets can be overridden by passing explicit props.
 */

import { HeroImage, type HeroCta } from "./hero-image";
import { heroImages } from "@/data/pricing";

type HubPreset = {
  eyebrow: string;
  icon: string;
  title: string;
  subtitle: string;
  image: string;
};

const presets: Record<string, HubPreset> = {
  blog: {
    eyebrow: "Waggies Blog",
    icon: "article",
    title: "Pet Care Tips &amp; News",
    subtitle:
      "Expert advice, heartwarming stories, and the latest from the Waggies team in Abuja.",
    image: heroImages.blog,
  },
  guide: {
    eyebrow: "Pet Care Guides",
    icon: "menu_book",
    title: "In-Depth Pet Care Guides",
    subtitle:
      "Comprehensive, expert-written guides to help you make the best decisions for your pet.",
    image: heroImages.guide,
  },
  kb: {
    eyebrow: "Knowledge Base",
    icon: "help",
    title: "How Can We Help?",
    subtitle:
      "Quick answers to common questions about our services, policies, and pet care.",
    image: heroImages.kb,
  },
  faq: {
    eyebrow: "Help Centre",
    icon: "help",
    title: "Frequently Asked Questions",
    subtitle:
      "Quick answers to the questions we hear most often. Can't find what you need? Contact us directly.",
    image: heroImages.faq,
  },
  checklist: {
    eyebrow: "Relocation Checklist",
    icon: "checklist",
    title: "Your Pet Relocation Checklist",
    subtitle:
      "Stay on top of every requirement. Start early - some steps can take weeks to complete.",
    image: heroImages.checklist,
  },
};

export type HeroHubProps = {
  type?: keyof typeof presets;
  eyebrow?: string;
  title?: string;
  subtitle?: string;
  imageSrc?: string;
  eyebrowIcon?: string;
  minHeight?: string;
  variant?: "bottom" | "center";
  primaryCta?: HeroCta | null;
  secondaryCta?: HeroCta | null;
};

export function HeroHub({
  type = "blog",
  eyebrow,
  title,
  subtitle,
  imageSrc,
  eyebrowIcon,
  minHeight = "480px",
  variant = "center",
  primaryCta = null,
  secondaryCta = null,
}: HeroHubProps) {
  const preset = presets[type] ?? presets.blog;
  return (
    <HeroImage
      imageSrc={imageSrc ?? preset.image}
      eyebrow={eyebrow ?? preset.eyebrow}
      eyebrowIcon={eyebrowIcon ?? preset.icon}
      title={title ?? preset.title}
      subtitle={subtitle ?? preset.subtitle}
      minHeight={minHeight}
      variant={variant}
      primaryCta={primaryCta}
      secondaryCta={secondaryCta}
    />
  );
}
