"use client";

import { useRef } from "react";
import { motion, useInView } from "framer-motion";
import { cn } from "@/lib/utils";

/**
 * SectionDivider - decorative wavy divider with Waggies purple gradient.
 *
 * SVG wave shape with a purple gradient fill that animates in on scroll
 * using framer-motion useInView.
 *
 * Props:
 * - direction: 'normal' | 'reversed' (flips the wave vertically)
 * - className: additional classes
 */

export function SectionDivider({
  direction = "normal",
  className = "",
}: {
  direction?: "normal" | "reversed";
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-50px" });

  const flipY = direction === "reversed";

  return (
    <div
      ref={ref}
      className={cn("relative w-full overflow-hidden", className)}
      aria-hidden="true"
    >
      <motion.svg
        viewBox="0 0 1440 80"
        preserveAspectRatio="none"
        className={cn("block w-full h-[60px] md:h-[80px]", flipY && "scale-y-[-1]")}
        initial={{ opacity: 0, scaleX: 0.3 }}
        animate={isInView ? { opacity: 1, scaleX: 1 } : { opacity: 0, scaleX: 0.3 }}
        transition={{ duration: 0.8, ease: "easeOut" }}
      >
        <defs>
          <linearGradient id="waggies-wave-gradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="var(--color-primary, #7c3aed)" stopOpacity="0.15" />
            <stop offset="50%" stopColor="var(--color-primary, #7c3aed)" stopOpacity="0.25" />
            <stop offset="100%" stopColor="var(--color-primary-dark, #4c1d95)" stopOpacity="0.15" />
          </linearGradient>
        </defs>
        <path
          d="M0,40 C240,80 480,0 720,40 C960,80 1200,0 1440,40 L1440,80 L0,80 Z"
          fill="url(#waggies-wave-gradient)"
        />
        <path
          d="M0,50 C360,10 720,70 1080,30 C1260,15 1380,55 1440,45 L1440,80 L0,80 Z"
          fill="url(#waggies-wave-gradient)"
          opacity="0.5"
        />
      </motion.svg>
    </div>
  );
}
