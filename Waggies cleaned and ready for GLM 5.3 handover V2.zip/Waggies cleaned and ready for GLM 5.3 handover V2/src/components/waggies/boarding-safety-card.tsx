/**
 * Safety policy callout card.
 *
 * Faithful React reproduction of
 * resources/views/components/boarding/safety-card.blade.php.
 */

import { MaterialSymbol } from "./material-symbol";

export type BoardingSafetyCardProps = {
  title?: string;
  intro?: string;
  bullets?: string[];
  linkLabel?: string | null;
  linkHref?: string | null;
};

export function BoardingSafetyCard({
  title = "Safety First Policy",
  intro = "",
  bullets = [],
  linkLabel = null,
  linkHref = null,
}: BoardingSafetyCardProps) {
  return (
    <section className="w-full py-20 bg-surface border-y border-surface-purple">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <div className="bg-white rounded-2xl p-6 md:p-12 shadow-sm border border-surface-purple">
          <h2 className="font-serif font-bold text-primary-dark mb-4 flex items-center gap-3 text-xl">
            <MaterialSymbol name="health_and_safety" className="text-primary" />
            {title}
          </h2>

          {intro ? (
            <p className="text-primary-dark/70 mb-6 leading-relaxed max-w-prose">
              {intro}
            </p>
          ) : null}

          {bullets.length > 0 ? (
            <ul className="space-y-2 text-sm text-primary-dark/70 mb-6" role="list">
              {bullets.map((bullet, i) => (
                <li key={i}>{bullet}</li>
              ))}
            </ul>
          ) : null}

          {linkLabel && linkHref ? (
            <a
              href={linkHref}
              className="text-primary font-bold hover:underline inline-flex items-center gap-1 focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2 rounded"
            >
              {linkLabel}
              <MaterialSymbol name="arrow_forward" className="text-sm" />
            </a>
          ) : null}
        </div>
      </div>
    </section>
  );
}
