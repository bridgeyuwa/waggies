"use client";

import Link from "next/link";
import { type RefObject, useCallback, useLayoutEffect, useEffect } from "react";
import { cn } from "@/lib/utils";
import { type MegaLink } from "@/lib/site";
import { PhosphorIcon } from "@/lib/phosphor-icons";

/**
 * MegaMenuFlyout — shared multi-column mega-menu panel.
 *
 * Used for Services and Tools desktop flyouts. Renders a wide panel
 * (≈70 rem) with grouped columns, a gradient header, and Phosphor icons.
 *
 * Positioning strategy:
 *   The panel is `position: absolute` inside the trigger `<li>`. CSS
 *   places it at `left: 50%` of the <li> then shifts it via
 *   `transform: translateX(calc(-50% + var(--mega-offset)))`.
 *
 *   `--mega-offset` is a CSS custom property set by this component
 *   (via JS) so the panel's centre aligns with the <nav> container's
 *   centre rather than the trigger button's centre. This produces the
 *   classic mega-menu look where the panel spans the header width.
 *
 *   The CSS `translate` property handles the vertical open/close
 *   animation independently from the `transform` property (horizontal
 *   offset) — they do not conflict.
 */
export function MegaMenuFlyout({
  columns,
  isOpen,
  onClose,
  triggerRef,
  panelRef,
  navRef,
  label,
  ariaLabel,
  columnsCount = 3,
}: {
  columns: ReadonlyArray<{
    groupLabel: string;
    links: MegaLink[];
  }>;
  isOpen: boolean;
  onClose: () => void;
  triggerRef: RefObject<HTMLElement | null>;
  panelRef: RefObject<HTMLDivElement | null>;
  navRef: RefObject<HTMLElement | null>;
  label: string;
  ariaLabel: string;
  columnsCount?: number;
}) {
  const ref = panelRef;

  // ── Calculate --mega-offset so the panel centres in the <nav> ──
  const updateOffset = useCallback(() => {
    const el = ref.current;
    const trigger = triggerRef.current;
    const nav = navRef.current;
    if (!el || !trigger || !nav) return;

    const triggerRect = trigger.getBoundingClientRect();
    const navRect = nav.getBoundingClientRect();
    const triggerCenter = triggerRect.left + triggerRect.width / 2;
    const navCenter = navRect.left + navRect.width / 2;
    const offset = navCenter - triggerCenter;
    el.style.setProperty("--mega-offset", `${offset}px`);
  }, [ref, triggerRef, navRef]);

  // useLayoutEffect fires before paint, so the correct offset is in
  // place when the browser first renders the panel (no flash).
  useLayoutEffect(() => {
    if (!isOpen) return;
    updateOffset();
    window.addEventListener("resize", updateOffset);
    return () => window.removeEventListener("resize", updateOffset);
  }, [isOpen, updateOffset]);

  // ── Keyboard: Escape + ArrowUp/Down ─────────────────────────────
  useEffect(() => {
    if (!isOpen) return;
    const el = ref.current;
    if (!el) return;

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        triggerRef.current?.focus();
        return;
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        const items = Array.from(
          el.querySelectorAll<HTMLElement>("[role=\"menuitem\"]"),
        );
        if (items.length === 0) return;
        const idx = items.indexOf(document.activeElement as HTMLElement);
        const dir = e.key === "ArrowDown" ? 1 : -1;
        let next = idx + dir;
        if (next < 0) next = items.length - 1;
        if (next >= items.length) next = 0;
        items[next]?.focus();
      }
    };

    el.addEventListener("keydown", handleKey);
    return () => el.removeEventListener("keydown", handleKey);
  }, [isOpen, onClose, triggerRef, ref]);

  return (
    <div
      ref={ref}
      role="menu"
      aria-label={ariaLabel}
      className={cn(
        "nav-dropdown nav-dropdown--mega absolute top-full mt-1 transition ease-out duration-150",
        isOpen
          ? "opacity-100 translate-y-0"
          : "opacity-0 -translate-y-1 pointer-events-none",
      )}
      style={{ display: isOpen ? "block" : "none" }}
    >
      <div className="nav-dropdown__header">
        <p className="text-white/80 text-xs font-bold uppercase tracking-widest">
          {label}
        </p>
      </div>
      <div
        className={cn(
          "nav-dropdown__columns",
          columnsCount === 3 && "nav-dropdown__columns--mega-3col",
        )}
      >
        {columns.map((column) => (
          <div key={column.groupLabel} role="group" aria-label={column.groupLabel}>
            <p className="nav-dropdown__group-heading">{column.groupLabel}</p>
            <div className="flex flex-col gap-0.5">
              {column.links.map((link) => (
                <MegaMenuLink
                  key={link.href}
                  href={link.href}
                  icon={link.icon}
                  title={link.title}
                  subtitle={link.subtitle}
                />
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

/**
 * Single link row inside a mega-menu column.
 *
 * Shared visual treatment: icon container + title + subtitle with
 * hover/focus states matching the site's menu grammar.
 */
function MegaMenuLink({
  href,
  icon,
  title,
  subtitle,
}: {
  href: string;
  icon: string;
  title: string;
  subtitle: string;
}) {
  return (
    <Link
      href={href}
      role="menuitem"
      tabIndex={-1}
      className="flex items-center gap-3 px-3 py-2.5 rounded-xl hover:bg-surface-purple transition-colors group focus-visible:outline-2 focus-visible:outline-primary focus-visible:outline-offset-2"
    >
      <div className="w-9 h-9 rounded-lg bg-surface-purple group-hover:bg-primary group-hover:text-white flex items-center justify-center text-primary transition-colors shrink-0">
        <PhosphorIcon name={icon} />
      </div>
      <div className="min-w-0">
        <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors leading-snug">
          {title}
        </p>
        {subtitle ? (
          <p className="text-xs text-primary-dark/50 leading-snug mt-0.5">
            {subtitle}
          </p>
        ) : null}
      </div>
    </Link>
  );
}
