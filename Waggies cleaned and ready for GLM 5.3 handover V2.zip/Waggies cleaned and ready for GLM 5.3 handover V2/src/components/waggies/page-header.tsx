/**
 * Page header band (title + optional eyebrow/subtitle).
 *
 * Faithful React reproduction of
 * resources/views/components/ui/page-header.blade.php.
 *
 * Two variants: `purple` (default - surface-purple bg) or `white`.
 */

export type PageHeaderProps = {
  eyebrow?: string | null;
  title: string;
  subtitle?: string | null;
  variant?: "purple" | "white";
  align?: "left" | "center";
  children?: React.ReactNode;
  className?: string;
};

export function PageHeader({
  eyebrow,
  title,
  subtitle,
  variant = "purple",
  align = "left",
  children,
  className = "",
}: PageHeaderProps) {
  const wrapper =
    variant === "purple"
      ? "bg-surface-purple border-b border-primary/10"
      : "bg-white border-b border-primary/10";

  const alignClass =
    align === "center" ? "text-center items-center" : "text-left items-start";

  return (
    <div className={`${wrapper} ${className}`}>
      <div
        className={`max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-16 md:py-20 flex flex-col ${alignClass}`}
      >
        {eyebrow ? (
          <span className="text-xs font-bold uppercase tracking-widest text-primary/60 block mb-3">
            {eyebrow}
          </span>
        ) : null}
        <h1 className="font-serif text-4xl md:text-5xl font-bold text-primary-dark mb-3">
          {title}
        </h1>
        {subtitle ? (
          <p
            className={`text-primary-dark/60 max-w-xl ${align === "center" ? "mx-auto" : ""}`}
          >
            {subtitle}
          </p>
        ) : null}
        {children ? <div className="mt-6">{children}</div> : null}
      </div>
    </div>
  );
}
