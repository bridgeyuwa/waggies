/**
 * Feature card grid for boarding pages.
 *
 * Faithful React reproduction of
 * resources/views/components/boarding/feature-grid.blade.php.
 *
 * Also reused (without the `mt-10`) for grooming/vet-care/training/transport/
 * relocation-import/export pages where the inline `@foreach` builds the same
 * purple-card structure. See <ServiceFeatureGrid/> for that variant.
 */

import { MaterialSymbol } from "./material-symbol";

export type BoardingFeature = {
  icon: string;
  title: string;
  desc: string;
};

export function BoardingFeatureGrid({
  features,
  withTopMargin = true,
}: {
  features: BoardingFeature[];
  /** Whether to include the `mt-10` top margin (boarding pages add it via
   *  the section heading's implicit spacing; service pages add `mt-10`
   *  explicitly in the foreach wrapper). */
  withTopMargin?: boolean;
}) {
  return (
    <div
      className={`grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 ${withTopMargin ? "mt-10" : ""}`}
    >
      {features.map((item, i) => (
        <div
          key={i}
          className="bg-surface-purple rounded-2xl p-6 flex gap-4 hover:shadow-soft transition-shadow"
        >
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
            <MaterialSymbol name={item.icon} filled className="text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-primary-dark mb-1">{item.title}</h3>
            <p className="text-sm text-primary-dark/60 leading-relaxed">
              {item.desc}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}

/**
 * Service feature grid - same visual as BoardingFeatureGrid but without the
 * hover shadow (used by grooming/vet-care/training/transport/import/export
 * pages where the Blade inline foreach does NOT include `hover:shadow-soft`).
 *
 * Source: services/grooming.blade.php lines 30-39 (and equivalent inline
 * foreaches on other service pages).
 */
export function ServiceFeatureGrid({ features }: { features: BoardingFeature[] }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
      {features.map((item, i) => (
        <div key={i} className="bg-surface-purple rounded-2xl p-6 flex gap-4">
          <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
            <MaterialSymbol name={item.icon} filled className="text-primary" />
          </div>
          <div>
            <h3 className="font-semibold text-primary-dark mb-1">{item.title}</h3>
            <p className="text-sm text-primary-dark/60 leading-relaxed">
              {item.desc}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
