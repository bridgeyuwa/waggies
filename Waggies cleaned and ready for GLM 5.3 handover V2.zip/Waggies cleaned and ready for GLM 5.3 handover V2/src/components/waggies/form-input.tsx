/**
 * Form input - React port of resources/views/components/form/input.blade.php
 *
 *
 * DO NOT change class names, label format, or error rendering.
 */

import { forwardRef, type InputHTMLAttributes } from "react";
import { cn } from "@/lib/utils";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type FormInputProps = {
  label?: string;
  name: string;
  type?: "text" | "email" | "tel" | "password" | "number";
  placeholder?: string;
  defaultValue?: string;
  error?: string | null;
  required?: boolean;
  hint?: string;
  className?: string;
} & Omit<InputHTMLAttributes<HTMLInputElement>, "name" | "type" | "placeholder" | "defaultValue">;

export const FormInput = forwardRef<HTMLInputElement, FormInputProps>(function FormInput(
  {
    label,
    name,
    type = "text",
    placeholder = "",
    defaultValue,
    error,
    required = false,
    hint,
    className,
    ...rest
  },
  ref,
) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label ? (
        <label
          htmlFor={name}
          className={cn(
            "text-sm font-semibold text-primary-dark",
            required && "after:content-['*'] after:text-error after:ml-0.5",
          )}
        >
          {label}
        </label>
      ) : null}

      <input
        ref={ref}
        id={name}
        name={name}
        type={type}
        placeholder={placeholder}
        defaultValue={defaultValue}
        required={required}
        aria-required={required || undefined}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${name}-error` : undefined}
        className={cn(
          "w-full h-14 px-5 rounded-2xl border bg-surface/50 outline-none font-medium text-primary-dark",
          "placeholder:text-primary-dark/50",
          "focus:outline-none focus:ring-2 focus:ring-primary/60 focus:border-primary transition",
          !error && "border-primary/30",
          error && "border-error bg-error-light",
        )}
        {...rest}
      />

      {error ? (
        <div
          id={`${name}-error`}
          className="flex items-center gap-2 text-error text-xs font-medium"
          role="alert"
        >
          <MaterialSymbol name="error" className="text-sm" aria-hidden />
          {error}
        </div>
      ) : hint ? (
        <p className="text-xs text-primary-dark/50">{hint}</p>
      ) : null}
    </div>
  );
});
