/**
 * FAQ accordion - list of <details> elements.
 *
 * Faithful React reproduction of
 * resources/views/components/faq-accordion.blade.php.
 *
 * Each FAQ is a native <details>/<summary> pair. The expand_more icon
 * rotates 180° when open via the `group-open:rotate-180` utility (defined
 * in globals.css via [details[open]] selectors).
 *
 * The Blade uses CSS `group` + `group-open:` - Tailwind v4 supports this
 * natively via the `group-open:` variant when the parent <details> has
 * `className="group"`. We rely on that here.
 */

import { MaterialSymbol } from "./material-symbol";

export type FaqItem = {
  question: string;
  answer: string;
};

export type FaqAccordionProps = {
  faqs: FaqItem[];
  /** Optional slot rendered when `faqs` is empty (matches Blade @forelse @empty). */
  children?: React.ReactNode;
};

export function FaqAccordion({ faqs, children }: FaqAccordionProps) {
  if (faqs.length === 0) return <>{children}</>;

  return (
    <div className="max-w-3xl mx-auto space-y-3">
      {faqs.map((faq, i) => (
        <details
          key={i}
          className="group bg-white border border-primary/10 rounded-2xl hover:border-primary/30 hover:shadow-sm transition"
        >
          <summary className="flex w-full cursor-pointer items-center justify-between gap-4 px-6 py-5 font-semibold text-primary-dark hover:text-primary transition-colors list-none [&::-webkit-details-marker]:hidden">
            {faq.question}
            <MaterialSymbol
              name="expand_more"
              className="text-primary shrink-0 transition-transform duration-200 group-open:rotate-180"
            />
          </summary>
          <div className="px-6 pb-5 pt-3 text-sm text-primary-dark/60 leading-relaxed">
            {faq.answer}
          </div>
        </details>
      ))}
    </div>
  );
}
