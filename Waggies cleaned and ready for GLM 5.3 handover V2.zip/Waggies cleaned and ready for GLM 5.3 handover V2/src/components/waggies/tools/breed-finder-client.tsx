"use client";

import { useState, useMemo } from "react";
import { cn } from "@/lib/utils";

type Species = "dog" | "cat";
type Size = "Small" | "Medium" | "Large";
type Energy = "Low" | "Moderate" | "High";
type Grooming = "Low" | "Moderate" | "High";

type Breed = {
  name: string;
  species: Species;
  size: Size;
  energy: Energy;
  grooming: Grooming;
  temperament: string;
  healthConsiderations: string;
  serviceLinks: { label: string; href: string }[];
};

const BREEDS: Breed[] = [
  // Dogs
  { name: "Labrador Retriever", species: "dog", size: "Large", energy: "High", grooming: "Moderate", temperament: "Friendly, outgoing, and active. Good with families and children. Known for being eager to please.", healthConsiderations: "Prone to hip and elbow dysplasia, obesity, and ear infections. Regular exercise and weight management are important.", serviceLinks: [{ label: "Grooming", href: "/services/grooming" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "German Shepherd", species: "dog", size: "Large", energy: "High", grooming: "Moderate", temperament: "Loyal, confident, and intelligent. Highly trainable and often used as working dogs. Protective of family.", healthConsiderations: "Prone to hip dysplasia, degenerative myelopathy, and digestive issues. Regular veterinary check-ups recommended.", serviceLinks: [{ label: "Training", href: "/services/training" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Golden Retriever", species: "dog", size: "Large", energy: "High", grooming: "Moderate", temperament: "Gentle, affectionate, and reliable. Excellent family dogs. Patient and good with children.", healthConsiderations: "Prone to cancer, hip dysplasia, and heart conditions. Regular health screenings are advisable.", serviceLinks: [{ label: "Grooming", href: "/services/grooming" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "French Bulldog", species: "dog", size: "Small", energy: "Low", grooming: "Low", temperament: "Playful, adaptable, and sociable. Good companion dogs for apartments. Generally quiet.", healthConsiderations: "Brachycephalic breed - prone to breathing difficulties, overheating, and spinal issues. Requires careful management in hot weather.", serviceLinks: [{ label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Rottweiler", species: "dog", size: "Large", energy: "Moderate", grooming: "Low", temperament: "Confident, loyal, and protective. Good guard dogs. Calm and devoted to family when properly trained.", healthConsiderations: "Prone to hip dysplasia, heart conditions, and obesity. Early socialisation and consistent training are important.", serviceLinks: [{ label: "Training", href: "/services/training" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Beagle", species: "dog", size: "Medium", energy: "High", grooming: "Low", temperament: "Curious, merry, and friendly. Good with children. Strong scent drive means they can be easily distracted on walks.", healthConsiderations: "Prone to obesity, ear infections, and hip dysplasia. Keep on a lead outdoors due to strong scent-tracking instinct.", serviceLinks: [{ label: "Grooming", href: "/services/grooming" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Poodle", species: "dog", size: "Medium", energy: "Moderate", grooming: "High", temperament: "Intelligent, active, and elegant. Highly trainable. Comes in three sizes (toy, miniature, standard). Hypoallergenic coat.", healthConsiderations: "Prone to hip dysplasia, eye conditions, and skin issues. Regular professional grooming is essential.", serviceLinks: [{ label: "Grooming", href: "/services/grooming" }, { label: "Training", href: "/services/training" }] },
  { name: "Shih Tzu", species: "dog", size: "Small", energy: "Low", grooming: "High", temperament: "Affectionate, outgoing, and friendly. Good apartment dogs. Generally gets along well with other pets.", healthConsiderations: "Brachycephalic breed - prone to breathing issues and eye problems. Coat requires daily brushing and regular professional grooming.", serviceLinks: [{ label: "Grooming", href: "/services/grooming" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Bulldog", species: "dog", size: "Medium", energy: "Low", grooming: "Low", temperament: "Calm, courageous, and friendly. Good family companions. Generally easygoing and adaptable.", healthConsiderations: "Brachycephalic breed - prone to breathing difficulties, skin fold infections, and joint issues. Requires careful management in warm weather.", serviceLinks: [{ label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Dalmatian", species: "dog", size: "Large", energy: "High", grooming: "Low", temperament: "Energetic, outgoing, and playful. Needs plenty of exercise. Good with active families.", healthConsiderations: "Prone to deafness (especially in dogs with blue eyes), urinary stones, and skin allergies. Requires consistent, high levels of exercise.", serviceLinks: [{ label: "Vet Care", href: "/services/vet-care" }, { label: "Training", href: "/services/training" }] },
  // Cats
  { name: "Persian", species: "cat", size: "Medium", energy: "Low", grooming: "High", temperament: "Quiet, gentle, and affectionate. Enjoys a calm environment. Good indoor cats.", healthConsiderations: "Flat face can cause breathing and eye issues. Prone to polycystic kidney disease. Requires daily grooming to prevent matting.", serviceLinks: [{ label: "Grooming", href: "/services/grooming" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Siamese", species: "cat", size: "Medium", energy: "High", grooming: "Low", temperament: "Vocal, social, and intelligent. Forms strong bonds with owners. Very interactive and demanding of attention.", healthConsiderations: "Prone to dental issues and respiratory infections. Generally healthy with proper care. Needs mental stimulation.", serviceLinks: [{ label: "Vet Care", href: "/services/vet-care" }] },
  { name: "British Shorthair", species: "cat", size: "Medium", energy: "Low", grooming: "Low", temperament: "Easygoing, calm, and independent. Good for working owners. Not demanding of attention but enjoys company.", healthConsiderations: "Prone to obesity and hypertrophic cardiomyopathy. Manage diet carefully and schedule regular vet check-ups.", serviceLinks: [{ label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Maine Coon", species: "cat", size: "Large", energy: "Moderate", grooming: "Moderate", temperament: "Gentle, friendly, and playful. Known as 'gentle giants.' Good with families and other pets.", healthConsiderations: "Prone to hip dysplasia, spinal muscular atrophy, and heart disease. Regular grooming needed, especially during shedding seasons.", serviceLinks: [{ label: "Grooming", href: "/services/grooming" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Ragdoll", species: "cat", size: "Large", energy: "Low", grooming: "Moderate", temperament: "Docile, affectionate, and relaxed. Goes limp when picked up. Good with children and other pets.", healthConsiderations: "Prone to hypertrophic cardiomyopathy and bladder stones. Keep indoors. Regular vet check-ups recommended.", serviceLinks: [{ label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Bengal", species: "cat", size: "Medium", energy: "High", grooming: "Low", temperament: "Active, athletic, and curious. Highly intelligent. Needs plenty of play and stimulation. Not a quiet lap cat.", healthConsiderations: "Generally healthy. Prone to progressive retinal atrophy in some lines. Requires lots of physical and mental activity.", serviceLinks: [{ label: "Training", href: "/services/training" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Sphynx", species: "cat", size: "Medium", energy: "Moderate", grooming: "High", temperament: "Friendly, outgoing, and curious. Loves attention. Warm to the touch due to lack of coat.", healthConsiderations: "Hairless cats need regular bathing to manage skin oils. Prone to sunburn, cold sensitivity, and respiratory infections. Indoor only.", serviceLinks: [{ label: "Grooming", href: "/services/grooming" }, { label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Scottish Fold", species: "cat", size: "Medium", energy: "Low", grooming: "Low", temperament: "Sweet, quiet, and loyal. Enjoys being around people but not demanding. Good apartment cats.", healthConsiderations: "The folded ear gene is linked to a skeletal condition (osteochondrodysplasia). Regular vet monitoring of joint health is important.", serviceLinks: [{ label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Russian Blue", species: "cat", size: "Medium", energy: "Moderate", grooming: "Low", temperament: "Gentle, reserved, and loyal. Forms strong bonds with one or two people. Quiet and clean.", healthConsiderations: "Generally healthy with few breed-specific issues. Prone to bladder stones. Maintain regular dental care.", serviceLinks: [{ label: "Vet Care", href: "/services/vet-care" }] },
  { name: "Abyssinian", species: "cat", size: "Medium", energy: "High", grooming: "Low", temperament: "Active, intelligent, and curious. One of the oldest known cat breeds. Loves to explore and play.", healthConsiderations: "Generally healthy. Can be prone to gingivitis and psychogenic alopecia (stress-related hair loss). Needs plenty of stimulation.", serviceLinks: [{ label: "Vet Care", href: "/services/vet-care" }] },
];

type Filter = {
  search: string;
  size: Size | "";
  energy: Energy | "";
  grooming: Grooming | "";
};

const SIZES: Size[] = ["Small", "Medium", "Large"];
const ENERGIES: Energy[] = ["Low", "Moderate", "High"];
const GROOMINGS: Grooming[] = ["Low", "Moderate", "High"];

export function BreedFinderClient() {
  const [species, setSpecies] = useState<Species>("dog");
  const [filter, setFilter] = useState<Filter>({
    search: "",
    size: "",
    energy: "",
    grooming: "",
  });

  const filtered = useMemo(() => {
    return BREEDS.filter((b) => {
      if (b.species !== species) return false;
      if (filter.search && !b.name.toLowerCase().includes(filter.search.toLowerCase()))
        return false;
      if (filter.size && b.size !== filter.size) return false;
      if (filter.energy && b.energy !== filter.energy) return false;
      if (filter.grooming && b.grooming !== filter.grooming) return false;
      return true;
    });
  }, [species, filter]);

  const updateFilter = (key: keyof Filter, value: string) => {
    setFilter((prev) => ({ ...prev, [key]: value }));
  };

  const clearFilters = () => {
    setFilter({ search: "", size: "", energy: "", grooming: "" });
  };

  const hasFilters = filter.size || filter.energy || filter.grooming;

  return (
    <div className="space-y-6">
      {/* Species */}
      <div>
        <label className="block text-sm font-semibold text-primary-dark mb-2">
          Species
        </label>
        <div className="grid grid-cols-2 gap-3">
          {(["dog", "cat"] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => { setSpecies(s); clearFilters(); }}
              className={cn(
                "rounded-xl border p-3 text-sm font-semibold transition text-center",
                species === s
                  ? "border-primary bg-surface-purple text-primary"
                  : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30"
              )}
            >
              {s === "dog" ? "Dogs" : "Cats"}
            </button>
          ))}
        </div>
      </div>

      {/* Search */}
      <div>
        <label htmlFor="breed-search" className="block text-sm font-semibold text-primary-dark mb-2">
          Search Breeds
        </label>
        <input
          id="breed-search"
          type="text"
          value={filter.search}
          onChange={(e) => updateFilter("search", e.target.value)}
          placeholder="e.g. Labrador"
          className="w-full rounded-xl border border-primary/10 bg-white px-4 py-3 text-sm text-primary-dark placeholder:text-primary-dark/30 focus:outline-none focus:ring-2 focus:ring-primary/40"
        />
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label htmlFor="filter-size" className="block text-xs font-semibold text-primary-dark/60 mb-1.5">
            Size
          </label>
          <select
            id="filter-size"
            value={filter.size}
            onChange={(e) => updateFilter("size", e.target.value)}
            className="w-full rounded-xl border border-primary/10 bg-white px-3 py-2.5 text-sm text-primary-dark focus:outline-none focus:ring-2 focus:ring-primary/40"
          >
            <option value="">All sizes</option>
            {SIZES.map((s) => (
              <option key={s} value={s}>{s}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="filter-energy" className="block text-xs font-semibold text-primary-dark/60 mb-1.5">
            Energy
          </label>
          <select
            id="filter-energy"
            value={filter.energy}
            onChange={(e) => updateFilter("energy", e.target.value)}
            className="w-full rounded-xl border border-primary/10 bg-white px-3 py-2.5 text-sm text-primary-dark focus:outline-none focus:ring-2 focus:ring-primary/40"
          >
            <option value="">All levels</option>
            {ENERGIES.map((e) => (
              <option key={e} value={e}>{e}</option>
            ))}
          </select>
        </div>
        <div>
          <label htmlFor="filter-grooming" className="block text-xs font-semibold text-primary-dark/60 mb-1.5">
            Grooming
          </label>
          <select
            id="filter-grooming"
            value={filter.grooming}
            onChange={(e) => updateFilter("grooming", e.target.value)}
            className="w-full rounded-xl border border-primary/10 bg-white px-3 py-2.5 text-sm text-primary-dark focus:outline-none focus:ring-2 focus:ring-primary/40"
          >
            <option value="">All levels</option>
            {GROOMINGS.map((g) => (
              <option key={g} value={g}>{g}</option>
            ))}
          </select>
        </div>
      </div>

      {hasFilters && (
        <button
          type="button"
          onClick={clearFilters}
          className="text-xs font-semibold text-primary hover:underline"
        >
          Clear filters
        </button>
      )}

      {/* Results count */}
      <p className="text-xs text-primary-dark/50">
        {filtered.length} breed{filtered.length !== 1 ? "s" : ""} found
      </p>

      {/* Breed cards */}
      <div className="space-y-4 max-h-[800px] overflow-y-auto">
        {filtered.map((breed) => (
          <div
            key={breed.name}
            className="bg-white border border-primary/10 rounded-2xl p-5 sm:p-6"
          >
            <h3 className="font-serif text-base sm:text-lg font-bold text-primary-dark">
              {breed.name}
            </h3>

            {/* Badges */}
            <div className="flex flex-wrap gap-2 mt-2">
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">
                {breed.size}
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/60">
                Energy: {breed.energy}
              </span>
              <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200/60">
                Grooming: {breed.grooming}
              </span>
            </div>

            {/* Temperament */}
            <div className="mt-4">
              <h4 className="text-xs font-bold uppercase tracking-wider text-primary/50 mb-1">
                Temperament
              </h4>
              <p className="text-sm text-primary-dark/60 leading-relaxed">
                {breed.temperament}
              </p>
            </div>

            {/* Health */}
            <div className="mt-3">
              <h4 className="text-xs font-bold uppercase tracking-wider text-primary/50 mb-1">
                General Health Considerations
              </h4>
              <p className="text-sm text-primary-dark/60 leading-relaxed">
                {breed.healthConsiderations}
              </p>
            </div>

            {/* Service links */}
            {breed.serviceLinks.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-4">
                {breed.serviceLinks.map((link) => (
                  <a
                    key={link.href}
                    href={link.href}
                    className="text-xs font-semibold text-primary hover:underline"
                  >
                    {link.label}
                  </a>
                ))}
              </div>
            )}
          </div>
        ))}

        {filtered.length === 0 && (
          <div className="text-center py-12">
            <p className="text-sm text-primary-dark/60">
              No breeds match your filters. Try adjusting your search criteria.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
