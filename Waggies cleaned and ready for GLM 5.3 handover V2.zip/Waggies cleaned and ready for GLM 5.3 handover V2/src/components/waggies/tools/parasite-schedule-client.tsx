"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { businessInfo } from "@/lib/business-info";

type Species = "dog" | "cat";

const TIMELINES = {
  dog: [
    {
      phase: "Puppy Phase",
      range: "2 weeks - 6 months",
      steps: [
        { label: "2 weeks", detail: "First deworming dose" },
        { label: "4 weeks", detail: "Second deworming dose" },
        { label: "6 weeks", detail: "Third deworming dose" },
        { label: "8 weeks", detail: "Fourth deworming dose" },
        { label: "12 weeks", detail: "Monthly deworming continues" },
        { label: "16 weeks", detail: "Monthly deworming continues" },
        { label: "6 months", detail: "Monthly deworming concludes; transition to adult schedule" },
      ],
    },
    {
      phase: "Adult",
      range: "6+ months",
      steps: [
        { label: "Every 3 months", detail: "Regular deworming (at minimum)" },
      ],
    },
    {
      phase: "After Travel",
      range: "As needed",
      steps: [
        { label: "Within 2 weeks of return", detail: "Deworm after travel to high-risk areas" },
      ],
    },
  ],
  cat: [
    {
      phase: "Kitten Phase",
      range: "2 weeks - 6 months",
      steps: [
        { label: "2 weeks", detail: "First deworming dose" },
        { label: "4 weeks", detail: "Second deworming dose" },
        { label: "6 weeks", detail: "Third deworming dose" },
        { label: "8 weeks", detail: "Fourth deworming dose" },
        { label: "12 weeks", detail: "Monthly deworming continues" },
        { label: "6 months", detail: "Monthly deworming concludes; transition to adult schedule" },
      ],
    },
    {
      phase: "Adult",
      range: "6+ months",
      steps: [
        { label: "Every 3 months", detail: "Regular deworming (at minimum)" },
      ],
    },
    {
      phase: "After Travel",
      range: "As needed",
      steps: [
        { label: "Within 2 weeks of return", detail: "Deworm after travel to high-risk areas" },
      ],
    },
  ],
};

export function ParasiteScheduleClient() {
  const [species, setSpecies] = useState<Species>("dog");
  const timeline = TIMELINES[species];

  return (
    <div className="space-y-8">
      {/* Species selector */}
      <div>
        <label className="block text-sm font-semibold text-primary-dark mb-2">
          Species
        </label>
        <div className="grid grid-cols-2 gap-3">
          {(["dog", "cat"] as const).map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => setSpecies(s)}
              className={cn(
                "rounded-xl border p-3 text-sm font-semibold transition text-center",
                species === s
                  ? "border-primary bg-surface-purple text-primary"
                  : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30"
              )}
            >
              {s === "dog" ? "Dog" : "Cat"}
            </button>
          ))}
        </div>
      </div>

      {/* Timeline */}
      {timeline.map((phase, phaseIdx) => (
        <div
          key={phase.phase}
          className="bg-white border border-primary/10 rounded-2xl p-5 sm:p-6"
        >
          <div className="flex items-center gap-3 mb-4">
            <span className="w-8 h-8 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold shrink-0">
              {phaseIdx + 1}
            </span>
            <div>
              <h3 className="font-serif text-base font-bold text-primary-dark">
                {phase.phase}
              </h3>
              <p className="text-xs text-primary-dark/50">{phase.range}</p>
            </div>
          </div>

          <div className="ml-4 border-l-2 border-primary/10 pl-5 space-y-4">
            {phase.steps.map((step, stepIdx) => (
              <div key={stepIdx} className="relative">
                <div className="absolute -left-[1.85rem] top-1 w-3 h-3 rounded-full bg-primary/30 border-2 border-white" />
                <p className="text-sm font-semibold text-primary-dark">
                  {step.label}
                </p>
                <p className="text-sm text-primary-dark/50 mt-0.5">
                  {step.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      ))}

      {/* Note */}
      <div className="bg-amber-50 border border-amber-200/60 rounded-xl p-4">
        <p className="text-xs text-amber-900 leading-relaxed">
          <strong>Important:</strong> Specific products and schedules should be
          confirmed with your veterinarian. The timeline above is general
          educational guidance and may vary based on your pet&apos;s health,
          environment, and local risk factors.
        </p>
      </div>

      {/* Book Appointment CTA */}
      <div className="text-center bg-primary-dark rounded-2xl p-8">
        <h3 className="font-serif text-lg font-bold text-white">
          Schedule a Deworming Appointment
        </h3>
        <p className="text-white/70 text-sm mt-2">
          Our veterinary team can advise on the right products and schedule for
          your pet.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-6">
          <a
            href="/contact"
            className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark font-bold px-8 py-3.5 rounded-full transition text-sm"
          >
            Book an Appointment
          </a>
          <a
            href={businessInfo.phoneHref}
            className="inline-flex items-center gap-2 border border-white/30 text-white hover:bg-white/10 font-semibold px-8 py-3.5 rounded-full transition text-sm"
          >
            Call {businessInfo.phoneLocal}
          </a>
        </div>
      </div>
    </div>
  );
}
