"use client";

import { useState, useCallback } from "react";
import { cn } from "@/lib/utils";
import { businessInfo } from "@/lib/business-info";

export type ChecklistItem = {
  id: string;
  label: string;
  vetConfirmed: boolean;
};

export type ChecklistCategory = {
  title: string;
  items: ChecklistItem[];
};

const CHECKLIST_DATA: ChecklistCategory[] = [
  {
    title: "Before You Bring Them Home",
    items: [
      { id: "prep-food", label: "Choose and buy appropriate food (age-specific)", vetConfirmed: true },
      { id: "prep-bowls", label: "Food and water bowls", vetConfirmed: false },
      { id: "prep-bed", label: "A bed or safe sleeping area", vetConfirmed: false },
      { id: "prep-crate", label: "A crate or carrier for transport and safe space", vetConfirmed: false },
      { id: "prep-gate", label: "Baby gates or barriers for restricted areas", vetConfirmed: false },
      { id: "prep-toxins", label: "Remove or secure toxic plants, chemicals, and small objects", vetConfirmed: true },
      { id: "prep-wires", label: "Tuck away electrical cords and cables", vetConfirmed: false },
      { id: "prep-vet", label: "Research and choose a veterinary clinic", vetConfirmed: true },
    ],
  },
  {
    title: "First Week Essentials",
    items: [
      { id: "week-vet-visit", label: "Schedule a vet check-up within the first few days", vetConfirmed: true },
      { id: "week-quiet", label: "Allow a quiet settling-in period", vetConfirmed: false },
      { id: "week-routine", label: "Establish a feeding and walking routine", vetConfirmed: false },
      { id: "week-toilet", label: "Set up a toilet area and begin house training", vetConfirmed: false },
      { id: "week-intro", label: "Introduce family members one at a time", vetConfirmed: false },
      { id: "week-other-pets", label: "Introduce existing pets gradually and supervised", vetConfirmed: false },
      { id: "week-microchip", label: "Check microchip registration is up to date", vetConfirmed: true },
    ],
  },
  {
    title: "Health & Wellness",
    items: [
      { id: "health-vax", label: "Discuss vaccination schedule with your vet", vetConfirmed: true },
      { id: "health-deworm", label: "Arrange deworming treatment", vetConfirmed: true },
      { id: "health-flea", label: "Start flea and tick prevention", vetConfirmed: true },
      { id: "health-neuter", label: "Discuss spaying/neutering timeline with your vet", vetConfirmed: true },
      { id: "health-insurance", label: "Consider pet insurance or a health savings plan", vetConfirmed: false },
      { id: "health-records", label: "Set up a file for vaccination and health records", vetConfirmed: false },
    ],
  },
  {
    title: "Training & Behaviour",
    items: [
      { id: "train-name", label: "Teach their name using positive reinforcement", vetConfirmed: false },
      { id: "train-sit", label: "Start basic commands (sit, stay, come)", vetConfirmed: false },
      { id: "train-social", label: "Begin socialisation with people, places, and sounds", vetConfirmed: false },
      { id: "train-bite", label: "Address mouthing and biting with redirection", vetConfirmed: false },
      { id: "train-crate", label: "Practise crate training if using a crate", vetConfirmed: false },
      { id: "train-pro", label: "Consider enrolling in a puppy or obedience class", vetConfirmed: false },
    ],
  },
  {
    title: "Supplies & Equipment",
    items: [
      { id: "sup-collar", label: "Collar or harness with ID tag", vetConfirmed: false },
      { id: "sup-leash", label: "Leash (and a longer one for training)", vetConfirmed: false },
      { id: "sup-toys", label: "A few safe toys for chewing and play", vetConfirmed: false },
      { id: "sup-grooming", label: "Grooming supplies (brush, nail clippers, shampoo)", vetConfirmed: false },
      { id: "sup-poop-bags", label: "Poop bags or a litter tray (for cats)", vetConfirmed: false },
      { id: "sup-cleaning", label: "Pet-safe cleaning products for accidents", vetConfirmed: false },
      { id: "sup-first-aid", label: "Basic pet first-aid kit", vetConfirmed: true },
    ],
  },
];

const STORAGE_KEY = "waggies-new-pet-checklist";

function loadChecked(): Record<string, boolean> {
  if (typeof window === "undefined") return {};
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch {
    return {};
  }
}

export function NewPetChecklistClient() {
  const [checked, setChecked] = useState<Record<string, boolean>>(() => loadChecked());

  const toggle = useCallback((id: string) => {
    setChecked((prev) => {
      const next = { ...prev, [id]: !prev[id] };
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      } catch {
        // localStorage unavailable
      }
      return next;
    });
  }, []);

  const allItems = CHECKLIST_DATA.flatMap((c) => c.items);
  const total = allItems.length;
  const completed = allItems.filter((i) => checked[i.id]).length;
  const pct = total > 0 ? Math.round((completed / total) * 100) : 0;

  return (
    <div className="space-y-8">
      {/* Progress bar */}
      <div className="bg-white border border-primary/10 rounded-2xl p-5 sm:p-6">
        <div className="flex items-center justify-between mb-3">
          <h3 className="font-serif text-base font-bold text-primary-dark">
            Your Progress
          </h3>
          <span className="text-sm font-semibold text-primary">
            {completed} of {total} completed
          </span>
        </div>
        <div className="w-full h-2.5 bg-primary/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all duration-300"
            style={{ width: `${pct}%` }}
            role="progressbar"
            aria-valuenow={completed}
            aria-valuemin={0}
            aria-valuemax={total}
            aria-label={`${completed} of ${total} items completed`}
          />
        </div>
        <p className="text-xs text-primary-dark/60 mt-2">
          Progress is saved in your browser&apos;s local storage.
        </p>
      </div>

      {/* Categories */}
      {CHECKLIST_DATA.map((category) => (
        <div
          key={category.title}
          className="bg-white border border-primary/10 rounded-2xl p-5 sm:p-6"
        >
          <h3 className="font-serif text-base font-bold text-primary-dark mb-4">
            {category.title}
          </h3>
          <ul className="space-y-3">
            {category.items.map((item) => {
              const isChecked = !!checked[item.id];
              return (
                <li key={item.id}>
                  <label className="flex items-start gap-3 cursor-pointer group">
                    <input
                      type="checkbox"
                      checked={isChecked}
                      onChange={() => toggle(item.id)}
                      className="mt-0.5 h-4 w-4 rounded border-primary/30 text-primary focus:ring-primary/40"
                    />
                    <span
                      className={cn(
                        "text-sm leading-relaxed transition",
                        isChecked
                          ? "text-primary-dark/60 line-through"
                          : "text-primary-dark/70 group-hover:text-primary-dark"
                      )}
                    >
                      {item.label}
                    </span>
                  </label>
                </li>
              );
            })}
          </ul>
        </div>
      ))}

      {/* Book Appointment CTA */}
      <div className="text-center bg-primary-dark rounded-2xl p-8">
        <h3 className="font-serif text-lg font-bold text-white">
          New Pet? Book a Vet Check-Up
        </h3>
        <p className="text-white/70 text-sm mt-2">
          Every new pet should see a vet within the first few days. We can help
          with vaccinations, microchipping, and a full health assessment.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-6">
          <a
            href="/contact"
            className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark font-bold px-8 py-3.5 rounded-full transition text-sm"
          >
            Book an Appointment
          </a>
          <a
            href={businessInfo.phoneHref}
            className="inline-flex items-center gap-2 border border-white/30 text-white hover:bg-white/10 font-semibold px-8 py-3.5 rounded-full transition text-sm"
          >
            Call {businessInfo.phoneLocal}
          </a>
        </div>
      </div>
    </div>
  );
}
