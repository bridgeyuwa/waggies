import { cn } from "@/lib/utils";
import { WarningCircle } from "@phosphor-icons/react/dist/ssr";

export function MedicalDisclaimer({
  variant = "default",
}: {
  variant?: "default" | "compact";
}) {
  return (
    <div
      className={cn(
        "rounded-xl border bg-amber-50 border-amber-200/60",
        variant === "default" ? "p-4 sm:p-5" : "p-3",
      )}
    >
      <div className="flex items-start gap-3">
        <WarningCircle
          className="text-amber-600 shrink-0 mt-0.5"
          size={variant === "default" ? 20 : 16}
          weight="fill"
          aria-hidden="true"
        />
        <div>
          <p
            className={cn(
              "text-amber-900",
              variant === "default" ? "text-sm font-medium" : "text-xs",
            )}
          >
            This tool provides general information only and is not a substitute
            for professional veterinary diagnosis or treatment. If your pet is
            in distress, contact your vet or an emergency animal clinic
            immediately.
          </p>
        </div>
      </div>
    </div>
  );
}
