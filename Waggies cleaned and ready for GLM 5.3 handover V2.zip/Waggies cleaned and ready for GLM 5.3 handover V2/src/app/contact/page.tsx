/**
 * /contact page — Canonical location & contact hub.
 *
 * Two-column layout on desktop:
 *   Left:  Business identity, address, map embed, phone, WhatsApp, email,
 *          full 7-day hours table, directions, booking CTA
 *   Right: Contact form (client component)
 *
 * Business data sourced from business-info.ts (authoritative).
 * Pricing query-param logic preserved from original.
 */

import type { Metadata } from "next";
import Link from "next/link";
import {
  MapPin,
  Phone,
  EnvelopeSimple,
  Clock,
  WhatsappLogo,
  ArrowSquareOut,
  CalendarCheck,
  NavigationArrow,
  PawPrint,
} from "@phosphor-icons/react/dist/ssr";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { ContactForm } from "@/components/waggies/contact-form";
import { JsonLd, contactPageSchema } from "@/components/waggies/json-ld";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { businessInfo } from "@/lib/business-info";
import {
  resolveServiceContext,
  buildPrefillMessage,
  estimateUrl,
} from "@/data/pricing";

export const metadata: Metadata = {
  title: "Contact Us — Waggies Pet Care Abuja",
  description:
    "Get in touch with Waggies Pet Services in Abuja. Book boarding, grooming, vet care, training, or relocation. Call, WhatsApp, email, or visit us.",
  alternates: { canonical: "/contact" },
  openGraph: {
    title: "Contact Waggies — Abuja Pet Care",
    description:
      "Get in touch with Waggies Pet Services in Abuja. Call, WhatsApp, email, or visit us.",
    url: "/contact",
  },
};

type ContactSearchParams = {
  intent?: string;
  service?: string;
  variant?: string;
  tier?: string;
  quantity?: string;
  summary?: string;
  message?: string;
};

const GOOGLE_MAPS_EMBED_URL =
  "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3939.758!2d7.4913!3d9.0579!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zOcKwMDMnMzQuNCJOIDfCsDI5JzI4LjciRQ!5e0!3m2!1sen!2sng!4v1";

const GOOGLE_MAPS_DIRECTIONS_URL = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(businessInfo.addressFormatted)}`;

export default async function ContactPage({
  searchParams,
}: {
  searchParams: Promise<ContactSearchParams>;
}) {
  const sp = await searchParams;

  const resolved = resolveServiceContext(sp.service ?? null, sp.variant ?? null);

  const context = {
    service: resolved.service,
    variant: resolved.variant ?? "",
    tier: sp.tier ?? "",
    intent: sp.intent ?? "consult",
    quantity: sp.quantity ?? "",
    summary: sp.summary ?? "",
  };

  const prefillMessage =
    sp.message && sp.message.trim() !== ""
      ? sp.message
      : buildPrefillMessage({
          service: context.service,
          variant: context.variant,
          tier: context.tier,
          intent: context.intent,
          summary: context.summary,
        });

  const hasPricingContext = Boolean(context.service || context.summary);

  return (
    <>
      {/* ── Breadcrumb ────────────────────────────────────────── */}
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Contact Us", href: "/contact" }]}
      />

      {/* ── Main two-column layout ────────────────────────────── */}
      <section
        className="py-12 md:py-16 bg-white"
        aria-labelledby="contact-page-heading"
      >
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          {/* Page heading */}
          <div className="mb-10 md:mb-12">
            <h1
              id="contact-page-heading"
              className="font-serif text-3xl md:text-4xl font-bold text-primary-dark"
            >
              Contact Waggies
            </h1>
            <p className="mt-2 text-primary-dark/60 text-base leading-relaxed max-w-2xl">
              Have a question, want to make a booking, or need a quote? We&rsquo;d
              love to hear from you.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 lg:gap-14">
            {/* ── LEFT: Info Column (3/5) ─────────────────────── */}
            <div className="lg:col-span-3 flex flex-col gap-8">
              {/* Business Identity */}
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <PawPrint
                    className="text-2xl text-primary"
                    weight="fill"
                    aria-hidden="true"
                  />
                </div>
                <div>
                  <h2 className="text-h3 text-primary-dark">
                    {businessInfo.name} Pet Services
                  </h2>
                  <p className="text-sm text-primary-dark/60">
                    Abuja&rsquo;s comprehensive pet care centre
                  </p>
                </div>
              </div>

              {/* Address + Map */}
              <div>
                <div className="flex items-center gap-2 mb-3">
                  <MapPin
                    className="text-lg text-primary"
                    weight="fill"
                    aria-hidden="true"
                  />
                  <h3 className="text-label text-primary-dark">
                    Our Address
                  </h3>
                </div>
                <p className="text-sm text-primary-dark/70 leading-relaxed mb-4">
                  {businessInfo.addressFormatted}
                </p>
                <div className="rounded-2xl overflow-hidden border border-primary/10 shadow-sm">
                  <iframe
                    src={GOOGLE_MAPS_EMBED_URL}
                    width="100%"
                    height={300}
                    style={{ border: 0 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Waggies location on Google Maps"
                    className="w-full"
                  />
                </div>
                <a
                  href={GOOGLE_MAPS_DIRECTIONS_URL}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 mt-3 text-sm font-medium text-primary hover:text-primary-dark transition-colors"
                >
                  <NavigationArrow
                    className="text-base"
                    weight="bold"
                    aria-hidden="true"
                  />
                  Get Directions on Google Maps
                  <ArrowSquareOut
                    className="text-sm"
                    weight="bold"
                    aria-hidden="true"
                  />
                </a>
              </div>

              {/* Phone & WhatsApp */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Phone */}
                <a
                  href={businessInfo.phoneHref}
                  className="flex items-start gap-3 p-4 bg-surface rounded-xl border border-primary/5 hover:border-primary/20 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Phone
                      className="text-lg text-primary"
                      weight="fill"
                      aria-hidden="true"
                    />
                  </div>
                  <div>
                    <p className="text-xs text-primary-dark/50">Phone</p>
                    <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors">
                      {businessInfo.phoneLocal}
                    </p>
                    <p className="text-xs text-primary-dark/60 mt-0.5">
                      {businessInfo.phoneInternational}
                    </p>
                  </div>
                </a>

                {/* WhatsApp */}
                <a
                  href={businessInfo.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-start gap-3 p-4 bg-surface rounded-xl border border-primary/5 hover:border-primary/20 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <WhatsappLogo
                      className="text-lg text-primary"
                      weight="fill"
                      aria-hidden="true"
                    />
                  </div>
                  <div>
                    <p className="text-xs text-primary-dark/50">WhatsApp</p>
                    <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors">
                      Chat with us
                    </p>
                    <p className="text-xs text-primary-dark/60 mt-0.5">
                      Quick replies during business hours
                    </p>
                  </div>
                </a>
              </div>

              {/* Email */}
              <a
                href={`mailto:${businessInfo.email}`}
                className="flex items-start gap-3 p-4 bg-surface rounded-xl border border-primary/5 hover:border-primary/20 transition-colors group"
              >
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                  <EnvelopeSimple
                    className="text-lg text-primary"
                    weight="fill"
                    aria-hidden="true"
                  />
                </div>
                <div>
                  <p className="text-xs text-primary-dark/50">Email</p>
                  <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors">
                    {businessInfo.email}
                  </p>
                  <p className="text-xs text-primary-dark/60 mt-0.5">
                    For bookings, quotes &amp; general enquiries
                  </p>
                </div>
              </a>

              {/* Full Opening Hours Table */}
              <div>
                <div className="flex items-center gap-2 mb-4">
                  <Clock
                    className="text-lg text-primary"
                    weight="fill"
                    aria-hidden="true"
                  />
                  <h3 className="text-label text-primary-dark">
                    Opening Hours
                  </h3>
                </div>
                <div className="bg-surface rounded-xl border border-primary/5 overflow-hidden">
                  <table className="w-full text-sm">
                    <tbody>
                      {businessInfo.hours.map((row, i) => (
                        <tr
                          key={row.day}
                          className={`${i > 0 ? "border-t border-primary/5" : ""}`}
                        >
                          <td className="py-3 px-4 font-medium text-primary-dark w-1/3">
                            {row.day}
                          </td>
                          <td className="py-3 px-4 text-primary-dark/70">
                            {row.open} – {row.close}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                <p className="text-xs text-primary-dark/50 mt-3">
                  Boarding guests receive 24/7 supervision regardless of office
                  hours.
                </p>
              </div>

              {/* Directions Text */}
              <div className="p-4 bg-surface-purple rounded-xl border border-primary/10">
                <div className="flex items-start gap-3">
                  <NavigationArrow
                    className="text-lg text-primary shrink-0 mt-0.5"
                    weight="duotone"
                    aria-hidden="true"
                  />
                  <div>
                    <h3 className="text-sm font-semibold text-primary-dark mb-1">
                      Finding Us
                    </h3>
                    <p className="text-sm text-primary-dark/70 leading-relaxed">
                      Waggies is located in Efab City Estate, Life Camp, Abuja.
                      From the Life Camp junction, head into the estate and follow
                      1st Avenue. We&rsquo;re on the left-hand side — look for the
                      Waggies signage. Parking is available on-site.
                    </p>
                  </div>
                </div>
              </div>

              {/* Booking CTA */}
              <div className="bg-primary rounded-2xl p-6 md:p-8 text-center">
                <CalendarCheck
                  className="text-4xl text-white/80 mx-auto mb-3"
                  weight="duotone"
                  aria-hidden="true"
                />
                <h3 className="text-lg font-bold text-white mb-1">
                  Ready to Book?
                </h3>
                <p className="text-sm text-white/70 mb-5">
                  Schedule a service or request a free consultation today.
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                  <Link
                    href="#contact-form"
                    className="inline-flex items-center justify-center gap-2 bg-white text-primary font-bold px-6 py-3 rounded-full hover:bg-surface transition-colors text-sm"
                  >
                    Send a Message
                  </Link>
                  <a
                    href={businessInfo.whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center justify-center gap-2 bg-white/15 text-white font-bold px-6 py-3 rounded-full hover:bg-white/25 transition-colors text-sm"
                  >
                    <WhatsappLogo
                      className="text-base"
                      weight="fill"
                      aria-hidden="true"
                    />
                    WhatsApp Us
                  </a>
                </div>
              </div>
            </div>

            {/* ── RIGHT: Form Column (2/5) ────────────────────── */}
            <div id="contact-form" className="lg:col-span-2">
              <div className="bg-surface rounded-2xl border border-primary/5 p-6 md:p-8">
                <ContactForm
                  service={context.service || undefined}
                  variant={context.variant || undefined}
                  tier={context.tier || undefined}
                  intent={context.intent || undefined}
                  estimateSummary={context.summary || undefined}
                  defaultMessage={prefillMessage}
                />

                {hasPricingContext ? (
                  <div className="mt-6 p-4 bg-surface-purple border border-primary/10 rounded-xl text-sm text-primary-dark/80">
                    <p className="font-semibold text-primary-dark mb-1">
                      Your estimate is attached to this message
                    </p>
                    {context.summary ? <p>{context.summary}</p> : null}
                    <p className="mt-2">
                      <a
                        href={estimateUrl(
                          context.service || null,
                          context.variant || null,
                          context.tier || null,
                        )}
                        className="text-primary font-medium hover:underline"
                      >
                        Adjust estimate
                      </a>
                    </p>
                  </div>
                ) : null}
              </div>
            </div>
          </div>
        </div>
      </section>

      <BreadcrumbSchema items={[{ name: "Contact", path: "/contact" }]} />
      <JsonLd
        data={contactPageSchema(
          "Contact Waggies - Abuja Pet Care",
          "Get in touch with Waggies Pet Services in Abuja. Book boarding, grooming, vet care, training, or relocation.",
          "/contact",
        )}
      />
    </>
  );
}
