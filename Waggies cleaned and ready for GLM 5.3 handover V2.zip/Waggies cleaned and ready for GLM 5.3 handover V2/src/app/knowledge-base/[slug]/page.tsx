import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { kbArticles } from "@/data/content-data";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { JsonLd, articleSchema } from "@/components/waggies/json-ld";
import { KbDetailClient } from "./page-client";
import { siteConfig } from "@/lib/site";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  return kbArticles.map((a) => ({ slug: a.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const article = kbArticles.find((a) => a.slug === slug);
  if (!article) return {};

  return {
    title: `${article.title} - Waggies Knowledge Base`,
    description: article.excerpt,
    alternates: { canonical: `/knowledge-base/${article.slug}` },
    openGraph: {
      title: article.title,
      description: article.excerpt,
      url: `/knowledge-base/${article.slug}`,
      type: "article",
      images: article.imageSrc ? [{ url: article.imageSrc }] : undefined,
    },
  };
}

export default async function KbDetailPage({ params }: Props) {
  const { slug } = await params;
  const article = kbArticles.find((a) => a.slug === slug);
  if (!article) notFound();

  const url = `${siteConfig.siteUrl}/knowledge-base/${article.slug}`;

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Knowledge Base", href: "/knowledge-base" },
          { label: article.title },
        ]}
      />

      <KbDetailClient article={article} />

      <BreadcrumbSchema
        items={[
          { name: "Knowledge Base", path: "/knowledge-base" },
          { name: article.title, path: `/knowledge-base/${article.slug}` },
        ]}
      />
      <JsonLd
        data={articleSchema({
          headline: article.title,
          description: article.excerpt,
          url,
          image: article.imageSrc,
        })}
      />
    </>
  );
}
