"use client";

import { useMemo, useState, useEffect } from "react";
import { kbArticles, type KbArticle } from "@/data/content-data";
import { WaggiesImage } from "@/components/waggies/waggies-image";
import { ShareThisPage } from "@/components/waggies/share-this-page";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { FadeIn } from "@/components/waggies/motion";
import { cn } from "@/lib/utils";

export type KbDetailClientProps = {
  article: KbArticle;
};

export function KbDetailClient({ article }: KbDetailClientProps) {
  const [activeTocId, setActiveTocId] = useState("");

  // Extract headings for table of contents
  const headings = useMemo(() => {
    const matches = article.content.matchAll(/<h([23])>([^<]+)<\/h[23]>/g);
    return Array.from(matches).map((m, i) => ({
      level: Number(m[1]) as 2 | 3,
      text: m[2],
      id: `heading-${i}`,
    }));
  }, [article.content]);

  // Inject IDs into content headings
  const processedContent = useMemo(() => {
    let idx = 0;
    return article.content.replace(
      /<(h[23])>([^<]+)<\/\1>/g,
      (_match, tag, text) => `<${tag} id="heading-${idx++}" class="scroll-mt-24">${text}</${tag}>`,
    );
  }, [article.content]);

  // Track active TOC heading
  useEffect(() => {
    if (headings.length === 0) return;
    const ids = headings.map((h) => h.id);
    const observer = new IntersectionObserver(
      (entries) => {
        for (const entry of entries) {
          if (entry.isIntersecting) {
            setActiveTocId(entry.target.id);
          }
        }
      },
      { rootMargin: "-80px 0px -60% 0px" },
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });
    return () => observer.disconnect();
  }, [headings]);

  return (
    <article className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-10 md:py-16">
      <div className="lg:grid lg:grid-cols-[1fr_240px] lg:gap-12">
        {/* Main column */}
        <div className="max-w-3xl">
          <FadeIn duration={0.3}>
            {/* KB label + category */}
            <div className="flex items-center gap-3 mb-4">
              <span className="inline-flex items-center gap-1.5 rounded-full bg-primary px-3 py-1 text-label text-white">
                <MaterialSymbol name="school" className="text-sm" />
                Knowledge Base
              </span>
              <span className="inline-flex items-center rounded-full bg-surface-purple px-3 py-1 text-label text-primary">
                {article.category}
              </span>
            </div>

            <h1 className="font-serif text-2xl md:text-3xl lg:text-4xl font-bold text-primary-dark leading-tight mb-6">
              {article.title}
            </h1>
          </FadeIn>

          {/* Hero image */}
          <FadeIn duration={0.3} delay={0.1}>
            <div className="relative aspect-[16/9] rounded-2xl overflow-hidden mb-10">
              <WaggiesImage
                src={article.imageSrc}
                alt={article.title}
                fill
                priority
              />
            </div>
          </FadeIn>

          {/* Article body */}
          <FadeIn duration={0.3} delay={0.15}>
            <div
              className="prose max-w-none"
              dangerouslySetInnerHTML={{ __html: processedContent }}
            />
          </FadeIn>

          {/* Share */}
          <div className="mt-10">
            <ShareThisPage
              title={article.title}
              description={article.excerpt}
              variant="row"
            />
          </div>
        </div>

        {/* Table of contents sidebar - desktop only */}
        {headings.length > 0 && (
          <aside className="hidden lg:block">
            <div className="sticky top-28">
              <h3 className="text-label text-primary mb-4">On this page</h3>
              <nav aria-label="Table of contents">
                <ul className="space-y-2">
                  {headings.map((h) => (
                    <li key={h.id}>
                      <a
                        href={`#${h.id}`}
                        className={cn(
                          "block text-sm leading-snug transition-colors",
                          h.level === 3 && "pl-4",
                          activeTocId === h.id
                            ? "text-primary font-semibold"
                            : "text-text-muted hover:text-primary-dark",
                        )}
                      >
                        {h.text}
                      </a>
                    </li>
                  ))}
                </ul>
              </nav>
            </div>
          </aside>
        )}
      </div>
    </article>
  );
}
