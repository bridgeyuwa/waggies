"use client";

import { useState, useMemo } from "react";
import { kbArticles, kbCategories, type KbCategory } from "@/data/content-data";
import { ArticleCard } from "@/components/waggies/content/article-card";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { FadeIn } from "@/components/waggies/motion";
import { cn } from "@/lib/utils";

export function KnowledgeBasePageClient() {
  const [activeCategory, setActiveCategory] = useState<KbCategory | "All">("All");
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    let items =
      activeCategory === "All"
        ? kbArticles
        : kbArticles.filter((a) => a.category === activeCategory);

    if (search.trim()) {
      const q = search.toLowerCase();
      items = items.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.excerpt.toLowerCase().includes(q),
      );
    }

    return items;
  }, [activeCategory, search]);

  return (
    <section className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-20">
      {/* Search + filters */}
      <FadeIn duration={0.3}>
        <div className="flex flex-col sm:flex-row gap-4 mb-10">
          {/* Search input */}
          <div className="relative flex-1 max-w-md">
            <MaterialSymbol
              name="search"
              className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted text-lg"
            />
            <input
              type="text"
              placeholder="Search articles..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-full border border-border-subtle bg-white text-sm text-primary-dark placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>

          {/* Category pills */}
          <div className="flex flex-wrap gap-2">
            {(["All", ...kbCategories] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => setActiveCategory(cat)}
                className={cn(
                  "rounded-full px-4 py-2 text-label transition-colors",
                  activeCategory === cat
                    ? "bg-primary text-white"
                    : "bg-surface-purple text-primary hover:bg-primary/10",
                )}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </FadeIn>

      {/* Articles grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((article, i) => (
            <FadeIn key={article.id} duration={0.3} delay={i * 0.05}>
              <ArticleCard
                href={`/knowledge-base/${article.slug}`}
                title={article.title}
                excerpt={article.excerpt}
                imageSrc={article.imageSrc}
                category={article.category}
              />
            </FadeIn>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <MaterialSymbol name="search_off" className="text-5xl text-text-muted/40 mb-4" />
          <p className="text-text-muted text-body">
            No articles found. Try a different search term or category.
          </p>
        </div>
      )}
    </section>
  );
}
