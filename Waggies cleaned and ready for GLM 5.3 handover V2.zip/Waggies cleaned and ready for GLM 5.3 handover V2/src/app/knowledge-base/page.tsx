import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { JsonLd, collectionPageSchema } from "@/components/waggies/json-ld";
import { KnowledgeBasePageClient } from "./page-client";

export const metadata: Metadata = {
  title: "Knowledge Base - Pet Care Answers",
  description:
    "Quick answers to common questions about pet boarding, grooming, health, and general pet care from Waggies.",
  alternates: { canonical: "/knowledge-base" },
  openGraph: {
    title: "Knowledge Base - Pet Care Answers - Waggies",
    description:
      "Quick answers to common questions about pet boarding, grooming, health, and general pet care from Waggies.",
    url: "/knowledge-base",
  },
};

export default function KnowledgeBasePage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Knowledge Base" }]}
      />

      <HeroPlain
        eyebrow="Knowledge Base"
        eyebrowIcon="school"
        title="Pet Care Answers"
        subtitle="Find quick, practical answers to common questions about pet care services and more."
      />

      <KnowledgeBasePageClient />

      <BreadcrumbSchema items={[{ name: "Knowledge Base", path: "/knowledge-base" }]} />
      <JsonLd
        data={collectionPageSchema(
          "Knowledge Base",
          "/knowledge-base",
          "Pet care answers from Waggies",
        )}
      />
    </>
  );
}
