import type { Metadata } from "next";
import { CaretDown } from "@phosphor-icons/react/dist/ssr";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ServiceCard } from "@/components/waggies/card-service";
import { TestimonialCard } from "@/components/waggies/card-testimonial";
import { CtaPrimary } from "@/components/waggies/cta-primary";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";

import { ServiceComparisonTable } from "@/components/waggies/service-comparison-table";
import {
  servicesIndexHero,
  servicesIndexCards,
  servicesIndexStats,
  servicesIndexStandards,
  servicesIndexInlineFaqs,
} from "@/data/services";
import { homeTestimonials } from "@/data/home";

export const metadata: Metadata = {
  title: "Our Services",
  description:
    "Pet services in Abuja: boarding, grooming, vet care, training, relocation and local transport.",
  alternates: { canonical: "/services" },
  openGraph: {
    title: "Our Services - Waggies Pet Care Abuja",
    description:
      "Pet services in Abuja: boarding, grooming, vet care, training, relocation and local transport.",
    url: "/services",
  },
};

export default function ServicesIndexPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Services", href: "/services" }]}
      />

      <HeroImage
        imageSrc={servicesIndexHero.imageSrc}
        eyebrow={servicesIndexHero.eyebrow}
        title={servicesIndexHero.title}
        subtitle={servicesIndexHero.subtitle}
        variant={servicesIndexHero.variant}
        primaryCta={servicesIndexHero.primaryCta}
      />

      <section id="services" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow="What We Offer"
            title='Services Built Around<br/>Your Pet&rsquo;s Wellbeing'
            subtitle="Every service is designed with your pet's comfort, health, and happiness at the centre."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {servicesIndexCards.map((card, i) => (
              <ServiceCard key={i} {...card} />
            ))}
          </div>
        </div>
      </section>

      {/* Service Comparison Table */}
      <ServiceComparisonTable />

      {/* Stats band */}
      <section className="py-12 bg-surface-purple/40 border-y border-primary/10">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 text-center">
            {servicesIndexStats.map((stat, i) => (
              <div key={i} className="flex flex-col items-center gap-2">
                <PhosphorIcon name={stat.icon} className="text-primary text-2xl" />
                <p className="font-bold text-primary-dark text-sm">{stat.title}</p>
                <p className="text-xs text-primary-dark/50">{stat.subtitle}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Waggies Standard - dark section */}
      <section id="standards" className="w-full bg-primary-dark text-white py-24">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 grid lg:grid-cols-2 gap-16 items-center">
          <div className="max-w-xl">
            <p className="text-label text-secondary">
              {servicesIndexStandards.eyebrow}
            </p>
            <h2
              className="text-h2 mt-3"
              dangerouslySetInnerHTML={{ __html: servicesIndexStandards.title }}
            />
            <p className="text-white/70 mt-4 leading-relaxed">
              {servicesIndexStandards.body}
            </p>
          </div>
          <div className="flex flex-col gap-5">
            {servicesIndexStandards.cards.map((card, i) => (
              <div key={i} className="p-5 rounded-2xl bg-white/5 border border-white/10">
                <h3 className="font-bold">{card.title}</h3>
                <p className="text-white/60 text-sm">{card.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <h2 className="text-h2 mb-12 max-w-lg">
            What pet owners experience after using our services
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {homeTestimonials.map((t, i) => (
              <TestimonialCard key={i} {...t} />
            ))}
          </div>
        </div>
      </section>

      {/* Inline FAQ section */}
      <section className="py-20 bg-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="text-center mb-14">
            <h2 className="text-h2 text-primary-dark leading-tight mb-4">
              Before You Book, Here's What You Should Know
            </h2>
            <p className="text-primary-dark/60 max-w-2xl mx-auto">
              Quick answers to help you choose the right service for your pet with confidence.
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-3">
            {servicesIndexInlineFaqs.map((faq, i) => (
              <details
                key={i}
                className="group bg-white border border-primary/10 rounded-2xl hover:border-primary/30 hover:shadow-sm transition"
              >
                <summary className="flex w-full cursor-pointer items-center justify-between gap-4 px-6 py-5 font-semibold text-primary-dark hover:text-primary transition-colors list-none [&::-webkit-details-marker]:hidden">
                  {faq.question}
                  <CaretDown
                    size={20}
                    weight="bold"
                    className="text-primary shrink-0 transition-transform duration-200 group-open:rotate-180"
                  />
                </summary>
                <p className="px-6 pb-5 pt-3 text-sm text-primary-dark/60 leading-relaxed">
                  {faq.answer}
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="w-full py-20">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <CtaPrimary
            heading="Book Your Pet's"
            headingAccent="Next Visit"
            body="Book a service or speak with our care team today."
            primaryLabel="Book a Service"
            primaryHref="#services"
            primaryIcon="arrow_forward"
            secondaryLabel="Call Us Now"
            secondaryHref="tel:+2349080811902"
            secondaryIcon="call"
          />
        </div>
      </section>

      <BreadcrumbSchema items={[{ name: "Services", path: "/services" }]} />
      <JsonLd
        data={webPageSchema(
          "Our Services - Waggies Pet Care Abuja",
          "Pet services in Abuja: boarding, grooming, vet care, training, relocation and local transport.",
          "/services",
        )}
      />
    </>
  );
}
