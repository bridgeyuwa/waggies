import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { CardPricing } from "@/components/waggies/card-pricing";
import { BoardingStatsBar } from "@/components/waggies/boarding-stats-bar";
import { BoardingFeatureGrid } from "@/components/waggies/boarding-feature-grid";
import { BoardingDayInLife } from "@/components/waggies/boarding-day-in-life";
import { BoardingSafetyCard } from "@/components/waggies/boarding-safety-card";
import { BoardingSiblingLinks } from "@/components/waggies/boarding-sibling-links";
import { CtaPrimary } from "@/components/waggies/cta-primary";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import {
  dogHero,
  dogStats,
  dogPackageHeading,
  dogFeaturesHeading,
  dogFeatures,
  dogDayInLife,
  dogSafetyCard,
  dogCta,
} from "@/data/boarding";
import { estimateUrl } from "@/data/pricing";
import { getFaqsForService } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Dog Boarding",
  description:
    "Premium dog boarding in Abuja with private suites, outdoor play areas, socialisation sessions, and 24/7 supervision.",
  alternates: { canonical: "/services/boarding/dogs" },
  openGraph: {
    title: "Dog Boarding Abuja - Waggies",
    description:
      "Premium dog boarding in Abuja with private suites, outdoor play areas, socialisation sessions, and 24/7 supervision.",
    url: "/services/boarding/dogs",
  },
};

export default function DogBoardingPage() {
  const faqs = getFaqsForService("boarding", "dogs");
  const unit = "/night";

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Boarding", href: "/services/boarding" },
          { label: "Dog Boarding", href: "/services/boarding/dogs" },
        ]}
      />

      <HeroImage {...dogHero} />

      <BoardingStatsBar stats={dogStats} />

      {/* Pricing packages */}
      <section id="boarding-options" className="py-20 bg-secondary/20 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={dogPackageHeading.eyebrow}
            title={dogPackageHeading.title}
            subtitle={dogPackageHeading.subtitle}
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-10 mx-auto">
            {/* Basic */}
            <CardPricing
              variant="standard"
              tierLabel="Basic"
              price="₦10,000"
              unit={unit}
              features={[
                { label: "1 dog boarding", included: true },
                { label: "Daily walks", included: true },
                { label: "24/7 supervision", included: false },
                { label: "Grooming service", included: false },
              ]}
              ctaLabel="Get Estimate"
              ctaHref={estimateUrl("boarding-dogs", null, "basic")}
            />
            {/* Premium */}
            <CardPricing
              variant="featured"
              tierLabel="Premium"
              badgeLabel="Most Popular"
              price="₦18,000"
              unit={unit}
              features={[
                { label: "2 dogs boarding", included: true },
                { label: "Daily walks", included: true },
                { label: "24/7 supervision", included: true },
                { label: "Grooming service", included: true },
              ]}
              ctaLabel="Get Estimate"
              ctaHref={estimateUrl("boarding-dogs", null, "premium")}
            />
            {/* Deluxe */}
            <CardPricing
              variant="standard"
              tierLabel="Deluxe"
              price="₦25,000"
              unit={unit}
              features={[
                { label: "3+ dogs boarding", included: true },
                { label: "Daily walks", included: true },
                { label: "24/7 supervision", included: true },
                { label: "Grooming + spa", included: true },
              ]}
              ctaLabel="Get Estimate"
              ctaHref={estimateUrl("boarding-dogs", null, "deluxe")}
            />
          </div>
          <p className="mt-8 text-center text-sm text-primary-dark/50">
            Need a custom stay or extended booking?{" "}
            <a href="/contact" className="text-primary font-medium hover:underline">
              Contact us
            </a>{" "}
            or{" "}
            <a href="/services/pricing" className="text-primary font-medium hover:underline">
              view full pricing
            </a>
            .
          </p>
        </div>
      </section>

      {/* Feature grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={dogFeaturesHeading.eyebrow}
            title={dogFeaturesHeading.title}
            subtitle={dogFeaturesHeading.subtitle}
          />
          <BoardingFeatureGrid features={dogFeatures} />
        </div>
      </section>

      {/* Day in the life */}
      <BoardingDayInLife {...dogDayInLife} />

      {/* Safety card */}
      <BoardingSafetyCard {...dogSafetyCard} />

      {/* CTA */}
      <section className="py-16 bg-surface-purple border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <CtaPrimary
            heading={dogCta.heading}
            body={dogCta.body}
            primaryLabel={dogCta.primaryLabel}
            primaryHref={dogCta.primaryHref}
            primaryIcon={dogCta.primaryIcon}
            secondaryLabel={dogCta.secondaryLabel}
            secondaryHref={dogCta.secondaryHref}
            secondaryIcon={dogCta.secondaryIcon}
          />
        </div>
      </section>

      {/* Sibling links */}
      <BoardingSiblingLinks current="dogs" />

      {/* FAQ */}
      {faqs.length > 0 ? (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              spacing="mb-8"
            />
            <FaqAccordion
              faqs={faqs.map((f) => ({ question: f.question, answer: f.answer }))}
            />
            <p className="mt-6 text-sm text-primary-dark/50">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      ) : null}

      <JsonLd
        data={serviceSchema(
          "Dog Boarding Abuja - Waggies",
          "Premium dog boarding in Abuja with private suites, outdoor play areas, socialisation sessions, and 24/7 supervision.",
          "/services/boarding/dogs",
        )}
      />
    </>
  );
}
