import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { CardPricing } from "@/components/waggies/card-pricing";
import { BoardingStatsBar } from "@/components/waggies/boarding-stats-bar";
import { BoardingFeatureGrid } from "@/components/waggies/boarding-feature-grid";
import { BoardingDayInLife } from "@/components/waggies/boarding-day-in-life";
import { BoardingSafetyCard } from "@/components/waggies/boarding-safety-card";
import { BoardingSiblingLinks } from "@/components/waggies/boarding-sibling-links";
import { CtaPrimary } from "@/components/waggies/cta-primary";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import {
  catHero,
  catStats,
  catPackageHeading,
  catFeaturesHeading,
  catFeatures,
  catDayInLife,
  catSafetyCard,
  catFelineSection,
  catCta,
} from "@/data/boarding";
import { estimateUrl } from "@/data/pricing";
import { getFaqsForService } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Cat Boarding",
  description:
    "Cat boarding in Abuja in a calm, dog-free environment with private condos, enrichment, and daily photo updates.",
  alternates: { canonical: "/services/boarding/cats" },
  openGraph: {
    title: "Cat Boarding Abuja - Waggies",
    description:
      "Cat boarding in Abuja in a calm, dog-free environment with private condos, enrichment, and daily photo updates.",
    url: "/services/boarding/cats",
  },
};

export default function CatBoardingPage() {
  const faqs = getFaqsForService("boarding", "cats");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Boarding", href: "/services/boarding" },
          { label: "Cat Boarding", href: "/services/boarding/cats" },
        ]}
      />

      <HeroImage {...catHero} />

      <BoardingStatsBar stats={catStats} />

      {/* Pricing packages */}
      <section id="boarding-options" className="py-20 bg-secondary/20 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={catPackageHeading.eyebrow}
            title={catPackageHeading.title}
            subtitle={catPackageHeading.subtitle}
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-10 mx-auto">
            {/* Cozy */}
            <CardPricing
              variant="standard"
              tierLabel="Cozy"
              price="₦8,000"
              unit="/night"
              features={[
                { label: "1 cat condo", included: true },
                { label: "Daily enrichment", included: true },
                { label: "Photo updates", included: true },
                { label: "Private playroom", included: false },
              ]}
              ctaLabel="Get Estimate"
              ctaHref={estimateUrl("boarding-cats", null, "cozy")}
            />
            {/* Premium */}
            <CardPricing
              variant="featured"
              tierLabel="Premium"
              badgeLabel="Most Popular"
              price="₦14,000"
              unit="/night"
              features={[
                { label: "2 cats (same condo)", included: true },
                { label: "Daily enrichment", included: true },
                { label: "Daily photo updates", included: true },
                { label: "Private playroom time", included: true },
              ]}
              ctaLabel="Get Estimate"
              ctaHref={estimateUrl("boarding-cats", null, "premium")}
            />
            {/* Luxury */}
            <CardPricing
              variant="standard"
              tierLabel="Luxury"
              price="₦22,000"
              unit="/night"
              features={[
                { label: "Luxury multi-level condo", included: true },
                { label: "1-on-1 play sessions", included: true },
                { label: "Daily vet check", included: true },
                { label: "Complimentary groom", included: true },
              ]}
              ctaLabel="Get Estimate"
              ctaHref={estimateUrl("boarding-cats", null, "luxury")}
            />
          </div>
          <p className="mt-8 text-center text-sm text-primary-dark/50">
            Bringing bonded cats or need a longer stay?{" "}
            <a href="/contact" className="text-primary font-medium hover:underline">
              Contact us
            </a>{" "}
            for a tailored quote.
          </p>
        </div>
      </section>

      {/* Feature grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={catFeaturesHeading.eyebrow}
            title={catFeaturesHeading.title}
            subtitle={catFeaturesHeading.subtitle}
          />
          <BoardingFeatureGrid features={catFeatures} />
        </div>
      </section>

      {/* Day in the life */}
      <BoardingDayInLife {...catDayInLife} />

      {/* Safety card */}
      <BoardingSafetyCard {...catSafetyCard} />

      {/* Built for Feline Instincts - two-column section */}
      <section className="py-20 bg-white border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="flex flex-col lg:flex-row gap-12 items-center">
            <div className="flex-1">
              <span className="text-primary font-bold tracking-widest uppercase text-xs mb-3 block">
                {catFelineSection.eyebrow}
              </span>
              <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark leading-tight mb-4">
                {catFelineSection.heading}
              </h2>
              <p className="text-primary-dark/60 text-lg max-w-prose mb-8">
                {catFelineSection.body}
              </p>
              <ul className="space-y-4 text-primary-dark/70">
                {catFelineSection.bullets.map((bullet, i) => (
                  <li key={i} className="flex gap-3">
                    <MaterialSymbol
                      name="check_circle"
                      filled
                      className="text-primary shrink-0"
                    />
                    <span>
                      <strong className="text-primary-dark">{bullet.bold}</strong>
                      {bullet.text}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex-1 w-full">
              { }
              <img
                src={catFelineSection.image}
                alt={catFelineSection.imageAlt}
                className="rounded-2xl w-full aspect-[4/3] object-cover shadow-[var(--shadow-soft)]"
                loading="lazy"
                decoding="async"
              />
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-16 bg-surface-purple border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <CtaPrimary
            heading={catCta.heading}
            body={catCta.body}
            primaryLabel={catCta.primaryLabel}
            primaryHref={catCta.primaryHref}
            primaryIcon={catCta.primaryIcon}
            secondaryLabel={catCta.secondaryLabel}
            secondaryHref={catCta.secondaryHref}
            secondaryIcon={catCta.secondaryIcon}
          />
        </div>
      </section>

      <BoardingSiblingLinks current="cats" />

      {faqs.length > 0 ? (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              spacing="mb-8"
            />
            <FaqAccordion
              faqs={faqs.map((f) => ({ question: f.question, answer: f.answer }))}
            />
            <p className="mt-6 text-sm text-primary-dark/50">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      ) : null}

      <JsonLd
        data={serviceSchema(
          "Cat Boarding Abuja - Waggies",
          "Cat boarding in Abuja in a calm, dog-free environment with private condos, enrichment, and daily photo updates.",
          "/services/boarding/cats",
        )}
      />
    </>
  );
}
