import type { Metadata } from "next";
import Link from "next/link";
import { Dog, Heart, AirplaneTilt } from "@phosphor-icons/react/dist/ssr";
import { PageHeader } from "@/components/waggies/page-header";
import { SectionHeading } from "@/components/waggies/section-heading";
import { PricingCalculator } from "@/components/waggies/pricing-calculator";
import { PricingTierCard } from "@/components/waggies/pricing-tier-card";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { pricingConfig, resolveServiceContext, estimateUrl } from "@/data/pricing";

export const metadata: Metadata = {
  title: "Pricing",
  description:
    "Transparent, honest pricing for Waggies pet boarding, grooming, and vet care services in Abuja, Nigeria. No hidden fees.",
  alternates: { canonical: "/services/pricing" },
  openGraph: {
    title: "Pet Care Pricing Abuja - Waggies",
    description:
      "Transparent, honest pricing for Waggies pet boarding, grooming, and vet care services in Abuja, Nigeria. No hidden fees.",
    url: "/services/pricing",
  },
}

/**
 * Pricing page.
 *
 * The pricing calculator reads query params (`service`, `variant`, `tier`)
 * from the URL. In Next.js App Router, Server Components can read searchParams
 * via the page props. We pass them through to the client-side calculator
 * which reproduces the Alpine state machine.
 *
 * NOTE: Next.js 15+ made `searchParams` a Promise. It must be awaited
 * before accessing its properties. Treating it synchronously causes
 * `searchParams.service` to be `undefined`, which silently breaks the
 * calculator's URL-param initialisation (the form stays empty even when
 * the URL has ?service=boarding-exotic).
 */
export default async function PricingPage({
  searchParams,
}: {
  searchParams: Promise<{ service?: string; variant?: string; tier?: string }>;
}) {
  const sp = await searchParams;

  // Reproduce PricingQuote::resolveServiceContext() on the server so the
  // calculator receives the resolved service/variant (e.g. "boarding-dogs"
  // alias → service="boarding", variant="dogs").
  const resolved = resolveServiceContext(
    sp.service ?? null,
    sp.variant ?? null,
  );

  // The pricing page shows two static pricing sections after the calculator:
  // boarding (3 variants × 3 tiers) and grooming (3 tiers). Source:
  // resources/views/pages/services/pricing.blade.php lines 20-55.
  const boardingService = pricingConfig.services.boarding;
  const groomingService = pricingConfig.services.grooming;

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Pricing", href: "/services/pricing" },
        ]}
      />

      <PageHeader
        align="center"
        eyebrow="Transparent Pricing"
        title="Simple, Honest Pricing"
        subtitle="No hidden fees. Use our estimator for a tailored quote, then book or speak with our team."
      />

      {/* Calculator - client component with URL-param initialisation */}
      <PricingCalculator
        service={resolved.service || null}
        variant={resolved.variant}
        tier={sp.tier ?? null}
      />

      {/* Boarding section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={boardingService.label}
            title="Overnight Boarding"
          />
          {boardingService.variants ? (
            <>
              {Object.entries(boardingService.variants).map(([variantKey, variant]) => (
                <div key={variantKey}>
                  <h3 className="mt-10 mb-6 text-h4 text-primary-dark">
                    {variant.label}
                  </h3>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
                    {Object.entries(variant.tiers).map(([tierKey, tier]) => (
                      <PricingTierCard
                        key={tierKey}
                        tier={tier}
                        unit={boardingService.unit}
                        serviceKey="boarding"
                        variantKey={variantKey}
                        tierKey={tierKey}
                      />
                    ))}
                  </div>
                </div>
              ))}
            </>
          ) : null}
        </div>
      </section>

      {/* Grooming section */}
      <section className="py-20 bg-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading eyebrow={groomingService.label} title="Grooming Packages" />
          {groomingService.tiers ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-10">
              {Object.entries(groomingService.tiers).map(([tierKey, tier]) => (
                <PricingTierCard
                  key={tierKey}
                  tier={tier}
                  unit={groomingService.unit}
                  serviceKey="grooming"
                  variantKey={null}
                  tierKey={tierKey}
                />
              ))}
            </div>
          ) : null}
        </div>
      </section>

      {/* Final CTA - "Training, vet care, or relocation?" */}
      <section className="py-16 bg-white">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="text-h2 text-primary-dark mb-3">
            Training, vet care, or relocation?
          </h2>
          <p className="text-primary-dark/60 mb-8">
            Jump straight to the service you need. The estimator will pre-select
            your choice so you can get a price in seconds.
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Link
              href={estimateUrl("training")}
              className="group flex flex-col items-center gap-3 rounded-2xl border-2 border-surface-purple bg-white p-6 transition hover:border-primary hover:shadow-sm"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary transition group-hover:bg-primary group-hover:text-white">
                <Dog className="h-6 w-6" weight="fill" />
              </span>
              <span className="text-sm font-bold text-primary-dark">
                Estimate Training Cost
              </span>
            </Link>

            <Link
              href={estimateUrl("vet-care")}
              className="group flex flex-col items-center gap-3 rounded-2xl border-2 border-surface-purple bg-white p-6 transition hover:border-primary hover:shadow-sm"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary transition group-hover:bg-primary group-hover:text-white">
                <Heart className="h-6 w-6" weight="fill" />
              </span>
              <span className="text-sm font-bold text-primary-dark">
                Estimate Vet Care Cost
              </span>
            </Link>

            <Link
              href={estimateUrl("relocation")}
              className="group flex flex-col items-center gap-3 rounded-2xl border-2 border-surface-purple bg-white p-6 transition hover:border-primary hover:shadow-sm"
            >
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 text-primary transition group-hover:bg-primary group-hover:text-white">
                <AirplaneTilt className="h-6 w-6" weight="fill" />
              </span>
              <span className="text-sm font-bold text-primary-dark">
                Estimate Relocation Cost
              </span>
            </Link>
          </div>
        </div>
      </section>

      <JsonLd
        data={webPageSchema(
          "Pet Care Pricing Abuja - Waggies",
          "Transparent, honest pricing for Waggies pet boarding, grooming, and vet care services in Abuja, Nigeria. No hidden fees.",
          "/services/pricing",
        )}
      />
    </>
  );
}
