import { ServicePageEnhanced } from "@/components/waggies/sections/service-page-enhanced";
import { vetCareHero } from "@/data/services";
import { getFaqsForService } from "@/data/faqs";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import {
  JsonLd,
  serviceSchema,
  faqPageSchema,
} from "@/components/waggies/json-ld";
import { ShareThisPage } from "@/components/waggies/share-this-page";

export const metadata = {
  title: "Veterinary Care",
  description:
    "Veterinary consultations, vaccinations, wellness check-ups and minor treatments from our on-site vet - every day at Waggies Abuja.",
  alternates: { canonical: "/services/vet-care" },
  openGraph: {
    title: "On-Site Veterinary Care Abuja - Waggies",
    description:
      "Veterinary consultations, vaccinations, wellness check-ups and minor treatments from our on-site vet - every day at Waggies Abuja.",
    url: "/services/vet-care",
  },
};

export default function VetCarePage() {
  const faqs = getFaqsForService("vet-care");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Veterinary Care", href: "/services/vet-care" },
        ]}
      />

      <ServicePageEnhanced
        title="Veterinary Care"
        subtitle="Consultations, vaccinations, wellness checks, and minor treatments - delivered by our on-site veterinarian every day of the week."
        description="Having a vet on-site every day means your pet gets professional care without the stress of a separate vet visit. Our vet provides comprehensive services from routine check-ups to minor surgical procedures - all in a calm, familiar environment."
        eyebrow="On-Site Vet Care · Abuja"
        imageSrc={vetCareHero.imageSrc}
        imageAlt="Veterinary care at Waggies Abuja"
        ctaText="Book Appointment"
        ctaHref="/contact?intent=book&service=vet-care"
        features={[
          "Full nose-to-tail wellness examinations and health consultations",
          "Core and non-core vaccinations on a personalised schedule",
          "Routine wellness check-ups to catch issues early",
          "Diagnosis, prescriptions, and minor treatment for common conditions",
          "Flea, tick, and worm treatments and prevention advice",
          "In-clinic diagnostic tests and external lab coordination",
          "Dental examination, scaling, and minor dental procedures",
          "Microchipping for permanent pet identification",
          "Pre-travel health certificates and documentation",
          "Weight monitoring and nutritional counselling",
          "Spay/neuter consultations and scheduling",
          "Emergency first aid and stabilisation",
        ]}
        benefits={[
          "Our vet is present on-site every day of the week, including weekends - no separate trip needed.",
          "All vet services are delivered to certified professional standards - PCSA registered.",
          "Boarding guests receive immediate veterinary attention if any concern arises during their stay.",
          "Consultations happen in a calm, familiar setting - significantly less anxiety for your pet.",
          "Full medical records maintained digitally for easy access and continuity of care.",
          "Vaccination reminders sent automatically so you never miss a booster.",
        ]}
        packages={[
          {
            name: "Wellness Check",
            price: "₦5,000",
            duration: "20-30 min",
            features: [
              "Full physical examination",
              "Weight & temperature check",
              "Health assessment report",
              "Diet & exercise advice",
            ],
          },
          {
            name: "Vaccination Package",
            price: "₦12,000",
            duration: "30-45 min",
            popular: true,
            features: [
              "Wellness check included",
              "Core vaccines (DHPP, Rabies)",
              "Non-core as needed",
              "Vaccination certificate",
              "Booster reminders",
            ],
          },
          {
            name: "Comprehensive Exam",
            price: "₦18,000",
            duration: "45-60 min",
            features: [
              "Extended physical exam",
              "Blood work & lab tests",
              "Dental assessment",
              "Parasite screening",
              "Full health report",
              "Follow-up consultation",
            ],
          },
        ]}
        faqItems={faqs.map((f) => ({
          question: f.question,
          answer: f.answer,
        }))}
      />

      <ShareThisPage
        variant="row"
        title="Veterinary Care - Waggies"
        description="Veterinary consultations, vaccinations, wellness check-ups and minor treatments from our on-site vet - every day at Waggies Abuja."
      />

      <JsonLd
        data={serviceSchema(
          "On-Site Veterinary Care Abuja - Waggies",
          "Veterinary consultations, vaccinations, wellness check-ups and minor treatments from our on-site vet - every day at Waggies Abuja.",
          "/services/vet-care",
        )}
      />

      <JsonLd
        data={faqPageSchema(
          faqs.map((faq) => ({
            question: faq.question,
            answer: faq.answer,
          })),
        )}
      />
    </>
  );
}
