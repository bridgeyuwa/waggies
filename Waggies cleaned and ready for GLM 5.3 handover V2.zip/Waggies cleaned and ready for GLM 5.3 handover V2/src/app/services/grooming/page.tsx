import { SimpleServicePage } from "@/components/waggies/sections/simple-service-page";
import { ServicePageEnhanced } from "@/components/waggies/sections/service-page-enhanced";
import {
  groomingHero,
  groomingSectionHeading,
  groomingFeatures,
  groomingFeatureBand,
} from "@/data/services";
import { getFaqsForService } from "@/data/faqs";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import {
  JsonLd,
  serviceSchema,
  faqPageSchema,
} from "@/components/waggies/json-ld";
import { ShareThisPage } from "@/components/waggies/share-this-page";

export const metadata = {
  title: "Pet Grooming Spa",
  description:
    "Breed-specific pet grooming in Abuja: baths, precision styling, nail trims, and de-shed treatments by experienced groomers.",
  alternates: { canonical: "/services/grooming" },
  openGraph: {
    title: "Pet Grooming Abuja - Waggies",
    description:
      "Breed-specific pet grooming in Abuja: baths, precision styling, nail trims, and de-shed treatments by experienced groomers.",
    url: "/services/grooming",
  },
};

export default function GroomingPage() {
  const faqs = getFaqsForService("grooming");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Grooming", href: "/services/grooming" },
        ]}
      />

      <ServicePageEnhanced
        title="Pet Grooming Spa"
        subtitle="Breed-specific treatments, baths, and precision styling by experienced groomers in a calm, purpose-built spa."
        description="Our groomers use pet-safe products in a calm environment designed to keep your pet relaxed and comfortable throughout every treatment."
        eyebrow="Grooming Spa · Abuja"
        imageSrc={groomingHero.imageSrc}
        imageAlt="Pet grooming spa at Waggies Abuja"
        ctaText="Book Grooming"
        ctaHref="/contact?intent=book&service=grooming"
        features={[
          "Bath with breed-specific shampoo and conditioner",
          "Professional blow-dry and brush-out for a flawless finish",
          "Breed-standard precision cut and styling by experienced groomers",
          "Deep de-shed treatment to dramatically reduce loose fur",
          "Gentle facial wash, eye cleaning, and ear inspection",
          "Safe nail trim and grind to a comfortable length",
          "Teeth brushing with pet-safe enzymatic toothpaste",
          "Light cologne spritz and bandana finishing touch",
          "Anal gland expression (upon request)",
          "Sanitary trim and paw pad tidy-up",
          "Flea and tick bath treatment available",
          "Blueberry facial for tear stain removal",
        ]}
        benefits={[
          "All groomers are professionally trained and experienced - your pet is in expert hands every time.",
          "We use only quality, non-toxic, pet-safe shampoos and conditioners - no harsh chemicals.",
          "Patient, low-stress handling techniques especially for nervous or anxious pets.",
          "We respect your time - drop-off and collection slots run to schedule, every single day.",
          "Full photo report sent after every groom so you can see the results before pickup.",
          "Breed-specific expertise means your pet gets a cut that suits their coat type and breed standard.",
        ]}
        packages={[
          {
            name: "Basic Bath",
            price: "₦8,500",
            duration: "45-60 min",
            features: [
              "Shampoo bath",
              "Blow-dry and brush-out",
              "Ear cleaning",
              "Nail trim",
              "Light spritz",
            ],
          },
          {
            name: "Premium Groom",
            price: "₦15,000",
            duration: "90-120 min",
            popular: true,
            features: [
              "Breed-specific shampoo bath",
              "Professional blow-dry",
              "Full breed-standard cut & styling",
              "Ear cleaning & nail grind",
              "Teeth brushing",
              "De-shed treatment",
              "Bandana finish",
            ],
          },
          {
            name: "Luxury Spa",
            price: "₦22,000",
            duration: "2-3 hours",
            features: [
              "Everything in Premium Groom",
              "Blueberry tear-stain facial",
              "Deep conditioning treatment",
              "Paw pad moisturising",
              "Flea/tick check & treatment",
              "Photo report after groom",
              "Complimentary bandana choice",
            ],
          },
        ]}
        faqItems={faqs.map((f) => ({
          question: f.question,
          answer: f.answer,
        }))}
      />

      <ShareThisPage
        variant="row"
        title="Pet Grooming Spa - Waggies"
        description="Breed-specific pet grooming in Abuja: baths, precision styling, nail trims, and de-shed treatments by experienced groomers."
      />

      <JsonLd
        data={serviceSchema(
          "Pet Grooming Spa Abuja - Waggies",
          "Breed-specific pet grooming in Abuja: baths, precision styling, nail trims, and de-shed treatments by experienced groomers.",
          "/services/grooming",
        )}
      />

      <JsonLd
        data={faqPageSchema(
          faqs.map((faq) => ({
            question: faq.question,
            answer: faq.answer,
          })),
        )}
      />
    </>
  );
}
