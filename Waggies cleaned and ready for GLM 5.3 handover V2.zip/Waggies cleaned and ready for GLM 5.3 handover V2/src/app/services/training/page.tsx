import { ServicePageEnhanced } from "@/components/waggies/sections/service-page-enhanced";
import { trainingHero } from "@/data/services";
import { getFaqsForService } from "@/data/faqs";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import {
  JsonLd,
  serviceSchema,
  faqPageSchema,
} from "@/components/waggies/json-ld";
import { ShareThisPage } from "@/components/waggies/share-this-page";

export const metadata = {
  title: "Dog Training",
  description:
    "Science-based, positive-reinforcement dog training in Abuja for puppies and adults - obedience, behaviour modification, and group classes.",
  alternates: { canonical: "/services/training" },
  openGraph: {
    title: "Dog Training Abuja - Waggies",
    description:
      "Science-based, positive-reinforcement dog training in Abuja for puppies and adults - obedience, behaviour modification, and group classes.",
    url: "/services/training",
  },
};

export default function TrainingPage() {
  const faqs = getFaqsForService("training");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Dog Training", href: "/services/training" },
        ]}
      />

      <ServicePageEnhanced
        title="Dog Training"
        subtitle="Science-based, positive-reinforcement training programmes for puppies and adult dogs - building confidence, manners, and a stronger bond."
        description="Our trainers use only reward-based, force-free methods. Whether you're starting with a new puppy or working through behavioural challenges, we design a programme that fits your dog's temperament and your goals."
        eyebrow="Dog Training · Abuja"
        imageSrc={trainingHero.imageSrc}
        imageAlt="Dog training session at Waggies Abuja"
        ctaText="Book Training"
        ctaHref="/contact?intent=consult&service=training"
        features={[
          "Puppy socialisation, recall, and bite inhibition (8-16 weeks)",
          "Basic obedience - sit, stay, come, heel, and leash manners",
          "Advanced obedience - off-lead reliability and distance commands",
          "Behaviour modification for reactivity, anxiety, and aggression",
          "Small group classes for socialisation and real-world practice",
          "1-to-1 private sessions tailored to your dog's specific needs",
          "Clicker training and marker-based positive reinforcement",
          "Loose-lead walking and polite greeting training",
          "Separation anxiety management programmes",
          "Trick training for mental stimulation and fun",
          "Follow-up sessions and progress tracking included",
          "Written training plan and homework for between sessions",
        ]}
        benefits={[
          "Reward-based, force-free methods only - we never use aversive tools or punishment-based techniques.",
          "All trainers are experienced in canine behaviour and positive-reinforcement training methods.",
          "Training that strengthens the relationship between you and your dog - bond-building focus.",
          "Clear goals set at the outset and tracked throughout the programme - measurable progress.",
          "Flexible scheduling - weekday, weekend, and evening session slots available.",
          "Small class sizes (max 6 dogs) ensure every dog gets personal attention.",
        ]}
        packages={[
          {
            name: "Puppy Basics",
            price: "₦25,000",
            duration: "6 sessions · 45 min each",
            features: [
              "Socialisation with people & dogs",
              "Sit, stay, recall foundation",
              "Bite inhibition & toilet training",
              "Leash introduction",
              "Puppy manual & homework",
            ],
          },
          {
            name: "Obedience Course",
            price: "₦45,000",
            duration: "8 sessions · 60 min each",
            popular: true,
            features: [
              "All basic commands",
              "Leash manners & heel",
              "Polite greetings",
              "Distraction proofing",
              "Written training plan",
              "Progress tracking report",
            ],
          },
          {
            name: "Behavioural Program",
            price: "₦75,000",
            duration: "Custom · 6-12 sessions",
            features: [
              "1-to-1 behavioural assessment",
              "Custom modification plan",
              "Reactivity & anxiety work",
              "Environmental management",
              "Ongoing trainer support",
              "Unlimited phone check-ins",
            ],
          },
        ]}
        faqItems={faqs.map((f) => ({
          question: f.question,
          answer: f.answer,
        }))}
      />

      <ShareThisPage
        variant="row"
        title="Dog Training - Waggies"
        description="Science-based, positive-reinforcement dog training in Abuja for puppies and adults - obedience, behaviour modification, and group classes."
      />

      <JsonLd
        data={serviceSchema(
          "Dog Training Abuja - Waggies",
          "Science-based, positive-reinforcement dog training in Abuja for puppies and adults - obedience, behaviour modification, and group classes.",
          "/services/training",
        )}
      />

      <JsonLd
        data={faqPageSchema(
          faqs.map((faq) => ({
            question: faq.question,
            answer: faq.answer,
          })),
        )}
      />
    </>
  );
}
