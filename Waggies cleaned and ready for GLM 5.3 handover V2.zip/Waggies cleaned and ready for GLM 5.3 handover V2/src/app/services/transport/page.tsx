import { redirect } from 'next/navigation';

export default function TransportRedirect() {
  redirect('/relocation/transport');
}
