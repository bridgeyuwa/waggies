/**
 * Twitter Card image (re-exported from the default OG image).
 *
 * Next.js App Router convention: `twitter-image.{ts,tsx}` follows the
 * same rules as `opengraph-image.{ts,tsx}` and is emitted as the
 * `twitter:image` meta tag. We re-use the default site OG image since
 * it's already sized at the recommended 1200×630 (which works for both
 * `summary_large_image` and `summary` Twitter cards).
 *
 * https://nextjs.org/docs/app/api-reference/file-conventions/metadata/twitter-image
 */

export { default, alt, size, contentType } from "./opengraph-image";
