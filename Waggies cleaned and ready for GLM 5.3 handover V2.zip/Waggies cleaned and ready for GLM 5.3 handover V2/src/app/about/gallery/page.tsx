/**
 * /about/gallery - Photo Gallery page.
 *
 * Uses the GalleryLightbox component for an interactive masonry gallery
 * with category filtering and a full-screen lightbox modal.
 *
 * IMAGE STATUS: TEMPORARY stock photos from Unsplash.
 * These will be replaced with real Waggies facility photographs
 * once supplied by the client.
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { PageHeader } from "@/components/waggies/page-header";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { GalleryLightbox } from "@/components/waggies/sections/gallery-lightbox";
import { galleryHero, galleryGroups } from "@/data/gallery";

export const metadata: Metadata = {
  title: "Photo Gallery",
  description:
    "Browse Waggies' boarding suites, grooming spa, veterinary clinic, training grounds, and happy guest photos.",
  alternates: { canonical: "/about/gallery" },
  openGraph: {
    title: "Photo Gallery - Waggies Pet Care Abuja",
    description:
      "Browse Waggies' boarding suites, grooming spa, veterinary clinic, training grounds, and happy guest photos.",
    url: "/about/gallery",
  },
};

export default function GalleryPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "About", href: "/about" },
          { label: "Gallery" },
        ]}
      />

      <PageHeader
        eyebrow={galleryHero.eyebrow}
        title={galleryHero.title}
        subtitle={galleryHero.subtitle}
        variant="white"
        align="center"
      />

      <section className="py-16 md:py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <GalleryLightbox groups={galleryGroups} />

          {/* Temporary images notice */}
          <p className="text-center text-meta text-primary-dark/50 mt-12">
            Gallery images are temporary placeholders and will be replaced with
            real facility photos.
          </p>
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Home", path: "/" },
          { name: "About", path: "/about" },
          { name: "Gallery", path: "/about/gallery" },
        ]}
      />
      <JsonLd
        data={webPageSchema(
          "Photo Gallery - Waggies Pet Care Abuja",
          "Browse Waggies' boarding suites, grooming spa, veterinary clinic, training grounds, and happy guest photos.",
          "/about/gallery",
        )}
      />
    </>
  );
}
