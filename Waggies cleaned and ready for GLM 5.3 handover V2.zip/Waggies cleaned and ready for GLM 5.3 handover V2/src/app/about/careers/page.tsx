/**
 * /about/careers - React port of resources/views/pages/about/careers.blade.php
 *
 * Static marketing page. All content from src/data/careers.ts.
 *
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import {
  careersHero,
  careersPerks,
  careersPerksHeading,
  careersOpenRoles,
  careersOpenRolesHeading,
  careersSpeculativeNote,
} from "@/data/careers";

export const metadata: Metadata = {
  title: "Careers at Waggies",
  description:
    "Join the Waggies team in Abuja. We are hiring passionate pet care professionals - view current vacancies and apply today.",
  alternates: { canonical: "/about/careers" },
  openGraph: {
    title: "Careers at Waggies - Join Our Pet Care Team in Abuja",
    description:
      "Join the Waggies team in Abuja. We are hiring passionate pet care professionals - view current vacancies and apply today.",
    url: "/about/careers",
  },
};

export default function CareersPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "About", href: "/about" },
          { label: "Careers" },
        ]}
      />

      <HeroImage
        imageSrc={careersHero.imageSrc}
        eyebrow={careersHero.eyebrow}
        title={careersHero.title}
        subtitle={careersHero.subtitle}
        primaryCta={careersHero.primaryCta}
        secondaryCta={careersHero.secondaryCta}
      />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={careersPerksHeading.eyebrow}
            title={careersPerksHeading.title}
            subtitle={careersPerksHeading.subtitle}
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-10">
            {careersPerks.map((perk) => (
              <div
                key={perk.title}
                className="bg-surface-purple rounded-2xl p-6 flex flex-col gap-3"
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <MaterialSymbol name={perk.icon} filled className="text-primary" />
                </div>
                <h3 className="font-semibold text-primary-dark">{perk.title}</h3>
                <p className="text-sm text-primary-dark/60 leading-relaxed">
                  {perk.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section id="open-roles" className="py-20 bg-white border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={careersOpenRolesHeading.eyebrow}
            title={careersOpenRolesHeading.title}
          />
          <div className="mt-10 flex flex-col gap-4">
            {careersOpenRoles.map((role) => (
              <div
                key={role.role}
                className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-surface-purple rounded-2xl px-6 py-5"
              >
                <div>
                  <h3 className="font-semibold text-primary-dark">{role.role}</h3>
                  <p className="text-sm text-primary-dark/50">
                    {role.dept} · {role.type}
                  </p>
                </div>
                <a
                  href={role.applyHref}
                  className="inline-flex items-center gap-2 border-2 border-primary text-primary px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-primary hover:text-white transition shrink-0"
                >
                  {role.applyLabel}
                  <MaterialSymbol name="arrow_forward" className="text-base" />
                </a>
              </div>
            ))}
          </div>
          <p className="mt-8 text-sm text-primary-dark/50">
            {careersSpeculativeNote}
          </p>
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "About", path: "/about" },
          { name: "Careers", path: "/about/careers" },
        ]}
      />
      <JsonLd
        data={webPageSchema(
          "Careers at Waggies - Join Our Pet Care Team in Abuja",
          "Join the Waggies team in Abuja. We are hiring passionate pet care professionals - view current vacancies and apply today.",
          "/about/careers",
        )}
      />
    </>
  );
}
