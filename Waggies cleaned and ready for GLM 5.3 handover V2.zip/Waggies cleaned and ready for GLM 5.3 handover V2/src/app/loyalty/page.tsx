/**
 * /loyalty page - React port of resources/views/pages/loyalty.blade.php
 *
 * Static marketing page. All content from src/data/loyalty.ts.
 *
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { HeroGradient } from "@/components/waggies/hero-gradient";
import { SectionHeading } from "@/components/waggies/section-heading";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import {
  loyaltyHero,
  loyaltyHowItWorks,
  loyaltyHowItWorksHeading,
  loyaltyTiers,
  loyaltyTiersHeading,
  loyaltyStartEarningCta,
} from "@/data/loyalty";

export const metadata: Metadata = {
  title: "Loyalty Programme",
  description:
    "Earn points on every Waggies visit and redeem them for free services, discounts, and exclusive member perks.",
  alternates: { canonical: "/loyalty" },
  openGraph: {
    title: "Loyalty Programme - Waggies Pet Care",
    description:
      "Earn points on every Waggies visit and redeem them for free services, discounts, and exclusive member perks.",
    url: "/loyalty",
  },
};

export default function LoyaltyPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Loyalty Programme", href: "/loyalty" }]}
      />

      <HeroGradient
        rating={loyaltyHero.rating}
        reviewCount={loyaltyHero.reviewCount}
        title={loyaltyHero.title}
        subtitle={loyaltyHero.subtitle}
        primaryCta={loyaltyHero.primaryCta}
        secondaryCta={loyaltyHero.secondaryCta}
      />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={loyaltyHowItWorksHeading.eyebrow}
            title={loyaltyHowItWorksHeading.title}
            subtitle={loyaltyHowItWorksHeading.subtitle}
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-10">
            {loyaltyHowItWorks.map((item) => (
              <div
                key={item.step}
                className="bg-surface-purple rounded-2xl p-8 flex flex-col gap-4"
              >
                <div className="flex items-center gap-4">
                  <span className="font-serif text-4xl font-bold text-primary/20">
                    {item.step}
                  </span>
                  <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <MaterialSymbol name={item.icon} filled className="text-primary" />
                  </div>
                </div>
                <h3 className="font-serif text-xl font-bold text-primary-dark">
                  {item.title}
                </h3>
                <p className="text-sm text-primary-dark/60 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-white border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={loyaltyTiersHeading.eyebrow}
            title={loyaltyTiersHeading.title}
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mt-10">
            {loyaltyTiers.map((tier) => (
              <div
                key={tier.tier}
                className="bg-white rounded-2xl border border-surface-purple shadow-sm p-8 hover:shadow-soft transition-shadow"
              >
                <MaterialSymbol
                  name={tier.icon}
                  filled
                  className={`text-4xl ${tier.color} mb-3 block`}
                />
                <h3 className="font-serif text-2xl font-bold text-primary-dark mb-1">
                  {tier.tier}
                </h3>
                <p className="text-xs text-primary-dark/60 uppercase tracking-widest mb-4">
                  {tier.threshold}
                </p>
                <ul className="flex flex-col gap-2">
                  {tier.perks.map((perk) => (
                    <li
                      key={perk}
                      className="flex items-center gap-2 text-sm text-primary-dark"
                    >
                      <MaterialSymbol
                        name="check_circle"
                        filled
                        className="text-success text-base"
                      />
                      {perk}
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-surface-purple">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="font-serif text-3xl font-bold text-primary-dark mb-3">
            {loyaltyStartEarningCta.heading}
          </h2>
          <p className="text-primary-dark/60 mb-6">
            {loyaltyStartEarningCta.body}
          </p>
          <a
            href={loyaltyStartEarningCta.ctaHref}
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-8 py-4 rounded-full font-bold transition shadow-sm"
          >
            {loyaltyStartEarningCta.ctaLabel}
            <MaterialSymbol name={loyaltyStartEarningCta.ctaIcon} />
          </a>
        </div>
      </section>

      <BreadcrumbSchema items={[{ name: "Loyalty Programme", path: "/loyalty" }]} />
      <JsonLd
        data={webPageSchema(
          "Loyalty Programme - Waggies Pet Care",
          "Earn points on every Waggies visit and redeem them for free services, discounts, and exclusive member perks.",
          "/loyalty",
        )}
      />
    </>
  );
}
