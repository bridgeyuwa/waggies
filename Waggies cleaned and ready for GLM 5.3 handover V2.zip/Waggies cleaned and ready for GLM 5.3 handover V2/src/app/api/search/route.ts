/**
 * GET /api/search  -  global search endpoint for the Waggies command palette.
 *
 * Query params:
 *   • q (string)  -  the user's search query. Trimmed + lowercased internally.
 *
 * Behaviour:
 *   • Empty / whitespace-only q → return up to 8 "popular" items
 *     (services + featured blog posts + shop link + contact).
 *   • Non-empty q → rank every search-index item by score:
 *       - Title startsWith query  → highest priority
 *       - Title includes query    → high
 *       - Description/keywords     → medium
 *     Return the top 8 with `score` attached for debugging.
 *
 * Response shape:
 *   { results: SearchResultItem[], total: number }
 *
 * The endpoint is intentionally stateless and reads from in-memory data
 * files only  -  no DB, no caching layer. Safe to call on every keystroke
 * (the client debounces 150ms before hitting this).
 */

import { NextResponse } from "next/server";
import {
  buildPopularItems,
  searchIndex,
  type SearchResultItem,
} from "@/lib/search-index";

// Always run on the Node.js runtime (not Edge)  -  the search index pulls in
// a few MB of static article data, which is happier on Node.
export const runtime = "nodejs";

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const raw = searchParams.get("q") ?? "";
  const q = raw.trim();

  // Empty query → popular starter pack.
  if (q.length === 0) {
    const popular = buildPopularItems();
    const results: Array<SearchResultItem & { score: number }> = popular.map(
      (item, i) => ({
        ...item,
        // Stable, descending score so the client side can sort safely if
        // it wants to  -  popular items are pre-ordered, so we just tag them
        // with a synthetic descending score.
        score: 1000 - i,
      }),
    );
    return NextResponse.json(
      { results, total: results.length },
      {
        headers: { "Cache-Control": "no-store" },
      },
    );
  }

  // Real query → score every item, return top 8.
  const { results, total } = searchIndex(q, 8);
  return NextResponse.json(
    { results, total },
    {
      headers: { "Cache-Control": "no-store" },
    },
  );
}
