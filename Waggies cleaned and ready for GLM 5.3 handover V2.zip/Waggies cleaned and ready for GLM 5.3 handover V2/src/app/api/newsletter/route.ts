/**
 * POST /api/newsletter  -  Next.js Route Handler.
 *
 * Reproduces the behaviour of Laravel's NewsletterController::store:
 *   1. Validates the email field (required|email|max:255).
 *   2. Returns 422 + { errors: { email: message } } on validation failure.
 *   3. Throttles 10/min per IP (in-memory Map).
 *   4. On success:
 *      - If RESEND_API_KEY + RESEND_AUDIENCE_ID env vars are set: forwards
 *        the email to Resend Audiences API.
 *      - Otherwise: logs to console.
 *      - Returns { success: true }.
 *
 * The marketing site is intentionally database-free. Subscriber persistence is
 * delegated to the email provider's audience feature (Resend Audiences,
 * Mailchimp, etc.). If a DB-backed subscriber list is later required, route
 * through an external service  -  do NOT add Prisma to the marketing repo.
 *
 * Source of truth:
 *   - app/Http/Controllers/NewsletterController.php
 *   - app/Http/Requests/StoreNewsletterRequest.php
 */

import { NextResponse } from "next/server";
import { z } from "zod";

// ── Throttle: 10 / min / IP (in-memory; resets on serverless cold start) ───
const WINDOW_MS = 60_000;
const MAX_HITS = 10;
const hits = new Map<string, number[]>();

function throttle(ip: string): boolean {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_HITS) return false;
  recent.push(now);
  hits.set(ip, recent);
  return true;
}

const NewsletterSchema = z.object({
  email: z
    .string()
    .min(1, "The email field is required.")
    .email("The email must be a valid email address.")
    .max(255, "The email may not be greater than 255 characters."),
});

export async function POST(request: Request) {
  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    request.headers.get("x-real-ip") ??
    "unknown";

  if (!throttle(ip)) {
    return NextResponse.json(
      { message: "Too many requests. Please try again later." },
      { status: 429 },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { message: "Invalid JSON body." },
      { status: 400 },
    );
  }

  const parsed = NewsletterSchema.safeParse(body);
  if (!parsed.success) {
    const errors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = issue.path[0];
      if (typeof key === "string" && !errors[key]) {
        errors[key] = issue.message;
      }
    }
    return NextResponse.json({ errors }, { status: 422 });
  }

  const email = parsed.data.email;

  const resendKey = process.env.RESEND_API_KEY;
  const audienceId = process.env.RESEND_AUDIENCE_ID;

  if (resendKey && audienceId) {
    try {
      const { Resend } = await import("resend");
      const resend = new Resend(resendKey);
      await resend.contacts.create({
        email,
        audienceId,
        unsubscribed: false,
      });
    } catch (err) {
      console.error("[newsletter] Resend contact create failed:", err);
      // Treat as success to avoid leaking audience state. Duplicate emails
      // are silently accepted by Resend Audiences (idempotent by email).
    }
  } else {
    console.log(`[newsletter] New subscriber (no RESEND_API_KEY/RESEND_AUDIENCE_ID configured  -  logging only): ${email}`);
  }

  return NextResponse.json({ success: true }, { status: 200 });
}
