import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { blogArticles } from "@/data/content-data";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { JsonLd, blogPostingSchema } from "@/components/waggies/json-ld";
import { BlogArticleClient } from "./page-client";
import { siteConfig } from "@/lib/site";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  return blogArticles.map((a) => ({ slug: a.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const article = blogArticles.find((a) => a.slug === slug);
  if (!article) return {};

  return {
    title: `${article.title} - Waggies Blog`,
    description: article.excerpt,
    alternates: { canonical: `/blog/${article.slug}` },
    openGraph: {
      title: article.title,
      description: article.excerpt,
      url: `/blog/${article.slug}`,
      type: "article",
      publishedTime: article.date,
      authors: [article.author],
      images: article.imageSrc ? [{ url: article.imageSrc }] : undefined,
    },
  };
}

export default async function BlogArticlePage({ params }: Props) {
  const { slug } = await params;
  const article = blogArticles.find((a) => a.slug === slug);
  if (!article) notFound();

  const url = `${siteConfig.siteUrl}/blog/${article.slug}`;

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Blog", href: "/blog" },
          { label: article.title },
        ]}
      />

      <BlogArticleClient article={article} />

      <BreadcrumbSchema
        items={[
          { name: "Blog", path: "/blog" },
          { name: article.title, path: `/blog/${article.slug}` },
        ]}
      />
      <JsonLd
        data={blogPostingSchema({
          headline: article.title,
          description: article.excerpt,
          author: article.author,
          datePublished: article.date,
          url,
          image: article.imageSrc,
        })}
      />
    </>
  );
}
