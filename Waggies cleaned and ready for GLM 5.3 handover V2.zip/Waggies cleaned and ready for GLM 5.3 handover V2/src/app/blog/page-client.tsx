"use client";

import { useState, useMemo } from "react";
import { blogArticles, blogCategories, type BlogCategory } from "@/data/content-data";
import { ArticleCard } from "@/components/waggies/content/article-card";
import { FadeIn } from "@/components/waggies/motion";
import { cn } from "@/lib/utils";

export function BlogPageClient() {
  const [activeCategory, setActiveCategory] = useState<BlogCategory | "All">("All");

  const filtered = useMemo(
    () =>
      activeCategory === "All"
        ? blogArticles
        : blogArticles.filter((a) => a.category === activeCategory),
    [activeCategory],
  );

  return (
    <section className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-20">
      {/* Category filter pills */}
      <FadeIn duration={0.3}>
        <div className="flex flex-wrap gap-2 mb-10">
          {(["All", ...blogCategories] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={cn(
                "rounded-full px-4 py-2 text-label transition-colors",
                activeCategory === cat
                  ? "bg-primary text-white"
                  : "bg-surface-purple text-primary hover:bg-primary/10",
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </FadeIn>

      {/* Articles grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((article, i) => (
            <FadeIn key={article.id} duration={0.3} delay={i * 0.05}>
              <ArticleCard
                href={`/blog/${article.slug}`}
                title={article.title}
                excerpt={article.excerpt}
                imageSrc={article.imageSrc}
                category={article.category}
                author={article.author}
                date={article.date}
                readTime={article.readTime}
              />
            </FadeIn>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-text-muted text-body">
            No articles found in this category.
          </p>
        </div>
      )}
    </section>
  );
}
