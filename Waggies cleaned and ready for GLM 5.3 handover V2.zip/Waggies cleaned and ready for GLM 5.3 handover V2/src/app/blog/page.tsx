import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { JsonLd, blogSchema } from "@/components/waggies/json-ld";
import { BlogPageClient } from "./page-client";

export const metadata: Metadata = {
  title: "Blog - Pet Care Articles & Tips",
  description:
    "Expert pet care articles covering health, nutrition, behaviour, and care tips for dogs and cats in Abuja, Nigeria.",
  alternates: { canonical: "/blog" },
  openGraph: {
    title: "Blog - Pet Care Articles & Tips - Waggies",
    description:
      "Expert pet care articles covering health, nutrition, behaviour, and care tips for dogs and cats in Abuja, Nigeria.",
    url: "/blog",
  },
};

export default function BlogPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Blog" }]}
      />

      <HeroPlain
        eyebrow="Blog"
        eyebrowIcon="article"
        title="Pet Care Articles & Tips"
        subtitle="Expert advice on health, nutrition, behaviour, and everyday care for your pets."
      />

      <BlogPageClient />

      <BreadcrumbSchema items={[{ name: "Blog", path: "/blog" }]} />
      <JsonLd data={blogSchema("Blog", "Pet care articles and tips from Waggies", "/blog")} />
    </>
  );
}
