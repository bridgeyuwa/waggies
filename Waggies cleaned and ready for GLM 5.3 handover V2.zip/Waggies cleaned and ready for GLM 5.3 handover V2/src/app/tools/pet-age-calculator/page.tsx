import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { PetAgeCalculatorClient } from "@/components/waggies/tools/pet-age-calculator-client";

export const metadata: Metadata = {
  title: "Pet Age Calculator",
  description:
    "Convert your dog or cat's age to human years. Our pet age calculator uses standard conversion tables based on your pet's size.",
  alternates: { canonical: "/tools/pet-age-calculator" },
  openGraph: {
    title: "Pet Age Calculator - Waggies",
    description: "Convert your pet's age to human years with our free calculator.",
    url: "/tools/pet-age-calculator",
  },
};

export default function PetAgeCalculatorPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Pet Age Calculator" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon="cake"
        title="Pet Age Calculator"
        subtitle="Find out how old your pet is in human years. Dogs and cats age differently depending on their size."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-lg mx-auto px-4 md:px-10">
          <PetAgeCalculatorClient />
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Pet Age Calculator", path: "/tools/pet-age-calculator" },
        ]}
      />
    </>
  );
}
