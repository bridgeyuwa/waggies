import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { CostCalculatorClient } from "@/components/waggies/tools/cost-calculator-client";

export const metadata: Metadata = {
  title: "Cost Calculator",
  description:
    "Estimate costs for Waggies pet services including boarding, grooming, vet care, and training. Get a quick price range for your pet's needs.",
  alternates: { canonical: "/tools/cost-calculator" },
  openGraph: {
    title: "Cost Calculator - Waggies",
    description: "Estimate costs for Waggies pet services.",
    url: "/tools/cost-calculator",
  },
};

export default function CostCalculatorPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Cost Calculator" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon="calculate"
        title="Cost Calculator"
        subtitle="Get a quick estimate for Waggies services based on your pet's type, size, and the service you need."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-lg mx-auto px-4 md:px-10">
          <CostCalculatorClient />
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Cost Calculator", path: "/tools/cost-calculator" },
        ]}
      />
    </>
  );
}
