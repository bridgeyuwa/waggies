import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { NewPetChecklistClient } from "@/components/waggies/tools/new-pet-checklist-client";

export const metadata: Metadata = {
  title: "New Pet Checklist - Waggies",
  description:
    "Interactive new pet checklist. Everything you need before and after bringing a dog or cat home. Tracks progress in your browser.",
  alternates: { canonical: "/tools/new-pet-checklist" },
  openGraph: {
    title: "New Pet Checklist - Waggies",
    description:
      "Comprehensive interactive checklist for new pet owners. Covers preparation, first week, health, training, and supplies.",
    url: "/tools/new-pet-checklist",
  },
};

export default function NewPetChecklistPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "New Pet Checklist" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon={
          <PhosphorIcon
            name="clipboard-text"
            size={14}
            className="text-secondary"
          />
        }
        title="New Pet Checklist"
        subtitle="An interactive checklist of everything you need before and after bringing a new pet home."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-2xl mx-auto px-4 md:px-10">
          <NewPetChecklistClient />
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "New Pet Checklist", path: "/tools/new-pet-checklist" },
        ]}
      />
    </>
  );
}
