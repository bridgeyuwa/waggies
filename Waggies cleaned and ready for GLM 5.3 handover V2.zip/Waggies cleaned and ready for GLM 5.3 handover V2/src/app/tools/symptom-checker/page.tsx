import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { MedicalDisclaimer } from "@/components/waggies/medical-disclaimer";
import { SymptomCheckerClient } from "@/components/waggies/tools/symptom-checker-client";

export const metadata: Metadata = {
  title: "Pet Symptom Checker",
  description:
    "Check your pet's symptoms and get guidance on next steps. Our free symptom checker helps you understand what might be going on with your dog, cat, or other pet.",
  alternates: { canonical: "/tools/symptom-checker" },
  openGraph: {
    title: "Pet Symptom Checker - Waggies",
    description:
      "Check your pet's symptoms and get guidance on next steps.",
    url: "/tools/symptom-checker",
  },
};

export default function SymptomCheckerPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Symptom Checker" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        title="Pet Symptom Checker"
        subtitle="Select your pet type, choose the affected area, and pick the symptoms you notice to get general guidance."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-3xl mx-auto px-4 md:px-10">
          <SymptomCheckerClient />

          <div className="mt-10">
            <MedicalDisclaimer />
          </div>
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Symptom Checker", path: "/tools/symptom-checker" },
        ]}
      />
    </>
  );
}
