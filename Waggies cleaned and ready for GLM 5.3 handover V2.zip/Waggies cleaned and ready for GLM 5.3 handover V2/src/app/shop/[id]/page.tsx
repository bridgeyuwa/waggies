import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { ProductDetailClient } from "@/components/waggies/shop/product-detail-client";
import { getProductById, getRelatedProducts, PRODUCTS } from "@/data/shop-data";

type PageProps = {
  params: Promise<{ id: string }>;
};

export async function generateStaticParams() {
  return PRODUCTS.map((p) => ({ id: p.id }));
}

export async function generateMetadata({
  params,
}: PageProps): Promise<Metadata> {
  const { id } = await params;
  const product = getProductById(id);
  if (!product) return { title: "Product Not Found" };

  return {
    title: `${product.name} - Waggies Shop`,
    description: product.description,
    alternates: { canonical: `/shop/${product.id}` },
    openGraph: {
      title: `${product.name} - Waggies Shop`,
      description: product.description,
      url: `/shop/${product.id}`,
      images: product.imageSrc ? [{ url: product.imageSrc }] : undefined,
    },
  };
}

export default async function ProductDetailPage({ params }: PageProps) {
  const { id } = await params;
  const product = getProductById(id);

  if (!product) {
    notFound();
  }

  const relatedProducts = getRelatedProducts(product.id, product.category, 3);

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Shop", href: "/shop" },
          { label: product.name },
        ]}
      />

      <ProductDetailClient product={product} relatedProducts={relatedProducts} />

      <BreadcrumbSchema
        items={[
          { name: "Shop", path: "/shop" },
          { name: product.name, path: `/shop/${product.id}` },
        ]}
      />
    </>
  );
}
