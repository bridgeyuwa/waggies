import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { ShopPageClient } from "@/components/waggies/shop/shop-page-client";
import { PRODUCTS } from "@/data/shop-data";

export const metadata: Metadata = {
  title: "Pet Shop - Supplies & Products",
  description:
    "Browse pet food, toys, grooming supplies, health products, and accessories at the Waggies pet shop in Abuja, Nigeria.",
  alternates: { canonical: "/shop" },
  openGraph: {
    title: "Pet Shop - Supplies & Products | Waggies",
    description:
      "Pet food, toys, grooming supplies, health products, and accessories in Abuja.",
    url: "/shop",
  },
};

export default function ShopPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Shop" }]}
      />

      <HeroPlain
        eyebrow="Pet Shop"
        title="Pet Supplies & Products"
        subtitle="Food, toys, grooming essentials, health products, and accessories for your pets."
      />

      <ShopPageClient products={PRODUCTS} />

      <BreadcrumbSchema items={[{ name: "Shop", path: "/shop" }]} />
    </>
  );
}
