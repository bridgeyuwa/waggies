/**
 * Default site-wide OG image.
 *
 * Used as the fallback OpenGraph image for any page that doesn't define
 * its own `opengraph-image.tsx` (homepage, /about, /services, /contact,
 * etc.). Renders a hero-style centered layout via `next/og`.
 *
 * https://nextjs.org/docs/app/api-reference/file-conventions/metadata/opengraph-image
 */

import {
  waggiesSiteOgImage,
  WAGGIES_OG_SIZE,
  WAGGIES_OG_CONTENT_TYPE,
} from "@/lib/og-image-helpers";

export const alt = "Waggies - Pet Care in Abuja, Nigeria";
export const size = WAGGIES_OG_SIZE;
export const contentType = WAGGIES_OG_CONTENT_TYPE;

export default async function Image() {
  return waggiesSiteOgImage();
}
