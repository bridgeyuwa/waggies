import type { Metadata } from "next";
import { Cormorant_Garamond, DM_Sans } from "next/font/google";
import "./globals.css";
import { SkipLink } from "@/components/waggies/skip-link";
import { Navbar } from "@/components/waggies/navbar";
import { Footer } from "@/components/waggies/footer";
import { CookieBanner } from "@/components/waggies/cookie-banner";
import { FloatingActions } from "@/components/waggies/floating-actions";
import { MobileBottomNav } from "@/components/waggies/mobile-bottom-nav";
import { LazySearchPalette } from "@/components/waggies/lazy-search-palette";
import { Toaster } from "@/components/ui/sonner";
import { CartDrawer } from "@/components/waggies/shop/cart-drawer";
import { siteConfig } from "@/lib/site";

// ── Fonts ──────────────────────────────────────────────────────────────────
const dmSans = DM_Sans({
  variable: "--font-dm-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const cormorantGaramond = Cormorant_Garamond({
  variable: "--font-cormorant-garamond",
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  style: ["normal", "italic"],
  display: "swap",
});

// ── Metadata ───────────────────────────────────────────────────────────────
export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.siteUrl),
  title: {
    default: siteConfig.defaultTitle,
    template: "%s - Waggies",
  },
  description: siteConfig.defaultDescription,
  applicationName: siteConfig.name,
  authors: [{ name: siteConfig.name }],
  generator: "Next.js",
  keywords: [
    "pet boarding Abuja",
    "pet care Abuja",
    "pet relocation Nigeria",
    "dog grooming Abuja",
    "veterinary care",
    "Waggies",
  ],
  referrer: "origin-when-cross-origin",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: siteConfig.locale,
    url: siteConfig.siteUrl,
    siteName: siteConfig.name,
    title: siteConfig.defaultTitle,
    description: siteConfig.defaultOgDescription,
  },
  twitter: {
    card: "summary_large_image",
    title: siteConfig.defaultTitle,
    description: siteConfig.defaultDescription,
  },
  icons: {
    icon: "/favicon.ico",
  },
  manifest: undefined,
};

// ── JSON-LD: Organization + LocalBusiness ──────────────────────────────────
const organizationLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Waggies",
  description:
    "Pet boarding, grooming, vet care, training, relocation and local transport in Abuja, Nigeria.",
  url: siteConfig.siteUrl,
};

const localBusinessLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Waggies",
  description:
    "Pet boarding, grooming, vet care, training, relocation and local transport in Abuja, Nigeria.",
  url: siteConfig.siteUrl,
  address: {
    "@type": "PostalAddress",
    addressLocality: "Abuja",
    addressRegion: "FCT",
    addressCountry: "NG",
  },
};

// ── Root layout ────────────────────────────────────────────────────────────
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${dmSans.variable} ${cormorantGaramond.variable} scroll-smooth`}
    >
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=swap"
          rel="stylesheet"
        />

        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessLd) }}
        />
      </head>
      <body className="bg-surface text-primary-dark antialiased min-h-screen flex flex-col">
        <SkipLink />
        <Navbar />
        <main id="main-content" className="flex-1 pb-16 md:pb-0" tabIndex={-1}>
          {children}
        </main>
        <Footer />
        <FloatingActions />
        <MobileBottomNav />
        <CookieBanner />
        <LazySearchPalette />
        <CartDrawer />
        <Toaster />
      </body>
    </html>
  );
}
