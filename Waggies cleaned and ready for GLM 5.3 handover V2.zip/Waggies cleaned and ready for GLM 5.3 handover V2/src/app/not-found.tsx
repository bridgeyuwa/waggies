import Link from "next/link";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { NotFoundSearchCTA } from "@/components/waggies/not-found-search-cta";
import { FloatingWatermark } from "@/components/waggies/not-found-watermark";
import { FadeIn } from "@/components/waggies/motion/fade-in";

/* ── Data ──────────────────────────────────────────────────────────────────── */

const popularPages = [
  { href: "/", label: "Home", icon: "pets" },
  { href: "/services", label: "Services", icon: "spa" },

  { href: "/about", label: "About", icon: "info" },
  { href: "/contact", label: "Contact", icon: "mail" },
  { href: "/faq", label: "FAQ", icon: "help" },
  { href: "/contact", label: "Book Appointment", icon: "calendar_month" },
] as const;

const quickServiceLinks = [
  { href: "/services/grooming", label: "Grooming" },
  { href: "/services/training", label: "Training" },
  { href: "/services/vet-care", label: "Vet Care" },
  { href: "/relocation/transport", label: "Transport" },
] as const;

/* ── Page ──────────────────────────────────────────────────────────────────── */

export default function NotFoundPage() {
  return (
    <section className="relative min-h-[80vh] flex flex-col items-center justify-center px-4 py-16 sm:py-24 overflow-hidden">
      {/* Floating 404 watermark */}
      <FloatingWatermark />

      {/* ── Logo link ──────────────────────────────────────────────────── */}
      <FadeIn delay={0} className="relative z-10 mb-8">
        <Link
          href="/"
          className="inline-flex items-center gap-2 text-primary font-serif text-2xl font-bold hover:opacity-80 transition-opacity"
          aria-label="Return to Waggies homepage"
        >
          <MaterialSymbol name="pets" filled className="text-3xl" />
          Waggies
        </Link>
      </FadeIn>

      {/* ── Hero heading ──────────────────────────────────────────────── */}
      <FadeIn delay={0.1} className="relative z-10 text-center max-w-2xl">
        <h1 className="font-serif text-4xl sm:text-5xl text-primary-dark mb-4">
          Page Not Found
        </h1>
        <p className="text-lg text-primary-dark/70 leading-relaxed">
          The page you&apos;re looking for doesn&apos;t exist or has been moved.
          Let&apos;s help you find your way back.
        </p>
      </FadeIn>

      {/* ── Search CTA ────────────────────────────────────────────────── */}
      <FadeIn delay={0.2} className="relative z-10 w-full max-w-lg mt-8">
        <NotFoundSearchCTA />
      </FadeIn>

      {/* ── Popular Pages grid ────────────────────────────────────────── */}
      <FadeIn delay={0.3} className="relative z-10 w-full max-w-3xl mt-12">
        <h2 className="text-center text-sm font-semibold uppercase tracking-wider text-primary-dark/50 mb-6">
          Popular Pages
        </h2>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4">
          {popularPages.map((page) => (
            <Link
              key={`${page.href}-${page.label}`}
              href={page.href}
              className="flex flex-col items-center gap-2 p-4 rounded-xl bg-surface-purple hover:bg-primary hover:text-white transition group"
            >
              <MaterialSymbol
                name={page.icon}
                className="text-2xl text-primary group-hover:text-white transition"
              />
              <span className="text-sm font-medium">{page.label}</span>
            </Link>
          ))}
        </div>
      </FadeIn>

      {/* ── Quick service links ───────────────────────────────────────── */}
      <FadeIn delay={0.4} className="relative z-10 mt-10 text-center">
        <span className="text-sm text-primary-dark/60 mr-2">
          Popular services:
        </span>
        <div className="flex flex-wrap items-center justify-center gap-2 mt-2">
          {quickServiceLinks.map((svc) => (
            <Link
              key={svc.href}
              href={svc.href}
              className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm hover:bg-primary hover:text-white transition"
            >
              <MaterialSymbol name="arrow_forward" className="text-xs" />
              {svc.label}
            </Link>
          ))}
        </div>
      </FadeIn>

      {/* ── CTA: Contact ──────────────────────────────────────────────── */}
      <FadeIn delay={0.5} className="relative z-10 mt-12">
        <Link
          href="/contact"
          className="inline-flex items-center gap-2 px-8 py-4 rounded-2xl bg-gradient-to-r from-primary to-primary-dark text-white font-semibold text-lg shadow-lg hover:shadow-xl transition-shadow focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/50 focus-visible:ring-offset-2"
        >
          <MaterialSymbol name="contact_support" className="text-xl" />
          Need help? Contact Us
        </Link>
      </FadeIn>
    </section>
  );
}
