"use client";

import { useState, useMemo } from "react";
import { guides, guideCategories, type GuideCategory } from "@/data/content-data";
import { ArticleCard } from "@/components/waggies/content/article-card";
import { FadeIn } from "@/components/waggies/motion";
import { cn } from "@/lib/utils";

export function GuidesPageClient() {
  const [activeCategory, setActiveCategory] = useState<GuideCategory | "All">("All");

  const filtered = useMemo(
    () =>
      activeCategory === "All"
        ? guides
        : guides.filter((g) => g.category === activeCategory),
    [activeCategory],
  );

  const featured = filtered[0];
  const rest = filtered.slice(1);

  return (
    <section className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-20">
      {/* Category filter pills */}
      <FadeIn duration={0.3}>
        <div className="flex flex-wrap gap-2 mb-10">
          {(["All", ...guideCategories] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => setActiveCategory(cat)}
              className={cn(
                "rounded-full px-4 py-2 text-label transition-colors",
                activeCategory === cat
                  ? "bg-primary text-white"
                  : "bg-surface-purple text-primary hover:bg-primary/10",
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </FadeIn>

      {filtered.length > 0 ? (
        <>
          {/* Featured guide - full width */}
          <FadeIn duration={0.35}>
            <ArticleCard
              href={`/guides/${featured.slug}`}
              title={featured.title}
              excerpt={featured.excerpt}
              imageSrc={featured.imageSrc}
              category={featured.category}
              readTime={featured.readTime}
              featured
              className="mb-8"
            />
          </FadeIn>

          {/* Remaining guides in a grid */}
          {rest.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {rest.map((guide, i) => (
                <FadeIn key={guide.id} duration={0.3} delay={i * 0.05}>
                  <ArticleCard
                    href={`/guides/${guide.slug}`}
                    title={guide.title}
                    excerpt={guide.excerpt}
                    imageSrc={guide.imageSrc}
                    category={guide.category}
                    readTime={guide.readTime}
                  />
                </FadeIn>
              ))}
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-16">
          <p className="text-text-muted text-body">No guides found in this category.</p>
        </div>
      )}
    </section>
  );
}
