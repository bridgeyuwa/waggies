import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { JsonLd, collectionPageSchema } from "@/components/waggies/json-ld";
import { GuidesPageClient } from "./page-client";

export const metadata: Metadata = {
  title: "Guides - Pet Care Guides",
  description:
    "In-depth pet care guides from Waggies covering getting started, everyday care, and training for dogs and cats.",
  alternates: { canonical: "/guides" },
  openGraph: {
    title: "Guides - Pet Care Guides - Waggies",
    description:
      "In-depth pet care guides from Waggies covering getting started, everyday care, and training for dogs and cats.",
    url: "/guides",
  },
};

export default function GuidesPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Guides" }]}
      />

      <HeroPlain
        eyebrow="Guides"
        eyebrowIcon="menu_book"
        title="Pet Care Guides"
        subtitle="Step-by-step guides to help you give your pets the best care."
      />

      <GuidesPageClient />

      <BreadcrumbSchema items={[{ name: "Guides", path: "/guides" }]} />
      <JsonLd
        data={collectionPageSchema(
          "Guides",
          "/guides",
          "In-depth pet care guides from Waggies",
        )}
      />
    </>
  );
}
