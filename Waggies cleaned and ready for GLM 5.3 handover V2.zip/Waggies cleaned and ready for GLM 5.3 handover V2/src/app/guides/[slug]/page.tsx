import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { guides } from "@/data/content-data";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { JsonLd, articleSchema } from "@/components/waggies/json-ld";
import { GuideDetailClient } from "./page-client";
import { siteConfig } from "@/lib/site";

type Props = { params: Promise<{ slug: string }> };

export async function generateStaticParams() {
  return guides.map((g) => ({ slug: g.slug }));
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params;
  const guide = guides.find((g) => g.slug === slug);
  if (!guide) return {};

  return {
    title: `${guide.title} - Waggies Guides`,
    description: guide.excerpt,
    alternates: { canonical: `/guides/${guide.slug}` },
    openGraph: {
      title: guide.title,
      description: guide.excerpt,
      url: `/guides/${guide.slug}`,
      type: "article",
      images: guide.imageSrc ? [{ url: guide.imageSrc }] : undefined,
    },
  };
}

export default async function GuideDetailPage({ params }: Props) {
  const { slug } = await params;
  const guide = guides.find((g) => g.slug === slug);
  if (!guide) notFound();

  const url = `${siteConfig.siteUrl}/guides/${guide.slug}`;

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Guides", href: "/guides" },
          { label: guide.title },
        ]}
      />

      <GuideDetailClient guide={guide} />

      <BreadcrumbSchema
        items={[
          { name: "Guides", path: "/guides" },
          { name: guide.title, path: `/guides/${guide.slug}` },
        ]}
      />
      <JsonLd
        data={articleSchema({
          headline: guide.title,
          description: guide.excerpt,
          url,
          image: guide.imageSrc,
        })}
      />
    </>
  );
}
