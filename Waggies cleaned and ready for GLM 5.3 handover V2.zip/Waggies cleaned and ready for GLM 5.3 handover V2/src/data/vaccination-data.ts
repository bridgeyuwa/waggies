/**
 * Vaccination schedule data for dogs and cats.
 *
 * Based on general veterinary guidelines. Always consult your vet for
 * a personalised schedule for your pet.
 */

export type PetType = "dog" | "cat";

export type VaccinationEntry = {
  age: string;
  vaccines: {
    name: string;
    type: "core" | "non-core";
    description: string;
  }[];
};

export const DOG_VACCINATIONS: VaccinationEntry[] = [
  {
    age: "6-8 weeks",
    vaccines: [
      {
        name: "DHPP (Distemper, Hepatitis, Parainfluenza, Parvovirus)",
        type: "core",
        description: "First dose of the core combination vaccine.",
      },
    ],
  },
  {
    age: "10-12 weeks",
    vaccines: [
      {
        name: "DHPP Booster",
        type: "core",
        description: "Second dose of the core combination vaccine.",
      },
      {
        name: "Leptospirosis",
        type: "non-core",
        description: "Recommended if your dog is exposed to wildlife or standing water.",
      },
    ],
  },
  {
    age: "12-16 weeks",
    vaccines: [
      {
        name: "Rabies",
        type: "core",
        description: "Required by law in most areas. First dose.",
      },
      {
        name: "DHPP Booster",
        type: "core",
        description: "Third and final dose of the puppy series.",
      },
    ],
  },
  {
    age: "16-20 weeks",
    vaccines: [
      {
        name: "Bordetella (Kennel Cough)",
        type: "non-core",
        description: "Especially important for dogs that are boarded, groomed, or socialise with other dogs.",
      },
    ],
  },
  {
    age: "12-16 months",
    vaccines: [
      {
        name: "DHPP Booster",
        type: "core",
        description: "First annual booster of the core vaccine.",
      },
      {
        name: "Rabies Booster",
        type: "core",
        description: "Annual or triennial depending on local regulations.",
      },
      {
        name: "Leptospirosis Booster",
        type: "non-core",
        description: "Annual booster if the initial series was given.",
      },
      {
        name: "Canine Influenza",
        type: "non-core",
        description: "Recommended for dogs that frequent dog parks or boarding facilities.",
      },
    ],
  },
  {
    age: "Annually (adult)",
    vaccines: [
      {
        name: "DHPP Booster",
        type: "core",
        description: "Annual booster. Some vets may switch to a 3-year schedule after the first few years.",
      },
      {
        name: "Rabies Booster",
        type: "core",
        description: "Every 1-3 years depending on the vaccine used and local law.",
      },
      {
        name: "Bordetella Booster",
        type: "non-core",
        description: "Every 6-12 months for dogs in high-contact environments.",
      },
    ],
  },
];

export const CAT_VACCINATIONS: VaccinationEntry[] = [
  {
    age: "6-8 weeks",
    vaccines: [
      {
        name: "FVRCP (Feline Viral Rhinotracheitis, Calicivirus, Panleukopenia)",
        type: "core",
        description: "First dose of the core combination vaccine.",
      },
    ],
  },
  {
    age: "10-12 weeks",
    vaccines: [
      {
        name: "FVRCP Booster",
        type: "core",
        description: "Second dose of the core combination vaccine.",
      },
      {
        name: "FeLV (Feline Leukaemia Virus)",
        type: "non-core",
        description: "Recommended for cats that go outdoors or live with FeLV-positive cats.",
      },
    ],
  },
  {
    age: "14-16 weeks",
    vaccines: [
      {
        name: "FVRCP Booster",
        type: "core",
        description: "Third and final dose of the kitten series.",
      },
      {
        name: "Rabies",
        type: "core",
        description: "Required by law in most areas. First dose.",
      },
      {
        name: "FeLV Booster",
        type: "non-core",
        description: "Second dose if the initial series was given.",
      },
    ],
  },
  {
    age: "12-16 months",
    vaccines: [
      {
        name: "FVRCP Booster",
        type: "core",
        description: "First annual booster of the core vaccine.",
      },
      {
        name: "Rabies Booster",
        type: "core",
        description: "Annual or triennial depending on the vaccine used.",
      },
      {
        name: "FeLV Booster",
        type: "non-core",
        description: "Annual booster if the cat is at risk.",
      },
    ],
  },
  {
    age: "Annually (adult)",
    vaccines: [
      {
        name: "FVRCP Booster",
        type: "core",
        description: "Every 1-3 years depending on the vaccine and your cat's risk level.",
      },
      {
        name: "Rabies Booster",
        type: "core",
        description: "Every 1-3 years depending on the vaccine used and local law.",
      },
    ],
  },
];

export function getVaccinationSchedule(petType: PetType): VaccinationEntry[] {
  return petType === "dog" ? DOG_VACCINATIONS : CAT_VACCINATIONS;
}
