/**
 * Boarding page content (dogs, cats, exotic)  -  extracted verbatim from
 * the Laravel Blade source.
 *
 * Sources:
 *   - resources/views/pages/services/boarding/dogs.blade.php
 *   - resources/views/pages/services/boarding/cats.blade.php
 *   - resources/views/pages/services/boarding/exotic.blade.php
 *
 * DO NOT paraphrase or "improve" this content.
 */

// ── Stats bar (per page) ──────────────────────────────────────────────────

export type BoardingStat = { value: string; label: string };

export const dogStats: BoardingStat[] = [
  { value: "5k+", label: "Happy Pet Guests" },
  { value: "24/7", label: "On-Site Supervision" },
  { value: "2×", label: "Daily Exercise Sessions" },
  { value: "100%", label: "Vaccination Verified" },
];

export const catStats: BoardingStat[] = [
  { value: "100%", label: "Dog-Free Cat Wing" },
  { value: "24/7", label: "Quiet Monitoring" },
  { value: "Daily", label: "Photo Updates" },
  { value: "3", label: "Condo Size Options" },
];

export const exoticStats: BoardingStat[] = [
  { value: "50+", label: "Species Experience" },
  { value: "24/7", label: "Climate Monitoring" },
  { value: "100%", label: "Custom Enclosures" },
  { value: "Daily", label: "Care Updates" },
];

// ── Hero sections (per page) ──────────────────────────────────────────────

export const dogHero = {
  imageSrc:
    "https://images.unsplash.com/photo-1596492784531-6e6eb5ea9993?w=1600&auto=format&fit=crop&q=80",
  imageAlt: "Happy dog in a safe boarding environment at Waggies",
  eyebrow: "Dog Boarding",
  eyebrowIcon: "pets",
  title: "A Safe, Structured Stay for Your Dog",
  subtitle:
    "Private suites, supervised play, and daily routines designed to keep your dog active and comfortable while you're away.",
  primaryCta: {
    label: "Book Boarding",
    href: "/contact?intent=book&service=boarding&variant=dogs",
    icon: "arrow_forward",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=boarding-dogs",
    icon: "calculate",
  },
  variant: "center" as const,
};

export const catHero = {
  imageSrc:
    "https://images.unsplash.com/photo-1574158622682-e40e69881006?w=1600&auto=format&fit=crop&q=80",
  imageAlt: "Relaxed cat in a calm boarding condo at Waggies",
  eyebrow: "Cat Boarding",
  eyebrowIcon: "emoticon",
  title: "Calm, Cosy Stays for Your Cat",
  subtitle:
    "Quiet cat condos in a dog-free wing  -  with enrichment, cosy nooks, and attentive care from cat-specialist staff.",
  primaryCta: {
    label: "Book a Stay",
    href: "/contact?intent=book&service=boarding&variant=cats",
    icon: "arrow_forward",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=boarding-cats",
    icon: "calculate",
  },
  variant: "center" as const,
};

export const exoticHero = {
  imageSrc:
    "https://images.unsplash.com/photo-1456926631375-92c8ce872def?w=1600&auto=format&fit=crop&q=80",
  imageAlt: "Colourful parrot in a specialist exotic pet care environment",
  eyebrow: "Exotic Pet Boarding",
  eyebrowIcon: "bug_report",
  title: "Specialist Care for Exotic Pets",
  subtitle:
    "Birds, reptiles, rabbits, guinea pigs, and small mammals  -  cared for by specialist staff in custom-built, species-appropriate enclosures.",
  primaryCta: {
    label: "Enquire Now",
    href: "/contact?intent=consult&service=boarding&variant=exotic",
    icon: "arrow_forward",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=boarding-exotic",
    icon: "calculate",
  },
  variant: "center" as const,
};

// ── Section headings for the boarding package & feature sections ──────────

export const dogPackageHeading = {
  eyebrow: "Dog Boarding Packages",
  title: "Find the Right Stay for Your Dog",
  subtitle:
    "From simple overnight stays to fully supervised care with extra comfort and attention  -  choose a package that matches your dog's needs and routine.",
};

export const dogFeaturesHeading = {
  eyebrow: "What's Included",
  title: "Everything Your Dog Needs",
  subtitle:
    "Structured care, enrichment, and comfort  -  all handled by trained dog-care staff.",
};

export const catPackageHeading = {
  eyebrow: "Cat Boarding Packages",
  title: "Find the Right Condo for Your Cat",
  subtitle:
    "From a peaceful overnight to extra enrichment and vet monitoring - every package respects how cats like to live.",
};

export const catFeaturesHeading = {
  eyebrow: "Cat Boarding Includes",
  title: "A Calm Environment for Cats",
  subtitle:
    "Cats are sensitive travellers. Our cat wing is calm, dog-free, and designed around feline behaviour.",
};

export const exoticSpeciesHeading = {
  eyebrow: "We Board",
  title: "Which Exotic Pets Do We Care For?",
  subtitle:
    "Our exotic wing is staffed by specialists trained for the unique needs of non-traditional pets.",
};

export const exoticPackageHeading = {
  eyebrow: "Exotic Boarding Packages",
  title: "Care Matched to Your Species",
  subtitle:
    "Pricing reflects enclosure complexity and specialist handling  -  we'll confirm exact rates when you enquire.",
};

export const exoticFeaturesHeading = {
  eyebrow: "What's Included",
  title: "Tailored Care for Every Species",
};

// ── Day-in-the-life schedule + image mosaic (per page) ────────────────────

export type DayInLifeStep = {
  icon: string;
  title: string;
  description: string;
};

export type DayInLifeImage = {
  src: string;
  alt: string;
  loading: "eager" | "lazy";
};

export const dogDayInLife = {
  headingId: "dog-daily-heading",
  heading: "A Day in the Life for Dogs",
  subtitle:
    "We keep tails wagging from sunrise to sunset with a structured routine of fun, food, and rest.",
  schedule: [
    { icon: "wb_sunny", title: "7:00 AM  -  Rise & Shine", description: "First potty walk and fresh water service." },
    { icon: "restaurant", title: "8:00 AM  -  Breakfast", description: "Premium kibble or owner-provided meals served individually." },
    { icon: "sports_baseball", title: "9:30 AM  -  Group Play", description: "Supervised socialisation in secure outdoor paddocks." },
    { icon: "bedtime", title: "12:00 PM  -  Rest Time", description: "Quiet rest in climate-controlled suites." },
    { icon: "nights_stay", title: "8:00 PM  -  Tuck In", description: "Final potty break, bedtime treats, and soothing music." },
  ] as DayInLifeStep[],
  images: [
    { src: "https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd?w=800&h=600&fit=crop&q=80", alt: "Two happy golden retrievers smiling at the camera", loading: "eager" },
    { src: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=800&h=600&fit=crop&q=80", alt: "French bulldog puppy looking curious", loading: "eager" },
    /* TODO(client): Waggies boarding activity photo */
    { src: "", alt: "Dog boarding activity [image required]", loading: "lazy" },
    { src: "https://images.unsplash.com/photo-1541599540903-216a46ca1dc0?w=800&h=600&fit=crop&q=80", alt: "Dog sleeping comfortably in a bed", loading: "lazy" },
  ] as DayInLifeImage[],
};

export const catDayInLife = {
  headingId: "cat-daily-heading",
  heading: "A Day in the Life for Cats",
  subtitle:
    "A calm, predictable rhythm that helps even shy cats feel secure  -  never rushed, never forced.",
  schedule: [
    { icon: "wb_sunny", title: "7:30 AM  -  Gentle Start", description: "Quiet check-in, fresh water, and litter refresh without disruption." },
    { icon: "restaurant", title: "8:30 AM  -  Breakfast", description: "Meals served in-suite on your cat's usual schedule." },
    { icon: "toys", title: "11:00 AM  -  Enrichment", description: "Puzzle feeders, wand play, or solo exploration in the private playroom." },
    { icon: "bedtime", title: "2:00 PM  -  Rest Period", description: "Lights dimmed for afternoon naps  -  staff keep noise levels low." },
    { icon: "nights_stay", title: "8:00 PM  -  Evening Settle", description: "Dinner, final litter check, and a calm goodnight routine." },
  ] as DayInLifeStep[],
  images: [
    { src: "https://images.unsplash.com/photo-1574158622682-e40e69881006?w=800&h=600&fit=crop&q=80", alt: "Ginger cat resting comfortably on a soft blanket", loading: "eager" },
    /* TODO(client): Waggies cat enrichment photo */
    { src: "", alt: "Cat enrichment activity [image required]", loading: "eager" },
    /* TODO(client): Waggies cat condo photo */
    { src: "", alt: "Cat in boarding condo [image required]", loading: "lazy" },
    { src: "https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?w=800&h=600&fit=crop&q=80", alt: "Sleeping cat curled up peacefully", loading: "lazy" },
  ] as DayInLifeImage[],
};

export const exoticDayInLife = {
  headingId: "exotic-daily-heading",
  heading: "A Day in the Life for Exotic Guests",
  subtitle:
    "Precise routines for temperature, feeding, and handling  -  because exotic pets thrive on consistency.",
  schedule: [
    { icon: "wb_sunny", title: "7:00 AM  -  Habitat Check", description: "Temperature, humidity, UV, and water systems verified for each enclosure." },
    { icon: "restaurant", title: "8:00 AM  -  Morning Feed", description: "Meals or feeders administered per your written protocol." },
    { icon: "visibility", title: "12:00 PM  -  Health Observation", description: "Behaviour, appetite, and enclosure condition logged by specialist staff." },
    { icon: "thermostat", title: "4:00 PM  -  Environment Review", description: "Climate adjustments and enrichment rotation as species require." },
    { icon: "nights_stay", title: "8:00 PM  -  Evening Round", description: "Final checks, secure enclosures, and overnight monitoring handover." },
  ] as DayInLifeStep[],
  images: [
    /* TODO(client): Waggies exotic pet photo */
    { src: "", alt: "Exotic pet in boarding [image required]", loading: "eager" },
    /* TODO(client): Waggies exotic pet enclosure photo */
    { src: "", alt: "Exotic pet enclosure [image required]", loading: "eager" },
    /* TODO(client): Waggies exotic habitat photo */
    { src: "", alt: "Exotic pet habitat [image required]", loading: "lazy" },
    { src: "https://images.unsplash.com/photo-1437409368301-e2d6e673f6fb?w=800&h=600&fit=crop&q=80", alt: "Small mammal cared for in a cosy habitat", loading: "lazy" },
  ] as DayInLifeImage[],
};

// ── Feature grids (per page) ──────────────────────────────────────────────

export const dogFeatures = [
  { icon: "cottage", title: "Private Suites", desc: "Climate-controlled rooms sized for your dog, with bedding refreshed daily." },
  { icon: "sports_baseball", title: "Supervised Play", desc: "Group or solo sessions in secure paddocks, matched by size and temperament." },
  { icon: "restaurant", title: "Tailored Feeding", desc: "Meals on your schedule using your food or our premium kibble." },
  { icon: "medical_services", title: "Daily Vet Checks", desc: "On-site vet monitors all guests and responds quickly to any concerns." },
  { icon: "notifications", title: "Photo Updates", desc: "Daily photos and notes so you always know how your dog is doing." },
  { icon: "spa", title: "Optional Grooming", desc: "Add a bath, brush, or full groom during their stay on Premium and Deluxe packages." },
];

export const catFeatures = [
  { icon: "cabin", title: "Private Cat Condos", desc: "Multi-level condos with hammocks, perches, and cosy hideaway nooks." },
  { icon: "do_not_disturb", title: "Dog-Free Zone", desc: "Our cat wing is fully separate  -  cats never share corridors or outdoor areas with dogs." },
  { icon: "toys", title: "Daily Enrichment", desc: "Puzzle feeders, interactive toys, and gentle one-on-one play tailored to your cat." },
  { icon: "restaurant", title: "Tailored Feeding", desc: "Meals on your cat's usual schedule using your preferred brand or our quality food." },
  { icon: "medical_services", title: "Vet Monitoring", desc: "On-site vet checks all cat guests daily and addresses health concerns immediately." },
  { icon: "notifications", title: "Daily Photo Updates", desc: "Photos and a brief note every day so you always know how your cat is settling in." },
];

export const exoticFeatures = [
  { icon: "home", title: "Species-Specific Enclosures", desc: "Custom housing with correct temperature, humidity, and lighting for each species." },
  { icon: "restaurant", title: "Specialist Diet", desc: "Feeding according to each animal's dietary needs and your usual routine  -  including live feeders when required." },
  { icon: "medical_services", title: "Exotic Vet Access", desc: "Our vet has experience with exotic and small animals and reviews guests daily." },
  { icon: "notifications", title: "Regular Updates", desc: "Photo updates so you can check in on your pet throughout their stay." },
  { icon: "lock_clock", title: "24/7 Monitoring", desc: "Staff check on exotic guests throughout the day and night, including climate systems." },
  { icon: "psychology", title: "Experienced Handlers", desc: "Trained staff who understand handling, stress signals, and species-specific behaviour." },
];

// ── Safety cards (per page) ───────────────────────────────────────────────

export type SafetyCard = {
  title: string;
  intro: string;
  bullets: string[];
  linkLabel: string;
  linkHref: string;
};

export const dogSafetyCard: SafetyCard = {
  title: "Safety First Policy",
  intro:
    "Every dog undergoes a health check and vaccination verification before admission. Dogs are grouped by size and temperament, and all play sessions are actively supervised by trained staff.",
  bullets: [
    "Vaccination and flea/tick verification required on arrival",
    "Dogs separated by size, temperament, and energy level",
    "Staff-supervised play sessions throughout the day",
    "Emergency vet protocol in place for all boarding dogs",
  ],
  linkLabel: "Ask about boarding requirements",
  linkHref: "/contact",
};

export const catSafetyCard: SafetyCard = {
  title: "Feline Safety & Comfort Standards",
  intro:
    "We never force interaction. Shy cats get extra settling time, familiar scents from home are welcome, and every condo has elevated perches and hiding spots.",
  bullets: [
    "Vaccination records verified before check-in",
    "Fully dog-free wing with separate air circulation",
    "Medication administered precisely to your instructions",
    "Immediate vet assessment if appetite or behaviour changes",
  ],
  linkLabel: "Discuss your cat's needs",
  linkHref: "/contact",
};

export const exoticSafetyCard: SafetyCard = {
  title: "Exotic Care & Safety Protocols",
  intro:
    "Every exotic booking starts with a pre-arrival consultation. We confirm species requirements, feeding instructions, and enclosure specifications before your pet arrives.",
  bullets: [
    "Pre-stay consultation to confirm habitat and dietary needs",
    "Owner-supplied feeders or equipment welcomed and labelled",
    "Separate exotic wing  -  no contact with dogs or cats",
    "Immediate vet escalation if behaviour or environment deviates",
  ],
  linkLabel: "Start an exotic boarding enquiry",
  linkHref: "/contact",
};

// ── Sibling links (cross-link cards at bottom of each boarding subpage) ────

export type BoardingSibling = {
  key: "dogs" | "cats" | "exotic";
  href: string;
  title: string;
  desc: string;
  icon: string;
  image: string;
};

export const boardingSiblings: BoardingSibling[] = [
  {
    key: "dogs",
    href: "/services/boarding/dogs",
    title: "Dog Boarding",
    desc: "Private suites, supervised play, and structured daily routines.",
    icon: "pets",
    image:
      "https://images.unsplash.com/photo-1541599540903-216a46ca1dc0?auto=format&fit=crop&w=600&q=80",
  },
  {
    key: "cats",
    href: "/services/boarding/cats",
    title: "Cat Boarding",
    desc: "Calm, dog-free condos with enrichment and daily photo updates.",
    icon: "emoticon",
    image:
      "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?auto=format&fit=crop&w=600&q=80",
  },
  {
    key: "exotic",
    href: "/services/boarding/exotic",
    title: "Exotic Pet Boarding",
    desc: "Species-specific enclosures with specialist handlers and vet access.",
    icon: "bug_report",
    /* TODO(client): Replace with Waggies exotic boarding photo */
    image:
      "https://images.unsplash.com/photo-1456926631375-92c8ce872def?w=600&h=400&fit=crop&q=80",
  },
];

// ── Exotic: species icons grid ────────────────────────────────────────────

export const exoticSpecies: ReadonlyArray<{ label: string; icon: string }> = [
  { label: "Birds", icon: "flutter" },
  { label: "Reptiles", icon: "pest_control" },
  { label: "Rabbits", icon: "cruelty_free" },
  { label: "Guinea Pigs", icon: "nest_eco_leaf" },
  { label: "Hamsters", icon: "pets" },
  { label: "Fish", icon: "water" },
];

// ── Exotic: feature band ("Before You Book") ──────────────────────────────

export const exoticFeatureBand = {
  eyebrow: "Before You Book",
  title: "What to Prepare for Check-In",
  subtitle:
    "A little preparation helps exotic pets settle faster and keeps their routine intact.",
  cta: { label: "Discuss Your Pet", href: "/contact" },
  features: [
    { icon: "description", title: "Written Care Sheet", description: "Feeding times, portion sizes, temperature ranges, and any handling preferences." },
    { icon: "inventory_2", title: "Supplies from Home", description: "Food, substrates, feeders, or habitat items your pet is used to  -  clearly labelled." },
    { icon: "verified", title: "Health Records", description: "Recent vet notes or vaccination records where applicable for your species." },
  ],
};

// ── Cat page: "Built for Feline Instincts" two-column section ─────────────

export const catFelineSection = {
  eyebrow: "Why Cats Love Waggies",
  heading: "Built for Feline Instincts",
  body: "Vertical space, privacy, and predictable routines  -  the three things cats need most when away from home.",
  bullets: [
    { bold: "No dog noise or smells", text: "  -  reduces stress for even the most anxious cats." },
    { bold: "Bring bedding and toys", text: "  -  familiar scents make settling in much faster." },
    { bold: "Cat-specialist staff", text: "  -  trained in low-stress handling and reading feline body language." },
  ],
  image:
    "https://images.unsplash.com/photo-1573865526739-10659fec78a5?auto=format&fit=crop&w=900&q=80",
  imageAlt: "Cat relaxing in a multi-level boarding condo",
} as const;

// ── CTA sections (per page) ───────────────────────────────────────────────

export const dogCta = {
  heading: "Ready to Book Your Dog's Stay?",
  body: "Secure a safe, structured boarding experience with daily updates and supervised routines.",
  primaryLabel: "Book Boarding",
  primaryHref: "/contact",
  primaryIcon: "arrow_forward",
  secondaryLabel: "View All Pricing",
  secondaryHref: "/services/pricing",
  secondaryIcon: "payments",
} as const;

export const catCta = {
  heading: "Ready to Book Your Cat's Stay?",
  body: "Reserve a calm, dog-free condo with daily updates and care from staff who understand cats.",
  primaryLabel: "Book Cat Boarding",
  primaryHref: "/contact",
  primaryIcon: "arrow_forward",
  secondaryLabel: "View All Pricing",
  secondaryHref: "/services/pricing",
  secondaryIcon: "payments",
} as const;

export const exoticCta = {
  heading: "Enquire About Exotic Boarding",
  body: "Tell us your species, setup, and dates  -  we'll confirm availability and build a care plan before check-in.",
  primaryLabel: "Get in Touch",
  primaryHref: "/contact?intent=consult&service=boarding&variant=exotic",
  primaryIcon: "arrow_forward",
  secondaryLabel: "Get Estimate",
  secondaryHref: "/services/pricing?service=boarding-exotic",
  secondaryIcon: "payments",
} as const;
