/**
 * Photo Gallery page content.
 *
 * IMAGE STATUS: TEMPORARY stock photos from Unsplash.
 * These will be replaced with real Waggies facility photographs
 * once supplied by the client.
 *
 * _temporary flag on each group and image marks them as placeholder assets.
 */

// ── Types ─────────────────────────────────────────────────────────────────

export type GalleryHero = {
  eyebrow: string;
  title: string;
  subtitle: string;
};

export type GalleryImageItem = {
  src: string;
  alt: string;
  /** @internal Marks this image as a temporary stock placeholder. */
  _temporary: true;
};

export type GalleryGroup = {
  eyebrow: string;
  title: string;
  headingClass: string;
  images: GalleryImageItem[];
  cellClassName: string;
  imgClassName: string;
  /** @internal Marks all images in this group as temporary stock photos. */
  _temporary: true;
};

// ── Page header ───────────────────────────────────────────────────────────

export const galleryHero: GalleryHero = {
  eyebrow: "Photo Gallery",
  title: "Take a Look Inside",
  subtitle:
    "Our facilities speak for themselves. Browse our boarding suites, grooming spa, veterinary clinic, training grounds, and the happy faces of our guests.",
} as const;

// ── Helper ────────────────────────────────────────────────────────────────

/** Build an Unsplash URL with consistent sizing. */
function unsplash(id: string): string {
  return `https://images.unsplash.com/photo-${id}?w=600&h=400&fit=crop&q=80`;
}

// ── Gallery groups ────────────────────────────────────────────────────────

export const galleryGroups: GalleryGroup[] = [
  /* ── Boarding ──────────────────────────────────────────────────────── */
  {
    eyebrow: "Boarding",
    title: "Boarding Suites & Play Areas",
    headingClass: "mb-8",
    _temporary: true,
    images: [
      {
        src: unsplash("1587300003388-59208cc962cb"),
        alt: "Golden retriever relaxing outdoors in a spacious green play area",
        _temporary: true,
      },
      {
        src: unsplash("1544568100-847a948585b9"),
        alt: "Happy dog running and playing in lush green grass",
        _temporary: true,
      },
      {
        src: unsplash("1560807707-8cc77767d783"),
        alt: "Cute puppy resting comfortably in a cozy boarding suite",
        _temporary: true,
      },
      {
        src: unsplash("1596854407944-bf87f6fdd49e"),
        alt: "Cat and dog resting peacefully together in a shared boarding space",
        _temporary: true,
      },
      {
        src: unsplash("1450778855892-8139e5e4f23f"),
        alt: "Close-up of a cat looking calm and content in its boarding suite",
        _temporary: true,
      },
    ],
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },

  /* ── Grooming ──────────────────────────────────────────────────────── */
  {
    eyebrow: "Grooming",
    title: "Grooming Spa",
    headingClass: "mb-8",
    _temporary: true,
    images: [
      {
        src: unsplash("1516734212186-a967f81ad0d7"),
        alt: "Cat being gently groomed with a professional brush at the spa",
        _temporary: true,
      },
      {
        src: unsplash("1607305389524-3e2de06068d5"),
        alt: "Dog getting a warm bath during a grooming session",
        _temporary: true,
      },
      {
        src: unsplash("1477884213160-51f6da289cc4"),
        alt: "Cat being carefully brushed to a silky smooth coat",
        _temporary: true,
      },
      {
        src: unsplash("1574158622682-e40e69881006"),
        alt: "Elegant cat portrait after a professional grooming session",
        _temporary: true,
      },
      {
        src: unsplash("1514888286974-6c03e2ca1dba"),
        alt: "Orange tabby cat looking fresh and well-groomed",
        _temporary: true,
      },
    ],
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },

  /* ── Veterinary ────────────────────────────────────────────────────── */
  {
    eyebrow: "Veterinary",
    title: "Veterinary Clinic",
    headingClass: "mb-8",
    _temporary: true,
    images: [
      {
        src: unsplash("1548199973-03cce0bbc87b"),
        alt: "Veterinarian examining a dog during a routine health checkup",
        _temporary: true,
      },
      {
        src: unsplash("1535930749574-099f483c0958"),
        alt: "Vet carefully examining a dog with a stethoscope in the clinic",
        _temporary: true,
      },
      {
        src: unsplash("1576201836106-1751265f008f"),
        alt: "Puppy receiving a gentle health examination from the vet team",
        _temporary: true,
      },
      {
        src: unsplash("1583337130417-13273c02f1f8"),
        alt: "Cat sleeping peacefully after a comfortable veterinary visit",
        _temporary: true,
      },
    ],
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },

  /* ── Training ──────────────────────────────────────────────────────── */
  {
    eyebrow: "Training",
    title: "Training & Behaviour",
    headingClass: "mb-8",
    _temporary: true,
    images: [
      {
        src: unsplash("1583511655857-d19b40a7a54e"),
        alt: "Dog focused and attentive during an obedience training session",
        _temporary: true,
      },
      {
        src: unsplash("1548767797-d96c944b7a63"),
        alt: "Group of dogs participating in a professional training class",
        _temporary: true,
      },
      {
        src: unsplash("1592194996308-7b43878e84a6"),
        alt: "Dog portrait showing the confident posture from behavioural training",
        _temporary: true,
      },
      {
        src: unsplash("1596422846543-75c6fc197f07"),
        alt: "Adorable pug portrait demonstrating calm trained behaviour",
        _temporary: true,
      },
      {
        src: unsplash("1560807707-8cc77767d783"),
        alt: "Young puppy beginning its first training lesson with the team",
        _temporary: true,
      },
    ],
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },

  /* ── Relocation ────────────────────────────────────────────────────── */
  {
    eyebrow: "Relocation",
    title: "Pet Relocation & Transport",
    headingClass: "mb-8",
    _temporary: true,
    images: [
      {
        src: unsplash("1436491865332-7a61a109cc05"),
        alt: "Dog wearing a travel backpack ready for a relocation journey",
        _temporary: true,
      },
      {
        src: unsplash("1601758228041-f3b2795255f1"),
        alt: "Dog sitting comfortably inside a car during pet transport",
        _temporary: true,
      },
      {
        src: unsplash("1582562124811-c09040d0a901"),
        alt: "Pet carrier prepared and ready for safe animal relocation",
        _temporary: true,
      },
      {
        src: unsplash("1587300003388-59208cc962cb"),
        alt: "Golden retriever calmly waiting for the next leg of its relocation trip",
        _temporary: true,
      },
    ],
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },
];
