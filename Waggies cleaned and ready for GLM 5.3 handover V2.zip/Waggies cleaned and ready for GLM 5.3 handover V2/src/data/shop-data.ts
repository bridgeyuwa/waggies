/**
 * Shop product data.
 *
 * 10 sample pet care products across 5 categories.
 * Images are Unsplash stock (temporary placeholders).
 * Prices in Nigerian Naira (NGN).
 */

export type ProductCategory = "Food" | "Toys" | "Grooming" | "Health" | "Accessories";

export type Product = {
  id: string;
  name: string;
  description: string;
  price: number;
  category: ProductCategory;
  imageSrc: string;
  badge?: string;
  features: string[];
};

export const PRODUCTS: readonly Product[] = [
  {
    id: "royal-canin-puppy",
    name: "Royal Canin Puppy Dry Food",
    description:
      "Complete and balanced dry food for puppies up to 12 months. Supports healthy growth with adapted protein, calcium, and phosphorus content.",
    price: 18500,
    category: "Food",
    imageSrc: "https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=600&h=600&fit=crop",
    badge: "Bestseller",
    features: [
      "Suitable for puppies up to 12 months",
      "Supports immune system development",
      "Highly digestible proteins",
      "Contains DHA for brain development",
    ],
  },
  {
    id: "whiskas-cat-food",
    name: "Whiskas Adult Cat Food",
    description:
      "Crunchy kibble with filled pockets for adult cats. Provides complete nutrition with the right balance of vitamins and minerals.",
    price: 9200,
    category: "Food",
    imageSrc: "https://images.unsplash.com/photo-1589924691995-400dc9ecc119?w=600&h=600&fit=crop",
    badge: undefined,
    features: [
      "For adult cats aged 1-7 years",
      "Contains essential fatty acids",
      "Supports healthy skin and coat",
      "Crunchy texture helps reduce plaque",
    ],
  },
  {
    id: "chew-rope-toy",
    name: "Indestructible Chew Rope Toy",
    description:
      "Durable cotton rope toy for dogs of all sizes. Helps clean teeth during play and withstands aggressive chewing.",
    price: 4500,
    category: "Toys",
    imageSrc: "https://images.unsplash.com/photo-1535294435445-d7249524ef2e?w=600&h=600&fit=crop",
    badge: "New",
    features: [
      "100% natural cotton fibres",
      "Helps clean teeth and massage gums",
      "Suitable for medium to large dogs",
      "Machine washable",
    ],
  },
  {
    id: "interactive-puzzle-feeder",
    name: "Interactive Puzzle Feeder",
    description:
      "Mental stimulation toy that dispenses treats as your pet solves the puzzle. Slows down fast eaters and reduces boredom.",
    price: 7800,
    category: "Toys",
    imageSrc: "https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=600&h=600&fit=crop",
    badge: undefined,
    features: [
      "Adjustable difficulty levels",
      "Works with most treat sizes",
      "Non-slip rubber base",
      "BPA-free food-grade materials",
    ],
  },
  {
    id: "oatmeal-shampoo",
    name: "Oatmeal Soothing Pet Shampoo",
    description:
      "Gentle, soap-free shampoo with colloidal oatmeal. Relieves itching and dry skin while leaving the coat clean and soft.",
    price: 6500,
    category: "Grooming",
    imageSrc: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=600&h=600&fit=crop",
    badge: "Bestseller",
    features: [
      "Soap-free and pH balanced",
      "Colloidal oatmeal formula",
      "Safe for puppies and kittens",
      "Fresh lavender scent",
    ],
  },
  {
    id: "deshedding-brush",
    name: "Professional Deshedding Brush",
    description:
      "Reduces shedding by up to 90% with stainless steel edge that reaches deep beneath the topcoat. Suitable for dogs and cats.",
    price: 5800,
    category: "Grooming",
    imageSrc: "https://images.unsplash.com/photo-1587300003388-5721b8c9a6bb?w=600&h=600&fit=crop",
    badge: undefined,
    features: [
      "Stainless steel edge",
      "Ergonomic handle",
      "Reduces shedding up to 90%",
      "For dogs and cats",
    ],
  },
  {
    id: "tick-flea-collar",
    name: "Tick and Flea Prevention Collar",
    description:
      "8-month continuous protection against ticks, fleas, and lice. Water-resistant collar with adjustable buckle for a secure fit.",
    price: 11200,
    category: "Health",
    imageSrc: "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=600&h=600&fit=crop",
    badge: "New",
    features: [
      "8 months of continuous protection",
      "Water-resistant design",
      "Adjustable length for all breeds",
      "Odourless and non-greasy",
    ],
  },
  {
    id: "pet-first-aid-kit",
    name: "Pet First Aid Kit",
    description:
      "Compact first aid kit with essential supplies for minor pet injuries. Includes bandages, antiseptic wipes, tweezers, and a guide.",
    price: 14500,
    category: "Health",
    imageSrc: "https://images.unsplash.com/photo-1601758124096-1fd661873b48?w=600&h=600&fit=crop",
    badge: undefined,
    features: [
      "25-piece essential supply set",
      "Includes first aid guide",
      "Compact travel-friendly case",
      "Suitable for dogs, cats, and small pets",
    ],
  },
  {
    id: "padded-dog-harness",
    name: "Padded No-Pull Dog Harness",
    description:
      "Breathable mesh harness with front clip to discourage pulling. Padded chest and belly straps for all-day comfort.",
    price: 9800,
    category: "Accessories",
    imageSrc: "https://images.unsplash.com/photo-1587300003388-5721b8c9a6bb?w=600&h=600&fit=crop",
    badge: "Bestseller",
    features: [
      "No-pull front clip design",
      "Breathable mesh padding",
      "4 adjustment points for custom fit",
      "Reflective stitching for visibility",
    ],
  },
  {
    id: "raised-pet-bowl",
    name: "Elevated Stainless Steel Pet Bowl",
    description:
      "Raised feeding bowl with stand to promote better posture and aid digestion. Detachable stainless steel bowl is easy to clean.",
    price: 6200,
    category: "Accessories",
    imageSrc: "https://images.unsplash.com/photo-1601758124096-1fd661873b48?w=600&h=600&fit=crop",
    badge: undefined,
    features: [
      "15-degree tilted design for digestion",
      "Detachable stainless steel bowl",
      "Anti-slip rubber base",
      "Available in small and large sizes",
    ],
  },
];

export const PRODUCT_CATEGORIES: readonly ProductCategory[] = [
  "Food",
  "Toys",
  "Grooming",
  "Health",
  "Accessories",
];

export function getProductById(id: string): Product | undefined {
  return PRODUCTS.find((p) => p.id === id);
}

export function getRelatedProducts(
  productId: string,
  category: ProductCategory,
  limit = 3,
): Product[] {
  return PRODUCTS.filter(
    (p) => p.id !== productId && p.category === category,
  ).slice(0, limit);
}
