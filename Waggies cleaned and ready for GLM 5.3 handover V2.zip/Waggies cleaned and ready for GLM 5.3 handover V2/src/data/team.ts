/**
 * Team data for the Waggies About page.
 *
 * Verified staff have verifiedStaff: true and are confirmed employees.
 * Placeholder staff have placeholder: true and are stand-in profiles.
 * All images are temporary Unsplash stock portraits.
 */

export type TeamMember = {
  name: string;
  role: string;
  responsibility?: string;
  imageSrc: string;
  imageAlt: string;
  verifiedStaff: boolean;
  temporaryImage: boolean;
  placeholder: boolean;
};

export const teamMembers: TeamMember[] = [
  // ── Verified staff ──────────────────────────────────────────────────────
  {
    name: "Dr. Nguhemen Doose Yuwa",
    role: "DVM, Head Veterinarian and Director",
    responsibility: "Leads all veterinary services and oversees clinical operations at Waggies.",
    imageSrc:
      "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face&q=80",
    imageAlt: "Portrait of Dr. Nguhemen Doose Yuwa",
    verifiedStaff: true,
    temporaryImage: true,
    placeholder: false,
  },
  {
    name: "Aifuwa Bob Osaze",
    role: "Director",
    responsibility: "Oversees business strategy, partnerships, and overall operations at Waggies.",
    imageSrc:
      "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=face&q=80",
    imageAlt: "Portrait of Aifuwa Bob Osaze",
    verifiedStaff: true,
    temporaryImage: true,
    placeholder: false,
  },
  {
    name: "Oghomwen Oyuki Obaseki",
    role: "Secretary",
    responsibility: "Manages administrative operations, scheduling, and client communications.",
    imageSrc:
      "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop&crop=face&q=80",
    imageAlt: "Portrait of Oghomwen Oyuki Obaseki",
    verifiedStaff: true,
    temporaryImage: true,
    placeholder: false,
  },

  // ── Placeholder staff ───────────────────────────────────────────────────
  {
    name: "Chukwuma Eze",
    role: "Veterinary Support",
    imageSrc:
      "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face&q=80",
    imageAlt: "Portrait of Chukwuma Eze",
    verifiedStaff: false,
    temporaryImage: true,
    placeholder: true,
  },
  {
    name: "Amina Bello",
    role: "Lead Groomer",
    imageSrc:
      "https://images.unsplash.com/photo-1594744803329-e58b31de8bf5?w=400&h=400&fit=crop&crop=face&q=80",
    imageAlt: "Portrait of Amina Bello",
    verifiedStaff: false,
    temporaryImage: true,
    placeholder: true,
  },
  {
    name: "Dayo Adekunle",
    role: "Boarding Manager",
    imageSrc:
      "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&crop=face&q=80",
    imageAlt: "Portrait of Dayo Adekunle",
    verifiedStaff: false,
    temporaryImage: true,
    placeholder: true,
  },
  {
    name: "Kemi Ogunleye",
    role: "Pet Trainer",
    imageSrc:
      "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=400&fit=crop&crop=face&q=80",
    imageAlt: "Portrait of Kemi Ogunleye",
    verifiedStaff: false,
    temporaryImage: true,
    placeholder: true,
  },
  {
    name: "Suleiman Ahmadu",
    role: "Relocation & Transport Coordinator",
    imageSrc:
      "https://images.unsplash.com/photo-1573497019940-1c28c88b4f3e?w=400&h=400&fit=crop&crop=face&q=80",
    imageAlt: "Portrait of Suleiman Ahmadu",
    verifiedStaff: false,
    temporaryImage: true,
    placeholder: true,
  },
];
