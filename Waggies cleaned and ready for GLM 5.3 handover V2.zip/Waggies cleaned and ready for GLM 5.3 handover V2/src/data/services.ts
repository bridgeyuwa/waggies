/**
 * Services index + per-service page content  -  extracted verbatim from the
 * Laravel Blade source.
 *
 * Sources of truth:
 *   - resources/views/pages/services/index.blade.php
 *   - resources/views/pages/services/boarding/index.blade.php
 *   - resources/views/pages/services/boarding/{dogs,cats,exotic}.blade.php
 *   - resources/views/pages/services/{grooming,vet-care,training,transport}.blade.php
 *
 * DO NOT paraphrase or "improve" this content.
 */

// ── Services index hero & cards ───────────────────────────────────────────
// Source: services/index.blade.php lines 5-33

export type ServiceCard = {
  title: string;
  description: string;
  href: string;
  imageSrc: string;
  icon: string;
};

export const servicesIndexHero = {
  /* TODO(client): Replace with Waggies facility hero photo */
  imageSrc: "https://images.unsplash.com/photo-1548199973-03d0b4fb1f8?w=1200&h=600&fit=crop&q=80",
  imageAlt: "Stock photo of dog outdoors (client photo required)",
  eyebrow: "Everything Your Pet Needs",
  title: "Pet Care Services,<br/>All Under One Roof",
  subtitle:
    "From overnight boarding to international relocation - Waggies handles it all from one facility.",
  primaryCta: { label: "View Our Services", href: "/services#services" },
  variant: "center" as const,
};

export const servicesIndexCards: ServiceCard[] = [
  {
    title: "Boarding",
    description:
      "Spacious, climate-controlled suites with 24/7 supervision and daily photo updates.",
    href: "/services/boarding",
    imageSrc: "https://images.unsplash.com/photo-1596492784531-6e6eb5ea9993?w=600&h=400&fit=crop&q=80",
    icon: "spa",
  },
  {
    title: "Grooming",
    description:
      "Breed-specific cuts, baths, and styling by experienced groomers using pet-safe products.",
    href: "/services/grooming",
    imageSrc: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=600&h=400&fit=crop&q=80",
    icon: "spa",
  },
  {
    title: "Vet Care",
    description:
      "On-site veterinary consultations, vaccinations, and routine wellness check-ups.",
    href: "/services/vet-care",
    imageSrc: "https://images.unsplash.com/photo-1628009368231-7bb7cfcb0def?w=600&h=400&fit=crop&q=80",
    icon: "medical_services",
  },
  {
    title: "Dog Training",
    description:
      "Positive-reinforcement programmes for puppies and adult dogs of all breeds.",
    href: "/services/training",
    imageSrc: "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=600&h=400&fit=crop&q=80",
    icon: "school",
  },
  {
    title: "Local Transport",
    description:
      "Door-to-door pet pickup and drop-off across Abuja, part of our relocation services.",
    href: "/relocation/transport",
    imageSrc: "https://images.unsplash.com/photo-1586671267731-da2cf3ceeb80?w=600&h=400&fit=crop&q=80",
    icon: "local_shipping",
  },
  {
    title: "Pet Relocation",
    description:
      "International moves with full documentation and airline coordination.",
    href: "/relocation",
    imageSrc: "https://images.unsplash.com/photo-1450778869180-e12d25b46b48?w=600&h=400&fit=crop&q=80",
    icon: "flight_takeoff",
  },
];

// ── Services index "standards" stat band ──────────────────────────────────
// Source: services/index.blade.php lines 39-71

export type ServiceStatItem = {
  icon: string;
  title: string;
  subtitle: string;
};

export const servicesIndexStats: ServiceStatItem[] = [
  { icon: "verified", title: "Vet-Supervised Care", subtitle: "Health-first handling" },
  { icon: "schedule", title: "24/7 Monitoring", subtitle: "Constant supervision" },
  { icon: "pets", title: "500+ Pets Served", subtitle: "Across Abuja & beyond" },
  { icon: "star", title: "4.9 Average Rating", subtitle: "Trusted by pet owners" },
];

// ── Services index "Waggies Standard" dark band ───────────────────────────
// Source: services/index.blade.php lines 73-115

export const servicesIndexStandards = {
  eyebrow: "The Waggies Standard",
  title: "Why Our Care System<br><span class=\"text-secondary italic\">Works So Well</span>",
  body: "Every pet is handled through structured care protocols designed to ensure safety, comfort, and emotional wellbeing.",
  cards: [
    { title: "Structured Daily Routines", desc: "Professionally trained handlers and protocols." },
    { title: "24/7 Supervision", desc: "Continuous monitoring, day and night." },
    { title: "Daily Updates", desc: "Owners receive real-time pet updates." },
  ],
} as const;

// ── Services index inline FAQ (6 hardcoded items) ────────────────────────
// Source: services/index.blade.php lines 154-274  -  note these are HARDCODED
// in the Blade, not pulled from the FAQ database. Preserved verbatim.

export type InlineFaqItem = { question: string; answer: string };

export const servicesIndexInlineFaqs: InlineFaqItem[] = [
  {
    question: "How do I know which service my pet needs?",
    answer:
      "If you're unsure, start with a consultation or contact us. Our team will recommend the right service based on your pet’s age, health, and behavior.",
  },
  {
    question: "Are all services safe for my pet?",
    answer:
      "Yes. Every service follows strict vet-supervised safety standards and trained handlers. Safety is built into every part of our system.",
  },
  {
    question: "Can I switch or combine services later?",
    answer:
      "Yes. Many clients combine grooming, boarding, and vet care depending on their pet’s needs. We can adjust plans anytime.",
  },
  {
    question: "Do I need a consultation before booking?",
    answer:
      "Not always. Some services can be booked directly, but consultations help us recommend the safest and most effective care plan.",
  },
  {
    question: "How do I get updates about my pet?",
    answer:
      "You receive regular updates including photos and status reports depending on the service you choose.",
  },
  {
    question: "What happens after I book a service?",
    answer:
      "Our team contacts you to confirm details, prepare your pet’s care plan, and guide you through the next steps.",
  },
];

// ── Boarding index page ───────────────────────────────────────────────────
// Source: services/boarding/index.blade.php

export const boardingIndexHero = {
  /* TODO(client): Replace with Waggies boarding facility hero photo */
  imageSrc: "https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=1200&h=600&fit=crop&q=80",
  imageAlt: "Stock photo of happy dog (client photo required)",
  eyebrow: "Pet Boarding in Abuja",
  eyebrowIcon: "pets",
  title: "A Home Away From Home",
  subtitle:
    "Spacious, climate-controlled suites with 24/7 supervision, orthopedic bedding, and daily updates for total peace of mind.",
  primaryCta: {
    label: "Book Appointment",
    href: "/contact?intent=book&service=boarding",
    icon: "arrow_forward",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=boarding",
    icon: "calculate",
  },
  variant: "center" as const,
};

export const boardingIndexCards: ServiceCard[] = [
  {
    title: "Dog Boarding",
    description:
      "Private suites with outdoor play areas, socialisation sessions, and daily grooming.",
    href: "/services/boarding/dogs",
    imageSrc: "https://images.unsplash.com/photo-1552053831-71594a27632d?w=600&h=400&fit=crop&q=80",
    icon: "pets",
  },
  {
    title: "Cat Boarding",
    description:
      "Calm, quiet cat condos away from dogs  -  with enrichment toys and cosy resting nooks.",
    href: "/services/boarding/cats",
    imageSrc: "https://images.unsplash.com/photo-1573864708626-c43d2d6f7a11?w=600&h=400&fit=crop&q=80",
    icon: "heart_plus",
  },
  {
    title: "Exotic Boarding",
    description:
      "Specialist care for birds, reptiles, rabbits and small mammals in custom enclosures.",
    href: "/services/boarding/exotic",
    imageSrc: "https://images.unsplash.com/photo-1437409368301-e2d6e673f6fb?w=600&h=400&fit=crop&q=80",
    icon: "nest_eco_leaf",
  },
];

/** Boarding index "What's Included" feature list (6 items). */
export const boardingIncludedFeatures: ReadonlyArray<{
  icon: string;
  title: string;
  desc: string;
}> = [
  { icon: "hotel", title: "Boarding Suites", desc: "Climate-controlled rooms with orthopedic bedding." },
  { icon: "restaurant", title: "Quality Meals", desc: "Nutritious food served on your pet's usual schedule." },
  { icon: "directions_run", title: "Daily Exercise", desc: "Structured play and exercise sessions every day." },
  // TODO(client): confirm daily vet check process
  { icon: "medical_services", title: "Vet on Site", desc: "Our on-site vet monitors all boarding guests daily." },
  { icon: "notifications", title: "Daily Photo Updates", desc: "Photo and report sent to you every single day." },
  { icon: "lock_clock", title: "24/7 Supervision", desc: "Staff present around the clock  -  never unsupervised." },
];

/** Boarding index "Safe Space" floating card content. */
export const boardingSafeSpaceCard = {
  /* TODO(client): Replace with Waggies facility interior photo */
  imageSrc:
    "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=600&h=400&fit=crop&q=80",
  imageAlt: "Stock photo of a puppy (client photo required)",
  title: "Safe, Supervised Space",
  happyGuests: "1,000+",
} as const;

/** Boarding index testimonials (3). */
export const boardingTestimonials = [
  {
    stars: 5,
    quote:
      "My dog came back happy and healthy. The daily photos made it so easy to relax while I was away.",
    authorInitial: "C",
    authorName: "Chidi A.",
    authorSubtitle: "Dog owner · Gwarinpa",
  },
  {
    stars: 5,
    quote:
      "Excellent facilities  -  clean, spacious and clearly well-managed. My cat was in great spirits on pickup.",
    authorInitial: "N",
    authorName: "Ngozi E.",
    authorSubtitle: "Cat owner · Maitama",
  },
  {
    stars: 5,
    quote:
      "I was nervous leaving my rabbit but the team clearly knew exactly how to care for him. Will return.",
    authorInitial: "T",
    authorName: "Tunde B.",
    authorSubtitle: "Rabbit owner · Wuse II",
  },
] as const;

// ── Generic "service feature grid" (used on grooming/vet-care/training/ ──
// ── transport/import/export pages  -  purple cards with icon+title+desc) ──

export type ServiceFeatureItem = {
  icon: string;
  title: string;
  desc: string;
};

// ── Grooming page ─────────────────────────────────────────────────────────
// Source: services/grooming.blade.php

export const groomingHero = {
  /* TODO(client): Replace with Waggies grooming spa hero photo */
  imageSrc: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=1200&h=600&fit=crop&q=80",
  imageAlt: "Stock photo of dog being groomed (client photo required)",
  title: "Professional Grooming<br/>by Experienced Staff",
  subtitle:
    "Breed-specific cuts, baths, and precision styling by trained groomers in a calm, purpose-built spa.",
  primaryCta: {
    label: "Book a Groom",
    href: "/contact?intent=book&service=grooming",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=grooming",
    icon: "calculate",
  },
};

export const groomingSectionHeading = {
  eyebrow: "Our Grooming Services",
  title: "A Full Menu of<br/>Grooming Treatments",
  subtitle:
    "Whether it is a quick bath and brush or a full breed-standard groom, we have a treatment to suit every pet.",
};

export const groomingFeatures: ServiceFeatureItem[] = [
  { icon: "water_drop", title: "Bath & Dry", desc: "Shampoo and conditioner suited to your pet's coat type, followed by a professional blow-dry." },
  // TODO(client): confirm groomer credentials
  { icon: "content_cut", title: "Breed-Standard Styling", desc: "Full cuts and styling to breed standard by experienced groomers with years of practice." },
  { icon: "spa", title: "De-shed Treatment", desc: "A deep deshedding treatment that dramatically reduces loose fur and keeps coats healthy." },
  { icon: "face", title: "Facial & Eye Clean", desc: "Gentle face wash, eye cleaning, and ear inspection to keep your pet fresh and comfortable." },
  { icon: "back_hand", title: "Nail Trim & Grind", desc: "Safe nail trimming and grinding to a comfortable, healthy length." },
  { icon: "star", title: "Full Groom Package", desc: "Bath, dry, cut, nails, ears, and a light spritz - everything in one appointment." },
];

export const groomingFeatureBand = {
  eyebrow: "Our Standards",
  title: "Grooming Done Right,<br/><span class=\"text-secondary italic\">Every Time</span>",
  subtitle:
    "We use pet-safe products and handle every animal with patience and care.",
  cta: { label: "Book a Groom", href: "/contact" },
  features: [
    // TODO(client): confirm groomer credentials
    { icon: "verified", title: "Experienced Groomers", description: "All groomers are professionally trained and experienced in breed-standard styling." },
    { icon: "eco", title: "Pet-Safe Products", description: "We use only quality, non-toxic, pet-safe shampoos and conditioners." },
    { icon: "psychology", title: "Calm Handling", description: "Patient, low-stress handling techniques  -  especially for nervous pets." },
    { icon: "schedule", title: "Punctual Service", description: "We respect your time. Drop-off and collection slots run to schedule." },
  ],
};

// ── Vet Care page ─────────────────────────────────────────────────────────
// Source: services/vet-care.blade.php

export const vetCareHero = {
  /* TODO(client): Replace with Waggies vet care hero photo */
  imageSrc: "https://images.unsplash.com/photo-1628009368231-7bb7cfcb0def?w=1200&h=600&fit=crop&q=80",
  imageAlt: "Stock photo of vet with dog (client photo required)",
  title: "On-Site Veterinary Care<br/>You Can Rely On",
  subtitle:
    "Consultations, vaccinations, wellness checks, and minor treatments  -  delivered by our on-site veterinarian every day of the week.",
  primaryCta: {
    label: "Book a Consultation",
    href: "/contact?intent=book&service=vet-care",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=vet-care",
    icon: "calculate",
  },
};

export const vetCareSectionHeading = {
  eyebrow: "Vet Services",
  title: "Comprehensive Care<br/>for Every Pet",
  subtitle:
    "From routine check-ups to treatment and advice, our vet is here to keep your pet healthy and thriving.",
};

export const vetCareFeatures: ServiceFeatureItem[] = [
  { icon: "stethoscope", title: "General Consultations", desc: "Full nose-to-tail wellness examinations and health consultations for all species." },
  { icon: "vaccines", title: "Vaccinations", desc: "Core and non-core vaccinations administered on a personalised schedule." },
  { icon: "monitor_heart", title: "Wellness Check-Ups", desc: "Routine health assessments to catch issues early and keep your pet in peak condition." },
  { icon: "medication", title: "Prescription & Treatment", desc: "Diagnosis, prescriptions, and minor treatment for common health conditions." },
  { icon: "pest_control", title: "Parasite Prevention", desc: "Flea, tick, and worm treatments and prevention advice tailored to your pet's lifestyle." },
  { icon: "science", title: "Lab & Diagnostics", desc: "In-clinic diagnostic tests and coordination with external labs for detailed results." },
];

export const vetCareFeatureBand = {
  eyebrow: "Why Our Vet Care?",
  title: "Caring, Professional,<br/><span class=\"text-secondary italic\">On-Site Daily</span>",
  subtitle:
    "Having a vet on-site every day means your pet gets professional care without the stress of a separate vet visit.",
  cta: { label: "Book a Consultation", href: "/contact" },
  features: [
    { icon: "medical_services", title: "On-Site Vet Daily", description: "Our vet is present on-site every day of the week, including weekends." },
    { icon: "verified", title: "PCSA Registered", description: "All vet services are delivered to certified professional standards." },
    { icon: "lock_clock", title: "Immediate Response", description: "Boarding guests receive immediate veterinary attention if any concern arises." },
    { icon: "psychology", title: "Low-Stress Environment", description: "Consultations in a calm, familiar setting  -  less anxiety for your pet." },
  ],
};

// ── Training page ─────────────────────────────────────────────────────────
// Source: services/training.blade.php

export const trainingHero = {
  /* TODO(client): Replace with Waggies training session hero photo */
  imageSrc: "https://images.unsplash.com/photo-1517849845537-4d257902454a?w=1200&h=600&fit=crop&q=80",
  imageAlt: "Stock photo of cute dog (client photo required)",
  title: "Positive Training for<br/>a Better-Behaved Dog",
  subtitle:
    "Science-based, positive-reinforcement training programmes for puppies and adult dogs  -  building confidence, manners, and a stronger bond.",
  primaryCta: {
    label: "Enquire About Training",
    href: "/contact?intent=consult&service=training",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=training",
    icon: "calculate",
  },
};

export const trainingSectionHeading = {
  eyebrow: "Training Programmes",
  title: "A Programme for<br/>Every Dog",
  subtitle:
    "We offer structured training programmes to suit puppies, adolescent dogs, and adults at any stage of their learning.",
};

export const trainingFeatures: ServiceFeatureItem[] = [
  { icon: "child_care", title: "Puppy Foundation", desc: "Essential early socialisation, toilet training, recall, and bite inhibition for puppies 8-16 weeks." },
  { icon: "school", title: "Basic Obedience", desc: "Sit, stay, come, heel, and leash manners  -  the core commands every dog should know." },
  { icon: "workspace_premium", title: "Advanced Obedience", desc: "Off-lead reliability, distance commands, and polished behaviour in real-world environments." },
  { icon: "psychology", title: "Behaviour Modification", desc: "Tailored programmes for reactivity, anxiety, aggression, or other specific behavioural concerns." },
  { icon: "groups", title: "Group Classes", desc: "Sociable small-group sessions to practise skills around other dogs and people." },
  { icon: "person", title: "1-to-1 Private Sessions", desc: "Focused one-on-one sessions with a trainer, tailored to your dog's specific needs and goals." },
];

export const trainingFeatureBand = {
  eyebrow: "Our Approach",
  title: "Positive Methods,<br/><span class=\"text-secondary italic\">Lasting Results</span>",
  subtitle:
    "We use only reward-based, force-free training methods that build trust and produce long-lasting behavioural change.",
  cta: { label: "Start Training", href: "/contact" },
  features: [
    { icon: "thumb_up", title: "Reward-Based Only", description: "We never use aversive tools or punishment-based techniques." },
    // TODO(client): confirm trainer credentials
    { icon: "verified", title: "Experienced Trainers", description: "All trainers are experienced in canine behaviour and positive-reinforcement training methods." },
    { icon: "favorite", title: "Bond-Building Focus", description: "Training that strengthens the relationship between you and your dog." },
    { icon: "trending_up", title: "Measurable Progress", description: "Clear goals set at the outset and tracked throughout the programme." },
  ],
};

// ── Transport page ────────────────────────────────────────────────────────
// Source: services/transport.blade.php

export const transportHero = {
  /* TODO(client): Replace with Waggies transport vehicle hero photo */
  imageSrc: "https://images.unsplash.com/photo-1606567595334-d39972c85dbe?w=1200&h=600&fit=crop&q=80",
  imageAlt: "Stock photo of pet travel (client photo required)",
  title: "Safe, Comfortable<br/>Door-to-Door Transport",
  subtitle:
    "Part of Waggies relocation services — air-conditioned, purpose-fitted vehicles for pet pickup and drop-off anywhere across Abuja.",
  primaryCta: { label: "Book a Transfer", href: "/contact" },
  secondaryCta: { label: "View Pricing", href: "/services/pricing" },
};

export const transportSectionHeading = {
  eyebrow: "Local Transport · Relocation",
  title: "We Go Where<br/>Your Pet Needs to Go",
  subtitle:
    "Whether it is a trip to Waggies for boarding or grooming, or a vet visit, we will collect and return your pet safely.",
};

export const transportFeatures: ServiceFeatureItem[] = [
  { icon: "local_shipping", title: "Pickup & Drop-Off", desc: "Door-to-door collection and return for boarding, grooming, or vet appointments at Waggies." },
  { icon: "air", title: "Air-Conditioned Vehicles", desc: "Climate-controlled vehicles to keep your pet comfortable whatever the Abuja weather." },
  { icon: "lock", title: "Secure Crating", desc: "Approved travel crates and harnesses to keep pets safe and secure during transit." },
  { icon: "person", title: "Experienced Handlers", desc: "Drivers trained in animal handling and pet first aid." },
  { icon: "map", title: "All Areas of Abuja", desc: "We cover all major districts  -  Maitama, Wuse, Asokoro, Garki, Gwarinpa, and beyond." },
  { icon: "schedule", title: "Punctual & Reliable", desc: "Time slots booked in advance so you can plan around your schedule." },
];

export const transportCtaBand = {
  heading: "Book a transport slot",
  body: "Contact us with your pickup address, destination, and preferred time.",
  primary: { label: "Book Now", href: "/contact", icon: "arrow_forward" },
  secondary: { label: "View Pricing", href: "/services/pricing" },
} as const;
