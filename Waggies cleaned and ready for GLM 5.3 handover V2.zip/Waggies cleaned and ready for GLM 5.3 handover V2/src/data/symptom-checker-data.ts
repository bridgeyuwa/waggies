/**
 * Symptom checker data for the Pet Symptom Checker tool.
 *
 * Body areas, symptoms, and guidance notes are general informational
 * content and do NOT constitute veterinary diagnosis.
 */

export type PetType = "dog" | "cat" | "other";

export type BodyArea = {
  id: string;
  label: string;
  icon: string;
};

export type Symptom = {
  id: string;
  label: string;
};

export type SymptomGroup = {
  bodyArea: BodyArea;
  symptoms: Symptom[];
};

export type SymptomGuidance = {
  severity: "low" | "moderate" | "high";
  title: string;
  description: string;
  recommendations: string[];
};

export const PET_TYPES: { id: PetType; label: string; icon: string }[] = [
  { id: "dog", label: "Dog", icon: "pets" },
  { id: "cat", label: "Cat", icon: "cat" },
  { id: "other", label: "Other", icon: "cruelty_free" },
];

export const BODY_AREAS: BodyArea[] = [
  { id: "head", label: "Head", icon: "psychology" },
  { id: "eyes", label: "Eyes", icon: "visibility" },
  { id: "ears", label: "Ears", icon: "hearing" },
  { id: "mouth", label: "Mouth / Teeth", icon: "sentiment_satisfied" },
  { id: "skin", label: "Skin / Coat", icon: "spa" },
  { id: "stomach", label: "Stomach / Digestive", icon: "restaurant" },
  { id: "legs", label: "Legs / Paws", icon: "directions_walk" },
  { id: "breathing", label: "Breathing", icon: "air" },
  { id: "general", label: "General", icon: "monitor_heart" },
];

export const SYMPTOM_DATA: Record<string, Symptom[]> = {
  head: [
    { id: "head-tilt", label: "Head tilting" },
    { id: "head-shaking", label: "Frequent head shaking" },
    { id: "head-pressing", label: "Pressing head against surfaces" },
    { id: "swelling-face", label: "Facial swelling" },
    { id: "discharge-nose", label: "Nasal discharge" },
    { id: "sneezing", label: "Sneezing" },
  ],
  eyes: [
    { id: "red-eyes", label: "Red or bloodshot eyes" },
    { id: "watery-eyes", label: "Excessive tearing" },
    { id: "cloudy-eyes", label: "Cloudy or hazy eyes" },
    { id: "squinting", label: "Squinting or keeping eyes closed" },
    { id: "eye-discharge", label: "Eye discharge (yellow/green)" },
    { id: "pawing-eyes", label: "Pawing at eyes" },
  ],
  ears: [
    { id: "ear-odor", label: "Bad odour from ears" },
    { id: "ear-scratching", label: "Frequent scratching at ears" },
    { id: "ear-discharge", label: "Discharge from ears" },
    { id: "ear-redness", label: "Red or swollen ears" },
    { id: "head-shake-ear", label: "Head shaking (ear-related)" },
    { id: "ear-pain", label: "Sensitivity when ears touched" },
  ],
  mouth: [
    { id: "bad-breath", label: "Persistent bad breath" },
    { id: "excessive-drool", label: "Excessive drooling" },
    { id: "difficulty-eating", label: "Difficulty eating or chewing" },
    { id: "bleeding-gums", label: "Bleeding or swollen gums" },
    { id: "tooth-loss", label: "Loose or missing teeth" },
    { id: "pawing-mouth", label: "Pawing at mouth" },
  ],
  skin: [
    { id: "itching", label: "Excessive itching or scratching" },
    { id: "hair-loss", label: "Hair loss or bald patches" },
    { id: "rashes", label: "Redness, rashes, or hot spots" },
    { id: "lumps", label: "Lumps or bumps on skin" },
    { id: "dry-skin", label: "Dry, flaky skin" },
    { id: "excessive-shedding", label: "Excessive shedding" },
    { id: "fleas-ticks", label: "Visible fleas or ticks" },
  ],
  stomach: [
    { id: "vomiting", label: "Vomiting" },
    { id: "diarrhoea", label: "Diarrhoea" },
    { id: "loss-appetite", label: "Loss of appetite" },
    { id: "bloated-belly", label: "Bloated or swollen belly" },
    { id: "constipation", label: "Constipation or straining" },
    { id: "weight-loss", label: "Unexplained weight loss" },
    { id: "excessive-thirst", label: "Excessive thirst or urination" },
  ],
  legs: [
    { id: "limping", label: "Limping or favouring a leg" },
    { id: "swollen-paw", label: "Swollen paws" },
    { id: "licking-paw", label: "Excessive licking of paws" },
    { id: "nail-issues", label: "Broken or overgrown nails" },
    { id: "stiffness", label: "Stiffness or difficulty rising" },
    { id: "joint-pain", label: "Apparent joint pain" },
  ],
  breathing: [
    { id: "coughing", label: "Coughing" },
    { id: "wheezing", label: "Wheezing or noisy breathing" },
    { id: "rapid-breathing", label: "Rapid or shallow breathing" },
    { id: "laboured-breathing", label: "Laboured breathing" },
    { id: "sneezing-resp", label: "Frequent sneezing" },
    { id: "exercise-intolerance", label: "Exercise intolerance" },
  ],
  general: [
    { id: "lethargy", label: "Lethargy or unusual tiredness" },
    { id: "fever", label: "Fever (warm ears, nose, body)" },
    { id: "aggression", label: "Unexplained aggression" },
    { id: "hiding", label: "Hiding or withdrawal" },
    { id: "excessive-thirst-gen", label: "Increased thirst" },
    { id: "seizures", label: "Seizures or tremors" },
    { id: "disorientation", label: "Disorientation or confusion" },
  ],
};

/**
 * Get guidance based on selected symptom IDs and body area.
 * Returns appropriate severity and recommendations.
 */
export function getGuidance(
  bodyAreaId: string,
  symptomIds: string[],
): SymptomGuidance {
  const count = symptomIds.length;

  // High-severity indicators
  const highSeverityIds = [
    "head-pressing",
    "laboured-breathing",
    "seizures",
    "bloated-belly",
    "cloudy-eyes",
    "bleeding-gums",
    "disorientation",
  ];

  const hasHigh = symptomIds.some((id) => highSeverityIds.includes(id));

  if (hasHigh || count >= 4) {
    return {
      severity: "high",
      title: "See a Veterinarian Soon",
      description:
        "The symptoms you have selected may indicate a condition that requires veterinary attention. We strongly recommend scheduling a visit with your vet as soon as possible.",
      recommendations: [
        "Schedule a vet appointment within 24 hours",
        "Monitor your pet closely for any worsening symptoms",
        "Keep your pet comfortable and hydrated",
        "Note when symptoms started and any changes you have observed",
        "Contact your vet immediately if symptoms worsen rapidly",
      ],
    };
  }

  if (count >= 2) {
    return {
      severity: "moderate",
      title: "Consider a Vet Visit",
      description:
        "Your pet is showing multiple symptoms that could be related. While not necessarily an emergency, a veterinary check-up would help identify the underlying cause.",
      recommendations: [
        "Monitor symptoms over the next 24-48 hours",
        "Check if symptoms are improving, staying the same, or worsening",
        "Schedule a routine vet visit if symptoms persist",
        "Ensure your pet has access to fresh water and food",
        "Avoid giving any human medication without vet guidance",
      ],
    };
  }

  return {
    severity: "low",
    title: "Monitor and Observe",
    description:
      "The symptom you have selected is common and may resolve on its own. However, if it persists or worsens, we recommend consulting with your veterinarian.",
    recommendations: [
      "Keep an eye on your pet over the next few days",
      "Note any changes in behaviour, appetite, or energy",
      "Check if the symptom appears at certain times or after specific activities",
      "Schedule a vet visit if the symptom lasts more than 48 hours",
      "Maintain your pet's regular routine for feeding and exercise",
    ],
  };
}
