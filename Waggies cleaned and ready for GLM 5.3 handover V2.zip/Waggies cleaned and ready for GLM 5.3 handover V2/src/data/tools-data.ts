export type ToolEntry = {
  name: string;
  route: string;
  icon: string; // Phosphor icon name (kebab-case, matches phosphor-icons.ts)
  description: string;
  longDescription: string;
  category: "health" | "calculator" | "reference" | "utility";
  requiresDisclaimer: boolean;
  seoTitle: string;
  seoDescription: string;
};

export const allTools: ToolEntry[] = [
  // Health tools
  {
    name: "Pet Symptom Checker",
    route: "/tools/symptom-checker",
    icon: "stethoscope",
    description:
      "Select symptoms by body area and get general guidance on next steps.",
    longDescription:
      "An interactive tool to help you identify potential health concerns by selecting your pet's species, the affected body area, and specific symptoms you notice.",
    category: "health",
    requiresDisclaimer: true,
    seoTitle: "Pet Symptom Checker - Waggies",
    seoDescription:
      "Check your pet's symptoms and get general guidance on next steps. Free interactive symptom checker for dogs, cats, and other pets.",
  },
  {
    name: "Emergency & Poison Guide",
    route: "/tools/emergency-guide",
    icon: "warning-circle",
    description:
      "Quick-reference for common pet emergencies, poisons, and what to do.",
    longDescription:
      "A reference guide covering poisonous foods, household dangers, heatstroke, choking, seizures, and bleeding - with immediate action steps and emergency contacts.",
    category: "health",
    requiresDisclaimer: true,
    seoTitle: "Emergency & Poison Guide - Waggies",
    seoDescription:
      "Pet emergency and poison reference guide: poisonous foods, household dangers, heatstroke, choking, and more. Know what to do in a crisis.",
  },
  {
    name: "Parasite & Deworming Schedule",
    route: "/tools/parasite-schedule",
    icon: "bug-beetle",
    description:
      "Educational timeline for deworming puppies, kittens, and adult pets.",
    longDescription:
      "A general educational timeline showing recommended deworming intervals for puppies, kittens, adult dogs, and adult cats, with notes on travel and veterinary confirmation.",
    category: "health",
    requiresDisclaimer: true,
    seoTitle: "Parasite & Deworming Schedule - Waggies",
    seoDescription:
      "Deworming schedule reference for puppies, kittens, and adult pets. Educational timeline with general parasite prevention guidance.",
  },
  {
    name: "Medication Dosage Guide",
    route: "/tools/medication-dosage-guide",
    icon: "pill",
    description:
      "Veterinary-reviewed medication reference information (coming soon).",
    longDescription:
      "A veterinary-reviewed reference for common pet medications, dosage guidelines, and safety notes. Currently being prepared by our veterinary team.",
    category: "health",
    requiresDisclaimer: true,
    seoTitle: "Medication Dosage Guide - Waggies",
    seoDescription:
      "Veterinary-reviewed pet medication reference guide. Dosage guidelines and safety notes for common pet medications.",
  },

  // Calculators
  {
    name: "Pet Age Calculator",
    route: "/tools/pet-age-calculator",
    icon: "paw-print",
    description: "Convert your pet's age to approximate human years.",
    longDescription:
      "Convert your dog or cat's age into approximate human years using species-specific conversion formulas that account for size and life stage.",
    category: "calculator",
    requiresDisclaimer: false,
    seoTitle: "Pet Age Calculator - Waggies",
    seoDescription:
      "Convert your pet's age to human years. Accurate dog and cat age conversion calculator by breed size and life stage.",
  },
  {
    name: "Cost Calculator",
    route: "/tools/cost-calculator",
    icon: "calculator",
    description: "Estimate costs for Waggies boarding, grooming, vet, and training services.",
    longDescription:
      "Get a quick cost estimate for Waggies services based on your pet's type, size, and the service you need. Covers boarding, grooming, vet care, and training.",
    category: "calculator",
    requiresDisclaimer: false,
    seoTitle: "Cost Calculator - Waggies",
    seoDescription:
      "Estimate costs for Waggies pet services including boarding, grooming, vet care, and training in Abuja.",
  },
  {
    name: "Diet & Nutrition Calculator",
    route: "/tools/nutrition-calculator",
    icon: "fork-knife",
    description:
      "Estimate your pet's daily calorie needs based on weight, species, and activity level.",
    longDescription:
      "Calculate your dog or cat's estimated daily calorie requirement using the RER formula, adjusted for life stage and activity level.",
    category: "calculator",
    requiresDisclaimer: true,
    seoTitle: "Diet & Nutrition Calculator - Waggies",
    seoDescription:
      "Calculate your pet's daily calorie needs. RER-based nutrition calculator for dogs and cats by weight, life stage, and activity level.",
  },

  // Reference
  {
    name: "Vaccination Schedule",
    route: "/tools/vaccination-schedule",
    icon: "syringe",
    description: "Track recommended vaccinations for dogs and cats by age.",
    longDescription:
      "An interactive vaccination schedule tracker showing recommended vaccines for puppies, kittens, adult dogs, and adult cats at each life stage.",
    category: "reference",
    requiresDisclaimer: true,
    seoTitle: "Vaccination Schedule - Waggies",
    seoDescription:
      "Pet vaccination schedule tracker for dogs and cats. Recommended vaccines by age and life stage.",
  },
  {
    name: "Breed Info Finder",
    route: "/tools/breed-finder",
    icon: "magnifying-glass",
    description:
      "Browse popular dog and cat breeds with size, energy, grooming, and temperament info.",
    longDescription:
      "Search and filter popular dog and cat breeds by size, energy level, and grooming needs. General breed information including temperament and common health considerations.",
    category: "reference",
    requiresDisclaimer: false,
    seoTitle: "Breed Info Finder - Waggies",
    seoDescription:
      "Browse popular dog and cat breeds. Filter by size, energy, and grooming needs. General breed information and health considerations.",
  },
  {
    name: "Behavior & Training Tips",
    route: "/tools/behavior-tips",
    icon: "brain",
    description:
      "Practical advice for common pet behavior issues like barking, anxiety, and house training.",
    longDescription:
      "General, non-diagnostic advice for common behavior issues in dogs and cats, including barking, jumping, anxiety, aggression, house training, and destructive chewing.",
    category: "reference",
    requiresDisclaimer: false,
    seoTitle: "Behavior & Training Tips - Waggies",
    seoDescription:
      "Practical pet behavior and training tips. Advice for barking, anxiety, house training, aggression, and more.",
  },

  // Utilities
  {
    name: "New Pet Checklist",
    route: "/tools/new-pet-checklist",
    icon: "clipboard-text",
    description:
      "Interactive checklist of everything you need before and after bringing a pet home.",
    longDescription:
      "A comprehensive interactive checklist covering preparation, first week essentials, health and wellness, training, and supplies for new pet owners. Saves progress in your browser.",
    category: "utility",
    requiresDisclaimer: false,
    seoTitle: "New Pet Checklist - Waggies",
    seoDescription:
      "Interactive new pet checklist. Everything you need before and after bringing a dog or cat home. Tracks progress in your browser.",
  },
];

export const categoryLabels: Record<ToolEntry["category"], string> = {
  health: "Health Tools",
  calculator: "Calculators",
  reference: "Reference",
  utility: "Utilities",
};

export const categoryOrder: ToolEntry["category"][] = [
  "health",
  "calculator",
  "reference",
  "utility",
];

export function getToolsByCategory(): Record<
  ToolEntry["category"],
  ToolEntry[]
> {
  const grouped: Record<ToolEntry["category"], ToolEntry[]> = {
    health: [],
    calculator: [],
    reference: [],
    utility: [],
  };
  for (const tool of allTools) {
    grouped[tool.category].push(tool);
  }
  return grouped;
}
