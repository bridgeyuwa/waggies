/**
 * Loyalty Programme page content  -  extracted verbatim from the Laravel Blade
 * source of truth.
 *
 *   - Hero (gradient):            lines 5-12
 *   - How It Works (3 steps):     lines 14-40
 *   - Membership Tiers (3 tiers): lines 42-67
 *   - Start Earning CTA:          lines 69-77
 *
 * Component defaults referenced:
 *   - resources/views/components/hero/gradient.blade.php (rating='4.9',
 *     reviewCount='500+', layout='split')
 *
 * Route translations applied (Laravel → Next.js path):
 *   route('contact')         → /contact
 *   route('services.index')  → /services
 *
 * DO NOT paraphrase, modernize, abbreviate, or "improve" this content. The
 * Laravel application is the canonical source of truth for the migration.
 */

// ── Hero ──────────────────────────────────────────────────────────────────

export type LoyaltyHero = {
  rating: string;
  reviewCount: string;
  /** Raw HTML  -  Blade renders via `{!! $title !!}`. Contains <br/> + <span>. */
  title: string;
  subtitle: string;
  primaryCta: { label: string; href: string };
  secondaryCta: { label: string; href: string };
};

export const loyaltyHero: LoyaltyHero = {
  rating: "4.9",
  reviewCount: "500+",
  title:
    'Rewards for Every<br/><span class="text-primary italic">Waggies Visit</span>',
  subtitle:
    "Earn points every time you use Waggies. Redeem them for free services, discounts, and exclusive member perks.",
  primaryCta: { label: "Join for Free", href: "/contact" },
  secondaryCta: { label: "View Services", href: "/services" },
} as const;

// ── How It Works (3 steps) ────────────────────────────────────────────────

export type LoyaltyStep = {
  step: string;
  icon: string;
  title: string;
  desc: string;
};

export const loyaltyHowItWorks: LoyaltyStep[] = [
  {
    step: "01",
    icon: "person_add",
    title: "Sign Up Free",
    desc: "Register in minutes at reception or by contacting us. No fees, no catches.",
  },
  {
    step: "02",
    icon: "star",
    title: "Earn Points",
    desc: "Earn points on every booking  -  boarding, grooming, vet visits, training, and transport.",
  },
  {
    step: "03",
    icon: "redeem",
    title: "Redeem Rewards",
    desc: "Spend your points on free nights, free grooms, discounts, and members-only offers.",
  },
];

// ── Section heading (How It Works) ────────────────────────────────────────

export const loyaltyHowItWorksHeading = {
  eyebrow: "How It Works",
  title: "Three Simple Steps<br/>to Earning Rewards",
  subtitle:
    "Our loyalty programme is free to join and designed to reward you every time you choose Waggies.",
} as const;

// ── Membership Tiers (3 tiers) ────────────────────────────────────────────

export type LoyaltyTier = {
  tier: string;
  icon: string;
  color: string;
  threshold: string;
  perks: string[];
};

export const loyaltyTiersHeading = {
  eyebrow: "Membership Tiers",
  title: "The More You Visit,<br/>the More You Earn",
} as const;

export const loyaltyTiers: LoyaltyTier[] = [
  {
    tier: "Silver",
    icon: "emoji_events",
    color: "text-primary-dark/60",
    threshold: "From your first visit",
    perks: [
      "1 point per ₦1,000 spent",
      "5% birthday discount",
      "Priority booking access",
    ],
  },
  {
    tier: "Gold",
    icon: "emoji_events",
    color: "text-gold",
    threshold: "After 10 visits",
    perks: [
      "1.5 points per ₦1,000 spent",
      "10% birthday discount",
      "Free monthly nail trim",
      "Early access to promotions",
    ],
  },
  {
    tier: "Platinum",
    icon: "emoji_events",
    color: "text-primary",
    threshold: "After 25 visits",
    perks: [
      "2 points per ₦1,000 spent",
      "15% birthday discount",
      "Free monthly groom",
      "Dedicated account manager",
      "Exclusive member events",
    ],
  },
];

// ── Start Earning CTA ─────────────────────────────────────────────────────

export type LoyaltyStartEarningCta = {
  heading: string;
  body: string;
  ctaLabel: string;
  ctaHref: string;
  ctaIcon: string;
};

export const loyaltyStartEarningCta: LoyaltyStartEarningCta = {
  heading: "Start earning today",
  body: "Join the Waggies Loyalty Programme for free and start earning rewards from your very first visit.",
  ctaLabel: "Join Now",
  ctaHref: "/contact",
  ctaIcon: "arrow_forward",
} as const;
