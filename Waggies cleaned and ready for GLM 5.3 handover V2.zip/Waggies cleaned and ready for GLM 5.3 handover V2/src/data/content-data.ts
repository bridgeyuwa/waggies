/**
 * Content data for Blog, Guides, and Knowledge Base pages.
 *
 * All content is genuinely useful pet care advice written for
 * Waggies' Abuja-based pet-owning audience.
 */

/* ════════════════════════════════════════════════════════════════
   BLOG ARTICLES
   ═══════════════════════════════════════════════════════════════ */

export type BlogCategory = "Health" | "Nutrition" | "Behaviour" | "Care Tips";

export type BlogArticle = {
  id: number;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: BlogCategory;
  author: string;
  date: string;
  imageSrc: string;
  readTime: string;
  tags: string[];
};

export const blogCategories: BlogCategory[] = [
  "Health",
  "Nutrition",
  "Behaviour",
  "Care Tips",
];

export const blogArticles: BlogArticle[] = [
  {
    id: 1,
    slug: "understanding-common-dog-illnesses",
    title: "Understanding Common Dog Illnesses in Nigeria",
    excerpt:
      "From tick-borne diseases to heat exhaustion, Nigerian pet owners face unique health challenges. Learn to recognise early warning signs and when to seek veterinary care.",
    content: `<h2>Why Awareness Matters</h2>
<p>Nigeria's tropical climate creates conditions that favour certain illnesses in dogs, from tick-borne infections like ehrlichiosis to heat-related conditions that can escalate quickly. As a responsible pet owner in Abuja, recognising the early signs of illness can make the difference between a quick recovery and a serious health crisis.</p>

<h2>Tick-Borne Diseases</h2>
<p>Ehrlichiosis and babesiosis are two of the most common tick-borne diseases affecting dogs in Nigeria. Symptoms include fever, lethargy, loss of appetite, pale gums, and in severe cases, nosebleeds. Ticks thrive in Abuja's warm, humid environment, making year-round prevention essential. Use vet-approved tick and flea prevention products consistently, and check your dog's coat after walks in grassy areas.</p>

<h2>Heat Exhaustion and Dehydration</h2>
<p>Abuja's dry season temperatures can exceed 38°C. Dogs cool themselves primarily through panting, which is far less efficient than human sweating. Signs of heat exhaustion include excessive panting, drooling, weakness, and confusion. Always provide fresh water, avoid midday walks, and never leave your dog in a parked vehicle.</p>

<h2>Parvovirus</h2>
<p>Parvovirus remains a significant threat, especially for unvaccinated puppies. It spreads through contact with infected faeces and can survive in the environment for months. Symptoms include severe vomiting, bloody diarrhoea, and rapid dehydration. Vaccination is your strongest defence—ensure your puppy completes the full vaccination schedule by 16 weeks of age.</p>

<h2>When to See Your Vet</h2>
<p>Trust your instincts. If your dog refuses food for more than 24 hours, shows sudden lethargy, vomits repeatedly, or has difficulty breathing, contact your veterinarian immediately. Early intervention almost always leads to better outcomes and lower treatment costs.</p>`,
    category: "Health",
    author: "Dr. Amina Okonkwo",
    date: "2025-12-15",
    imageSrc:
      "https://images.unsplash.com/photo-1560807707-8cc77767d783?w=800&h=500&fit=crop&q=80",
    readTime: "4 min read",
    tags: ["dogs", "health", "ticks", "vaccination"],
  },
  {
    id: 2,
    slug: "best-nutrition-tips-nigerian-pets",
    title: "Nutrition Tips for Nigerian Pet Owners",
    excerpt:
      "Feeding your pet well doesn't have to be complicated. A practical guide to balanced nutrition using locally available foods and quality commercial diets.",
    content: `<h2>Building a Balanced Diet</h2>
<p>Good nutrition is the foundation of your pet's health. Whether you feed a commercial diet, home-cooked meals, or a combination, the goal is the same: provide the right balance of proteins, fats, carbohydrates, vitamins, and minerals your pet needs to thrive in Nigeria's climate.</p>

<h2>Understanding Pet Food Labels</h2>
<p>Not all pet foods are created equal. Look for products that list a specific animal protein (chicken, fish, or lamb) as the first ingredient. Avoid foods where "meat meal" or "by-products" appear at the top of the ingredient list. Reputable brands available in Nigeria include Royal Canin, Hill's, and Eukanuba, which formulate for different life stages and breed sizes.</p>

<h2>Local Foods Your Dog Can Safely Eat</h2>
<p>Many Nigerian households supplement commercial food with home-cooked meals. Safe options include boiled chicken (no bones or seasoning), sweet potatoes, carrots, green beans, and plain boiled rice. Eggs are an excellent protein source and can be fed cooked. Avoid onions, garlic, chocolate, grapes, and anything seasoned with salt or spices common in Nigerian cooking.</p>

<h2>Feeding Schedules</h2>
<p>Adult dogs do well with two meals per day, while puppies under six months need three to four smaller meals. Establish consistent feeding times and remove uneaten food after 20 minutes to prevent bacterial growth in Abuja's heat. Always ensure fresh, clean water is available throughout the day.</p>

<h2>Weight Management</h2>
<p>Obesity is a growing problem among urban pets in Nigeria. You should be able to feel your dog's ribs without pressing hard, and they should have a visible waist when viewed from above. If your pet is gaining weight, reduce portion sizes by 10% and increase daily exercise gradually.</p>`,
    category: "Nutrition",
    author: "Chioma Adeyemi",
    date: "2025-11-28",
    imageSrc:
      "https://images.unsplash.com/photo-1573864708626-c43d2d6f7a11?w=800&h=500&fit=crop&q=80",
    readTime: "5 min read",
    tags: ["nutrition", "dogs", "feeding", "local-foods"],
  },
  {
    id: 3,
    slug: "separation-anxiety-guide",
    title: "Helping Your Dog Overcome Separation Anxiety",
    excerpt:
      "Does your dog become destructive or overly vocal when left alone? Learn proven techniques to ease separation anxiety and build your pet's confidence.",
    content: `<h2>Recognising the Signs</h2>
<p>Separation anxiety is one of the most common behavioural issues reported by dog owners. It goes beyond normal boredom and manifests as genuine distress when your dog is separated from you. Common signs include excessive barking or howling, destructive chewing (especially near doors and windows), house soiling, pacing, and attempts to escape. In severe cases, dogs may injure themselves trying to break out of their crate or room.</p>

<h2>Understanding the Cause</h2>
<p>Anxiety often develops after a significant change—a move to a new home, a change in work schedule, the loss of a family member, or after a period of constant togetherness such as during a holiday. Some breeds, particularly Labrador Retrievers, German Shepherds, and rescue dogs, are more predisposed. Understanding that your dog isn't being "naughty" but is experiencing genuine fear is the first step toward helping them.</p>

<h2>Gradual Desensitisation</h2>
<p>The most effective approach is systematic desensitisation. Start by picking up your keys or putting on your shoes without actually leaving. Repeat this several times daily until your dog no longer reacts. Then progress to stepping outside for just ten seconds, gradually increasing the duration over weeks. The key is to stay below your dog's anxiety threshold at each stage.</p>

<h2>Creating a Safe Space</h2>
<p>Provide a comfortable, enclosed area where your dog feels secure. This might be a crate with the door left open, a specific room, or a cosy corner with their bed and favourite toys. Leave a piece of clothing that carries your scent. Puzzle feeders stuffed with treats can provide positive associations with alone time.</p>

<h2>When to Seek Professional Help</h2>
<p>If your dog's anxiety is severe or not improving after several weeks of consistent training, consult a veterinary behaviourist. They can rule out medical causes and may recommend behavioural therapy alongside temporary anti-anxiety medication to help your dog cope during the training process.</p>`,
    category: "Behaviour",
    author: "Dr. Amina Okonkwo",
    date: "2025-11-10",
    imageSrc:
      "https://images.unsplash.com/photo-1518717758536-85ae29035b6d?w=800&h=500&fit=crop&q=80",
    readTime: "5 min read",
    tags: ["behaviour", "anxiety", "dogs", "training"],
  },
  {
    id: 4,
    slug: "grooming-routine-at-home",
    title: "A Complete At-Home Grooming Routine for Dogs",
    excerpt:
      "Professional grooming is important, but regular at-home maintenance between visits keeps your dog comfortable, clean, and looking their best.",
    content: `<h2>Why Home Grooming Matters</h2>
<p>Regular grooming isn't just about appearance—it's essential for your dog's health and comfort. In Nigeria's dusty, humid climate, dirt and moisture can quickly lead to skin infections, matting, and hot spots. A consistent home grooming routine between professional visits helps prevent these issues and strengthens the bond between you and your pet.</p>

<h2>Brushing</h2>
<p>Brush your dog at least two to three times per week, daily for long-haired breeds. Use a slicker brush for removing loose fur and tangles, followed by a bristle brush to distribute natural oils. For breeds like Golden Retrievers and German Shepherds, an undercoat rake during shedding season makes a significant difference. Always brush in the direction of hair growth and be gentle around sensitive areas like the belly and ears.</p>

<h2>Bathing</h2>
<p>Most dogs need a bath every two to four weeks, depending on their breed and activity level. Use lukewarm water and a dog-specific shampoo—human shampoos disrupt the pH balance of your dog's skin. Wet your dog thoroughly, lather from neck to tail, and rinse completely to prevent skin irritation. In Abuja's heat, ensure your dog dries fully to prevent fungal infections, using a towel or low-heat hair dryer on a cool setting.</p>

<h2>Nail Care</h2>
<p>Trim nails every two to three weeks. If you can hear clicking on hard floors, the nails are too long. Use proper dog nail clippers and cut below the quick—the pink part of the nail containing blood vessels. If you're unsure, trim small amounts more frequently. Many dogs dislike nail trims, so pairing the experience with high-value treats helps create positive associations.</p>

<h2>Ear and Dental Care</h2>
<p>Check and clean ears weekly using a vet-recommended ear cleaner. Dogs with floppy ears are especially prone to infections. For dental health, aim to brush your dog's teeth daily or at least three times per week using dog-specific toothpaste. Dental chews and toys help reduce plaque buildup between brushings.</p>`,
    category: "Care Tips",
    author: "Chioma Adeyemi",
    date: "2025-10-22",
    imageSrc:
      "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=800&h=500&fit=crop&q=80",
    readTime: "4 min read",
    tags: ["grooming", "dogs", "care", "home-care"],
  },
  {
    id: 5,
    slug: "cat-care-beginners-nigeria",
    title: "Cat Care Essentials for First-Time Owners in Nigeria",
    excerpt:
      "Thinking about getting a cat? Here's everything you need to know about keeping your feline companion happy and healthy in a Nigerian home.",
    content: `<h2>Preparing Your Home</h2>
<p>Before bringing a cat home, you'll need a few essentials: a litter tray and clumping litter, food and water bowls, quality cat food, a scratching post, a carrier for vet visits, and a cosy bed. Cats are naturally curious climbers, so secure windows with screens and remove toxic plants like lilies, which are extremely dangerous to cats even in small amounts.</p>

<h2>Feeding Your Cat</h2>
<p>Cats are obligate carnivores, meaning they must eat meat to survive. Choose a high-quality commercial cat food that meets AAFCO standards. Wet food is particularly important for cats in Nigeria because it provides additional hydration in the heat. Feed adult cats twice daily, and always provide fresh water in a separate location from the food bowl—cats instinctively prefer this arrangement.</p>

<h2>Litter Training</h2>
<p>Most cats instinctively use a litter tray, but you should still show them where it is immediately after arrival. Place the tray in a quiet, accessible location and scoop waste daily. A general rule is one litter tray per cat, plus one extra. Avoid strongly scented litters—cats prefer unscented, fine-clumping varieties. If your cat stops using the tray, it's often a sign of stress or a medical issue, so consult your vet.</p>

<h2>Health Care</h2>
<p>Schedule a vet check within the first week of bringing your cat home. Core vaccinations protect against feline panleukopenia, calicivirus, and rhinotracheitis. Regular deworming is essential, especially for cats that may hunt insects or lizards, which are common in Nigerian homes. Spaying or neutering is strongly recommended—it prevents unwanted litters, reduces the risk of certain cancers, and can decrease behavioural issues like spraying and roaming.</p>

<h2>Indoor vs Outdoor</h2>
<p>In Abuja's busy urban environment, keeping your cat indoors is generally safer. Indoor cats live significantly longer on average—up to three times longer—because they're protected from traffic, fights with other animals, and infectious diseases. Provide enrichment through vertical spaces (cat trees, shelves), interactive toys, and window perches so your cat can observe the outside world safely.</p>`,
    category: "Care Tips",
    author: "Dr. Amina Okonkwo",
    date: "2025-10-05",
    imageSrc:
      "https://images.unsplash.com/photo-1526336024174-e58f5cdd8e13?w=800&h=500&fit=crop&q=80",
    readTime: "5 min read",
    tags: ["cats", "beginners", "care", "health"],
  },
  {
    id: 6,
    slug: "pet-vaccination-schedule-guide",
    title: "The Complete Pet Vaccination Guide for Nigerian Pets",
    excerpt:
      "Vaccinations protect your pet from serious and potentially fatal diseases. Here is a clear, practical vaccination schedule for dogs and cats in Nigeria.",
    content: `<h2>Why Vaccination Matters</h2>
<p>Vaccination is one of the most important things you can do to protect your pet's health. In Nigeria, where access to emergency veterinary care can be limited and certain diseases are more prevalent, prevention through vaccination is even more critical. Vaccines work by stimulating your pet's immune system to recognise and fight specific disease-causing organisms without actually causing the disease.</p>

<h2>Puppy Vaccination Schedule</h2>
<p>Puppies should begin their vaccination course at six to eight weeks of age. The core vaccine (often called the "5-in-1" or DHPP) protects against distemper, hepatitis, parainfluenza, parvovirus, and leptospirosis. The typical schedule is: first dose at 6–8 weeks, second dose at 10–12 weeks, third dose at 14–16 weeks, and a booster at 12 months. Rabies vaccination is given at 12–16 weeks of age and is legally required in many Nigerian states.</p>

<h2>Kitten Vaccination Schedule</h2>
<p>Kittens receive their first vaccination at eight to nine weeks (FVRCP: feline viral rhinotracheitis, calicivirus, and panleukopenia), a second dose at 12 weeks, and a third at 16 weeks. Rabies vaccination follows at 16 weeks. After the initial series, adult cats need annual boosters to maintain immunity.</p>

<h2>Non-Core Vaccines</h2>
<p>Depending on your pet's lifestyle and risk factors, your vet may recommend additional vaccines. For dogs, these can include Bordetella (kennel cough)—especially important if your dog frequents boarding facilities or dog parks—and canine coronavirus. Discuss your pet's specific risk profile with your veterinarian to create a tailored vaccination plan.</p>

<h2>Keeping Records</h2>
<p>Always keep a vaccination card for your pet. You'll need it for boarding, travel, and veterinary visits. Waggies requires up-to-date vaccination records for all boarding stays. If you're unsure whether your pet's vaccinations are current, contact your vet to schedule a review appointment rather than guessing.</p>`,
    category: "Health",
    author: "Dr. Amina Okonkwo",
    date: "2025-09-18",
    imageSrc:
      "https://images.unsplash.com/photo-1560807707-8cc77767d783?w=800&h=500&fit=crop&q=80",
    readTime: "4 min read",
    tags: ["health", "vaccination", "dogs", "cats"],
  },
];

/* ════════════════════════════════════════════════════════════════
   GUIDES
   ═══════════════════════════════════════════════════════════════ */

export type GuideCategory = "Getting Started" | "Pet Care" | "Training";

export type Guide = {
  id: number;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: GuideCategory;
  imageSrc: string;
  readTime: string;
};

export const guideCategories: GuideCategory[] = [
  "Getting Started",
  "Pet Care",
  "Training",
];

export const guides: Guide[] = [
  {
    id: 1,
    slug: "new-pet-checklist",
    title: "The Essential New Pet Checklist",
    excerpt:
      "Bringing a new pet home? This step-by-step checklist covers everything you need to prepare, from supplies and vet visits to creating a safe and welcoming environment.",
    content: `<h2>Before Your Pet Arrives</h2>
<p>Preparation is the key to a smooth transition. In the days before your new pet comes home, take the time to set up their space, gather supplies, and prepare your household. A little planning now prevents stress for both you and your new companion.</p>

<h3>Step 1: Pet-Proof Your Home</h3>
<p>Walk through your home at pet-eye level. Secure loose electrical cords, move toxic plants out of reach, install child-proof latches on cabinets containing cleaning products, and ensure windows and balconies are secure. Remove small objects that could be swallowed, and set up baby gates to restrict access to certain areas during the adjustment period.</p>

<h3>Step 2: Gather Essential Supplies</h3>
<p>For dogs: food and water bowls, high-quality puppy or adult food, a collar with ID tag, a leash, a crate or bed, chew toys, and grooming basics. For cats: litter tray and litter, food and water bowls, cat food, a scratching post, a carrier, and toys. Buy the same food the pet has been eating to avoid dietary upset during transition.</p>

<h3>Step 3: Choose a Veterinarian</h3>
<p>Research and select a veterinary clinic before your pet arrives. Book an initial health check within the first week. If adopting from Waggies or a shelter, ask for the pet's vaccination and medical records to share with your vet.</p>

<h3>Step 4: Prepare a Safe Space</h3>
<p>Set up a quiet, comfortable area where your new pet can retreat when overwhelmed. For dogs, this might be a crate with the door open and soft bedding. For cats, a small room with their litter tray, food, and water. This space gives them a secure base from which to explore at their own pace.</p>

<h3>Step 5: The First Few Days</h3>
<p>Keep things calm and predictable. Maintain a regular schedule for feeding, walks, and play. Allow your pet to approach family members on their terms. Resist the urge to invite visitors immediately—give your new pet at least a week to settle in before introducing them to new people and environments.</p>`,
    category: "Getting Started",
    imageSrc:
      "https://images.unsplash.com/photo-1601758174114-e711c0cbaa56?w=800&h=500&fit=crop&q=80",
    readTime: "6 min read",
  },
  {
    id: 2,
    slug: "preparing-pet-boarding",
    title: "How to Prepare Your Pet for Boarding",
    excerpt:
      "A comprehensive guide to ensuring your pet has a comfortable and stress-free boarding experience, from choosing the right facility to packing their essentials.",
    content: `<h2>Choosing the Right Facility</h2>
<p>Not all boarding facilities are the same. Look for a clean, well-maintained environment with adequate space, proper ventilation, and trained staff. Ask about daily routines, exercise schedules, and how they handle emergencies. A reputable facility like Waggies will welcome a pre-boarding visit so you can inspect the premises and meet the team caring for your pet.</p>

<h3>Step 1: Check Vaccination Requirements</h3>
<p>All boarding facilities require up-to-date vaccinations. Typically, dogs need DHPP, rabies, and kennel cough (Bordetella). Cats need FVRCP and rabies. Ensure all vaccinations are administered at least two weeks before the boarding date for full immunity to develop. Bring your vaccination records when you drop off your pet.</p>

<h3>Step 2: Pack Their Essentials</h3>
<p>Bring your pet's regular food to avoid dietary upset. Pack enough for the entire stay plus a few extra days. Include their favourite treats, a familiar blanket or toy, any medications with clear instructions, and your vet's contact information. Label everything with your pet's name.</p>

<h3>Step 3: Prepare Your Pet</h3>
<p>If your pet hasn't been boarded before, start with a short overnight stay to build confidence. Ensure they are comfortable in a crate if the facility uses them. Maintain your normal routine in the days leading up to boarding—avoid making the goodbye dramatic, as pets pick up on your emotions.</p>

<h3>Step 4: Provide Detailed Instructions</h3>
<p>Write down your pet's feeding schedule, dietary restrictions, medication times, behavioural quirks, and your vet's emergency contact. The more information the care team has, the better they can meet your pet's individual needs.</p>

<h3>Step 5: Settle Back at Home</h3>
<p>After boarding, your pet may be temporarily tired or drink more water than usual. This is normal—they've been active and stimulated. Return to their normal routine and give them space to rest. Most pets settle back within 24 to 48 hours.</p>`,
    category: "Pet Care",
    imageSrc:
      "https://images.unsplash.com/photo-1586671267731-da2cf3ceeb80?w=800&h=500&fit=crop&q=80",
    readTime: "6 min read",
  },
  {
    id: 3,
    slug: "basic-dog-training-guide",
    title: "Basic Dog Training: A Practical Guide for Beginners",
    excerpt:
      "From sit and stay to loose-lead walking, master the fundamental training techniques that every dog owner should know using positive reinforcement methods.",
    content: `<h2>The Principles of Positive Reinforcement</h2>
<p>Positive reinforcement training rewards desired behaviours rather than punishing unwanted ones. This approach builds trust, accelerates learning, and creates a willing, enthusiastic training partner. The principle is simple: when your dog performs a behaviour you want, immediately reward them with a treat, praise, or play. Timing is everything—the reward must come within one to two seconds of the behaviour.</p>

<h3>Step 1: Teach "Sit"</h3>
<p>Hold a treat close to your dog's nose and slowly move it upwards and backwards over their head. As their head follows the treat, their bottom will naturally lower. The moment they sit, say "Sit" clearly, give the treat, and offer praise. Repeat five to ten times per session, two to three sessions daily. Gradually reduce the hand motion until your dog sits on the verbal cue alone.</p>

<h3>Step 2: Teach "Stay"</h3>
<p>Ask your dog to sit, then hold your open palm towards them and say "Stay." Take one step back. If they hold position, return immediately and reward. If they move, calmly return them to the starting position and try again. Gradually increase distance and duration over multiple sessions. Keep expectations realistic—a two-second stay is a great start for a beginner.</p>

<h3>Step 3: Loose-Lead Walking</h3>
<p>Walking on a loose lead is one of the most valuable skills you can teach. Start in a low-distraction environment. When your dog pulls forward, stop walking. Wait for them to look back or the lead to go slack, then resume walking and reward. Consistency is critical—every time the lead goes tight, stop. Over time, your dog will learn that pulling doesn't get them where they want to go.</p>

<h3>Step 4: "Come" (Recall)</h3>
<p>Recall can save your dog's life. Start in a secure, enclosed area. Crouch down, open your arms, and say "Come" in an enthusiastic tone. When your dog reaches you, give a high-value reward (like a small piece of chicken) and lots of praise. Never call your dog to you for something unpleasant, like a bath or nail trim, as this will undermine the command.</p>

<h3>Step 5: Consistency and Patience</h3>
<p>Short, frequent training sessions of five to ten minutes are far more effective than long sessions. End each session on a positive note with a command your dog already knows well. Every family member should use the same commands and rules to avoid confusing your pet.</p>`,
    category: "Training",
    imageSrc:
      "https://images.unsplash.com/photo-1583511655857-d19b40a7a54e?w=800&h=500&fit=crop&q=80",
    readTime: "7 min read",
  },
  {
    id: 4,
    slug: "seasonal-pet-care-nigeria",
    title: "Seasonal Pet Care Guide for Nigeria's Climate",
    excerpt:
      "Nigeria's distinct wet and dry seasons each bring unique challenges for pet owners. Learn how to keep your pet comfortable and healthy year-round.",
    content: `<h2>Understanding Nigeria's Seasons</h2>
<p>Nigeria's climate varies by region, but Abuja experiences a clear dry season (November to March) and wet season (April to October). Each season presents specific challenges for pet health and comfort, from extreme heat and Harmattan dust to heavy rainfall and increased parasite activity. Adapting your care routine to the seasons keeps your pet healthy and comfortable all year.</p>

<h3>Dry Season: November to March</h3>
<p>The dry season brings intense heat and the Harmattan—a dry, dusty wind from the Sahara. During this time, increase your pet's water intake and provide access to shade at all times. Walk dogs early morning or late evening to avoid the hottest parts of the day. The Harmattan dust can irritate eyes and respiratory systems, so wipe your pet's eyes and paws after outdoor time. Apply pet-safe paw balm to prevent cracked pads on dry, hot surfaces.</p>

<h3>Wet Season: April to October</h3>
<p>The wet season increases humidity and creates ideal conditions for fleas, ticks, and mosquitoes. Step up your parasite prevention programme during these months. Check your pet's coat daily for ticks after walks. Ensure sleeping areas are dry and well-ventilated to prevent fungal skin infections. After rain, rinse mud off your dog's paws and belly to prevent hot spots and skin irritation.</p>

<h3>Year-Round Essentials</h3>
<p>Regardless of season, maintain consistent parasite prevention, keep vaccinations up to date, and schedule regular vet check-ups every six to twelve months. Provide a balanced diet appropriate to your pet's life stage and activity level. Grooming needs may change with the seasons—more frequent brushing during the Harmattan to remove dust, and more frequent bathing during the wet season to manage mud and moisture.</p>`,
    category: "Pet Care",
    imageSrc:
      "https://images.unsplash.com/photo-1535294435445-d7249524ef2e?w=800&h=500&fit=crop&q=80",
    readTime: "5 min read",
  },
];

/* ════════════════════════════════════════════════════════════════
   KNOWLEDGE BASE
   ═══════════════════════════════════════════════════════════════ */

export type KbCategory = "Boarding" | "Grooming" | "Health" | "General";

export type KbArticle = {
  id: number;
  slug: string;
  title: string;
  excerpt: string;
  content: string;
  category: KbCategory;
  imageSrc: string;
};

export const kbCategories: KbCategory[] = [
  "Boarding",
  "Grooming",
  "Health",
  "General",
];

export const kbArticles: KbArticle[] = [
  {
    id: 1,
    slug: "what-to-expect-boarding",
    title: "What to Expect During Your Pet's Boarding Stay",
    excerpt:
      "A detailed overview of a typical day at Waggies' boarding facility, from morning routines and feeding schedules to playtime and evening wind-down.",
    content: `<h2>A Typical Day at Waggies</h2>
<p>When you board your pet with Waggies, we follow a structured daily routine designed to keep your pet comfortable, active, and content. Understanding this routine helps you feel confident about your pet's care while you're away.</p>

<h2>Morning Routine</h2>
<p>Staff arrive early to check on all boarding guests. Each pet receives a morning health check—looking for any signs of illness, changes in appetite, or abnormal behaviour. Dogs are taken out for their first walk of the day by 7:00 AM, followed by breakfast at their regular feeding time using the food you provide. Water bowls are refreshed throughout the day.</p>

<h2>Midday Activity</h2>
<p>After breakfast, dogs enjoy supervised play sessions in our secure exercise yard. Playgroups are carefully managed to match dogs by size and temperament. Cats have access to climbing structures and interactive toys in their dedicated boarding area. For pets that prefer quieter time, individual attention and gentle play are provided in their suite.</p>

<h2>Afternoon and Evening</h2>
<p>A second walk follows in the afternoon, and dinner is served according to each pet's individual schedule. As evening approaches, the environment becomes calmer. Beds are prepared with clean bedding, and lights are dimmed. For anxious pets, we offer additional comfort measures such as playing soft music and providing a worn item of your clothing if supplied during drop-off.</p>

<h2>Communication</h2>
<p>We understand you want to know how your pet is doing. Waggies provides photo and video updates during your pet's stay so you can see them settling in and enjoying their time. If any concerns arise, our team will contact you immediately using the emergency number provided during check-in.</p>`,
    category: "Boarding",
    imageSrc:
      "https://images.unsplash.com/photo-1544568100-847a948585b9?w=800&h=500&fit=crop&q=80",
  },
  {
    id: 2,
    slug: "grooming-services-explained",
    title: "Understanding Our Grooming Services",
    excerpt:
      "A clear breakdown of each grooming service offered at Waggies, what's included, how long it takes, and how to choose the right package for your pet.",
    content: `<h2>Our Grooming Philosophy</h2>
<p>At Waggies, grooming is more than cosmetic—it's an essential part of your pet's health and wellbeing. Our groomers are trained professionals who handle each pet with patience and care, ensuring a positive experience from start to finish.</p>

<h2>Bath and Brush</h2>
<p>Our most popular service includes a thorough shampoo using breed-appropriate products, conditioner application, blow-drying, and a full brush-out. We clean ears, trim nails, and express anal glands if needed. This service typically takes 1.5 to 2 hours depending on breed and coat condition.</p>

<h2>Full Groom</h2>
<p>The full groom includes everything in the bath and brush package plus a breed-specific haircut or styling. Our groomers are experienced with all common breeds and can follow your preferred style or recommend the best cut for your dog's lifestyle. This service takes 2 to 3 hours.</p>

<h2>Puppy's First Groom</h2>
<p>Designed for puppies under six months, this introductory service focuses on creating positive associations with grooming. It includes a gentle bath, light brush, nail trim, and ear clean—all delivered at a relaxed pace with plenty of treats and reassurance. Sessions are shorter (45 to 60 minutes) to match a puppy's attention span.</p>

<h2>Add-On Services</h2>
<p>We offer a range of add-ons including teeth brushing, paw pad moisturising, de-shedding treatments, flea and tick baths, and premium coat conditioning. These can be added to any grooming package. Discuss your pet's specific needs with our team when booking.</p>

<h2>Booking and Preparation</h2>
<p>Book grooming appointments at least three to five days in advance. Brush your pet at home before the appointment to remove loose fur and tangles—this makes the professional groom more efficient and comfortable for your pet. Let us know about any skin conditions, allergies, or behavioural concerns when booking.</p>`,
    category: "Grooming",
    imageSrc:
      "https://images.unsplash.com/photo-1601758124510-52d02ddb7cbd?w=800&h=500&fit=crop&q=80",
  },
  {
    id: 3,
    slug: "when-to-take-pet-vet",
    title: "When Should You Take Your Pet to the Vet?",
    excerpt:
      "Some situations clearly require immediate veterinary attention, while others can wait. This guide helps you assess symptoms and make the right call for your pet's health.",
    content: `<h2>Emergency Situations</h2>
<p>Certain symptoms always warrant an immediate trip to the vet. If your pet experiences any of the following, don't wait—seek emergency care right away: difficulty breathing, prolonged seizures, collapse or unconsciousness, severe bleeding that doesn't stop with pressure, suspected poisoning (chocolate, rat bait, human medications), obvious broken bones, or a swollen, painful abdomen. These are true emergencies where minutes can matter.</p>

<h2>Urgent but Not Emergency</h2>
<p>Some situations require a same-day vet visit but aren't immediately life-threatening. These include vomiting or diarrhoea lasting more than 24 hours (especially in puppies or kittens), a sudden refusal to eat or drink, limping that doesn't improve within a few hours, eye injuries or excessive discharge, ear infections with head shaking and odour, and minor cuts that may need stitches. Call your vet to explain the situation and they will advise you on timing.</p>

<h2>Signs to Monitor</h2>
<p>Not every symptom means a vet visit is needed immediately, but you should monitor closely. These include mild lethargy lasting less than 24 hours, a single episode of vomiting (with no other symptoms), slight decrease in appetite, and occasional sneezing. If any of these persist beyond 24 hours or worsen, schedule a visit.</p>

<h2>Regular Check-Ups</h2>
<p>Preventive care is just as important as treating illness. Adult pets should see the vet at least once a year for a wellness check, with senior pets (dogs over seven years, cats over ten) benefiting from twice-yearly visits. These appointments catch problems early when they're easier and less expensive to treat.</p>

<h2>Waggies On-Site Vet Care</h2>
<p>Waggies has veterinary support available on-site. If your pet is boarding with us and shows any signs of illness, our team will consult with our vet immediately and contact you with a recommended course of action. We never wait when your pet's health is concerned.</p>`,
    category: "Health",
    imageSrc:
      "https://images.unsplash.com/photo-1573865526739-10659fec78a5?w=800&h=500&fit=crop&q=80",
  },
  {
    id: 4,
    slug: "pet-transport-what-to-know",
    title: "Pet Transport: What You Need to Know",
    excerpt:
      "Whether you're moving across Abuja or booking door-to-door service, here's what to expect from professional pet transport and how to prepare your pet for the journey.",
    content: `<h2>How Pet Transport Works</h2>
<p>Waggies provides professional pet transport services across Abuja and surrounding areas. Our transport team uses climate-controlled vehicles equipped with secure, size-appropriate carriers. Whether you need a one-way trip to our facility or door-to-door service between locations, we ensure your pet travels safely and comfortably.</p>

<h2>Before the Journey</h2>
<p>Feed your pet a light meal two to three hours before transport—avoid feeding right before travel to prevent motion sickness. Ensure your pet has had an opportunity to relieve themselves. For dogs, a short walk before pickup helps them settle. Bring any medications your pet needs during transit, clearly labelled with dosage instructions.</p>

<h2>During Transport</h2>
<p>Pets travel in secure carriers within our vehicles. Our drivers are trained to drive smoothly and avoid sudden stops. For anxious travellers, we can provide a familiar-smelling item (like a worn t-shirt) in the carrier. The vehicle is climate-controlled to maintain a comfortable temperature regardless of Abuja's weather conditions.</p>

<h2>Special Requirements</h2>
<p>Brachycephalic breeds (such as Bulldogs and Pugs) require extra care during transport due to their breathing difficulties. Puppies and kittens under four months, and very elderly pets, may need additional monitoring. Inform us of any health conditions, anxiety issues, or special needs when booking so we can make appropriate arrangements.</p>

<h2>Booking Transport</h2>
<p>Book pet transport at least 24 to 48 hours in advance. Provide your pickup and drop-off addresses, your pet's breed and size, and any special requirements. We will confirm the time window and send you a driver's contact information on the day of transport. You will receive updates when your pet is picked up and when they arrive safely at their destination.</p>`,
    category: "General",
    imageSrc:
      "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=800&h=500&fit=crop&q=80",
  },
];