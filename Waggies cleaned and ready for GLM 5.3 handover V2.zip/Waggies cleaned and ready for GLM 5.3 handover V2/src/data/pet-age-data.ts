/**
 * Pet age conversion data.
 *
 * Standard conversion tables for dogs and cats.
 * Dog conversions vary by size category.
 */

export type DogSize = "small" | "medium" | "large" | "giant";

export const DOG_SIZES: { id: DogSize; label: string; description: string }[] = [
  { id: "small", label: "Small", description: "Under 10 kg (e.g. Chihuahua, Pug)" },
  { id: "medium", label: "Medium", description: "10-25 kg (e.g. Beagle, Corgi)" },
  { id: "large", label: "Large", description: "25-45 kg (e.g. Golden Retriever)" },
  { id: "giant", label: "Giant", description: "Over 45 kg (e.g. Great Dane, Mastiff)" },
];

/**
 * Dog age conversion table.
 * Key = dog age in years. Value = equivalent human age.
 * Dogs age faster in the first two years, then the rate depends on size.
 */
export const DOG_AGE_TABLE: Record<DogSize, Record<number, number>> = {
  small: {
    0: 0,
    1: 15,
    2: 24,
    3: 28,
    4: 32,
    5: 36,
    6: 40,
    7: 44,
    8: 48,
    9: 52,
    10: 56,
    11: 60,
    12: 64,
    13: 68,
    14: 72,
    15: 76,
    16: 80,
    17: 84,
    18: 88,
    19: 92,
    20: 96,
  },
  medium: {
    0: 0,
    1: 15,
    2: 24,
    3: 28,
    4: 32,
    5: 36,
    6: 42,
    7: 47,
    8: 51,
    9: 56,
    10: 60,
    11: 65,
    12: 69,
    13: 74,
    14: 78,
    15: 83,
    16: 87,
  },
  large: {
    0: 0,
    1: 15,
    2: 24,
    3: 28,
    4: 32,
    5: 36,
    6: 45,
    7: 50,
    8: 55,
    9: 61,
    10: 66,
    11: 72,
    12: 77,
    13: 82,
    14: 88,
    15: 93,
  },
  giant: {
    0: 0,
    1: 15,
    2: 24,
    3: 28,
    4: 32,
    5: 36,
    6: 49,
    7: 56,
    8: 64,
    9: 71,
    10: 78,
    11: 86,
    12: 93,
  },
};

/**
 * Cat age conversion table.
 * Key = cat age in years. Value = equivalent human age.
 */
export const CAT_AGE_TABLE: Record<number, number> = {
  0: 0,
  1: 15,
  2: 24,
  3: 28,
  4: 32,
  5: 36,
  6: 40,
  7: 44,
  8: 48,
  9: 52,
  10: 56,
  11: 60,
  12: 64,
  13: 68,
  14: 72,
  15: 76,
  16: 80,
  17: 84,
  18: 88,
  19: 92,
  20: 96,
  21: 100,
  22: 104,
  23: 108,
  24: 112,
  25: 116,
};

/**
 * Calculate dog equivalent human age using linear interpolation between table entries.
 */
export function calculateDogAge(
  years: number,
  months: number,
  size: DogSize,
): number {
  const table = DOG_AGE_TABLE[size];
  const totalYears = years + months / 12;
  const lowerYear = Math.floor(totalYears);
  const upperYear = Math.ceil(totalYears);

  // Clamp to table bounds
  const maxAge = Math.max(...Object.keys(table).map(Number));
  const clampedTotal = Math.min(totalYears, maxAge);
  const clampedLower = Math.floor(clampedTotal);
  const clampedUpper = Math.ceil(clampedTotal);

  if (clampedLower === clampedUpper || clampedUpper > maxAge) {
    return table[clampedLower] ?? table[maxAge];
  }

  const lowerAge = table[clampedLower] ?? 0;
  const upperAge = table[clampedUpper] ?? lowerAge;
  const fraction = clampedTotal - clampedLower;

  return Math.round(lowerAge + (upperAge - lowerAge) * fraction);
}

/**
 * Calculate cat equivalent human age using linear interpolation.
 */
export function calculateCatAge(years: number, months: number): number {
  const totalYears = years + months / 12;
  const maxAge = Math.max(...Object.keys(CAT_AGE_TABLE).map(Number));
  const clampedTotal = Math.min(totalYears, maxAge);
  const lower = Math.floor(clampedTotal);
  const upper = Math.ceil(clampedTotal);

  if (lower === upper || upper > maxAge) {
    return CAT_AGE_TABLE[lower] ?? CAT_AGE_TABLE[maxAge];
  }

  const lowerAge = CAT_AGE_TABLE[lower] ?? 0;
  const upperAge = CAT_AGE_TABLE[upper] ?? lowerAge;
  const fraction = clampedTotal - lower;

  return Math.round(lowerAge + (upperAge - lowerAge) * fraction);
}

/**
 * Fun comparison messages based on human-equivalent age.
 */
export function getAgeFunFact(humanAge: number, petType: "dog" | "cat"): string {
  if (humanAge === 0) return "Your pet is just a baby!";
  if (humanAge <= 3) return "Your pet is a toddler in human years.";
  if (humanAge <= 12) return `Your ${petType} is in their childhood years.`;
  if (humanAge <= 19) return `Your ${petType} is a teenager in human years.`;
  if (humanAge <= 30) return `Your ${petType} is a young adult.`;
  if (humanAge <= 50) return `Your ${petType} is in their middle-aged years.`;
  if (humanAge <= 70) return `Your ${petType} is a senior — give them extra love and comfort!`;
  return `Your ${petType} is a true elder. Cherish every moment together!`;
}

/**
 * Get life stage description.
 */
export function getLifeStage(humanAge: number): {
  stage: string;
  color: string;
} {
  if (humanAge === 0) return { stage: "Newborn", color: "bg-pink-100 text-pink-800" };
  if (humanAge <= 12) return { stage: "Puppy/Kitten", color: "bg-amber-100 text-amber-800" };
  if (humanAge <= 30) return { stage: "Adult", color: "bg-green-100 text-green-800" };
  if (humanAge <= 60) return { stage: "Mature", color: "bg-primary/10 text-primary" };
  return { stage: "Senior", color: "bg-orange-100 text-orange-800" };
}
