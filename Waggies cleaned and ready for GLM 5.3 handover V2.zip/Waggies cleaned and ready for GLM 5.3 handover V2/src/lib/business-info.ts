/**
 * CANONICAL BUSINESS INFORMATION
 *
 * This is the single authoritative source for all Waggies business facts.
 * Every page and component must consume these values.
 *
 * Values explicitly provided by the product owner (Stage 4).
 * If any other source conflicts, THESE values win.
 */

export const businessInfo = {
  /** Business legal name */
  name: "Waggies" as const,

  /** Full address */
  address: {
    street: "Life Camp, Efab City Estate, 65 1st Ave",
    city: "Abuja",
    postalCode: "900108",
    state: "Federal Capital Territory",
    country: "Nigeria",
  },

  /** Formatted single-line address for display */
  get addressFormatted() {
    const { street, city, postalCode, state, country } = this.address;
    return `${street}, ${city} ${postalCode}, ${state}, ${country}`;
  },

  /** Short address for cards/footers */
  get addressShort() {
    return "Efab City Estate, Life Camp, Abuja";
  },

  /** Primary phone - local display format */
  phoneLocal: "0908 081 1902" as const,

  /** Primary phone - international / tel: / WhatsApp canonical */
  phoneInternational: "+234 908 081 1902" as const,

  /** Phone as href for tel: links (no spaces, no parens) */
  get phoneHref() {
    return `tel:${this.phoneInternational.replace(/[^+0-9]/g, "")}`;
  },

  /** WhatsApp number (digits only, no +) */
  get whatsappDigits() {
    return "2349080811902";
  },

  /** WhatsApp URL */
  get whatsappUrl() {
    return `https://wa.me/${this.whatsappDigits}`;
  },

  /** Email */
  email: "hello@waggies.ng" as const,

  /** Operating hours by day */
  hours: [
    { day: "Monday",    open: "9:00 AM", close: "5:00 PM" },
    { day: "Tuesday",   open: "9:00 AM", close: "5:00 PM" },
    { day: "Wednesday", open: "9:00 AM", close: "5:00 PM" },
    { day: "Thursday",  open: "9:00 AM", close: "5:00 PM" },
    { day: "Friday",    open: "9:00 AM", close: "5:00 PM" },
    { day: "Saturday",  open: "10:00 AM", close: "2:00 PM" },
    { day: "Sunday",    open: "10:00 AM", close: "2:00 PM" },
  ] as const,

  /** Hours formatted for footer (grouped) */
  get hoursGrouped() {
    return [
      { day: "Mon - Fri", hours: "9:00 AM - 5:00 PM" },
      { day: "Saturday", hours: "10:00 AM - 2:00 PM" },
      { day: "Sunday", hours: "10:00 AM - 2:00 PM" },
    ];
  },

  /** Hours formatted as single-line string */
  get hoursString() {
    return "Mon-Fri: 9am-5pm, Sat-Sun: 10am-2pm";
  },

  /** Social media links */
  socials: {
    instagram: "https://instagram.com/waggies",
    facebook: "https://facebook.com/waggies",
    x: "https://x.com/waggies",
    linkedin: "https://linkedin.com/company/waggies",
    tiktok: "https://tiktok.com/@waggies",
    youtube: "https://youtube.com/@waggies",
  } as const,
} as const;
