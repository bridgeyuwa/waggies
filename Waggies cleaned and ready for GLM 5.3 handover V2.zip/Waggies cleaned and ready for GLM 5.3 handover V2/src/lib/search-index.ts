/**
 * Server-side global search index.
 *
 * Pulls every searchable content type into a flat `SearchResultItem[]`:
 *   - Static pages (Home, Services, FAQ, About, Contact, etc.)
 *   - Service index cards (services.ts -> servicesIndexCards)
 *   - FAQs (faqs.ts -> getGroupedFaqs(), flattened into individual entries)
 */

import { servicesIndexCards } from "@/data/services";
import { getGroupedFaqs } from "@/data/faqs";
import { allTools } from "@/data/tools-data";

export type SearchResultType =
  | "service"
  | "faq"
  | "page";

export type SearchResultItem = {
  id: string;
  type: SearchResultType;
  title: string;
  description?: string;
  href: string;
  category?: string;
  icon: string;
  keywords?: string;
};

const STATIC_PAGES: SearchResultItem[] = [
  {
    id: "page-home",
    type: "page",
    title: "Home",
    description: "Waggies - pet boarding, grooming, vet care, training, relocation and local transport in Abuja.",
    href: "/",
    category: "Page",
    icon: "home",
    keywords: "home waggies landing page start main",
  },
  {
    id: "page-services",
    type: "page",
    title: "Services",
    description: "Browse every Waggies service - boarding, grooming, vet care, training, relocation and local transport.",
    href: "/services",
    category: "Page",
    icon: "grid_view",
    keywords: "services overview menu list all",
  },
  {
    id: "page-faq",
    type: "page",
    title: "FAQ",
    description: "Quick answers to the questions we hear most about Waggies services.",
    href: "/faq",
    category: "Page",
    icon: "help",
    keywords: "faq frequently asked questions help support",
  },
  {
    id: "page-about",
    type: "page",
    title: "About",
    description: "Learn about Waggies - our team, our standards, and our story.",
    href: "/about",
    category: "Page",
    icon: "info",
    keywords: "about team story company mission",
  },
  {
    id: "page-contact",
    type: "page",
    title: "Contact",
    description: "Book an appointment, request a quote, or send us a message.",
    href: "/contact",
    category: "Page",
    icon: "mail",
    keywords: "contact book appointment quote message email phone",
  },
  {
    id: "page-loyalty",
    type: "page",
    title: "Loyalty Programme",
    description: "Earn Waggies points on every booking and redeem them for discounts and perks.",
    href: "/loyalty",
    category: "Page",
    icon: "card_membership",
    keywords: "loyalty rewards points programme perks membership",
  },
  {
    id: "page-relocation",
    type: "page",
    title: "Pet Relocation",
    description: "International pet moves with full documentation, permits, and airline coordination.",
    href: "/relocation",
    category: "Page",
    icon: "flight_takeoff",
    keywords: "relocation moving export import travel international pet move",
  },
  {
    id: "page-tools",
    type: "page",
    title: "Pet Care Tools",
    description: "Free pet care tools: symptom checker, age calculator, nutrition calculator, emergency guide, breed finder, and more.",
    href: "/tools",
    category: "Page",
    icon: "stethoscope",
    keywords: "tools calculator checker guide schedule pet care free",
  },
];

export function buildSearchIndex(): SearchResultItem[] {
  const items: SearchResultItem[] = [];

  items.push(...STATIC_PAGES);

  // Tool pages
  for (const tool of allTools) {
    items.push({
      id: `tool-${tool.route}`,
      type: "page" as const,
      title: tool.name,
      description: tool.description,
      href: tool.route,
      category: "Tool",
      icon: tool.icon,
      keywords: `${tool.name} ${tool.description} tool calculator guide`.toLowerCase(),
    });
  }

  for (const card of servicesIndexCards) {
    items.push({
      id: `service-${card.href}`,
      type: "service",
      title: card.title,
      description: card.description,
      href: card.href,
      category: "Service",
      icon: card.icon,
      keywords: `${card.title} ${card.description} service`.toLowerCase(),
    });
  }

  const { grouped, categories } = getGroupedFaqs();
  for (const cat of categories) {
    const faqs = grouped[cat.slug] ?? [];
    for (const faq of faqs) {
      items.push({
        id: `faq-${faq.id}`,
        type: "faq",
        title: faq.question,
        description: faq.answer,
        href: "/faq",
        category: cat.label,
        icon: "help_outline",
        keywords: `${faq.question} ${faq.answer} ${cat.label} faq`.toLowerCase(),
      });
    }
  }

  return items;
}

export function buildPopularItems(): SearchResultItem[] {
  const index = buildSearchIndex();
  const services = index.filter((item) => item.type === "service").slice(0, 4);
  const contact = index.find((item) => item.id === "page-contact");
  const faq = index.find((item) => item.id === "page-faq");
  return [
    ...services,
    ...(faq ? [faq] : []),
    ...(contact ? [contact] : []),
  ].slice(0, 8);
}

export function scoreItem(item: SearchResultItem, q: string): number | null {
  const title = item.title.toLowerCase();
  const keywords = (item.keywords ?? "").toLowerCase();
  const description = (item.description ?? "").toLowerCase();

  if (title.startsWith(q)) {
    return 100 + Math.max(0, 20 - title.length);
  }

  if (title.includes(q)) {
    return 60 + Math.max(0, 10 - title.length);
  }

  if (keywords.includes(q) || description.includes(q)) {
    return 20;
  }

  return null;
}

export function searchIndex(
  q: string,
  limit = 8,
): { results: Array<SearchResultItem & { score: number }>; total: number } {
  const query = q.trim().toLowerCase();

  if (query.length === 0) {
    return { results: [], total: 0 };
  }

  const index = buildSearchIndex();
  const scored: Array<SearchResultItem & { score: number }> = [];

  for (const item of index) {
    const score = scoreItem(item, query);
    if (score !== null) {
      scored.push({ ...item, score });
    }
  }

  scored.sort((a, b) => {
    if (b.score !== a.score) return b.score - a.score;
    return a.title.length - b.title.length;
  });

  return {
    results: scored.slice(0, limit),
    total: scored.length,
  };
}
