export type PetType = "dog" | "cat" | "bird" | "exotic";
export type PetSize = "small" | "medium" | "large";

export type CostItem = {
  id: string;
  label: string;
  icon: string; // Phosphor icon name
  baseCost: number; // Monthly cost in NGN
  sizeMultiplier?: Record<PetSize, number>;
  petTypes?: PetType[]; // If omitted, applies to all types
  description?: string;
  category: "essential" | "recommended" | "optional";
};

export type PetTypeConfig = {
  label: string;
  icon: string;
  emoji: string;
  sizes: PetSize[];
  sizeLabels: Record<PetSize, string>;
};

/* ───────── Pet type configuration ───────── */

export const PET_TYPES: Record<PetType, PetTypeConfig> = {
  dog: {
    label: "Dog",
    icon: "pets",
    emoji: "🐕",
    sizes: ["small", "medium", "large"],
    sizeLabels: {
      small: "Small (0-10kg)",
      medium: "Medium (10-25kg)",
      large: "Large (25kg+)",
    },
  },
  cat: {
    label: "Cat",
    icon: "cat",
    emoji: "🐈",
    sizes: ["small", "medium"],
    sizeLabels: {
      small: "Small (0-4kg)",
      medium: "Medium (4kg+)",
      large: "",
    },
  },
  bird: {
    label: "Bird",
    icon: "flutter_dash",
    emoji: "🦜",
    sizes: ["small"],
    sizeLabels: {
      small: "All sizes",
      medium: "",
      large: "",
    },
  },
  exotic: {
    label: "Exotic Pet",
    icon: "cruelty_free",
    emoji: "🦎",
    sizes: ["small"],
    sizeLabels: {
      small: "All sizes",
      medium: "",
      large: "",
    },
  },
};

/* ───────── Cost items ───────── */

export const COST_ITEMS: CostItem[] = [
  /* ── Essential (pre-selected, cannot deselect) ── */
  {
    id: "food",
    label: "Food & Treats",
    icon: "restaurant",
    baseCost: 8000,
    sizeMultiplier: { small: 0.6, medium: 1, large: 1.8 },
    petTypes: ["dog", "cat"],
    category: "essential",
  },
  {
    id: "food-bird",
    label: "Bird Seed & Supplements",
    icon: "restaurant",
    baseCost: 3000,
    petTypes: ["bird"],
    category: "essential",
  },
  {
    id: "food-exotic",
    label: "Specialist Diet",
    icon: "restaurant",
    baseCost: 5000,
    petTypes: ["exotic"],
    category: "essential",
  },
  {
    id: "vet-routine",
    label: "Routine Vet Visits",
    icon: "medical_services",
    baseCost: 2500,
    sizeMultiplier: { small: 0.8, medium: 1, large: 1.3 },
    description: "Annual checkup + minor consults (averaged monthly)",
    category: "essential",
  },
  {
    id: "grooming-basic",
    label: "Basic Grooming",
    icon: "content_cut",
    baseCost: 3000,
    petTypes: ["dog", "cat"],
    description: "Nail trimming, ear cleaning, basic wash",
    category: "essential",
  },

  /* ── Recommended (pre-selected, can toggle) ── */
  {
    id: "vaccination",
    label: "Vaccinations",
    icon: "vaccines",
    baseCost: 1500,
    description: "Annual booster + puppy/kitten series (averaged monthly)",
    category: "recommended",
  },
  {
    id: "parasite-control",
    label: "Flea & Tick Prevention",
    icon: "pest_control",
    baseCost: 2000,
    sizeMultiplier: { small: 0.7, medium: 1, large: 1.4 },
    category: "recommended",
  },
  {
    id: "grooming-pro",
    label: "Professional Grooming",
    icon: "spa",
    baseCost: 8000,
    petTypes: ["dog", "cat"],
    description: "Full bath, haircut, styling",
    sizeMultiplier: { small: 0.7, medium: 1, large: 1.5 },
    category: "recommended",
  },
  {
    id: "boarding",
    label: "Boarding (when you travel)",
    icon: "hotel",
    baseCost: 15000,
    petTypes: ["dog", "cat"],
    description: "Per stay (7 nights avg), divided over 12 months",
    category: "recommended",
    // Boarding is per-stay; divide by 12 for monthly average  -  handled in getCost
  },
  {
    id: "training",
    label: "Training Classes",
    icon: "school",
    baseCost: 10000,
    petTypes: ["dog"],
    description: "Group classes, 4 sessions/month",
    category: "recommended",
  },

  /* ── Optional (off by default, can toggle) ── */
  {
    id: "pet-insurance",
    label: "Pet Insurance",
    icon: "shield",
    baseCost: 5000,
    description: "Covers accidents & illness",
    category: "optional",
  },
  {
    id: "transport",
    label: "Pet Transport",
    icon: "local_shipping",
    baseCost: 3500,
    description: "Average monthly cost if used regularly",
    category: "optional",
  },
  {
    id: "accessories",
    label: "Toys & Accessories",
    icon: "toys",
    baseCost: 2000,
    sizeMultiplier: { small: 0.6, medium: 1, large: 1.3 },
    category: "optional",
  },
  {
    id: "dental",
    label: "Dental Care",
    icon: "dentistry",
    baseCost: 3000,
    description: "Annual cleaning (averaged monthly)",
    category: "optional",
  },
  {
    id: "walking",
    label: "Dog Walking Service",
    icon: "directions_walk",
    baseCost: 15000,
    petTypes: ["dog"],
    description: "5 walks/week",
    category: "optional",
  },
];

/* ───────── Helpers ───────── */

/**
 * Compute the monthly cost for a single item given pet type and size.
 */
export function getItemCost(
  item: CostItem,
  petType: PetType,
  petSize: PetSize,
): number {
  let cost = item.baseCost;

  // Boarding is per-stay; spread over 12 months
  if (item.id === "boarding") {
    cost = Math.round(item.baseCost / 12);
  }

  // Apply size multiplier if defined
  if (item.sizeMultiplier && petSize in item.sizeMultiplier) {
    cost = Math.round(cost * item.sizeMultiplier[petSize]);
  }

  return cost;
}

/**
 * Filter cost items that apply to a given pet type.
 */
export function getItemsForPetType(petType: PetType): CostItem[] {
  return COST_ITEMS.filter(
    (item) => !item.petTypes || item.petTypes.includes(petType),
  );
}

/**
 * Format a number as Nigerian Naira string: ₦X,XXX
 */
export function formatNaira(value: number): string {
  return `₦${value.toLocaleString()}`;
}
