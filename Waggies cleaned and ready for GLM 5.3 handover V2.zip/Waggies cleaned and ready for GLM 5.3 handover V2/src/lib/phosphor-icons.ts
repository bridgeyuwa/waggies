import React from "react";
import type { IconWeight } from "@phosphor-icons/react";
import {
  // Navigation & Services
  Info,
  Article,
  BookOpen,
  BookBookmark,
  ChatCircleText,
  Images,
  Briefcase,
  Handshake,
  Stethoscope,
  PawPrint,
  Syringe,
  Calculator,
  Pill,
  ForkKnife,
  WarningCircle,
  ClipboardText,
  BugBeetle,
  Brain,
  MagnifyingGlass,
  Question,
  HouseLine,
  Dog,
  Cat,
  Bug,
  Scissors,
  Heartbeat,
  GraduationCap,
  AirplaneTilt,
  AirplaneLanding,
  AirplaneTakeoff,
  Truck,
  // Material Symbol → Phosphor equivalents (homepage & services pages)
  ShieldCheck,
  ClockCountdown,
  Building,
  Camera,
  Star,
  ArrowRight,
  Clock,
  CaretDown,
  Phone,
} from "@phosphor-icons/react/dist/ssr";

/**
 * Shared Phosphor icon lookup.
 *
 * Keys include both kebab-case Phosphor names (used in site.tsx menu data)
 * and Material Symbol names (mapped to Phosphor equivalents for page content).
 * Falls back to a generic Question icon for unknown names.
 */
const PHOSPHOR_ICONS: Record<string, React.ComponentType<{ size?: number; weight?: IconWeight; className?: string }>> = {
  // Services (nav menu data)
  "house-line": HouseLine,
  dog: Dog,
  cat: Cat,
  bug: Bug,
  scissors: Scissors,
  heartbeat: Heartbeat,
  "graduation-cap": GraduationCap,
  "airplane-tilt": AirplaneTilt,
  "airplane-landing": AirplaneLanding,
  "airplane-takeoff": AirplaneTakeoff,
  truck: Truck,

  // About (nav menu data)
  info: Info,
  "chat-circle-text": ChatCircleText,
  images: Images,
  briefcase: Briefcase,
  handshake: Handshake,

  // Resources (nav menu data)
  question: Question,
  article: Article,
  "book-open": BookOpen,
  "book-bookmark": BookBookmark,

  // Tools (nav menu data)
  stethoscope: Stethoscope,
  "paw-print": PawPrint,
  syringe: Syringe,
  calculator: Calculator,
  pill: Pill,
  "fork-knife": ForkKnife,
  "warning-circle": WarningCircle,
  "clipboard-text": ClipboardText,
  "bug-beetle": BugBeetle,
  brain: Brain,
  "magnifying-glass": MagnifyingGlass,

  // Material Symbol → Phosphor mappings (homepage & services pages)
  verified: ShieldCheck,
  "medical_services": Stethoscope,
  "lock_clock": ClockCountdown,
  hotel: Building,
  apartment: Building,
  "photo_camera": Camera,
  star: Star,
  "arrow_forward": ArrowRight,
  schedule: Clock,
  pets: PawPrint,
  "expand_more": CaretDown,
  call: Phone,
  school: GraduationCap,
  spa: Scissors,
  "flight_takeoff": AirplaneTakeoff,
  "local_shipping": Truck,
};

/**
 * Render a Phosphor icon by name.
 *
 * Uses React.createElement to avoid the react-hooks/static-components lint
 * rule that flags assigning dynamically-looked-up components to variables
 * during render.
 */
export function PhosphorIcon({
  name,
  size = 20,
  weight = "regular",
  className,
}: {
  name: string;
  size?: number;
  weight?: IconWeight;
  className?: string;
}) {
  const Comp = PHOSPHOR_ICONS[name] ?? Question;
  return React.createElement(Comp, { size, weight, className } as Record<string, unknown>);
}
