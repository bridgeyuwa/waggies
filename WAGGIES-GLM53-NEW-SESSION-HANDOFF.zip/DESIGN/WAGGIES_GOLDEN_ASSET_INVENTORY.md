# Waggies Golden Reference — Asset Inventory

> Last updated: Phase 8–9 imagery audit
> All image slots verified: no empty `src` fields remain.

---

## Temporary Stock Images

All images currently sourced from Unsplash. Each should be replaced with authentic Waggies photography when available.

### Homepage (`src/data/home.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| Hero image | `homeHero.imageSrc` | `photo-1587300003388` (dog with owner outdoors) | Waggies facility hero photo |
| Boarding card | `homeServiceCards[0].imageSrc` | `photo-1544568100-847a948585b9` (happy dog) | Waggies boarding suite/guest photo |
| Grooming card | `homeServiceCards[1].imageSrc` | `photo-1516734212186-a967f81ad0d7` (cat grooming) | Waggies grooming session photo |
| Vet Care card | `homeServiceCards[2].imageSrc` | `photo-1514888286974-6c03e2ca1dba` (orange tabby) | Waggies vet consultation photo |
| Training card | `homeServiceCards[3].imageSrc` | `photo-1583511655857-d19b40a7a54e` (focused dog) | Waggies training session photo |
| Relocation card | `homeServiceCards[4].imageSrc` | `photo-1436491865332-7a61a109cc05` (dog with backpack) | Waggies relocation/travel photo |
| Transport card | `homeServiceCards[5].imageSrc` | `photo-1601758228041-f3b2795255f1` (dog in car) | Waggies transport vehicle photo |

### Services Index (`src/data/services.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| Services hero | `servicesIndexHero.imageSrc` | `photo-1548199973-03d0b4fb1f8` (dog outdoors) | Waggies facility hero photo |
| Boarding card | `servicesIndexCards[0].imageSrc` | `photo-1596492784531-6e6eb5ea9993` (dog running) | Waggies boarding photo |
| Grooming card | `servicesIndexCards[1].imageSrc` | `photo-1516734212186-a967f81ad0d7` (cat grooming) | Waggies grooming photo |
| Vet Care card | `servicesIndexCards[2].imageSrc` | `photo-1628009368231-7bb7cfcb0def` (vet with dog) | Waggies vet care photo |
| Training card | `servicesIndexCards[3].imageSrc` | `photo-1583511655857-d19b40a7a54e` (focused dog) | Waggies training photo |
| Transport card | `servicesIndexCards[4].imageSrc` | `photo-1586671267731-da2cf3ceeb80` (pet travel) | Waggies transport vehicle photo |
| Relocation card | `servicesIndexCards[5].imageSrc` | `photo-1450778869180-e12d25b46b48` (airplane) | Waggies relocation photo |

### Boarding Page (`src/data/services.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| Boarding hero | `boardingIndexHero.imageSrc` | `photo-1601758228041-f3b2795255f1` (dog in car) | Waggies boarding facility hero photo |
| Dog Boarding card | `boardingIndexCards[0].imageSrc` | `photo-1552053831-71594a27632d` (golden retriever) | Waggies dog boarding suite photo |
| Cat Boarding card | `boardingIndexCards[1].imageSrc` | `photo-1573864708626-c43d2d6f7a11` (cat) | Waggies cat condo photo |
| Exotic Boarding card | `boardingIndexCards[2].imageSrc` | `photo-1437409368301-e2d6e673f6fb` (rabbit) | Waggies exotic pet enclosure photo |
| Safe Space card | `boardingSafeSpaceCard.imageSrc` | `photo-1583511655857-d19b40a7a54e` (puppy) | Waggies supervised play area photo |

### Grooming Page (`src/data/services.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| Grooming hero | `groomingHero.imageSrc` | `photo-1516734212186-a967f81ad0d7` (cat grooming) | Waggies grooming spa hero photo |

### Vet Care Page (`src/data/services.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| Vet Care hero | `vetCareHero.imageSrc` | `photo-1628009368231-7bb7cfcb0def` (vet with dog) | Waggies vet clinic hero photo |

### Training Page (`src/data/services.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| Training hero | `trainingHero.imageSrc` | `photo-1517849845537-4d257902454a` (cute dog) | Waggies training session hero photo |

### Transport Page (`src/data/services.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| Transport hero | `transportHero.imageSrc` | `photo-1606567595334-d39972c85dbe` (pet travel) | Waggies transport vehicle hero photo |

### Relocation Pages (`src/data/relocation.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| Relocation index hero | `relocationIndexHero.imageSrc` | `photo-1436491865332-7a61a109cc05` (dog with backpack) | Waggies relocation hero photo |
| Import card | `relocationIndexCards[0].imageSrc` | `photo-1606567595334-d39972c85dbe` (pet travel) | Waggies import arrival photo |
| Export card | `relocationIndexCards[1].imageSrc` | `photo-1601758228041-f3b2795255f1` (dog in car) | Waggies export departure photo |
| Transport card | `relocationIndexCards[2].imageSrc` | `photo-1606567595334-d39972c85dbe` (pet travel) | Waggies transport vehicle photo |
| Checklist card | `relocationIndexCards[3].imageSrc` | `photo-1558618666-fcd25c85f82e` (documents) | Waggies documentation/relocation photo |
| Import hero | `relocationImportHero.imageSrc` | `photo-1606567595334-d39972c85dbe` (pet travel) | Waggies import service photo |
| Export hero | `relocationExportHero.imageSrc` | `photo-1552053831-71594a27632d` (golden retriever) | Waggies export service photo |
| FAQ hero | `heroHubPresets.faq.image` | `photo-1601758228041-f3b2795255f1` (dog in car) | Waggies FAQ/help hero photo |
| Checklist hero | `heroHubPresets.checklist.image` | `photo-1548199973-03d0b4fb1f8` (dog outdoors) | Waggies checklist hero photo |

### About Page (`src/data/about.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| About hero | `aboutHero.imageSrc` | `photo-1559839734-2b71ea197ec2` (dog at vet) | Waggies facility hero photo |
| Mosaic image 1 | `aboutMosaicImages[0].src` | `photo-1628009368231-7bb7cfcb0def` (vet examining dog) | Waggies clinic interior photo |
| Mosaic image 2 | `aboutMosaicImages[1].src` | `photo-1516734212186-a967f81ad0d7` (dog grooming) | Waggies grooming session photo |

### Team Portraits (`src/data/team.ts`)

| Slot | Field | Current Unsplash URL | Replace With |
|------|-------|---------------------|--------------|
| Dr. Nguhemen Doose Yuwa | `teamMembers[0].imageSrc` | `photo-1507003211169-0a1dd7228f2d` (male portrait) | Real portrait photo of Dr. Yuwa |
| Aifuwa Bob Osaze | `teamMembers[1].imageSrc` | `photo-1573496359142-b8d87734a5a2` (male portrait) | Real portrait photo of Aifuwa Bob Osaze |
| Oghomwen Oyuki Obaseki | `teamMembers[2].imageSrc` | `photo-1580489944761-15a19d654956` (female portrait) | Real portrait photo of Oghomwen Obaseki |
| Chukwuma Eze (placeholder) | `teamMembers[3].imageSrc` | `photo-1472099645785-5658abf4ff4e` (male portrait) | Real portrait when verified |
| Amina Bello (placeholder) | `teamMembers[4].imageSrc` | `photo-1594744803329-e58b31de8bf5` (female portrait) | Real portrait when verified |
| Dayo Adekunle (placeholder) | `teamMembers[5].imageSrc` | `photo-1500648767791-00dcc994a43e` (male portrait) | Real portrait when verified |
| Kemi Ogunleye (placeholder) | `teamMembers[6].imageSrc` | `photo-1560250097-0b93528c311a` (female portrait) | Real portrait when verified |

### Gallery (`src/data/gallery.ts`)

All 23 gallery images across 5 groups are Unsplash stock photos marked with `_temporary: true`.

| Group | Image Count | Replace With |
|-------|------------|--------------|
| Boarding Suites & Play Areas | 5 | Real Waggies boarding facility photos |
| Grooming Spa | 5 | Real Waggies grooming session photos |
| Veterinary Clinic | 4 | Real Waggies vet clinic photos |
| Training & Behaviour | 5 | Real Waggies training session photos |
| Pet Relocation & Transport | 4 | Real Waggies relocation/transport photos |

---

## Authentic Assets

| Location | Description | Notes |
|----------|-------------|-------|
| *(none currently)* | No authentic Waggies brand photography has been supplied yet. | All images are temporary Unsplash stock. |

---

## Components With Intentionally Absent Images

| Component | Reason |
|-----------|--------|
| Testimonial cards (homepage, boarding, relocation) | Use authorInitial letter avatar instead of portrait photos. No image slot exists. |
| Feature/stat bands (all pages) | Icon-driven layout — no photographic image slot by design. |
| FAQ items | Text-only accordion — no image slot. |
| Checklist items | Text-based list — no image slot. |
| Contact form page | Text + form layout — no hero image. |
| Breadcrumb strips | Navigation-only — no image. |

---

## Summary

- **Total image slots audited**: ~70
- **Empty/missing slots found and fixed**: 2 (`aboutMosaicImages[0].src` and `aboutMosaicImages[1].src` in `src/data/about.ts` were empty strings; filled with appropriate Unsplash stock photos)
- **All slots now have valid Unsplash URLs**: ✅
- **"Dr. Amara Okeke" check**: Not found anywhere in the codebase ✅
- **Team member count**: 8 (3 verified + 5 placeholder) — team is not artificially limited ✅
- **Dr. Nguhemen Doose Yuwa DVM credential**: Displayed in role field ("DVM, Head Veterinarian and Director") ✅
