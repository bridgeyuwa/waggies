# Waggies Feature Inventory

> Generated: handoff documentation for the Waggies pet care website project.
> This document catalogues every feature, its implementation status, data sources, and known limitations.

---

## Legend

| Column | Meaning |
|---|---|
| **Frontend Status** | `Complete` = rendered and functional; `Partial` = some gaps remain |
| **Backend Status** | `None` = no server-side logic/API; `Static` = data baked in at build time; `WhatsApp Fallback` = routes to WhatsApp message |
| **State/Persistence** | Where user data is stored, if any |
| **Known Limitations** | Gaps, placeholders, or missing integrations |

---

## Interactive Tools (11)

### 1. Chatbot
| Field | Value |
|---|---|
| **Route** | `/` (floating, global) |
| **Current Implementation** | Keyword-matching prototype embedded in floating-actions.tsx. Responds to pet-care keywords with pre-written answers. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | Hardcoded keyword/response map inside component |
| **State/Persistence** | None (conversation lost on page refresh) |
| **Known Limitations** | Limited response set; no NLU; no conversation memory; no escalation to human agent |
| **Relevant Components** | `src/components/waggies/floating-actions.tsx` |
| **Relevant Files** | `src/components/waggies/floating-actions.tsx` |

### 2. Symptom Checker
| Field | Value |
|---|---|
| **Route** | `/tools/symptom-checker` |
| **Current Implementation** | Interactive body-part selection → keyword-matched conditions with severity and advice. Includes MedicalDisclaimer. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | `src/data/symptom-checker-data.ts` (static) |
| **State/Persistence** | None |
| **Known Limitations** | Not a diagnosis tool; limited condition set; no logging or history |
| **Relevant Components** | `src/components/waggies/tools/symptom-checker-client.tsx`, `MedicalDisclaimer` |
| **Relevant Files** | `src/data/symptom-checker-data.ts`, `src/app/tools/symptom-checker/page.tsx` |

### 3. Pet Age Calculator
| Field | Value |
|---|---|
| **Route** | `/tools/pet-age-calculator` |
| **Current Implementation** | User inputs pet type, age, and size → converts to approximate human years. Client-side calculation. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | `src/data/pet-age-data.ts` (static conversion tables) |
| **State/Persistence** | None |
| **Known Limitations** | Approximation only; breed-specific factors not considered |
| **Relevant Components** | `src/components/waggies/tools/pet-age-calculator-client.tsx` |
| **Relevant Files** | `src/data/pet-age-data.ts`, `src/app/tools/pet-age-calculator/page.tsx` |

### 4. Vaccination Schedule
| Field | Value |
|---|---|
| **Route** | `/tools/vaccination-schedule` |
| **Current Implementation** | Displays recommended vaccine timeline by pet type and age. Includes MedicalDisclaimer. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | `src/data/vaccination-data.ts` (static) |
| **State/Persistence** | None |
| **Known Limitations** | Generalised schedules; may not reflect Nigerian-specific requirements; no PDF export |
| **Relevant Components** | `src/components/waggies/tools/vaccination-schedule-client.tsx`, `MedicalDisclaimer` |
| **Relevant Files** | `src/data/vaccination-data.ts`, `src/app/tools/vaccination-schedule/page.tsx` |

### 5. Cost Calculator
| Field | Value |
|---|---|
| **Route** | `/tools/cost-calculator` |
| **Current Implementation** | User selects services, pet type, duration → estimates total cost. Client-side data. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | `src/data/cost-calculator-data.ts` (static pricing data) |
| **State/Persistence** | None |
| **Known Limitations** | Prices are estimates only; not linked to live pricing or booking system |
| **Relevant Components** | `src/components/waggies/tools/cost-calculator-client.tsx` |
| **Relevant Files** | `src/data/cost-calculator-data.ts`, `src/app/tools/cost-calculator/page.tsx` |

### 6. Medication Dosage Guide
| Field | Value |
|---|---|
| **Route** | `/tools/medication-dosage-guide` |
| **Current Implementation** | Reference table for common pet medications with dosage ranges. Includes MedicalDisclaimer. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | Inline static data in client component |
| **State/Persistence** | None |
| **Known Limitations** | Reference only; not veterinary advice; limited drug list |
| **Relevant Components** | `src/components/waggies/tools/medication-dosage-guide-client.tsx`, `MedicalDisclaimer` |
| **Relevant Files** | `src/app/tools/medication-dosage-guide/page.tsx` |

### 7. Nutrition Calculator
| Field | Value |
|---|---|
| **Route** | `/tools/nutrition-calculator` |
| **Current Implementation** | User inputs pet weight, age, activity level → estimates daily caloric needs and feeding amounts. Includes MedicalDisclaimer. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | Client-side calculation formulas |
| **State/Persistence** | None |
| **Known Limitations** | Generalised formulas; does not account for breed, health conditions, or specific diets |
| **Relevant Components** | `src/components/waggies/tools/nutrition-calculator-client.tsx`, `MedicalDisclaimer` |
| **Relevant Files** | `src/app/tools/nutrition-calculator/page.tsx` |

### 8. Emergency & Poison Guide
| Field | Value |
|---|---|
| **Route** | `/tools/emergency-guide` |
| **Current Implementation** | Emergency care reference with common poisons, symptoms, and first-aid steps. Includes MedicalDisclaimer. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | Inline static data in client component |
| **State/Persistence** | None |
| **Known Limitations** | Not a substitute for veterinary care; limited to common emergencies |
| **Relevant Components** | `src/components/waggies/tools/emergency-guide-client.tsx`, `MedicalDisclaimer` |
| **Relevant Files** | `src/app/tools/emergency-guide/page.tsx` |

### 9. New Pet Checklist
| Field | Value |
|---|---|
| **Route** | `/tools/new-pet-checklist` |
| **Current Implementation** | Interactive checklist with categories (supplies, vet visits, home prep). Items can be checked off. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | Inline static checklist items |
| **State/Persistence** | `localStorage` (checked items persist across sessions) |
| **Known Limitations** | No sharing/printing; no pet-specific customisation |
| **Relevant Components** | `src/components/waggies/tools/new-pet-checklist-client.tsx` |
| **Relevant Files** | `src/app/tools/new-pet-checklist/page.tsx` |

### 10. Parasite Schedule
| Field | Value |
|---|---|
| **Route** | `/tools/parasite-schedule` |
| **Current Implementation** | Prevention schedule for fleas, ticks, heartworm, and intestinal parasites by pet type. Includes MedicalDisclaimer. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | Inline static data |
| **State/Persistence** | None |
| **Known Limitations** | Generalised schedule; not tailored to Nigerian climate specifics |
| **Relevant Components** | `src/components/waggies/tools/parasite-schedule-client.tsx`, `MedicalDisclaimer` |
| **Relevant Files** | `src/app/tools/parasite-schedule/page.tsx` |

### 11. Behavior Tips
| Field | Value |
|---|---|
| **Route** | `/tools/behavior-tips` |
| **Current Implementation** | Static advice content for common pet behaviour topics (barking, litter training, anxiety, etc.). |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | Inline static data |
| **State/Persistence** | None |
| **Known Limitations** | No interactive elements; content not searchable by behaviour issue |
| **Relevant Components** | `src/components/waggies/tools/behavior-tips-client.tsx` |
| **Relevant Files** | `src/app/tools/behavior-tips/page.tsx` |

### 12. Breed Finder
| Field | Value |
|---|---|
| **Route** | `/tools/breed-finder` |
| **Current Implementation** | Explore dog and cat breeds with filtering. Displays breed characteristics, temperament, and care needs. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | Inline static breed data |
| **State/Persistence** | None |
| **Known Limitations** | Limited breed list; no image assets for all breeds |
| **Relevant Components** | `src/components/waggies/tools/breed-finder-client.tsx` |
| **Relevant Files** | `src/app/tools/breed-finder/page.tsx` |

---

## E-Commerce

### 13. Shop (Product Listing)
| Field | Value |
|---|---|
| **Route** | `/shop` |
| **Current Implementation** | Grid of product cards with filtering. Static product catalogue. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | `src/data/shop-data.ts` (static) |
| **State/Persistence** | None |
| **Known Limitations** | No live inventory; no payment processing; no user accounts |
| **Relevant Components** | `src/components/waggies/shop/shop-page-client.tsx`, `product-card.tsx` |
| **Relevant Files** | `src/data/shop-data.ts`, `src/app/shop/page.tsx` |

### 14. Shop (Product Detail)
| Field | Value |
|---|---|
| **Route** | `/shop/[id]` |
| **Current Implementation** | Individual product page with description, price, add-to-cart. Dynamic route from shop-data.ts. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | `src/data/shop-data.ts` (static) |
| **State/Persistence** | None |
| **Known Limitations** | No variant selection (size/colour); no reviews; no related products algorithm |
| **Relevant Components** | `src/components/waggies/shop/product-detail-client.tsx` |
| **Relevant Files** | `src/data/shop-data.ts`, `src/app/shop/[id]/page.tsx` |

### 15. Cart
| Field | Value |
|---|---|
| **Route** | `/shop` (drawer overlay) |
| **Current Implementation** | Slide-out drawer with quantity adjustment, item removal, subtotal. Zustand store with localStorage persistence. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | `src/store/cart-store.ts` (zustand) |
| **State/Persistence** | `localStorage` via zustand persist middleware |
| **Known Limitations** | No checkout flow; no server-side cart sync; no abandoned cart recovery |
| **Relevant Components** | `src/components/waggies/shop/cart-drawer.tsx`, `cart-button.tsx` |
| **Relevant Files** | `src/store/cart-store.ts` |

### 16. Recently Viewed
| Field | Value |
|---|---|
| **Route** | `/shop` (displayed on shop pages) |
| **Current Implementation** | Tracks products the user has viewed and displays them in a horizontal row. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | Product IDs stored in localStorage |
| **State/Persistence** | `localStorage` |
| **Known Limitations** | No expiry mechanism; no cross-device sync |
| **Relevant Components** | `src/components/waggies/shop/recently-viewed.tsx` |
| **Relevant Files** | — |

---

## Booking & Contact

### 17. Booking Modal
| Field | Value |
|---|---|
| **Route** | `/contact?intent=book` (also triggered from service CTAs) |
| **Current Implementation** | Radix Dialog with form fields (pet type, service, name, phone, date, notes). On submit, composes a WhatsApp message. |
| **Frontend Status** | Complete |
| **Backend Status** | WhatsApp Fallback |
| **Data Source** | Form input only |
| **State/Persistence** | None |
| **Known Limitations** | No real booking system; no availability check; no confirmation email; no calendar integration |
| **Relevant Components** | `src/components/waggies/booking-modal.tsx` |
| **Relevant Files** | — |

### 18. WhatsApp Request (Structured Messaging)
| Field | Value |
|---|---|
| **Route** | Multiple pages (service CTAs, contact form) |
| **Current Implementation** | Contact form and booking modal compose structured WhatsApp messages with pre-filled service/user info. |
| **Frontend Status** | Partial (form exists but submission only opens WhatsApp) |
| **Backend Status** | WhatsApp Fallback |
| **Data Source** | Form input |
| **State/Persistence** | None |
| **Known Limitations** | Requires user to have WhatsApp installed; no server-side message logging; no auto-reply |
| **Relevant Components** | `src/components/waggies/contact-form.tsx`, `booking-modal.tsx` |
| **Relevant Files** | — |

### 19. Contact Page
| Field | Value |
|---|---|
| **Route** | `/contact` |
| **Current Implementation** | Location hub with embedded map, contact form (→ WhatsApp), business hours, and location details. |
| **Frontend Status** | Complete |
| **Backend Status** | WhatsApp Fallback (form) |
| **Data Source** | `src/data/about.ts`, `src/data/home.ts` |
| **State/Persistence** | None |
| **Known Limitations** | Form does not send email; map is embedded (Google Maps iframe or static) |
| **Relevant Components** | `src/components/waggies/contact-form.tsx` |
| **Relevant Files** | `src/app/contact/page.tsx` |

---

## Content & Resources

### 20. Blog
| Field | Value |
|---|---|
| **Route** | `/blog`, `/blog/[slug]` |
| **Current Implementation** | Blog listing page with article cards. Individual article pages with prose content. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/content-data.ts` |
| **State/Persistence** | None |
| **Known Limitations** | No CMS; content hardcoded; no comments; no categories/tags filtering |
| **Relevant Components** | — |
| **Relevant Files** | `src/data/content-data.ts`, `src/app/blog/page.tsx`, `src/app/blog/[slug]/page.tsx` |

### 21. Guides
| Field | Value |
|---|---|
| **Route** | `/guides`, `/guides/[slug]` |
| **Current Implementation** | Guide listing and detail pages. Structured similarly to blog but focused on how-to and reference content. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/content-data.ts` |
| **State/Persistence** | None |
| **Known Limitations** | No CMS; content hardcoded |
| **Relevant Components** | — |
| **Relevant Files** | `src/data/content-data.ts`, `src/app/guides/page.tsx`, `src/app/guides/[slug]/page.tsx` |

### 22. Knowledge Base
| Field | Value |
|---|---|
| **Route** | `/knowledge-base`, `/knowledge-base/[slug]` |
| **Current Implementation** | KB article listing and detail pages. Reference-style content. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/content-data.ts` |
| **State/Persistence** | None |
| **Known Limitations** | No CMS; content hardcoded; no search within KB |
| **Relevant Components** | — |
| **Relevant Files** | `src/data/content-data.ts`, `src/app/knowledge-base/page.tsx`, `src/app/knowledge-base/[slug]/page.tsx` |

### 23. FAQ
| Field | Value |
|---|---|
| **Route** | `/faq` |
| **Current Implementation** | Searchable FAQ page with expandable accordion items. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/faqs.ts` |
| **State/Persistence** | None |
| **Known Limitations** | No categorisation; no analytics on what users search for |
| **Relevant Components** | `src/components/waggies/tools/faq-page-client.tsx` |
| **Relevant Files** | `src/data/faqs.ts`, `src/app/faq/page.tsx` |

### 24. Testimonials
| Field | Value |
|---|---|
| **Route** | `/about/testimonials`, homepage, `/services/boarding` |
| **Current Implementation** | Carousel and card displays of client testimonials. 3-column grid on homepage, carousel on testimonials page. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/testimonials.ts` |
| **State/Persistence** | None |
| **Known Limitations** | No review submission form; no star ratings; all quotes are static |
| **Relevant Components** | `src/components/waggies/testimonials-carousel.tsx` |
| **Relevant Files** | `src/data/testimonials.ts` |

### 25. Gallery
| Field | Value |
|---|---|
| **Route** | `/about/gallery` |
| **Current Implementation** | Photo gallery with category filtering and lightbox viewer. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/gallery.ts` (23 Unsplash stock images — all temporary) |
| **State/Persistence** | None |
| **Known Limitations** | All images are Unsplash stock and need client photo replacement; see GOLDEN_ASSET_INVENTORY.md |
| **Relevant Components** | `src/components/waggies/sections/gallery-lightbox.tsx` |
| **Relevant Files** | `src/data/gallery.ts`, `src/app/about/gallery/page.tsx` |

---

## Service Pages

### 26. Boarding (Hub)
| Field | Value |
|---|---|
| **Route** | `/services/boarding` |
| **Current Implementation** | Overview page with links to dog, cat, and exotic boarding sub-pages. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/services.ts`, `src/data/home.ts` |
| **State/Persistence** | None |
| **Known Limitations** | No real-time availability |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/services/boarding/page.tsx` |

### 27. Boarding — Dogs
| Field | Value |
|---|---|
| **Route** | `/services/boarding/dogs` |
| **Current Implementation** | Dog-specific boarding service details. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/services.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/services/boarding/dogs/page.tsx` |

### 28. Boarding — Cats
| Field | Value |
|---|---|
| **Route** | `/services/boarding/cats` |
| **Current Implementation** | Cat-specific boarding service details. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/services.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/services/boarding/cats/page.tsx` |

### 29. Boarding — Exotic
| Field | Value |
|---|---|
| **Route** | `/services/boarding/exotic` |
| **Current Implementation** | Exotic pet boarding service details. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/services.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/services/boarding/exotic/page.tsx` |

### 30. Grooming
| Field | Value |
|---|---|
| **Route** | `/services/grooming` |
| **Current Implementation** | Grooming service page with services list, pricing, and CTA. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/services.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/services/grooming/page.tsx` |

### 31. Veterinary Care
| Field | Value |
|---|---|
| **Route** | `/services/vet-care` |
| **Current Implementation** | Veterinary care service page. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/services.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/services/vet-care/page.tsx` |

### 32. Training
| Field | Value |
|---|---|
| **Route** | `/services/training` |
| **Current Implementation** | Pet training service page. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/services.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/services/training/page.tsx` |

### 33. Pricing
| Field | Value |
|---|---|
| **Route** | `/services/pricing` |
| **Current Implementation** | Service pricing tiers with comparison table and package cards. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/pricing.ts` |
| **State/Persistence** | None |
| **Known Limitations** | Prices are static; no booking integration from pricing page |
| **Relevant Components** | `card-pricing.tsx`, `service-comparison-table.tsx` |
| **Relevant Files** | `src/data/pricing.ts`, `src/app/services/pricing/page.tsx` |

---

## Relocation

### 34. Relocation Hub
| Field | Value |
|---|---|
| **Route** | `/relocation` |
| **Current Implementation** | Overview of pet relocation services with links to import, export, transport, and checklist. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/relocation.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/relocation/page.tsx` |

### 35. Pet Import
| Field | Value |
|---|---|
| **Route** | `/relocation/import` |
| **Current Implementation** | Pet import into Nigeria — requirements, process, documentation. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/relocation.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/relocation/import/page.tsx` |

### 36. Pet Export
| Field | Value |
|---|---|
| **Route** | `/relocation/export` |
| **Current Implementation** | Pet export from Nigeria — requirements and process. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/relocation.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/relocation/export/page.tsx` |

### 37. Local Transport
| Field | Value |
|---|---|
| **Route** | `/relocation/transport` (CANONICAL) |
| **Current Implementation** | Local pet transport service page. Note: `/services/transport` 301 redirects here. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/relocation.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced`, `HeroGradient` |
| **Relevant Files** | `src/app/relocation/transport/page.tsx`, `src/app/services/transport/page.tsx` (redirect) |

### 38. Relocation Document Checklist
| Field | Value |
|---|---|
| **Route** | `/relocation/checklist` (CANONICAL) |
| **Current Implementation** | Interactive document checklist for pet relocation. Discoverable from both Relocation section and Tools hub. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/relocation.ts` |
| **State/Persistence** | None |
| **Known Limitations** | — |
| **Relevant Components** | `ServicePageEnhanced` |
| **Relevant Files** | `src/app/relocation/checklist/page.tsx` |

---

## About & Company

### 39. About
| Field | Value |
|---|---|
| **Route** | `/about` |
| **Current Implementation** | Company story, values, team overview, and mosaic images. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/data/about.ts`, `src/data/team.ts` |
| **State/Persistence** | None |
| **Known Limitations** | Team photos are placeholder; 7 members (3 verified, 4 placeholder) |
| **Relevant Components** | — |
| **Relevant Files** | `src/app/about/page.tsx` |

### 40. Careers
| Field | Value |
|---|---|
| **Route** | `/about/careers` |
| **Current Implementation** | Job listings with role descriptions and application CTA (WhatsApp). |
| **Frontend Status** | Complete |
| **Backend Status** | WhatsApp Fallback |
| **Data Source** | `src/data/careers.ts`, `src/data/careers-roles.ts` |
| **State/Persistence** | None |
| **Known Limitations** | No application form; no job board integration |
| **Relevant Components** | — |
| **Relevant Files** | `src/app/about/careers/page.tsx` |

### 41. Partnerships
| Field | Value |
|---|---|
| **Route** | `/about/partnerships` |
| **Current Implementation** | Partnership opportunities page. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | `src/data/partnerships.ts` |
| **State/Persistence** | None |
| **Known Limitations** | No partner portal; no application tracking |
| **Relevant Components** | — |
| **Relevant Files** | `src/app/about/partnerships/page.tsx` |

---

## User Features

### 42. My Pets
| Field | Value |
|---|---|
| **Route** | `/my-pets` |
| **Current Implementation** | Pet profile management — add, edit, delete pet profiles (name, species, breed, birthday, weight, notes). |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | User input only |
| **State/Persistence** | `localStorage` via zustand (`src/store/pet-store.ts`) |
| **Known Limitations** | NOT in navigation; NOT in sitemap; robots.txt disallowed; no server sync; no photo upload; single-device only |
| **Relevant Components** | `pet-profile-card.tsx` |
| **Relevant Files** | `src/store/pet-store.ts`, `src/app/my-pets/page.tsx` |

### 43. Loyalty Programme
| Field | Value |
|---|---|
| **Route** | `/loyalty` |
| **Current Implementation** | Loyalty programme information page — tiers, benefits, how it works. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | `src/data/loyalty.ts` |
| **State/Persistence** | None |
| **Known Limitations** | No actual loyalty system/backend; no points tracking; no user accounts |
| **Relevant Components** | — |
| **Relevant Files** | `src/data/loyalty.ts`, `src/app/loyalty/page.tsx` |

---

## Global Features

### 44. Search (Command Palette)
| Field | Value |
|---|---|
| **Route** | Global (Ctrl+K / search icon) |
| **Current Implementation** | Command-palette style search across all pages, tools, services, blog posts, and FAQ items. Static search index built at build time. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | `src/lib/search-index.ts` (static index) |
| **State/Persistence** | None |
| **Known Limitations** | No fuzzy matching; index is static (must rebuild for new content); no recent searches |
| **Relevant Components** | `src/components/waggies/search-command-palette.tsx`, `lazy-search-palette.tsx`, `search-trigger.tsx` |
| **Relevant Files** | `src/lib/search-index.ts` |

### 45. Newsletter Signup
| Field | Value |
|---|---|
| **Route** | Global (footer) |
| **Current Implementation** | Email input in footer. Frontend form only. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | User input |
| **State/Persistence** | None |
| **Known Limitations** | No email service integration; submissions are silently lost; no confirmation |
| **Relevant Components** | `src/components/waggies/newsletter-form.tsx` |
| **Relevant Files** | — |

### 46. Cookie Banner
| Field | Value |
|---|---|
| **Route** | Global (layout) |
| **Current Implementation** | Cookie consent banner with accept/reject. Shows once, stores preference. |
| **Frontend Status** | Complete |
| **Backend Status** | None |
| **Data Source** | None |
| **State/Persistence** | `localStorage` |
| **Known Limitations** | No analytics integration; consent preference not used to conditionally load scripts |
| **Relevant Components** | `src/components/waggies/cookie-banner.tsx` |
| **Relevant Files** | — |

---

## Legal Pages

### 47. Privacy Policy
| Field | Value |
|---|---|
| **Route** | `/privacy-policy` |
| **Current Implementation** | Static legal text page. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | Inline in page.tsx |
| **State/Persistence** | None |
| **Known Limitations** | Not reviewed by legal counsel |
| **Relevant Components** | — |
| **Relevant Files** | `src/app/privacy-policy/page.tsx` |

### 48. Terms of Service
| Field | Value |
|---|---|
| **Route** | `/terms-of-service` |
| **Current Implementation** | Static legal text page. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | Inline in page.tsx |
| **State/Persistence** | None |
| **Known Limitations** | Not reviewed by legal counsel |
| **Relevant Components** | — |
| **Relevant Files** | `src/app/terms-of-service/page.tsx` |

### 49. Cookies Policy
| Field | Value |
|---|---|
| **Route** | `/cookies-policy` |
| **Current Implementation** | Static legal text page. |
| **Frontend Status** | Complete |
| **Backend Status** | Static |
| **Data Source** | Inline in page.tsx |
| **State/Persistence** | None |
| **Known Limitations** | Not reviewed by legal counsel |
| **Relevant Components** | — |
| **Relevant Files** | `src/app/cookies-policy/page.tsx` |

---

## Summary Statistics

| Category | Count |
|---|---|
| Total Features Catalogued | 49 |
| Features with Backend (non-static) | 0 |
| Features with localStorage Persistence | 5 (Cart, Recently Viewed, New Pet Checklist, My Pets, Cookie Banner) |
| Features Using WhatsApp Fallback | 3 (Booking, Contact Form, Careers) |
| Features with MedicalDisclaimer | 6 (Symptom Checker, Vaccination, Med Dosage, Nutrition, Emergency, Parasite) |
| Features with No Backend Integration | 49 |
| All Images Temporary Stock | ~70 slots (see GOLDEN_ASSET_INVENTORY.md) |
