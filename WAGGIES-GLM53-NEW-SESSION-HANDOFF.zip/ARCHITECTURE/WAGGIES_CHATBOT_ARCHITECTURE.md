# Waggies Chatbot Architecture

> **Handoff Document** — Current implementation state and future architecture vision

---

## CURRENT STATE (Implemented)

### Architecture

| Aspect              | Details                                                                  |
|---------------------|--------------------------------------------------------------------------|
| **Type**            | Deterministic / pattern-based keyword matching                           |
| **Location**        | Embedded directly in `floating-actions.tsx`                              |
| **Data Sources**    | Hardcoded keyword-response pairs within the component                    |
| **NLU/LLM**         | None. Pure string matching with `.includes()` and regex patterns         |
| **Trigger**         | Floating action button (bottom-right corner of viewport)                 |
| **Panel**           | Slides up as chat panel, viewport-contained, uses `dvh` sizing           |
| **Icons**           | Phosphor Icons (`@phosphor-icons/react v2.1.10`)                        |
| **State**           | React `useState` — resets on every page reload/navigation               |

### Capabilities

| Capability             | Status | Notes                                                                      |
|------------------------|--------|----------------------------------------------------------------------------|
| Greeting responses     | Yes    | Responds to "hi", "hello", "hey", "good morning", etc.                   |
| Service information    | Partial | Responds to keywords like "boarding", "grooming", "transport" with canned responses |
| Business hours         | Yes    | Returns static hours information                                          |
| Location/directions   | Yes    | Returns static address information                                        |
| WhatsApp escalation    | Yes    | Can redirect user to WhatsApp for live support                            |
| Multi-turn conversation| No     | Each message is processed independently, no context carried forward       |

### Limitations (Current)

1. **No Natural Language Understanding**: Cannot handle paraphrases, typos, or ambiguous queries beyond exact keyword matches
2. **No Context Memory**: Every message is evaluated in isolation; no conversation history awareness
3. **Limited Response Coverage**: Only a small set of keywords are recognized; most queries fall through to a generic fallback
4. **No Personalization**: Cannot access user data, pet profiles, booking history, or any stored information
5. **No Conversation Persistence**: All chat state is lost on page reload or navigation
6. **No Analytics**: No tracking of what users ask, conversation outcomes, or escalation rates
7. **Monolithic Component**: Chat logic is embedded in the floating actions component, not modularized
8. **No Typing Indicators**: No visual feedback that the bot is "processing"

### Technical Details

- **Component**: Chat panel rendered conditionally via React state toggle
- **Message matching**: Iterates through an array of `{ keywords: string[], response: string }` objects
- **Matching method**: Checks if user input (lowercased) includes any keyword from each pattern
- **Fallback**: Generic "I'm not sure about that" message with WhatsApp escalation link
- **UI**: Simple message bubbles with timestamps, scroll-to-bottom on new messages
- **Viewport handling**: Panel height uses `dvh` units for mobile-accurate viewport sizing

---

## FUTURE VISION (NOT Implemented)

> **IMPORTANT**: Everything in this section is planned architecture. None of it is currently implemented.

### 1. Intent Router

Classify incoming user messages into structured intents:

| Intent              | Description                                    | Example Triggers                         |
|----------------------|------------------------------------------------|------------------------------------------|
| `booking`            | Wants to book/make a reservation               | "I want to book grooming", "reserve boarding" |
| `service_info`       | Asking about a specific service                | "What services do you offer?", "transport fees" |
| `pricing`            | Asking about costs                             | "How much is boarding?", "grooming price"   |
| `emergency`          | Urgent/medical situation                       | "my dog is sick", "emergency", "help now"  |
| `medical_question`   | General pet health questions                   | "why is my cat vomiting", "flea treatment"  |
| `hours_location`     | Business hours and location                    | "when are you open", "where are you"        |
| `testimonial`        | Wants to leave a review                        | "I want to review", "leave feedback"       |
| `general`            | General inquiries that don't fit above         | "thank you", "who are you"                 |
| `escalation`         | Explicitly wants human support                 | "talk to someone", "real person"           |

### 2. Waggies RAG (Retrieve-Augmented Generation)

Retrieve relevant information from Waggies' own knowledge base before generating a response.

**Approved Knowledge Sources:**
- Service page content (all service descriptions, pricing, FAQs)
- Static FAQ data (`data/faq.ts`)
- Tools data (pet care tool content and results)
- Business info (hours, location, contact, policies)
- Blog/content pages (when available)

**Pipeline:**
1. User message received
2. Intent router classifies the message
3. Query constructed from intent + user message
4. Relevant chunks retrieved from knowledge base
5. Context window assembled: system prompt + retrieved chunks + conversation history
6. LLM generates response with citations to source

### 3. LLM Backend

- **Provider**: Backend LLM via `z-ai-web-dev-sdk`
- **Role**: Natural language understanding and response generation
- **Mode**: Streaming responses for better UX (progressive message display)
- **Safety**: System prompt constrains responses to Waggies-related topics only
- **Cost control**: Intent routing avoids unnecessary LLM calls for simple queries (hours, location)

### 4. Safety Routing

#### Medical Escalation
- Detect medical urgency through intent classification and keyword analysis
- When detected, immediately show:
  - Emergency phone number (not just WhatsApp)
  - WhatsApp quick-link with pre-filled "EMERGENCY" tag
  - Disclaimer: "For emergencies, please call our vet directly"
- Never attempt to diagnose or prescribe via chatbot

#### Emergency Detection Signals
- Keywords: "emergency", "bleeding", "can't breathe", "poison", "seizure", "not moving", "collapse"
- Urgency indicators: ALL CAPS, repeated messages, exclamation marks

### 5. Conversation Persistence

Store conversations in the database for:
- Context continuity across page reloads
- Analytics on common questions and conversation outcomes
- Handoff to human agents (conversation history visible)
- Training data for improving response quality

**Database schema** (see `WAGGIES_DATABASE_SCHEMA.md`):
- `ChatConversation` — session-level record
- `ChatMessage` — individual messages within a conversation

### 6. Multi-Turn Context

- Maintain conversation history (last N messages) in context window
- Reference previous messages: "Yes, about the grooming you mentioned earlier..."
- Slot filling: Progressively collect required booking info across multiple messages
  - "I'd like to book boarding" → "What's your pet's name?" → "And what dates?"

---

## Migration Path

The following is the recommended order for upgrading the chatbot:

| Phase | Change                                                        | Effort |
|-------|---------------------------------------------------------------|--------|
| 1     | Extract chatbot into standalone component (modularize)         | Low    |
| 2     | Add intent router (replace flat keyword matching)             | Medium |
| 3     | Add conversation persistence (localStorage → database)        | Medium |
| 4     | Add LLM backend for natural responses                         | High   |
| 5     | Add RAG pipeline for Waggies knowledge base                   | High   |
| 6     | Add safety routing (medical escalation, emergency detection)  | Medium |
| 7     | Add multi-turn slot filling for booking flows                 | High   |
| 8     | Add analytics dashboard for conversation insights             | Medium |
