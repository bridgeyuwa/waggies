# Waggies Route Map

> Complete route inventory for the Waggies pet care website.
> Covers all 46 page.tsx files plus the redirect route.

---

## Legend

| Column | Meaning |
|---|---|
| **Canonical?** | `YES` = this is the authoritative URL for the content; `—` = N/A (only one URL) |
| **Redirect?** | Source route that 301s to another route |
| **Indexable?** | `YES` = intended for search engines; `NO` = blocked (robots/sitemap exclusion) |
| **Navigation Location** | Where the route appears in the site's UI navigation |
| **SEO Metadata?** | `YES` = page has a `metadata` export or `generateMetadata` function |
| **Structured Data?** | `YES` = page includes `BreadcrumbSchema` or `JsonLd` component |
| **Status** | `ACTIVE` = live page · `REDIRECT` = 301 · `HIDDEN` = exists but excluded from nav/sitemap · `TEMPLATE` = requires dynamic slug |

---

## Routes

### Home

| Route | Page Purpose | Canonical? | Redirect? | Indexable? | Navigation Location | Breadcrumb Hierarchy | SEO Metadata? | Structured Data? | Status |
|---|---|---|---|---|---|---|---|---|---|
| `/` | Homepage — hero, services overview, testimonials, CTA | — | No | YES | Top-level navbar logo, footer home link | Home | YES | YES (Organization + WebSite JsonLd in layout) | ACTIVE |

### Services

| Route | Page Purpose | Canonical? | Redirect? | Indexable? | Navigation Location | Breadcrumb Hierarchy | SEO Metadata? | Structured Data? | Status |
|---|---|---|---|---|---|---|---|---|---|
| `/services` | Services hub — links to all service categories | — | No | YES | Main nav ("Services" dropdown) | Home > Services | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/services/boarding` | Boarding hub — links to dogs, cats, exotic | — | No | YES | Services dropdown → Boarding | Home > Services > Boarding | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/services/boarding/dogs` | Dog boarding service details | — | No | YES | Boarding page → Dogs link | Home > Services > Boarding > Dogs | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/services/boarding/cats` | Cat boarding service details | — | No | YES | Boarding page → Cats link | Home > Services > Boarding > Cats | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/services/boarding/exotic` | Exotic pet boarding service details | — | No | YES | Boarding page → Exotic link | Home > Services > Boarding > Exotic | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/services/grooming` | Grooming service page | — | No | YES | Services dropdown → Grooming | Home > Services > Grooming | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/services/vet-care` | Veterinary care service page | — | No | YES | Services dropdown → Vet Care | Home > Services > Veterinary Care | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/services/training` | Pet training service page | — | No | YES | Services dropdown → Training | Home > Services > Training | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/services/pricing` | Pricing tiers and comparison | — | No | YES | Services dropdown → Pricing | Home > Services > Pricing | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/services/transport` | **301 redirect** to `/relocation/transport` | No | **→ `/relocation/transport`** | NO | Nowhere (redirected) | — | — | — | REDIRECT |

### Relocation

| Route | Page Purpose | Canonical? | Redirect? | Indexable? | Navigation Location | Breadcrumb Hierarchy | SEO Metadata? | Structured Data? | Status |
|---|---|---|---|---|---|---|---|---|---|
| `/relocation` | Relocation hub — import, export, transport, checklist | — | No | YES | Main nav ("Relocation" dropdown) | Home > Relocation | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/relocation/import` | Pet import into Nigeria | — | No | YES | Relocation dropdown → Import | Home > Relocation > Pet Import | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/relocation/export` | Pet export from Nigeria | — | No | YES | Relocation dropdown → Export | Home > Relocation > Pet Export | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/relocation/transport` | Local pet transport | YES (canonical for transport) | No | YES | Relocation dropdown → Transport | Home > Relocation > Local Transport | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/relocation/checklist` | Relocation document checklist | YES (canonical) | No | YES | Relocation dropdown → Doc Checklist; also linked from Tools hub | Home > Relocation > Doc Checklist | YES | YES (BreadcrumbSchema) | ACTIVE |

### About

| Route | Page Purpose | Canonical? | Redirect? | Indexable? | Navigation Location | Breadcrumb Hierarchy | SEO Metadata? | Structured Data? | Status |
|---|---|---|---|---|---|---|---|---|---|
| `/about` | Company story, team, values | — | No | YES | Main nav ("About" dropdown) | Home > About | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/about/testimonials` | Client testimonials carousel/grid | — | No | YES | About dropdown → Testimonials | Home > About > Testimonials | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/about/gallery` | Photo gallery with lightbox | — | No | YES | About dropdown → Gallery | Home > About > Gallery | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/about/careers` | Job listings and application | — | No | YES | About dropdown → Careers | Home > About > Careers | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/about/partnerships` | Partnership opportunities | — | No | YES | About dropdown → Partnerships | Home > About > Partnerships | YES | YES (BreadcrumbSchema) | ACTIVE |

### Tools

| Route | Page Purpose | Canonical? | Redirect? | Indexable? | Navigation Location | Breadcrumb Hierarchy | SEO Metadata? | Structured Data? | Status |
|---|---|---|---|---|---|---|---|---|---|
| `/tools` | Tools hub — 11 pet care tools grid | — | No | YES | Main nav ("Tools" dropdown) | Home > Tools | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/symptom-checker` | Interactive symptom checker | — | No | YES | Tools hub → Symptom Checker | Home > Tools > Symptom Checker | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/pet-age-calculator` | Pet age to human years converter | — | No | YES | Tools hub → Pet Age Calculator | Home > Tools > Pet Age Calculator | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/vaccination-schedule` | Vaccination timeline by pet type | — | No | YES | Tools hub → Vaccination Schedule | Home > Tools > Vaccination Schedule | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/cost-calculator` | Service cost estimator | — | No | YES | Tools hub → Cost Calculator | Home > Tools > Cost Calculator | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/medication-dosage-guide` | Medication reference guide | — | No | YES | Tools hub → Medication Dosage | Home > Tools > Medication Dosage Guide | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/nutrition-calculator` | Diet and feeding calculator | — | No | YES | Tools hub → Nutrition Calculator | Home > Tools > Nutrition Calculator | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/emergency-guide` | Emergency & poison first-aid | — | No | YES | Tools hub → Emergency Guide | Home > Tools > Emergency Guide | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/new-pet-checklist` | Interactive new pet preparation checklist | — | No | YES | Tools hub → New Pet Checklist | Home > Tools > New Pet Checklist | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/parasite-schedule` | Parasite prevention schedule | — | No | YES | Tools hub → Parasite Schedule | Home > Tools > Parasite Schedule | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/behavior-tips` | Pet behavior advice articles | — | No | YES | Tools hub → Behavior Tips | Home > Tools > Behavior Tips | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/tools/breed-finder` | Dog & cat breed explorer | — | No | YES | Tools hub → Breed Finder | Home > Tools > Breed Finder | YES | YES (BreadcrumbSchema) | ACTIVE |

### Resources

| Route | Page Purpose | Canonical? | Redirect? | Indexable? | Navigation Location | Breadcrumb Hierarchy | SEO Metadata? | Structured Data? | Status |
|---|---|---|---|---|---|---|---|---|---|
| `/blog` | Blog listing page | — | No | YES | Main nav ("Resources" dropdown) → Blog | Home > Resources > Blog | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/blog/[slug]` | Individual blog article | — | No | YES | Blog listing → article link | Home > Resources > Blog > [Article Title] | YES | YES (BreadcrumbSchema + ArticleSchema) | TEMPLATE |
| `/guides` | Guides listing page | — | No | YES | Main nav ("Resources" dropdown) → Guides | Home > Resources > Guides | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/guides/[slug]` | Individual guide article | — | No | YES | Guides listing → guide link | Home > Resources > Guides > [Guide Title] | YES | YES (BreadcrumbSchema) | TEMPLATE |
| `/knowledge-base` | Knowledge base listing page | — | No | YES | Main nav ("Resources" dropdown) → Knowledge Base | Home > Resources > Knowledge Base | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/knowledge-base/[slug]` | Individual KB article | — | No | YES | Knowledge Base listing → article link | Home > Resources > Knowledge Base > [Article Title] | YES | YES (BreadcrumbSchema) | TEMPLATE |
| `/faq` | Searchable FAQ page | — | No | YES | Main nav ("Resources" dropdown) → FAQ | Home > Resources > FAQ | YES | YES (BreadcrumbSchema + FAQSchema) | ACTIVE |

### Shop

| Route | Page Purpose | Canonical? | Redirect? | Indexable? | Navigation Location | Breadcrumb Hierarchy | SEO Metadata? | Structured Data? | Status |
|---|---|---|---|---|---|---|---|---|---|
| `/shop` | Product listing grid with filters | — | No | YES | Main nav ("Shop") | Home > Shop | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/shop/[id]` | Individual product detail page | — | No | YES | Shop listing → product card | Home > Shop > [Product Name] | YES | YES (BreadcrumbSchema + ProductSchema) | TEMPLATE |

### Other Pages

| Route | Page Purpose | Canonical? | Redirect? | Indexable? | Navigation Location | Breadcrumb Hierarchy | SEO Metadata? | Structured Data? | Status |
|---|---|---|---|---|---|---|---|---|---|
| `/contact` | Location hub — map, form, hours | — | No | YES | Main nav ("Contact") | Home > Contact | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/my-pets` | Pet profile management (add/edit/delete) | — | No | **NO** (robots disallow, not in sitemap) | **NOWHERE** (not in nav) | Home > My Pets | YES | YES (BreadcrumbSchema) | HIDDEN |
| `/loyalty` | Loyalty programme information | — | No | YES | Footer link | Home > Loyalty | YES | YES (BreadcrumbSchema) | ACTIVE |
| `/privacy-policy` | Privacy policy legal page | — | No | YES | Footer link | — | YES | No | ACTIVE |
| `/terms-of-service` | Terms of service legal page | — | No | YES | Footer link | — | YES | No | ACTIVE |
| `/cookies-policy` | Cookies policy legal page | — | No | YES | Cookie banner link | — | YES | No | ACTIVE |

---

## Route Statistics

| Metric | Count |
|---|---|
| Total routes (including redirect) | 47 |
| ACTIVE pages | 44 |
| REDIRECT (301) | 1 (`/services/transport`) |
| HIDDEN (exists, not in nav/sitemap) | 1 (`/my-pets`) |
| TEMPLATE (dynamic `[slug]`/`[id]`) | 5 (`/blog/[slug]`, `/guides/[slug]`, `/knowledge-base/[slug]`, `/shop/[id]`) — note: relocation/checklist is static, not templated |
| Pages with SEO metadata | 46 (all pages) |
| Pages with BreadcrumbSchema | 43 (all except legal pages) |
| Pages with additional Schema (Article, FAQ, Product) | 4 (`/blog/[slug]`, `/faq`, `/shop/[id]`, homepage layout) |
| Pages excluded from sitemap/robots | 2 (`/my-pets`, `/services/transport`) |

---

## Navigation Structure

### Main Navbar (top-level)
- **Home** → `/`
- **Services** (dropdown)
  - Boarding → `/services/boarding`
  - Grooming → `/services/grooming`
  - Vet Care → `/services/vet-care`
  - Training → `/services/training`
  - Pricing → `/services/pricing`
- **Relocation** (dropdown)
  - Pet Import → `/relocation/import`
  - Pet Export → `/relocation/export`
  - Local Transport → `/relocation/transport`
  - Doc Checklist → `/relocation/checklist`
- **Tools** (dropdown)
  - Tools Hub → `/tools`
- **Resources** (dropdown)
  - Blog → `/blog`
  - Guides → `/guides`
  - Knowledge Base → `/knowledge-base`
  - FAQ → `/faq`
- **Shop** → `/shop`
- **Contact** → `/contact`

### Footer Links
- Home → `/`
- About → `/about`
- Services → `/services`
- Relocation → `/relocation`
- Shop → `/shop`
- Blog → `/blog`
- FAQ → `/faq`
- Contact → `/contact`
- Privacy Policy → `/privacy-policy`
- Terms of Service → `/terms-of-service`
- Cookies Policy → `/cookies-policy`
- Loyalty → `/loyalty`

### Not in Navigation
- `/my-pets` — accessible only by direct URL
- `/services/transport` — redirects to `/relocation/transport`
- Legal pages — only in footer

---

## Redirect Chain

```
/services/transport  →  301  →  /relocation/transport
```

This is the only redirect. No other redirect chains exist.

---

## Sitemap & Robots Notes

- **Sitemap** (`/sitemap.xml`): Generated via `src/app/sitemap.ts`. Includes all ACTIVE routes plus all tool routes. **Excludes** `/my-pets` and `/services/transport`.
- **Robots.txt**: Disallows `/my-pets` and `/api/*`.
- **Canonical URLs**: All pages use `next.config.js` or metadata `alternates.canonical` to set canonical URLs. `/relocation/transport` is the canonical for transport content (old `/services/transport` 301s to it).