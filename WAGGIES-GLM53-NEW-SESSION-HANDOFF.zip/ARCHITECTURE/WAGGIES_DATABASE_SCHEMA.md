# Waggies Database Schema

> **Handoff Document** — Schema preparation for future production backend
>
> **STATUS: SCHEMA PREPARATION ONLY — NOT PRODUCTION BACKEND**
> Production backend implementation is deferred. Current app uses static data files and localStorage.

---

## Current State

| Aspect              | Details                                                       |
|----------------------|---------------------------------------------------------------|
| ORM                  | Prisma                                                        |
| Database             | SQLite (`file:/home/z/my-project/db/custom.db`)               |
| Current schema       | Next.js template only: `User` and `Post` models               |
| Waggies-specific data| None in database — all data is in static files (`data/*.ts`)  |
| Client-side storage  | localStorage for pets, cart, preferences                      |
| Migrations run       | Template migration only                                       |

### Current Template Models (NOT Waggies-specific)

```prisma
model User {
  id        String   @id @default(cuid())
  name      String?
  email     String   @unique
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
  posts     Post[]
}

model Post {
  id        String   @id @default(cuid())
  title     String
  content   String?
  published Boolean  @default(false)
  author    User     @relation(fields: [authorId], references: [id], onDelete: Cascade)
  authorId  String
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}
```

---

## Proposed Schema (For Future Implementation)

> These models are designed for when a production backend is built.
> They are documented here as a reference for future development.

### 1. User

Extended user model replacing the template `User`.

```prisma
model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  phone     String?
  role      String   @default("customer") // "customer", "staff", "admin"
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  // Relations
  pets           Pet[]
  bookings       Booking[]
  orders         Order[]
  cartItems      CartItem[]
  loyaltyAccount LoyaltyAccount?
  testimonials   Testimonial[]
  contacts       ContactRequest[]
  conversations  ChatConversation[]
}
```

### 2. Pet

```prisma
model Pet {
  id          String   @id @default(cuid())
  userId      String
  name        String
  species     String   // "dog", "cat", "exotic", "other"
  breed       String?
  dateOfBirth DateTime?
  gender      String?  // "male", "female", "unknown"
  notes       String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  user     User     @relation(fields: [userId], references: [id], onDelete: Cascade)
  bookings Booking[]
}
```

### 3. Booking

```prisma
model Booking {
  id             String   @id @default(cuid())
  userId         String
  petId          String?
  service        String   // e.g. "boarding", "grooming"
  serviceCategory String  // e.g. "Boarding", "Wellness"
  status         String   @default("pending") // "pending", "confirmed", "completed", "cancelled"
  checkIn        DateTime?
  checkOut       DateTime?
  notes          String?
  totalPrice     Float?
  pricingMode    String?  // "FIXED", "ESTIMATED", "QUOTE_REQUIRED"
  createdAt      DateTime @default(now())
  updatedAt      DateTime @updatedAt

  user         User          @relation(fields: [userId], references: [id], onDelete: Cascade)
  pet          Pet?          @relation(fields: [petId], references: [id])
  appointments Appointment[]
}
```

### 4. Product

```prisma
model Product {
  id        String   @id @default(cuid())
  name      String
  description String?
  price     Float
  category  String?
  imageUrl  String?
  inStock   Boolean  @default(true)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  orderItems OrderItem[]
  cartItems  CartItem[]
}
```

### 5. Order

```prisma
model Order {
  id          String   @id @default(cuid())
  userId      String
  status      String   @default("pending") // "pending", "paid", "shipped", "delivered"
  totalAmount Float
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  user       User        @relation(fields: [userId], references: [id], onDelete: Cascade)
  orderItems OrderItem[]
}
```

### 6. OrderItem

```prisma
model OrderItem {
  id        String @id @default(cuid())
  orderId   String
  productId String
  quantity  Int
  unitPrice Float

  order   Order   @relation(fields: [orderId], references: [id], onDelete: Cascade)
  product Product @relation(fields: [productId], references: [id])

  @@unique([orderId, productId])
}
```

### 7. CartItem

```prisma
model CartItem {
  id        String @id @default(cuid())
  userId    String
  productId String
  quantity  Int

  user    User    @relation(fields: [userId], references: [id], onDelete: Cascade)
  product Product @relation(fields: [productId], references: [id])

  @@unique([userId, productId])
}
```

> **Note**: Cart may remain localStorage-only for the initial production phase. Server-side cart requires authentication.

### 8. LoyaltyAccount

```prisma
model LoyaltyAccount {
  id        String   @id @default(cuid())
  userId    String   @unique
  points    Int      @default(0)
  tier      String   @default("bronze") // "bronze", "silver", "gold"
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt

  user User @relation(fields: [userId], references: [id], onDelete: Cascade)
}
```

### 9. Testimonial

```prisma
model Testimonial {
  id         String   @id @default(cuid())
  authorName String?
  authorEmail String?
  petType    String?
  rating     Int      // 1-5
  quote      String
  verified   Boolean  @default(false)
  approved   Boolean  @default(false)
  createdAt  DateTime @default(now())

  user User? @relation(fields: [userId], references: [id])
  userId String? // nullable — anonymous testimonials allowed
}
```

### 10. NewsletterSubscription

```prisma
model NewsletterSubscription {
  id        String   @id @default(cuid())
  email     String   @unique
  active    Boolean  @default(true)
  createdAt DateTime @default(now())
}
```

### 11. ContactRequest

```prisma
model ContactRequest {
  id        String   @id @default(cuid())
  name      String?
  email     String?
  phone     String?
  service   String?
  message   String?
  intent    String?  // "booking", "inquiry", "complaint", "feedback"
  createdAt DateTime @default(now())

  user User? @relation(fields: [userId], references: [id])
  userId String? // nullable — unauthenticated contact form
}
```

### 12. Content

```prisma
model Content {
  id          String    @id @default(cuid())
  slug        String    @unique
  title       String
  body        String?
  type        String    // "blog", "guide", "kb"
  status      String    @default("draft") // "draft", "published"
  authorId    String?
  publishedAt DateTime?
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}
```

### 13. MedicalToolContent

Structured data for pet health tools (calculators, checklists, etc.).

```prisma
model MedicalToolContent {
  id          String    @id @default(cuid())
  toolSlug    String    // e.g. "pet-age-calculator", "symptom-checker"
  condition   String    // e.g. "obesity", "fleas"
  symptoms    String?   // JSON array of symptom strings
  advice      String?   // Care recommendations
  severity    String?   // "low", "medium", "high", "emergency"
  reviewedBy  String?   // Staff/vet who reviewed
  reviewedAt  DateTime?
}
```

### 14. ChatConversation

```prisma
model ChatConversation {
  id        String    @id @default(cuid())
  userId    String?   // nullable — anonymous chat sessions
  sessionId String    @unique // client-generated session ID
  startedAt DateTime  @default(now())
  endedAt   DateTime?

  messages  ChatMessage[]
}
```

### 15. ChatMessage

```prisma
model ChatMessage {
  id            String   @id @default(cuid())
  conversationId String
  role          String   // "user", "assistant", "system"
  content       String
  timestamp     DateTime @default(now())

  conversation ChatConversation @relation(fields: [conversationId], references: [id], onDelete: Cascade)
}
```

### 16. Staff

```prisma
model Staff {
  id         String  @id @default(cuid())
  name       String
  role       String  // "vet", "groomer", "trainer", "manager"
  credential String? // e.g. "DVM", "Certified Dog Trainer"
  bio        String?
  imageUrl   String?
  verified   Boolean @default(false)
  sortOrder  Int     @default(0)
  active     Boolean @default(true)
}
```

### 17. Service

```prisma
model Service {
  id          String  @id @default(cuid())
  slug        String  @unique
  name        String
  description String?
  category    String  // "Boarding", "Wellness", "Relocation", "Training"
  basePrice   Float?
  pricingMode String  @default("QUOTE_REQUIRED") // "FIXED", "ESTIMATED", "QUOTE_REQUIRED"
  imageUrl    String?
  active      Boolean @default(true)

  pricingTiers PricingTier[]
}
```

### 18. PricingTier

```prisma
model PricingTier {
  id          String  @id @default(cuid())
  serviceId   String
  name        String  // "basic", "standard", "premium"
  description String?
  price       Float?
  features    String? // JSON array of feature strings

  service Service @relation(fields: [serviceId], references: [id], onDelete: Cascade)
}
```

### 19. Appointment

```prisma
model Appointment {
  id        String   @id @default(cuid())
  bookingId String?
  staffId   String?
  date      DateTime
  time      String   // e.g. "10:00 AM"
  duration  String?  // e.g. "1 hour"
  status    String   @default("pending") // "pending", "confirmed", "completed", "cancelled"
  notes     String?

  booking Booking? @relation(fields: [bookingId], references: [id])
  staff   Staff?   @relation(fields: [staffId], references: [id])
}
```

---

## Entity Relationship Summary

```
User (1) ──── (N) Pet
User (1) ──── (N) Booking
User (1) ──── (N) Order
User (1) ──── (N) CartItem
User (1) ──── (1) LoyaltyAccount
User (1) ──── (N) Testimonial
User (1) ──── (N) ContactRequest
User (1) ──── (N) ChatConversation
Pet  (1) ──── (N) Booking
Booking (1) ──── (N) Appointment
Order (1) ──── (N) OrderItem
Product (1) ──── (N) OrderItem
Product (1) ──── (N) CartItem
Service (1) ──── (N) PricingTier
Staff (1) ──── (N) Appointment
ChatConversation (1) ──── (N) ChatMessage
```

## Implementation Notes

1. **This is schema preparation only.** No migration has been generated or run for these models.
2. **Current app uses static data.** All service data, FAQ, tools, pricing, and testimonials live in TypeScript files under `data/`.
3. **Client-side state uses localStorage.** Pet profiles, cart items, and preferences are stored in the browser.
4. **When implementing**, start with: User, Pet, Booking, Service, PricingTier — these are the core business entities.
5. **Chatbot persistence** (ChatConversation, ChatMessage) should be implemented alongside the LLM backend upgrade.
6. **E-commerce models** (Product, Order, OrderItem, CartItem) are lowest priority — shop is informational-only currently.
7. **Database choice**: SQLite is suitable for development. Consider PostgreSQL for production (better concurrency, JSON support, full-text search).
