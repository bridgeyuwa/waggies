# Waggies — Current State Handoff Document

**Generated:** Handoff batch 1
**Repository:** `/home/z/my-project`
**Git branch:** `main`
**Git HEAD:** `328eb1cd752e2700d393bee04324667cb6bd9f64`
**Working tree:** **NOT clean** — 30 uncommitted changes (mostly `tool-results/` temp files and a few source modifications)

---

## Tech Stack

| Layer | Version / Detail |
|---|---|
| Next.js | 16.1.1 |
| React | 19.0.0 |
| TypeScript | 5.x |
| Tailwind CSS | 4 |
| UI library | shadcn/ui (~45 components) |
| Package manager | bun |
| Database | SQLite via Prisma (template schema only — User + Post models) |
| ORM | Prisma |
| Auth | NextAuth (available but not configured) |
| State management | zustand (cart-store, pet-store) |
| Data fetching | @tanstack/react-query |
| Validation | zod + react-hook-form |
| Icons | @phosphor-icons/react (primary), lucide-react (legacy, still in deps) |
| Animation | framer-motion (restrained intensity) |
| Charts | recharts |
| Carousel | embla-carousel |
| Content rendering | react-markdown |
| Drawers/modals | vaul, sonner (toasts) |
| Image processing | sharp |
| Email | resend (configured but unused) |
| AI SDK | z-ai-web-dev-sdk (in deps) |

---

## Major Dependencies (non-exhaustive)

- @phosphor-icons/react
- framer-motion
- zustand
- @tanstack/react-query
- prisma / @prisma/client
- next-auth
- zod
- react-hook-form
- recharts
- embla-carousel-react
- react-markdown
- vaul
- sonner
- sharp
- resend
- z-ai-web-dev-sdk
- lucide-react (discouraged, cleanup needed)

---

## Dev / Build Status

- **Dev server:** Runs on port 3000 (confirmed)
- **Production build:** Not attempted in this session
- **`typescript.ignoreBuildErrors`:** `true` in `next.config.ts` (suppresses type errors at build time)

---

## Known Runtime Limitations

1. **No production backend** — Booking, auth, cart persistence, and pet profiles are all client-side only.
2. **Booking** is request-only with WhatsApp fallback. No real appointment scheduling backend.
3. **Cart** uses localStorage via zustand. No server persistence.
4. **Pet Profiles** use localStorage only.
5. **AI Chatbot** is a keyword-matching prototype, not LLM-powered.
6. **Database schema** is template only (User + Post models). No application tables.
7. **Auth** (NextAuth) is available but completely unconfigured.

---

## Known Warnings / Issues

| Issue | Detail |
|---|---|
| TypeScript build errors suppressed | `ignoreBuildErrors: true` in next.config.ts |
| Invalid favicon.ico | 223 bytes — almost certainly corrupt/placeholder |
| Lucide in dependencies | `lucide-react` still in package.json and potentially still imported; Phosphor is the approved primary icon set |
| No `.env.example` | `.env` exists with only `DATABASE_URL`; no example file for onboarding |
| Temp files in working tree | `tool-results/` directory contains uncommitted temp files |
| No middleware file | No `middleware.ts` exists at project root or `src/` |
| No cron jobs | No scheduled tasks configured |

---

## Route Inventory (46 page.tsx files)

### Home
- `/`

### Services
- `/services`
- `/services/boarding`
- `/services/boarding/dogs`
- `/services/boarding/cats`
- `/services/boarding/exotic`
- `/services/grooming`
- `/services/vet-care`
- `/services/training`
- `/services/pricing`
- `/services/transport` → **301 redirect to `/relocation/transport`**

### Relocation
- `/relocation`
- `/relocation/import`
- `/relocation/export`
- `/relocation/transport`
- `/relocation/checklist`

### About
- `/about`
- `/about/testimonials`
- `/about/gallery`
- `/about/careers`
- `/about/partnerships`

### Tools (11 tools)
- `/tools`
- `/tools/symptom-checker`
- `/tools/pet-age-calculator`
- `/tools/vaccination-schedule`
- `/tools/cost-calculator`
- `/tools/medication-dosage-guide`
- `/tools/nutrition-calculator`
- `/tools/emergency-guide`
- `/tools/new-pet-checklist`
- `/tools/parasite-schedule`
- `/tools/behavior-tips`
- `/tools/breed-finder`

### Resources
- `/blog`
- `/blog/[slug]`
- `/guides`
- `/guides/[slug]`
- `/knowledge-base`
- `/knowledge-base/[slug]`
- `/faq`

### Shop
- `/shop`
- `/shop/[id]`

### Other
- `/contact`
- `/my-pets` (route exists but NOT in nav, NOT in sitemap, robots disallow)
- `/loyalty`
- `/privacy-policy`
- `/terms-of-service`
- `/cookies-policy`

---

## Component Inventory

- **Waggies components:** 90+ (in `src/components/waggies/`)
- **shadcn/ui components:** ~45 (in `src/components/ui/`)
- **Key components:**
  - Navigation: `navbar.tsx`, `nav-flyout.tsx`, `mobile-bottom-nav.tsx`, `floating-actions.tsx`
  - Layout: `footer.tsx`
  - Hero variants: `hero-fullscreen`, `hero-gradient`, `hero-hub`, `hero-image`, `hero-plain`, `hero-split`
  - Tools: 11 client-side tool components
  - Shop: `cart.tsx`, `product-card.tsx`, `recently-viewed.tsx`
  - Booking: `booking-modal.tsx`
  - Contact: `contact-form.tsx`
  - Search: `search-command-palette.tsx`

---

## Data Files

20 TypeScript data files in `src/data/` covering services, tools, team, gallery, FAQ, blog posts, guides, knowledge base, shop products, and more.

## Store Files

- `cart-store.ts` — zustand, localStorage persistence
- `pet-store.ts` — zustand, localStorage persistence

---

## Business Info

| Field | Value |
|---|---|
| Name | Waggies |
| Address | Life Camp, Efab City Estate, 65 1st Ave, Abuja 900108, FCT, Nigeria |
| Phone | 0908 081 1902 / +234 908 081 1902 |
| WhatsApp | 2349080811902 (https://wa.me/2349080811902) |
| Email | hello@waggies.ng |
| Hours | Mon–Fri 9 AM–5 PM, Sat–Sun 10 AM–2 PM |
| Source | `src/lib/business-info.ts` |

---

## Design System Summary

- **Color mode:** Light only (no dark mode)
- **Brand primary:** Purple `#6B2C91`
- **Brand secondary:** `#E8D5B5`
- **Surface:** `#FDFBF7`
- **Color tokens:** OKLCH in `globals.css`
- **Fonts:** DM Sans (body), Cormorant Garamond (headings)
- **Icons:** Phosphor (primary), Lucide (legacy/discouraged)
- **Motion:** Framer Motion with `prefers-reduced-motion` respect
- **Design variance:** 4, Motion intensity: 2, Visual density: 4

---

## Navigation Structure

### Desktop (primary)
Services (flyout) → About (flyout) → Tools (flyout) → Resources (flyout) → Shop (plain) → **Book Now** CTA

### Mobile
Hamburger drawer with accordion groups + fixed bottom nav bar.

### Notable omissions
- **My Pets** is NOT in primary navigation (route exists but intentionally hidden).

---

## Infrastructure

- **No middleware** — no `middleware.ts` file exists.
- **No cron jobs** — no scheduled tasks.
- **No `.env.example`** — only `.env` with `DATABASE_URL`.
- **No production deployment** configured.
