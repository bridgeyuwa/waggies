# Waggies GLM-5.3 New Session Handoff Manifest

> **Purpose**: This manifest explains what the NEW GLM-5.3 session should receive and how to use each file.

---

## Transfer Archive

**File**: `WAGGIES-GLM53-NEW-SESSION-HANDOFF.zip`

This is the single compressed archive containing everything needed to continue Waggies development in a fresh session.

---

## File Index

### PROJECT/

| File | Description |
|------|-------------|
| `WAGGIES-GOLDEN-REFERENCE-HANDOFF.zip` | Complete current codebase ZIP. Contains `src/`, `public/`, `package.json`, `bun.lock`, `tsconfig.json`, `next.config.ts`, `postcss.config.mjs`, `components.json`, `prisma/schema.prisma`, and in-repo documentation. Excludes: node_modules, .next, .git, tool-results, db files, logs, .env secrets. |

### AUTHORITATIVE/

| File | Description |
|------|-------------|
| `WAGGIES_MASTER_PRODUCT_SPECIFICATION.md` | **HIGHEST AUTHORITY**. The definitive product specification. All implementation decisions must align with this document. Contains brand identity, navigation structure, service hierarchy, IA rules, design constraints, accessibility requirements, and all user-confirmed decisions. |
| `WAGGIES_USER_DECISIONS.md` | Decisions explicitly made by the user, organized by category. Use this to understand what has been settled (no reopening) vs. what is still open. |
| `WAGGIES_GOLDEN_REFERENCE.md` | Quick-reference summary of the authoritative product features, IA, business facts, design system, team, and known temporary assets. |

### ARCHITECTURE/

| File | Description |
|------|-------------|
| `WAGGIES_FEATURE_INVENTORY.md` | Complete inventory of every feature with route, implementation status, frontend/backend status, data source, persistence, limitations, and relevant files. |
| `WAGGIES_ROUTE_MAP.md` | Every route with canonical status, redirects, indexability, navigation location, breadcrumb hierarchy, SEO metadata, and structured data presence. |
| `WAGGIES_DATABASE_SCHEMA.md` | Proposed future Prisma schema (19 models). Clearly marked as **SCHEMA PREPARATION ONLY** — production backend is deferred. Current schema is Next.js template (User + Post). |
| `WAGGIES_CHATBOT_ARCHITECTURE.md` | Current state (keyword-matching prototype) and future vision (LLM + RAG + safety routing). **FUTURE is NOT implemented.** |

### DESIGN/

| File | Description |
|------|-------------|
| `WAGGIES_CURRENT_UI_STATE.md` | Implementation status of every UI system (tokens, colors, typography, radii, shadows, buttons, cards, nav, flyouts, footer, hero, chatbot, tools, gallery, forms, motion, responsive, icons). Status: IMPLEMENTED, PARTIAL, KNOWN ISSUE, or DEFERRED. |
| `WAGGIES_GOLDEN_ASSET_INVENTORY.md` | Every image slot across all pages, current Unsplash source, replacement target, and authenticity status. Confirms zero empty image slots. |

### QUALITY/

| File | Description |
|------|-------------|
| `WAGGIES_ACCESSIBILITY_STATE.md` | Actual WCAG 2.2 AA findings per criterion. Status: VERIFIED, UNVERIFIED, PARTIAL, FAIL, or DEFERRED. |
| `WAGGIES_RESPONSIVE_STATE.md` | Viewport-by-viewport test results (all currently UNVERIFIED). Responsive CSS is implemented but formal testing has not been done. |
| `WAGGIES_SEO_STATE.md` | SEO implementation status (sitemap, robots, canonicals, OG, breadcrumbs, JSON-LD, redirects). 10 known issues documented. |
| `WAGGIES_BUILD_STATUS.md` | Actual build/test status. Lint, typecheck, and build were NOT run. Dev server works. 8 known warnings documented. |

### HANDOFF/

| File | Description |
|------|-------------|
| `WAGGIES_HANDOFF_CURRENT_STATE.md` | Technical snapshot: git state, tech stack versions, dependency list, route count, component count, runtime limitations. |
| `WAGGIES_HANDOFF_MANIFEST.md` | **This file**. Explains the entire handoff package. |
| `WAGGIES_REMAINING_DECISIONS.md` | Genuinely unresolved items requiring user input. 8 items, 6 requiring user confirmation. |
| `WAGGIES_WHATSAPP_REQUEST_SCHEMA.md` | WhatsApp service request interface definition, message construction rules, and examples. |

---

## Authority Hierarchy

When documents conflict, this order resolves the conflict:

1. **WAGGIES_MASTER_PRODUCT_SPECIFICATION.md** — absolute authority
2. **WAGGIES_USER_DECISIONS.md** — explicit user decisions
3. **WAGGIES_GOLDEN_REFERENCE.md** — quick-reference truth
4. **Current codebase** — implementation evidence
5. Other handoff documents — supporting context

## Critical Rules for the New Session

1. **DO NOT start a redesign.** The Taste Skill v2 design language is locked.
2. **DO NOT make product decisions.** Use WAGGIES_MASTER_PRODUCT_SPECIFICATION.md as authority.
3. **Phosphor is the primary icon system.** Lucide is discouraged. Material Symbols are legacy.
4. **Light mode only.** No dark mode.
5. **WCAG 2.2 AA is mandatory.**
6. **Local Transport is under Relocation.** Canonical: /relocation/transport. /services/transport → 301 redirect.
7. **My Pets is removed from the product for this version.** Route exists but is hidden.
8. **Booking is a Request, not auto-confirmed.** WhatsApp fallback.
9. **All images are temporary Unsplash stock.** Zero empty slots. Not visibly labeled as stock.
10. **Three verified staff.** Others are placeholders pending client confirmation.

## Quick-Start for New Session

1. Extract `WAGGIES-GOLDEN-REFERENCE-HANDOFF.zip` to a working directory
2. Run `bun install`
3. Run `bun run dev` (starts on port 3000)
4. Read `WAGGIES_MASTER_PRODUCT_SPECIFICATION.md` first
5. Read `WAGGIES_REMAINING_DECISIONS.md` for open items
6. Read `WAGGIES_CURRENT_UI_STATE.md` and `WAGGIES_BUILD_STATUS.md` for current state
7. Continue implementation from where the current session left off