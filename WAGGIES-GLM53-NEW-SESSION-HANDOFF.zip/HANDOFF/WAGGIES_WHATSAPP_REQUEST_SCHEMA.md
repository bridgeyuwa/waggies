# Waggies WhatsApp Request Schema

> **Handoff Document** — Intended structured request object for WhatsApp-first conversion model

## Overview

Waggies uses a WhatsApp-first conversion model. All service requests, booking flows, and contact forms route to WhatsApp with structured, pre-populated context. The customer can edit the message before sending.

## WhatsApp Contact Details

| Field     | Value                       |
|-----------|-----------------------------|
| Number    | `2349080811902`             |
| Base URL  | `https://wa.me/2349080811902` |

Full message URL format:

```
https://wa.me/2349080811902?text=<URL_ENCODED_TEXT>
```

## TypeScript Interface

```typescript
interface WhatsAppServiceRequest {
  // ── Service Identification ──────────────────────────────
  service: string;           // e.g. "boarding", "grooming", "vet-care", "training",
                             //      "relocation-import", "relocation-export", "local-transport"
  serviceCategory: string;   // e.g. "Boarding", "Wellness", "Relocation"

  // ── Pet Information ────────────────────────────────────
  petName?: string;
  petType?: string;          // "dog", "cat", "exotic", "other"
  breed?: string;

  // ── Service Specifics ──────────────────────────────────
  package?: string;          // e.g. "standard", "premium", "basic"
  options?: string[];        // e.g. ["bath-and-dry", "nail-trim"]

  // ── Scheduling ─────────────────────────────────────────
  dates?: {
    checkIn?: string;        // ISO date, e.g. "2025-02-15"
    checkOut?: string;       // ISO date, e.g. "2025-02-18"
    preferredDate?: string;  // ISO date
    preferredTime?: string;  // e.g. "10:00 AM"
  };
  duration?: string;         // e.g. "3 nights", "1 hour"

  // ── Location (Transport / Relocation) ───────────────────
  location?: {
    pickup?: string;
    dropoff?: string;
    route?: string;          // e.g. "Abuja - Lagos"
    destination?: string;
  };

  // ── Pricing ─────────────────────────────────────────────
  estimate?: string;         // e.g. "₦15,000 - ₦25,000"
  pricingMode: 'FIXED' | 'ESTIMATED' | 'QUOTE_REQUIRED';

  // ── Customer Information ────────────────────────────────
  customerName?: string;
  phone?: string;
  email?: string;

  // ── Additional Context ──────────────────────────────────
  additionalMessage?: string;
  source: string;            // e.g. "contact-form", "booking-modal", "service-page-cta"
}
```

## Field Reference

| Field              | Type                               | Required | Description                                                      |
|--------------------|------------------------------------|----------|------------------------------------------------------------------|
| `service`          | `string`                           | Yes      | Machine-readable service identifier                               |
| `serviceCategory`  | `string`                           | Yes      | Human-readable service category name                              |
| `petName`          | `string?`                          | No       | Pet's name                                                       |
| `petType`          | `string?`                          | No       | Species: `dog`, `cat`, `exotic`, `other`                         |
| `breed`            | `string?`                          | No       | Pet breed                                                        |
| `package`          | `string?`                          | No       | Selected service tier/package                                    |
| `options`          | `string[]?`                        | No       | Add-on service options selected                                  |
| `dates.checkIn`    | `string?` (ISO date)               | No       | Boarding check-in or appointment start date                       |
| `dates.checkOut`   | `string?` (ISO date)               | No       | Boarding check-out date                                           |
| `dates.preferredDate` | `string?` (ISO date)            | No       | Preferred date for one-off services                               |
| `dates.preferredTime` | `string?`                       | No       | Preferred time slot                                              |
| `duration`         | `string?`                          | No       | Service duration in human-readable form                           |
| `location.pickup`  | `string?`                          | No       | Pickup address                                                   |
| `location.dropoff` | `string?`                          | No       | Drop-off address                                                 |
| `location.route`   | `string?`                          | No       | Route description (e.g. "Abuja - Lagos")                        |
| `location.destination` | `string?`                     | No       | Final destination                                                |
| `estimate`         | `string?`                          | No       | Price range display string                                       |
| `pricingMode`      | `'FIXED' \| 'ESTIMATED' \| 'QUOTE_REQUIRED'` | Yes | How pricing is communicated to customer                           |
| `customerName`     | `string?`                          | No       | Customer's full name                                             |
| `phone`            | `string?`                          | No       | Customer's phone number                                          |
| `email`            | `string?`                          | No       | Customer's email address                                         |
| `additionalMessage`| `string?`                          | No       | Free-text additional notes from customer                          |
| `source`           | `string`                           | Yes      | Where the request originated (for analytics)                      |

## Message Construction Rules

### 1. Convert to Readable WhatsApp Text (NOT JSON)

The `WhatsAppServiceRequest` object is NEVER sent as JSON. It is converted into a human-readable, structured plain text message before being URL-encoded.

### 2. URL Encoding

The constructed text message MUST be passed through `encodeURIComponent()` before being appended to the WhatsApp URL:

```typescript
const message = buildWhatsAppMessage(request); // returns plain text string
const url = `https://wa.me/2349080811902?text=${encodeURIComponent(message)}`;
```

### 3. Fallback Behavior

If WhatsApp link opening fails (e.g., no WhatsApp installed, network error):
- Display the phone number `2349080811902` as a fallback
- Provide a "copy number" action
- Never silently fail — always show a usable contact option

### 4. User-Editable Message

The WhatsApp pre-populated message is always user-editable. The customer can modify any field before sending. This is a feature, not a bug — it allows customers to add context or correct information.

## Message Template

The generated text should follow this structure:

```🐾 *Waggies Pet Care - Service Request*

*Service:* {serviceCategory} - {formatted service name}
*Package:* {package} (if applicable)
*Options:* {comma-separated options} (if any)

*Pet:* {petName} ({petType}, {breed})

*Dates:* {checkIn} to {checkOut} ({duration})
*Time:* {preferredTime} (if applicable)

*Location:* {route or pickup/dropoff} (if applicable)
*Pricing:* {estimate or pricingMode description}

*Name:* {customerName}
*Phone:* {phone}
*Email:* {email}

{additionalMessage}

---
Sent from: {source}
```

## Service-Specific Examples

### Example 1: Boarding Request

```typescript
const boardingRequest: WhatsAppServiceRequest = {
  service: "boarding",
  serviceCategory: "Boarding",
  petName: "Buddy",
  petType: "dog",
  breed: "Golden Retriever",
  package: "premium",
  options: ["daily-walk", "playtime"],
  dates: {
    checkIn: "2025-02-15",
    checkOut: "2025-02-18",
    preferredTime: "10:00 AM",
  },
  duration: "3 nights",
  estimate: "₦45,000 - ₦60,000",
  pricingMode: "ESTIMATED",
  customerName: "Aisha Ibrahim",
  phone: "2348012345678",
  email: "aisha@example.com",
  source: "booking-modal",
};
```

Generated WhatsApp message:

```
🐾 Waggies Pet Care - Service Request

Service: Boarding
Package: premium
Options: daily-walk, playtime

Pet: Buddy (dog, Golden Retriever)

Dates: 2025-02-15 to 2025-02-18 (3 nights)
Time: 10:00 AM

Pricing: ₦45,000 - ₦60,000

Name: Aisha Ibrahim
Phone: 2348012345678
Email: aisha@example.com

---
Sent from: booking-modal
```

### Example 2: Grooming Request

```typescript
const groomingRequest: WhatsAppServiceRequest = {
  service: "grooming",
  serviceCategory: "Wellness",
  petName: "Luna",
  petType: "cat",
  breed: "Persian",
  package: "standard",
  options: ["bath-and-dry", "nail-trim", "ear-cleaning"],
  dates: {
    preferredDate: "2025-02-20",
    preferredTime: "2:00 PM",
  },
  duration: "1.5 hours",
  estimate: "₦15,000",
  pricingMode: "FIXED",
  customerName: "Chidi Okafor",
  phone: "2349012345678",
  source: "service-page-cta",
};
```

Generated WhatsApp message:

```
🐾 Waggies Pet Care - Service Request

Service: Wellness
Package: standard
Options: bath-and-dry, nail-trim, ear-cleaning

Pet: Luna (cat, Persian)

Dates: 2025-02-20
Time: 2:00 PM
Duration: 1.5 hours

Pricing: ₦15,000

Name: Chidi Okafor
Phone: 2349012345678

---
Sent from: service-page-cta
```

### Example 3: Transport/Relocation Request

```typescript
const transportRequest: WhatsAppServiceRequest = {
  service: "relocation-export",
  serviceCategory: "Relocation",
  petName: "Max",
  petType: "dog",
  breed: "German Shepherd",
  location: {
    pickup: "Lagos, Nigeria",
    dropoff: "London, UK",
    route: "Lagos - London (International)",
    destination: "London Heathrow Airport",
  },
  estimate: "₦350,000 - ₦500,000 (varies by airline/season)",
  pricingMode: "QUOTE_REQUIRED",
  customerName: "Folake Adeyemi",
  phone: "2347012345678",
  email: "folake@example.com",
  additionalMessage: "Need help with veterinary paperwork and UK import permit.",
  source: "contact-form",
};
```

Generated WhatsApp message:

```
🐾 Waggies Pet Care - Service Request

Service: Relocation

Pet: Max (dog, German Shepherd)

Location: Lagos - London (International)
Pickup: Lagos, Nigeria
Dropoff: London Heathrow Airport

Pricing: Quote required

Name: Folake Adeyemi
Phone: 2347012345678
Email: folake@example.com

Need help with veterinary paperwork and UK import permit.

---
Sent from: contact-form
```

## Integration Points

| Trigger Location             | Fields Typically Populated          |
|------------------------------|--------------------------------------|
| Contact form (`/contact`)    | All customer fields, service, message |
| Booking modal                | Service, pet, dates, package, options |
| Service page CTA             | Service, serviceCategory, estimate   |
| Chatbot escalation           | Service (if detected), message       |
