# Waggies — Remaining Decisions

Genuinely unresolved items requiring user input or action. Does NOT include already-resolved questions.

---

## 1. Homepage Hero Final Composition

- **Issue:** User said the hero must be "image-led and visually distinctive" but has not approved a specific layout or composition.
- **Why it matters:** The hero is the first impression and sets the visual tone for the entire site. It needs visual quality authority.
- **Options:**
  - `HeroSplit` — image on one side, text on the other
  - `HeroImage` — full-bleed image with overlaid text
  - `HeroGradient` — gradient background with imagery
  - `HeroFullscreen` — immersive full-viewport hero
  - Custom composition
- **Recommended:** Taste Skill evaluation to select the optimal composition based on available imagery and brand guidelines.
- **Requires user confirmation:** **Yes** — user must approve the final hero design.

---

## 2. Authentic Photography

- **Issue:** All images on the site are currently Unsplash stock. The client has not supplied any real Waggies photography.
- **Why it matters:** A pet care business needs authentic brand imagery for credibility and trust. Stock photos undermine the premium, trust-first positioning.
- **Options:**
  - Wait for the client to supply real photos (delays launch)
  - Hire a professional photographer in Abuja
  - Use AI-generated brand-consistent imagery as an interim solution
- **Recommended:** Request client photos for priority slots (hero, team photos, gallery) as a near-term action. Consider AI-generated imagery for lower-priority slots.
- **Requires user confirmation:** **Yes** — client needs to decide on photography plan and provide real images.

---

## 3. Placeholder Team Members (5 unverified)

- **Issue:** Five team members have placeholder profiles with unverified names, roles, and stock photos: Chukwuma Eze (Vet Support), Amina Bello (Lead Groomer), Dayo Adekunle (Boarding Manager), Kemi Ogunleye (Pet Trainer), Suleiman Ahmadu (Relocation & Transport).
- **Why it matters:** Publishing unverified staff profiles with fabricated names/roles is a credibility and legal risk.
- **Options:**
  - Keep as placeholders with a disclosure note (undermines trust)
  - Remove all unverified profiles and show only the 3 verified staff
  - Get client to verify or provide the correct staff roster
- **Recommended:** Request the client to verify the existing placeholder profiles or provide the correct staff roster with names, roles, titles, and photos.
- **Requires user confirmation:** **Yes** — client must provide verified staff information.

---

## 4. Lucide Icon Cleanup

- **Issue:** `lucide-react` remains in `package.json` and may still be imported in some components. This violates the icon policy (Phosphor is primary, Lucide is discouraged).
- **Why it matters:** Inconsistent icon libraries increase bundle size and violate the design system.
- **Options:**
  - Full audit of all imports, replace with Phosphor equivalents, remove `lucide-react` from dependencies
  - Leave as-is (not recommended)
- **Recommended:** Full audit and replacement. Search all files for `lucide-react` imports, map each to the Phosphor equivalent, update imports, and remove the package.
- **Requires user confirmation:** **No** — already decided. Phosphor is primary. This is a cleanup task.

---

## 5. Invalid favicon.ico

- **Issue:** The current `favicon.ico` is 223 bytes, which is almost certainly corrupt or a placeholder.
- **Why it matters:** A broken favicon looks unprofessional in browser tabs and bookmarks.
- **Options:**
  - Create a proper Waggies favicon from the SVG logo
  - Remove the favicon temporarily until a proper one is created
- **Recommended:** Create a proper favicon from the Waggies SVG logo (generate multiple sizes: 16x16, 32x32, 180x180 apple-touch-icon).
- **Requires user confirmation:** **No** — implied fix. This is a technical cleanup task.

---

## 6. Production Deployment Domain

- **Issue:** `NEXT_PUBLIC_SITE_URL` is not set. Canonical URLs, Open Graph tags, and the sitemap all depend on knowing the production URL.
- **Why it matters:** Without a production URL, SEO metadata (canonicals, OG tags, sitemap) will use incorrect or fallback values.
- **Options:**
  - Client provides the production domain (e.g., `https://waggies.ng`)
  - Use a placeholder domain for development (not suitable for production)
- **Recommended:** Client must provide the production domain name.
- **Requires user confirmation:** **Yes** — client must provide the production URL.

---

## 7. Chatbot Backend

- **Issue:** The AI chatbot is currently a keyword-matching prototype. The target state is an LLM-powered chatbot with Waggies-specific RAG (Retrieval-Augmented Generation).
- **Why it matters:** The keyword-matching prototype provides a poor user experience and cannot handle the breadth of questions a pet care site receives.
- **Options:**
  - Implement LLM backend with Waggies knowledge base (RAG) and safety routing for medical questions
  - Keep the keyword-matching prototype for launch
  - Remove the chatbot entirely until a proper backend is ready
- **Recommended:** Implement LLM backend with RAG, with safety routing that directs medical/veterinary questions to the disclaimer and vet contact.
- **Requires user confirmation:** **Yes** — client needs to approve the chatbot approach and budget for LLM API costs.

---

## 8. Social Media URLs

- **Issue:** Social media links in the footer and elsewhere currently use placeholder URLs (e.g., `instagram.com/waggies`). These may point to non-existent or incorrect profiles.
- **Why it matters:** Links to non-existent profiles damage credibility. Links to wrong profiles mislead users.
- **Options:**
  - Get verified social media URLs from the client
  - Remove all social links until real URLs are available
  - Keep placeholders (not recommended)
- **Recommended:** Get verified social media URLs from the client for each platform (Instagram, Facebook, Twitter/X, TikTok, etc.).
- **Requires user confirmation:** **Yes** — client must provide verified social media handles/URLs.

---

## Summary

| # | Item | Needs User Confirmation? | Type |
|---|---|---|---|
| 1 | Homepage hero composition | Yes | Design |
| 2 | Authentic photography | Yes | Content |
| 3 | Placeholder team verification | Yes | Content |
| 4 | Lucide icon cleanup | No (already decided) | Technical |
| 5 | Invalid favicon | No (implied fix) | Technical |
| 6 | Production domain | Yes | Infrastructure |
| 7 | Chatbot backend | Yes | Feature |
| 8 | Social media URLs | Yes | Content |
