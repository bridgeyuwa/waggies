# Waggies SEO State

> **Handoff Document** — Current SEO implementation status and known gaps

---

## Implementation Status Summary

| # | Area                  | Status     | File(s)                                   |
|---|-----------------------|------------|-------------------------------------------|
| 1 | Sitemap               | IMPLEMENTED| `src/app/sitemap.ts`                      |
| 2 | Robots.txt            | IMPLEMENTED| `src/app/robots.ts`                       |
| 3 | Canonical URLs        | IMPLEMENTED| `src/app/layout.tsx` (metadataBase)       |
| 4 | Metadata              | IMPLEMENTED| `src/app/layout.tsx`                      |
| 5 | Open Graph            | PARTIAL    | `src/app/layout.tsx`                      |
| 6 | Breadcrumbs           | IMPLEMENTED| `src/components/breadcrumb-schema.tsx`    |
| 7 | JSON-LD               | PARTIAL    | `src/components/breadcrumb-schema.tsx`, `src/components/json-ld.tsx` |
| 8 | Internal Linking      | IMPLEMENTED| Service pages, footer, navbar             |
| 9 | Search Index          | IMPLEMENTED| `src/lib/search-index.ts`                 |
| 10| Tool SEO              | PARTIAL    | Tool pages have metadata exports           |
| 11| Redirect Integrity    | IMPLEMENTED| `next.config.ts`                          |
| 12| Page Titles           | IMPLEMENTED| `src/app/layout.tsx` (title template)     |

---

## 1. Sitemap — IMPLEMENTED

**File**: `src/app/sitemap.ts`

- Dynamically generates sitemap entries for all public routes
- Approximately 35+ entries covering:
  - Homepage
  - All service pages
  - About page
  - Contact page
  - FAQ page
  - Tools pages (11 tools + tools hub)
  - Loyalty page
  - Gallery page
  - Other public pages
- Excludes `/my-pets` (authenticated/private route)
- Each entry has `priority` and `changeFrequency` where appropriate
- Format: Next.js native sitemap generation (returns `MetadataRoute.Sitemap`)

## 2. Robots.txt — IMPLEMENTED

**File**: `src/app/robots.ts`

- `User-agent: *`
- `Allow: /`
- `Disallow: /my-pets`
- Sitemap URL reference included
- **Note**: Does not disallow `/api/` (no API routes exist yet)

## 3. Canonical URLs — IMPLEMENTED

**File**: `src/app/layout.tsx`

- `metadataBase` set from `siteConfig.siteUrl`
- Applied via Next.js `generateMetadata` / root layout metadata export
- **Known issue**: `NEXT_PUBLIC_SITE_URL` environment variable is not set, so `siteConfig.siteUrl` defaults to `http://localhost:3000` in development. Canonical URLs in dev point to localhost.

## 4. Metadata — IMPLEMENTED

**File**: `src/app/layout.tsx`

Root layout exports:
- `title` — uses template: `"%s - Waggies"`
- `description` — site-wide default description
- `keywords` — relevant pet care keywords
- `authors` — Waggies brand
- `robots` — index/follow directives
- Open Graph fields (see #5)
- Twitter card metadata

Individual pages can override via `generateMetadata` or `metadata` export.

## 5. Open Graph — PARTIAL

**File**: `src/app/layout.tsx`

Implemented:
- `og:type` — set to `"website"`
- `og:locale` — set
- `og:url` — set
- `og:site_name` — set
- `og:title` — set (uses title template)
- `og:description` — set

Missing:
- **`og:image`** — NOT set. `defaultOgImage` is `undefined` in `site.tsx`. Social sharing previews will have no image.
- `og:image:width` / `og:image:height` — not set (depends on og:image)
- Per-page OG images — not implemented

## 6. Breadcrumbs — IMPLEMENTED

**Files**:
- `src/components/breadcrumb-schema.tsx` — `BreadcrumbSchema` component
- Used on inner pages (services, about, tools, etc.)

- Renders JSON-LD `BreadcrumbList` structured data
- Visual breadcrumb navigation rendered alongside structured data
- Helps search engines understand page hierarchy

## 7. JSON-LD — PARTIAL

**Files**:
- `src/components/breadcrumb-schema.tsx`
- `src/components/json-ld.tsx`

Implemented:
- BreadcrumbList schema on inner pages
- General JSON-LD helper component exists

Missing:
- No `Organization` schema
- No `LocalBusiness` schema (critical for a local service business)
- No `Service` schema for individual service pages
- No `FAQPage` schema for the FAQ page
- No `Product` schema (if shop becomes transactional)

## 8. Internal Linking — IMPLEMENTED

- Service pages link to related/other services
- Footer contains links to all major sections
- Navigation flyouts provide deep linking to sub-pages
- Tools link to relevant service pages
- Homepage links to all major sections

## 9. Search Index — IMPLEMENTED

**File**: `src/lib/search-index.ts`

- Indexes all public pages for the command palette (`Cmd+K` search)
- Includes page title, description, URL, and keywords
- Used by `search-command-palette.tsx`
- ~40+ indexed entries
- Client-side search (no server-side search API)

## 10. Tool SEO — PARTIAL

- Each tool page (`/tools/[slug]`) has a `metadata` export with title and description
- Tools hub page (`/tools`) has metadata

Missing:
- No `FAQPage` structured data on tool pages (even though tools have Q&A-style content)
- No `HowTo` or `SoftwareApplication` schema for interactive tools
- Dynamic routes may need `generateMetadata` for per-tool SEO customization

## 11. Redirect Integrity — IMPLEMENTED

**File**: `next.config.ts`

- `/services/transport` → `301` → `/relocation/transport`
- Implemented via `redirects()` in Next.js config
- No middleware file exists (redirects handled at config level)

## 12. Page Titles — IMPLEMENTED

**File**: `src/app/layout.tsx`

- Title template: `"%s - Waggies"`
- Individual pages set their page-specific title via metadata export
- Examples: "Grooming - Waggies", "Pet Age Calculator - Waggies"

---

## Known Issues

| Issue                                              | Severity | Action Required                                        |
|----------------------------------------------------|----------|--------------------------------------------------------|
| No OG image set (`defaultOgImage: undefined`)      | High     | Create and set a 1200x630 OG image for social sharing |
| Canonical URLs point to localhost in dev           | Medium   | Set `NEXT_PUBLIC_SITE_URL` in `.env` for production    |
| robots.txt doesn't disallow `/api/`                | Low      | Add disallow when API routes are created               |
| No hreflang tags (single locale site)              | Low      | Not needed for single-locale; add if expanding         |
| No `LocalBusiness` JSON-LD schema                  | Medium   | Critical for local SEO — add Organization/LocalBusiness|
| No `FAQPage` JSON-LD on FAQ page                   | Medium   | Would enhance FAQ page search presence                 |
| No `Service` JSON-LD on service pages              | Medium   | Would enhance service page search presence             |
| Dynamic routes may need `generateMetadata`         | Low      | Audit blog/[slug] and similar for per-page metadata    |
| No middleware file                                  | Low      | May be needed for auth redirects, i18n, etc.           |
| Tool pages lack structured data                    | Low      | Add FAQPage/HowTo schema as appropriate                |

## Recommendations (Priority Order)

1. **Create and set OG image** — Highest SEO impact for social sharing
2. **Add `LocalBusiness` JSON-LD** — Critical for local search / Google Business Profile
3. **Set `NEXT_PUBLIC_SITE_URL`** in production environment for correct canonical URLs
4. **Add `FAQPage` JSON-LD** on FAQ page for rich results
5. **Add `Service` JSON-LD** on individual service pages
6. **Create `.env.example`** documenting required environment variables
7. **Audit dynamic routes** for per-page `generateMetadata` implementation