# Waggies Responsive State — Viewport Verification

> Generated for handoff. Last updated: documentation pass.
> Note: Responsive CSS patterns ARE implemented. The issue is **lack of formal verification**, not lack of implementation.

## Implementation Summary

The following responsive patterns are in place:
- **Mobile-first** Tailwind breakpoints: `sm(640)`, `md(768)`, `lg(1024)`, `xl(1280)`, `2xl(1536)`.
- **Fluid typography** via `clamp()` for headings.
- **Mobile navigation**: Hamburger drawer with accordion groups + fixed bottom nav bar.
- **Desktop navigation**: Horizontal nav with flyout menus.
- **Responsive grids** using Tailwind grid utilities (`grid-cols-1 md:grid-cols-2 lg:grid-cols-3`, etc.).
- **`dvh` units** for chatbot panel viewport containment.
- **Content container**: `max-w-7xl` with responsive padding `px-4 md:px-10 lg:px-12`.
- **Section spacing**: `py-20` with potential responsive overrides.

---

## Viewport Testing Status

All viewports listed below are **UNVERIFIED** — responsive CSS is written but no formal visual/functional QA has been performed at these widths.

| Viewport Width | Device Context | Status |
|---|---|---|
| 320px | Small Android (e.g., Galaxy Fold cover screen) | UNVERIFIED |
| 360px | Budget Android | UNVERIFIED |
| 375px | iPhone SE / iPhone 12 Mini | UNVERIFIED |
| 390px | iPhone 14 / 15 | UNVERIFIED |
| 414px | iPhone 12/13 Pro Max | UNVERIFIED |
| 430px | iPhone 14/15 Pro Max | UNVERIFIED |
| 768px | iPad portrait / small laptop | UNVERIFIED |
| 820px | iPad Air portrait | UNVERIFIED |
| 1024px | iPad landscape / laptop | UNVERIFIED |
| 1280px | Standard laptop / small desktop | UNVERIFIED |
| 1440px | Large laptop / desktop | UNVERIFIED |
| 1920px | Full HD desktop | UNVERIFIED |
| 2560px | QHD / 4K desktop | UNVERIFIED |

---

## Interaction Mode Testing

| Mode | Status | Notes |
|---|---|---|
| Portrait orientation | UNVERIFIED | — |
| Landscape orientation | UNVERIFIED | — |
| Touch interaction | UNVERIFIED | 44px targets enforced but not tap-tested on device |
| Keyboard-only navigation | PARTIAL | Flyout keyboard nav (ArrowUp/Down/Escape) verified |
| Reduced motion | VERIFIED | CSS `prefers-reduced-motion` + Framer Motion `useReducedMotion` |
| Zoom/reflow at 200% | UNVERIFIED | No `maximum-scale` restriction; reflow not tested |

---

## Known Responsive Risks

1. **Bottom nav + FAB collision** — Repositioning logic exists in `floating-actions.tsx` but not tested at 375px–430px where both are visible.
2. **Flyout menus on tablet** — 768px–1024px is the transition zone between mobile drawer and desktop flyouts; hover behavior may conflict with touch.
3. **Hero split layout** — Asymmetric hero may not degrade gracefully below 375px.
4. **Gallery lightbox** — Not verified for correct viewport containment at small widths.
5. **Tools pages** — 11 tools with varying form layouts; not verified for reflow at 320px.
6. **Contact page** — Google Maps embed + form side-by-side may stack unexpectedly at mid breakpoints.

---

## Recommended Testing Plan

1. **Browser DevTools**: Test all 13 viewport widths listed above using Chrome/Firefox responsive mode.
2. **Physical devices**: Test on at least one small Android (≤375px) and one iPhone (390px or 430px).
3. **Tablet**: Test at 768px and 820px in both portrait and landscape.
4. **Key pages to test**: Homepage, Services, Contact, Gallery, any Tool page, Booking modal.
5. **Zoom**: Test 200% zoom at 1280px and 1920px base widths.
6. **Touch**: Verify all 44px targets are actually tappable without misfires on a real device.
