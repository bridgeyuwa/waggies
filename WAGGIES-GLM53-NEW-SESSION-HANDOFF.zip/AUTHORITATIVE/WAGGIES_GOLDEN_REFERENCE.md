# Waggies Golden Reference

## Authoritative Product Features
- Pet Boarding (dogs, cats, exotic)
- Pet Grooming
- Veterinary Care (on-site DVM)
- Dog Training (positive reinforcement)
- Pet Relocation (import, export, local transport)
- Pet Shop (cart, localStorage persistence)
- Pet Profiles (My Pets, localStorage, NOT in primary nav)
- Booking (request-only, honest state, WhatsApp fallback)
- AI Chatbot (preview/prototype, honestly labeled)
- 11 Pet Care Tools (with medical disclaimers where applicable)
- Gallery (populated with temporary stock)
- Blog, Guides, Knowledge Base
- FAQ
- Search (command palette with all public pages indexed)
- Newsletter
- Loyalty Programme

## Final Information Architecture

### Primary Navigation (desktop)
1. Services (flyout: Boarding, Wellness, Relocation)
2. About (flyout: About Us, Testimonials, Gallery, Careers, Partnerships)
3. Tools (flyout: all 11 tools)
4. Resources (flyout: FAQ, Blog, Guides, Knowledge Base)
5. Shop (plain link)
6. Book Now CTA button

### Services Hierarchy
Services
├── Boarding
│   ├── Boarding
│   ├── Dog Boarding
│   ├── Cat Boarding
│   └── Exotic Pet Boarding
├── Wellness (grouping label only, no page)
│   ├── Grooming
│   ├── Veterinary Care
│   └── Training
└── Relocation
    ├── Relocation (hub)
    ├── Pet Import
    ├── Pet Export
    └── Local Transport

### Canonical Routes
/services, /services/boarding, /services/boarding/dogs, /services/boarding/cats, /services/boarding/exotic, /services/grooming, /services/vet-care, /services/training, /services/pricing
/relocation, /relocation/import, /relocation/export, /relocation/transport, /relocation/checklist
/services/transport → 301 redirect → /relocation/transport
/about, /about/testimonials, /about/gallery, /about/careers, /about/partnerships
/tools, /tools/symptom-checker, /tools/pet-age-calculator, /tools/vaccination-schedule, /tools/cost-calculator, /tools/medication-dosage-guide, /tools/nutrition-calculator, /tools/emergency-guide, /tools/new-pet-checklist, /tools/parasite-schedule, /tools/behavior-tips, /tools/breed-finder
/blog, /guides, /knowledge-base, /faq
/shop, /shop/[id]
/contact
/my-pets (NOT in primary nav, NOT in sitemap)
/privacy-policy, /terms-of-service, /cookies-policy

## Business Facts
- Name: Waggies
- Address: Life Camp, Efab City Estate, 65 1st Ave, Abuja 900108, FCT, Nigeria
- Phone: 0908 081 1902 / +234 908 081 1902
- WhatsApp: 2349080811902
- Email: hello@waggies.ng
- Hours: Mon-Fri 9AM-5PM, Sat-Sun 10AM-2PM
- Source: src/lib/business-info.ts

## Design System
- Framework: Next.js 16, Tailwind CSS 4, shadcn/ui
- Colors: Waggies brand (purple/cream), light-mode only
- Icon family: Phosphor (primary), Lucide discouraged, Material Symbols removed from redesigned surfaces
- Motion: Framer Motion (restrained), prefers-reduced-motion respected
- Typography: Serif for headlines, sans-serif for body

## Team
- Dr. Nguhemen Doose Yuwa (DVM) — Head Veterinarian and Director [VERIFIED]
- Aifuwa Bob Osaze — Director [VERIFIED]
- Oghomwen Oyuki Obaseki — Secretary [VERIFIED]
- Chukwuma Eze — Veterinary Support [PLACEHOLDER]
- Amina Bello — Lead Groomer [PLACEHOLDER]
- Dayo Adekunle — Boarding Manager [PLACEHOLDER]
- Kemi Ogunleye — Pet Trainer [PLACEHOLDER]
- Suleiman Ahmadu — Relocation & Transport Coordinator [PLACEHOLDER]

## Accessibility Standard
- WCAG 2.2 AA targeted
- Contrast: All text at /60 opacity or higher
- Touch targets: Minimum 44x44px
- Focus visibility: 2px primary outline, 2px offset
- Keyboard: All flyouts support ArrowUp/Down/Escape
- Reduced motion: All animations respect prefers-reduced-motion

## SEO
- sitemap.ts: Dynamic, all public routes (excludes /my-pets)
- robots.ts: Allow all, disallow /my-pets
- Canonical URLs on all pages
- BreadcrumbSchema on all inner pages
- JsonLd structured data where applicable

## Deferred Backend Work
- Booking: No actual backend submission; shows "Booking Request Sent" with WhatsApp fallback
- Auth: NextAuth available but not configured
- Database: Prisma available but schema not yet used for production data
- Cart: localStorage only; server persistence deferred
- Pet Profiles: localStorage only; auth/database integration deferred
- AI Chatbot: Prototype with keyword matching; real LLM backend deferred

## Known Temporary Assets
- ALL images are temporary Unsplash stock
- See GOLDEN_ASSET_INVENTORY.md for full mapping
