# SALVAGE REPORT — Waggies AI-Slop Analysis

> **Generated**: Forensic analysis of `upload/waggies-ai-slop.tar`
> **Analyzed**: 2026-08-19
> **Tar commit HEAD**: `73f2c71` (2026-08-19 02:04:21 UTC)
> **Current repo baseline**: `f2d2a75` / `26388fe` (clean scaffold)
> **Build window**: 2026-08-18 17:26 → 2026-08-19 02:04 (~8.5 hours, 11 commits)

---

## BASELINE IDENTIFICATION

| Property | Value |
|---|---|
| **Current repo clean baseline** | `26388fe` (Initial commit) — contains only `.env`, `.gitignore`, `download/README.md` |
| **Current repo latest** | `f2d2a75` (scaffold + shadcn/ui setup — no Waggies code) |
| **Tar HEAD** | `73f2c71` (complete 8-hour Waggies build) |
| **Tar initial commit** | `ce51842` (identical scaffold — `.env`, `.gitignore`, `download/README.md`) |

**CRITICAL FINDING**: The current repo (`/home/z/my-project`) contains NO Waggies application code. The entire Waggies project exists exclusively inside the tar file. There is no "clean Waggies" commit in either git history — the scaffold was empty, and all Waggies code was generated in one 11-commit autonomous session.

---

## VIOLATION SUMMARY (at a glance)

| Violation | Scope | Severity |
|---|---|---|
| Platform-coupled images (`z-cdn.chatglm.cn`) | 11 data/component files, **143 references** | HIGH |
| Dark mode (`next-themes`, `dark:` classes) | `layout.tsx`, `globals.css` (36 `.dark` rules), **15 components with 201 `dark:` references** | HIGH |
| AI Chatbot | `chatbot-widget.tsx`, `lazy-chatbot-widget.tsx`, `api/chat/route.ts` | HIGH |
| Pet Symptom Checker | `symptom-checker.tsx`, `symptom-checker-section.tsx`, `symptom-data.ts` (542 lines) | HIGH |
| Shopping Cart / E-commerce | `cart-button.tsx`, `cart-drawer.tsx`, `cart-store.ts`, `shop/` pages, `product-card.tsx`, `recently-viewed-store.ts` | HIGH |
| Animated gradient mesh hero | `hero-gradient-mesh.tsx` | MEDIUM |
| Floating paw prints | `floating-particles.tsx` | MEDIUM |
| AI-hallucinated blog content | `blog-posts.ts` (31 posts, 657 lines) | HIGH |
| AI-hallucinated guide content | `guide-posts.ts` (14 guides, 329 lines) | HIGH |
| Faker-seeded KB content | `kb-articles.ts` (155KB, 90 z-cdn refs) | HIGH |
| Unprovenanced shop products | `shop.ts` (13 products, 2 z-cdn refs) | HIGH |
| `next-themes` package dependency | `package.json` | MEDIUM |
| `z-cdn.chatglm.cn` in `next.config.ts` `remotePatterns` | `next.config.ts` line 79 | LOW |

---

## CATEGORY A: DISCARD — Violates v4.0 Audit / AI-Slop

> These files **must be discarded** or heavily rewritten. They contain hallucinated content, platform-coupled resources, dark mode, or features explicitly prohibited by the v4.0 audit.

### A1. AI-Hallucinated Content Data (fake articles)

| File | Lines | What's wrong |
|---|---|---|
| `src/data/blog-posts.ts` | 657 | 31 AI-generated blog posts. Header says "All content is original, written for the Waggies brand." No Laravel source. Uses Unsplash images. |
| `src/data/guide-posts.ts` | 329 | 14 AI-generated guides. Same provenance as blog-posts. Uses Unsplash images. |
| `src/data/kb-articles.ts` | 4,192 (155KB) | 2 KB articles seeded from Faker (Latin lorem-ipsum per header). **90 z-cdn.chatglm.cn image URLs**. |
| `src/data/shop.ts` | 283 | 13 e-commerce products with no Laravel provenance. **2 z-cdn URLs**. |

### A2. AI Chatbot System

| File | Lines | What's wrong |
|---|---|---|
| `src/components/waggies/chatbot-widget.tsx` | ~500 | Full AI pet care chatbot with LLM integration |
| `src/components/waggies/lazy-chatbot-widget.tsx` | ~30 | Lazy wrapper for chatbot |
| `src/app/api/chat/route.ts` | ~60 | Backend chat endpoint using z-ai-web-dev-sdk |

### A3. Pet Symptom Checker

| File | Lines | What's wrong |
|---|---|---|
| `src/components/waggies/symptom-checker.tsx` | ~400 | Interactive pet symptom triage tool |
| `src/components/waggies/symptom-checker-section.tsx` | ~60 | Section wrapper for symptom checker |
| `src/lib/symptom-data.ts` | 542 | Symptom database for dogs, cats, birds, rabbits |

### A4. Shopping Cart / E-commerce

| File | Lines | What's wrong |
|---|---|---|
| `src/components/waggies/cart-button.tsx` | ~80 | Floating cart button with badge |
| `src/components/waggies/cart-drawer.tsx` | ~300 | Cart slide-out drawer |
| `src/lib/cart-store.ts` | ~60 | Zustand cart state (localStorage-persisted) |
| `src/lib/recently-viewed-store.ts` | ~40 | Zustand recently-viewed state |
| `src/app/shop/page.tsx` | ~100 | E-commerce shop listing page |
| `src/app/shop/[id]/page.tsx` | ~120 | Product detail page |
| `src/components/waggies/product-card.tsx` | ~100 | Product card component |
| `src/components/waggies/sections/shop-page-client.tsx` | ~80 | Shop page client logic |
| `src/components/waggies/sections/home-shop-section.tsx` | ~60 | Homepage shop section |
| `src/components/waggies/sections/product-detail-client.tsx` | ~200 | Product detail client logic |
| `src/components/waggies/sections/recently-viewed.tsx` | ~50 | Recently viewed products section |

### A5. Dark Mode System

| File | What's wrong |
|---|---|
| `src/components/waggies/theme-toggle.tsx` | Sun/moon toggle using `next-themes` |
| `src/app/globals.css` | **36 `.dark` CSS rules** (Tailwind dark mode variant) |
| `src/app/layout.tsx` | `ThemeProvider` from `next-themes` wrapping entire app (line 17, 157, 175) |

### A6. Animated Gradient Mesh Hero

| File | What's wrong |
|---|---|
| `src/components/waggies/hero-gradient-mesh.tsx` | 4 blurred color blobs drifting with framer-motion. Has separate `dark` mode variants. Violates audit. |

### A7. Floating Paw Prints

| File | What's wrong |
|---|---|
| `src/components/waggies/floating-particles.tsx` | 8-12 floating paw-print particles using framer-motion infinite animations. Decorative "ai-slop" per audit. |

### A8. Pages Routed to Discarded Content

These page files render the AI-hallucinated content and cannot exist without it:

| File | Reason |
|---|---|
| `src/app/blog/page.tsx` | Renders 31 fake blog posts |
| `src/app/blog/[slug]/page.tsx` | Renders individual fake blog post |
| `src/app/blog/category/[slug]/page.tsx` | Renders fake blog posts by category |
| `src/app/blog/[slug]/opengraph-image.tsx` | OG image for fake blog posts |
| `src/app/blog/[slug]/twitter-image.tsx` | Twitter card for fake blog posts |
| `src/app/guides/page.tsx` | Renders 14 fake guides |
| `src/app/guides/[slug]/page.tsx` | Renders individual fake guide |
| `src/app/guides/category/[slug]/page.tsx` | Renders fake guides by category |
| `src/app/knowledge-base/page.tsx` | Renders Faker-seeded KB articles |
| `src/app/knowledge-base/[slug]/page.tsx` | Renders individual fake KB article |
| `src/app/knowledge-base/category/[slug]/page.tsx` | Renders fake KB by category |
| `src/app/shop/page.tsx` | E-commerce shop (see A4) |
| `src/app/shop/[id]/page.tsx` | Product detail (see A4) |

### A9. Components Used Exclusively by Discarded Pages

| File | Used by |
|---|---|
| `src/components/waggies/blog-section.tsx` | Homepage blog section (fake content) |
| `src/components/waggies/blog-detail-client.tsx` | Blog post detail (fake content) |
| `src/components/waggies/blog-share-sidebar.tsx` | Blog post sidebar (fake content) |
| `src/components/waggies/blog-toc.tsx` | Blog table of contents (fake content) |
| `src/components/waggies/card-blog.tsx` | Blog card (fake content) |
| `src/components/waggies/guides-featured-card.tsx` | Guide featured card (fake content) |
| `src/components/waggies/guides-featured-card-row.tsx` | Guide card row (fake content) |
| `src/components/waggies/kb-article-card.tsx` | KB article card (fake content) |
| `src/components/waggies/article-card.tsx` | Generic article card (fake content) |
| `src/components/waggies/reading-progress.tsx` | Blog reading progress bar |
| `src/components/waggies/reading-time.tsx` | Blog reading time display |
| `src/components/waggies/sections/home-guides-section.tsx` | Homepage guides section |
| `src/components/waggies/content-featured-story.tsx` | Featured content story |

### A10. Components Tainted by Dark Mode (201 `dark:` class references)

These 15 waggies components contain `dark:` Tailwind classes and must be stripped:

| File | `dark:` refs |
|---|---|
| `src/components/waggies/navbar.tsx` | Heavy |
| `src/components/waggies/footer.tsx` | Heavy |
| `src/components/waggies/card-service.tsx` | Heavy |
| `src/components/waggies/card-pricing.tsx` | Medium |
| `src/components/waggies/card-testimonial.tsx` | Medium |
| `src/components/waggies/faq-accordion.tsx` | Medium |
| `src/components/waggies/faq-page-client.tsx` | Medium |
| `src/components/waggies/search-command-palette.tsx` | Heavy |
| `src/components/waggies/hero-gradient.tsx` | Heavy |
| `src/components/waggies/hero-image.tsx` | Medium |
| `src/components/waggies/not-found-search-cta.tsx` | Light |
| `src/components/waggies/layout-minimal.tsx` | Light |
| `src/components/waggies/pet-of-the-month.tsx` | Medium |
| `src/components/waggies/promo-banner.tsx` | Light |
| `src/components/waggies/section-heading.tsx` | Light |

### A11. Hero Variants Using Gradient/Slop

| File | What's wrong |
|---|---|
| `src/components/waggies/hero-gradient.tsx` | Gradient hero with dark mode support |
| `src/components/waggies/hero-gradient-mesh.tsx` | Animated mesh (see A6) |
| `src/components/waggies/hero-split.tsx` | Split hero layout |
| `src/components/waggies/hero-hub.tsx` | Hub/resource hero |
| `src/components/waggies/hero-plain.tsx` | Plain hero variant |

### A12. Pet Profile / Pet-of-Month (z-cdn contaminated)

| File | What's wrong |
|---|---|
| `src/components/waggies/pet-of-the-month.tsx` | **3 z-cdn.chatglm.cn URLs** for pet images |
| `src/components/waggies/pet-of-the-month-section.tsx` | Section wrapper for above |
| `src/components/waggies/pet-profile-card.tsx` | Pet profile card |
| `src/components/waggies/pet-profiles-section.tsx` | Pet profiles section on homepage |
| `src/components/waggies/add-pet-form.tsx` | Add pet form |
| `src/lib/pet-profile-store.ts` | Zustand pet profile state |

### A13. Other Slop Components

| File | What's wrong |
|---|---|
| `src/components/waggies/tilt-card.tsx` | 3D tilt hover effect on cards |
| `src/components/waggies/scroll-reveal.tsx` | Scroll-triggered reveal animation |
| `src/components/waggies/promo-banner.tsx` | Promotional banner (dark mode tainted) |
| `src/components/waggies/whatsapp-fab.tsx` | WhatsApp FAB (dark mode tainted) |
| `src/components/waggies/mobile-bottom-nav.tsx` | Mobile bottom navigation (dark mode tainted) |
| `src/components/waggies/cookie-banner.tsx` | Cookie consent banner |
| `src/components/waggies/bom-spacer.tsx` | Browser-occlusion-manager spacer |
| `src/components/waggies/shimmer-loading.tsx` | Shimmer loading skeleton |
| `src/components/waggies/content-skeleton.tsx` | Content loading skeleton |

### A14. Pricing/Calculator Tools (questionable for v1)

| File | Lines | What's wrong |
|---|---|---|
| `src/components/waggies/cost-calculator.tsx` | ~300 | Interactive cost calculator |
| `src/components/waggies/cost-calculator-section.tsx` | ~50 | Section wrapper |
| `src/lib/cost-calculator-data.ts` | ~100 | Calculator data |
| `src/components/waggies/pricing-calculator.tsx` | ~200 | Pricing calculator widget |
| `src/components/waggies/pricing-tier-card.tsx` | ~80 | Pricing tier card |
| `src/components/waggies/pet-age-calculator.tsx` | ~100 | Pet age calculator |
| `src/components/waggies/pet-age-calculator-section.tsx` | ~40 | Section wrapper |
| `src/components/waggies/vaccination-schedule.tsx` | ~150 | Vaccination schedule widget |
| `src/components/waggies/vaccination-schedule-section.tsx` | ~40 | Section wrapper |
| `src/components/waggies/weight-log-dialog.tsx` | ~100 | Pet weight logging dialog |

### A15. Packages to Remove from package.json

| Package | Reason |
|---|---|
| `next-themes` | Dark mode system |
| `@dnd-kit/core` | Drag-and-drop (used by cart/shop) |
| `@dnd-kit/sortable` | Sortable (used by cart/shop) |
| `@dnd-kit/utilities` | DnD utilities |
| `@reactuses/core` | React hooks library (verify if needed) |
| `@tanstack/react-table` | Table library (verify if needed) |
| `cheerio` | HTML scraping (used by chat API) |
| `@mdxeditor/editor` | MDX editor (verify if needed) |

---

## CATEGORY B: POTENTIALLY VALUABLE — Keep for Now

> These are **reusable UI components and patterns** that implement legitimate features. They may need dark-mode class stripping and image URL fixes, but the underlying logic/architecture is sound.

### B1. FAQ Search System

| File | Lines | Value |
|---|---|---|
| `src/components/waggies/search-command-palette.tsx` | 854 | Full CmdK-based search palette with fuzzy search. **Dark mode tainted (must strip)**. |
| `src/components/waggies/lazy-search-palette.tsx` | ~30 | Lazy `dynamic()` wrapper for search palette |
| `src/components/waggies/search-trigger.tsx` | ~60 | Search trigger button (navbar icon) |
| `src/lib/search-index.ts` | 389 | Search index builder (indexes FAQs, services, pages) |
| `src/app/api/search/route.ts` | ~40 | Search API endpoint |

### B2. Booking Modal

| File | Lines | Value |
|---|---|---|
| `src/components/waggies/booking-modal.tsx` | 361 | Full booking form modal with service selection, date/time pickers, pet info. **Dark mode tainted.** |

### B3. Custom 404 Page

| File | Lines | Value |
|---|---|---|
| `src/app/not-found.tsx` | 116 | Custom 404 with watermark and search CTA |
| `src/components/waggies/not-found-watermark.tsx` | 32 | "Waggies" watermark background |
| `src/components/waggies/not-found-search-cta.tsx` | 40 | Search CTA on 404 page |

### B4. OG Image Generation

| File | Lines | Value |
|---|---|---|
| `src/lib/og-image-helpers.tsx` | 438 | Reusable OG image generation helpers (gradient backgrounds, text rendering) |
| `src/app/opengraph-image.tsx` | ~40 | Root OG image route |
| `src/app/twitter-image.tsx` | ~40 | Root Twitter card image route |
| `src/app/services/grooming/opengraph-image.tsx` | ~30 | Per-service OG images |
| `src/app/services/training/opengraph-image.tsx` | ~30 | Per-service OG images |
| `src/app/services/transport/opengraph-image.tsx` | ~30 | Per-service OG images |
| `src/app/services/vet-care/opengraph-image.tsx` | ~30 | Per-service OG images |

**Note**: The blog OG/Twitter image files (`src/app/blog/[slug]/opengraph-image.tsx` and `twitter-image.tsx`) are CATEGORY A since they render fake blog content.

### B5. Framer-Motion Wrappers

| File | Lines | Value |
|---|---|---|
| `src/components/waggies/motion/fade-in.tsx` | ~20 | Reusable fade-in animation wrapper |
| `src/components/waggies/motion/slide-in.tsx` | ~20 | Slide-in animation wrapper |
| `src/components/waggies/motion/scale-in.tsx` | ~20 | Scale-in animation wrapper |
| `src/components/waggies/motion/stagger-children.tsx` | ~20 | Staggered children animation |
| `src/components/waggies/motion/counter.tsx` | ~30 | Animated number counter |
| `src/components/waggies/motion/index.ts` | ~10 | Barrel export |

### B6. JSON-LD Structured Data

| File | Lines | Value |
|---|---|---|
| `src/components/waggies/json-ld.tsx` | 194 | Generic JSON-LD component (FAQ, Service, Breadcrumb schemas) |
| `src/components/waggies/breadcrumb-schema.tsx` | ~40 | Breadcrumb-specific JSON-LD schema |

**Note**: 40+ page files include inline JSON-LD. The component pattern is valuable; the inline scripts in pages need review.

### B7. Reusable Layout Components

| File | Lines | Value |
|---|---|---|
| `src/components/waggies/layout-content.tsx` | ~40 | Content page layout (sidebar + main) |
| `src/components/waggies/layout-listing.tsx` | ~40 | Listing page layout (grid of cards) |
| `src/components/waggies/layout-minimal.tsx` | ~30 | Minimal page layout |

### B8. Reusable UI Primitives

| File | Value |
|---|---|
| `src/components/waggies/material-symbol.tsx` | Material Symbols Outlined React component (icon font wrapper) |
| `src/components/waggies/skip-link.tsx` | Accessibility skip link |
| `src/components/waggies/back-to-top.tsx` | Scroll-to-top button |
| `src/components/waggies/back-to-top-link.tsx` | Scroll-to-top link variant |
| `src/components/waggies/page-header.tsx` | Page header with title + breadcrumb |
| `src/components/waggies/section-heading.tsx` | Section heading with subtitle |
| `src/components/waggies/section-divider.tsx` | Visual section divider |
| `src/components/waggies/breadcrumb.tsx` | Breadcrumb navigation component |
| `src/components/waggies/pagination.tsx` | Pagination component |
| `src/components/waggies/form-input.tsx` | Styled form input |
| `src/components/waggies/form-textarea.tsx` | Styled form textarea |
| `src/components/waggies/contact-form.tsx` | Contact form component |
| `src/components/waggies/contact-info.tsx` | Contact info display |
| `src/components/waggies/newsletter-form.tsx` | Newsletter subscription form |
| `src/components/waggies/share-this-page.tsx` | Social share buttons |
| `src/components/waggies/animated-divider.tsx` | Animated section divider |
| `src/components/waggies/animated-stat.tsx` | Animated stat counter |
| `src/components/waggies/badge-stat.tsx` | Badge-style stat display |

### B9. Card Components

| File | Value |
|---|---|
| `src/components/waggies/card-service.tsx` | Service card (needs dark mode stripping) |
| `src/components/waggies/card-testimonial.tsx` | Testimonial card (needs dark mode stripping) |
| `src/components/waggies/feature-band.tsx` | Feature/stats band |

### B10. Site Configuration (Laravel-Verbatim)

| File | Lines | Value |
|---|---|---|
| `src/lib/site.tsx` | ~350 | **HIGH VALUE** — Complete site config: nav menus (desktop mega-menu + mobile accordion), footer links, social links, WhatsApp config, cookie settings. All extracted verbatim from Laravel Blade templates. |

### B11. Service Page Infrastructure

| File | Value |
|---|---|
| `src/components/waggies/sections/simple-service-page.tsx` | Reusable service page template |
| `src/components/waggies/sections/service-page-enhanced.tsx` | Enhanced service page template |
| `src/components/waggies/staggered-service-grid.tsx` | Animated service grid |
| `src/components/waggies/service-comparison-table.tsx` | Service comparison table |
| `src/components/waggies/cta-primary.tsx` | Primary CTA button |
| `src/components/waggies/cta-secondary.tsx` | Secondary CTA |
| `src/components/waggies/cta-tertiary.tsx` | Tertiary CTA |
| `src/components/waggies/cta-buttons.tsx` | CTA button group |

### B12. Testimonials Carousel

| File | Value |
|---|---|
| `src/components/waggies/testimonials-carousel.tsx` | Carousel component using shadcn/ui carousel |
| `src/components/waggies/sections/testimonial-form.tsx` | Testimonial submission form |

### B13. Boarding Page Components

| File | Value |
|---|---|
| `src/components/waggies/boarding-day-in-life.tsx` | "A day in the life" section |
| `src/components/waggies/boarding-feature-grid.tsx` | Feature grid |
| `src/components/waggies/boarding-safety-card.tsx` | Safety feature card |
| `src/components/waggies/boarding-sibling-links.tsx` | Sibling page navigation links |
| `src/components/waggies/boarding-stats-bar.tsx` | Stats bar component |

### B14. waggies-image Component

| File | Value |
|---|---|
| `src/components/waggies/waggies-image.tsx` | Custom image component (possibly wrapper around next/image) |

---

## CATEGORY C: CONFLICTED — Modified Existing Baseline Files

> These files existed in the clean baseline (or are foundational config) and were modified by the agent. They need **manual line-by-line review** to separate legitimate changes from violations.

### C1. `package.json`

**Baseline**: Minimal Next.js scaffold dependencies.
**Changes**: Added ~50+ packages including violations (`next-themes`, `@dnd-kit/*`, `cheerio`, `framer-motion`) and legitimate ones (`cmdk`, `zustand`, `sonner`, etc.).

**Action needed**: Remove A15 packages. Keep: `framer-motion` (if animations desired), `cmdk` (for search), `zustand` (if state needed), `sonner` (toasts).

### C2. `next.config.ts`

**Baseline**: Not present in scaffold (newly created).
**Changes**: Added security headers, CSP, image remotePatterns.

**Violations**: Line 79 — `hostname: "z-cdn.chatglm.cn"` in `remotePatterns`.

**Action needed**: Remove z-cdn hostname. Keep security headers and CSP (valuable). Review `images.unsplash.com` — is this wanted?

### C3. `src/app/layout.tsx`

**Baseline**: Basic Next.js layout (no Waggies content).
**Changes**: Complete rewrite with Waggies branding, fonts (Cormorant Garamond + DM Sans), navbar, footer, JSON-LD, ThemeProvider.

**Violations**: Lines 12-13 (CartButton, CartDrawer), Line 15 (LazyChatbotWidget), Line 17 (ThemeProvider import), Lines 157/175 (ThemeProvider wrapping).

**Action needed**: Remove cart imports, chatbot import, ThemeProvider. Keep fonts, navbar, footer, WhatsApp FAB, back-to-top, cookie banner, search palette, Toaster, JSON-LD, BomSpacer, SkipLink.

### C4. `src/app/globals.css`

**Baseline**: Basic Tailwind CSS imports.
**Changes**: Expanded to 979 lines with Waggies design tokens, custom properties, and **36 `.dark` variant rules**.

**Violations**: All `.dark` CSS rules.

**Action needed**: Strip all `.dark` rules. Keep design tokens, custom properties, and light-mode styles.

### C5. `src/app/page.tsx`

**Baseline**: Default Next.js landing page.
**Changes**: Complete Waggies homepage with hero, services, testimonials, blog section, guides section, shop section, pet profiles, FAQ preview, CTA sections.

**Violations**: References to blog-section (fake content), home-shop-section (e-commerce), pet-profiles-section, hero-gradient-mesh, floating-particles, symptom-checker-section, chatbot, cart.

**Action needed**: Strip all references to CATEGORY A components. This file needs a near-complete rewrite using only CATEGORY B components.

### C6. `prisma/schema.prisma`

**Baseline**: Not present (newly created).
**Changes**: Basic Prisma schema.

**Action needed**: Review schema — likely clean. No violations expected.

### C7. `tailwind.config.ts`

**Baseline**: Not present (newly created).
**Changes**: Extended Tailwind config with Waggies design tokens, custom colors.

**Action needed**: Review for any dark-mode-specific configuration. May need minor cleanup.

### C8. `components.json`

**Baseline**: Not present (newly created).
**Changes**: shadcn/ui configuration.

**Action needed**: Likely clean. Standard shadcn/ui setup.

### C9. `tsconfig.json`

**Baseline**: Not present (newly created).
**Changes**: TypeScript configuration.

**Action needed**: Likely clean.

### C10. `.gitignore`

**Baseline**: 2 lines.
**Changes**: Expanded to 56 lines.

**Action needed**: Review additions. Likely all reasonable.

---

## DATA FILES — PROVENANCE MATRIX

| File | Lines | z-cdn refs | Provenance | Verdict |
|---|---|---|---|---|
| `about.ts` | 398 | 0 | Laravel-verbatim | **KEEP** (clean) |
| `faqs.ts` | 232 | 0 | Laravel-verbatim | **KEEP** (clean) |
| `loyalty.ts` | 154 | 0 | Laravel-verbatim | **KEEP** (clean) |
| `partnerships.ts` | 100 | 0 | Laravel-verbatim | **KEEP** (clean) |
| `home.ts` | 335 | 1 | Laravel-verbatim | **KEEP** (fix 1 z-cdn URL) |
| `services.ts` | 455 | 16 | Laravel-verbatim | **KEEP** (fix 16 z-cdn URLs) |
| `boarding.ts` | 426 | 8 | Laravel-verbatim | **KEEP** (fix 8 z-cdn URLs) |
| `relocation.ts` | 261 | 7 | Laravel-verbatim | **KEEP** (fix 7 z-cdn URLs) |
| `gallery.ts` | — | 17 | Laravel-verbatim | **KEEP** (fix 17 z-cdn URLs) |
| `pricing.ts` | 588 | 2 | Laravel-verbatim | **KEEP** (fix 2 z-cdn URLs) |
| `careers.ts` | 170 | 1 | Laravel-verbatim | **KEEP** (fix 1 z-cdn URL) |
| `testimonials.ts` | 187 | 0 (1 unsplash) | Laravel-verbatim | **KEEP** (fix 1 unsplash URL) |
| `blog-posts.ts` | 657 | 0 (10 unsplash) | AI-hallucinated | **DISCARD** |
| `guide-posts.ts` | 329 | 0 (4 unsplash) | AI-hallucinated | **DISCARD** |
| `kb-articles.ts` | 4,192 | 90 | Faker-seeded | **DISCARD** |
| `shop.ts` | 283 | 2 | Unprovenanced | **DISCARD** |

---

## STATISTICS

| Metric | Count |
|---|---|
| Total source files in tar | 246 |
| shadcn/ui components (untouched) | 48 |
| Waggies components | 111 |
| Page routes | 41 |
| API routes | 5 |
| Data files | 16 |
| Lib files | 11 |
| Hooks | 2 |
| **CATEGORY A (Discard)** | **~80+ files** |
| **CATEGORY B (Potentially Valuable)** | **~50+ files** |
| **CATEGORY C (Conflicted)** | **~10 files** |
| Total z-cdn.chatglm.cn references | 143 |
| Total dark: class references | 201+ |
| Total .dark CSS rules | 36 |
| AI-hallucinated content files | 4 (8,361 lines / ~161KB) |

---

## RECOMMENDED NEXT STEPS

1. **Do NOT extract the tar into the working repo** — it would overwrite the clean scaffold.
2. **Selectively cherry-pick** CATEGORY B files from the tar into `/tmp/` for review.
3. **For each CATEGORY B file**: strip `dark:` Tailwind classes, fix any z-cdn URLs, verify imports.
4. **For CATEGORY C files**: manually merge the legitimate changes (fonts, security headers, design tokens) while excluding violations (ThemeProvider, cart, chatbot imports).
5. **For CATEGORY A data files with z-cdn**: if the non-image content is from Laravel, consider keeping the text data and only replacing the image URLs.
6. **Rebuild `page.tsx` and `layout.tsx` from scratch** using only clean CATEGORY B components.

---
*End of SALVAGE_REPORT.md*