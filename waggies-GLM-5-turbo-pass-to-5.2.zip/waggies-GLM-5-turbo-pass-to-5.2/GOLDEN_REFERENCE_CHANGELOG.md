# Waggies Golden Reference — Changelog

## Pass 3 Stabilization (Golden Reference)

### Phase 1 — Correctness
- Deleted duplicate /services/transport page; replaced with 301 redirect to /relocation/transport
- Added Grooming card to Services hub (was missing)
- Added Local Transport card to Relocation hub (was missing)
- Created src/app/sitemap.ts with all 35+ public routes
- Created src/app/robots.ts (allow all, disallow /my-pets)
- Added localStorage persistence to cart store (zustand persist middleware)
- Fixed booking modal to honestly communicate request-only state with WhatsApp fallback

### Phase 2 — Information Architecture
- Verified primary nav order: Services, About, Tools, Resources, Shop, Contact/Booking
- Confirmed My Pets is NOT in primary navigation
- Services hierarchy: Boarding, Wellness (label only), Relocation
- Local Transport canonical route: /relocation/transport

### Phase 3 — Navigation
- Refactored Services desktop flyout: extracted to ServicesFlyout component
- Fixed Services flyout CSS overflow (changed to 1fr grid, proper max-width)
- Added ArrowUp/ArrowDown keyboard navigation to all flyout panels (About, Tools, Resources)
- Replaced MaterialSymbol in mobile bottom nav with Phosphor icons
- Replaced MaterialSymbol in homepage and services index with Phosphor icons
- Marked dead socialLinks array in site.tsx as @deprecated

### Phase 4 — Footer
- Removed duplicate hours from brand block (kept in Support column only)
- Replaced inline SVG logo with Phosphor PawPrint icon

### Phase 5 — Contact/Map
- Rebuilt Contact page as canonical location hub with map, form, hours, directions, booking CTA
- Google Maps embed added
- Full 7-day hours table from businessInfo
- All Phosphor icons

### Phase 6 — FAB/Chatbot
- Fixed FAB collision: repositioned Chatbot and Back-to-Top buttons
- Added iOS safe-area support to all 3 FABs
- Improved chat panel viewport containment (clamp width, max-height with 8rem clearance)

### Phase 7 — Hero/Visual Quality
- Switched homepage from HeroFullscreen to HeroSplit editorial layout
- Added eyebrow support to EditorialHero
- Added trust badge (PCSA Certified, On-Site Vet, 24/7 Supervision)
- Replaced MaterialSymbol in HeroSplit default layout with Phosphor

### Phase 8 — Imagery
- Audited ~70 image slots across all data files
- Fixed 2 empty image slots in about.ts
- All slots now have valid Unsplash stock images
- Created GOLDEN_ASSET_INVENTORY.md

### Phase 9 — Team
- Verified 3 authoritative staff members
- Added DVM credential to Dr. Nguhemen Doose Yuwa
- Reduced to 7 profiles (removed 1 placeholder)
- Confirmed Dr. Amara Okeke absent from codebase

### Phase 10 — Tools
- Verified all 11 tool routes exist
- Added MedicalDisclaimer to symptom-checker and vaccination-schedule pages
- Added all 12 tool entries to search index
- Replaced MaterialSymbol with Phosphor in 6 tool files
- Created phosphor-icons-client.tsx for client-side icon mapping

### Phase 11 — Accessibility
- Fixed muted-text contrast: replaced /40 and /50 opacity with /60 across 20+ files
- Fixed booking-modal label associations (petType, service)
- Verified focus-visible styles in globals.css
- Enlarged 8 interactive elements to meet 44x44px touch target minimum
