# Waggies Asset Inventory

> Updated: Task 6-f — Image Diversification + Link QA + Asset Inventory
> Previous: Task 8 — Image Provenance Audit

## Summary
- **Verified (self-contained / generated):** 7
- **Generic Stock (Unsplash, temporary):** 31 unique photos, 62 total references (all ≤2 per photo)
- **Temporary (unverified local hero images):** 9
- **Missing (client asset required):** 19
- **Broken:** 0 (favicon.ico fixed — 223 bytes)

### Totals by Category

| Category | Count | Action Required |
|----------|-------|-----------------|
| Verified (code-generated OG, SVG, embed) | 7 | None |
| Generic Stock (Unsplash) | 31 unique, 62 refs | Acceptable — all ≤2 uses per photo; replace with Waggies originals when available |
| Temporary (local hero JPGs) | 9 files | Client to verify provenance; replace if not original |
| Missing (empty src / empty arrays) | 19 slots | **Client must supply** |
| Broken | 0 | — |

---

## Verified Assets

Assets that are self-contained, generated at runtime, or of confirmed provenance.

| ID | Page | Component | Purpose | Dimensions | Source |
|----|------|-----------|---------|------------|--------|
| V-01 | All pages | `opengraph-image.tsx` | Default site OG image | 1200×630 | `next/og` Satori (code-generated) |
| V-02 | /services/grooming | `opengraph-image.tsx` | Grooming OG image | 1200×630 | `next/og` Satori (code-generated) |
| V-03 | /services/vet-care | `opengraph-image.tsx` | Vet Care OG image | 1200×630 | `next/og` Satori (code-generated) |
| V-04 | /services/training | `opengraph-image.tsx` | Training OG image | 1200×630 | `next/og` Satori (code-generated) |
| V-05 | /services/transport | `opengraph-image.tsx` | Transport OG image | 1200×630 | `next/og` Satori (code-generated) |
| V-06 | / | `logo.svg` in footer | Waggies logo | SVG (1.1 KB) | `public/logo.svg` |
| V-07 | /about | About page | Google Maps embed | Responsive iframe | `maps.google.com` embed |

## Generic Stock (Acceptable)

Unsplash stock photos used as atmospheric placeholders. All use `images.unsplash.com`. **All photos appear ≤2 times across the site** (diversified in Task 6-f). Appropriate subject matter. Replace with Waggies originals when available.

| ID | Photo ID | Description | Uses | Pages |
|----|----------|-------------|------|-------|
| S-01 | `photo-1650454027983` | Dog in boarding suite | 2 | Pricing (default + services hero) |
| S-02 | `photo-1606567595334` | Pet carrier | 2 | Relocation (import card + import hero) |
| S-03 | `photo-1601758228041` | Pet supplies | 2 | Home (transport card) + shop (puzzle feeder) |
| S-04 | `photo-1601758174114` | Pet with person | 2 | Relocation (export card) + content (new pet checklist guide) |
| S-05 | `photo-1601758124510` | Two golden retrievers | 2 | Boarding (dog day-in-life + grooming KB article) |
| S-06 | `photo-1601758124096` | Pet supplies | 2 | Shop (first aid kit + elevated bowl) |
| S-07 | `photo-1596492784531` | Happy dog | 2 | Services (boarding card) + boarding (dog hero) |
| S-08 | `photo-1589924691995` | Pet food | 2 | Shop (puppy food + cat food) |
| S-09 | `photo-1587300003388-59208cc962cb` | Golden retriever | 2 | Home (training card) + content (dog training guide) |
| S-10 | `photo-1587300003388-5721b8c9a6bb` | Dog brush/product | 2 | Shop (deshedding brush + padded harness) |
| S-11 | `photo-1586671267731` | Dog/carrier | 2 | Services (transport card) + content (boarding guide) |
| S-12 | `photo-1583511655857` | Golden retriever portrait | 2 | Services (training card) + boarding (dog day-in-life) |
| S-13 | `photo-1574158622682` | Cat closeup | 2 | Boarding (cat hero) + services (cat boarding card) |
| S-14 | `photo-1573865526739` | Cat in condo | 2 | Boarding (cat feline section + content/vet KB article) |
| S-15 | `photo-1573864708626` | Cat portrait | 2 | Services (exotic card) + content (nutrition article) |
| S-16 | `photo-1560807707` | Dog | 2 | Content (dog illnesses article + vaccination article) |
| S-17 | `photo-1558618666` | Pet transport | 2 | Relocation (checklist card) + content (pet transport KB) |
| S-18 | `photo-1552053831` | Dog portrait | 2 | Services (dog boarding card) + relocation (export hero) |
| S-19 | `photo-1548199973-03d0b4fb1f8` | Person with dog | 2 | Testimonials (hero) + relocation (checklist hero) |
| S-20 | `photo-1548199973-03cce0bbc87b` | Dog with person | 2 | Content (grooming article) + shop (tick/flea collar) |
| S-21 | `photo-1544568100-847a948585b9` | Cat and dog together | 2 | Home (boarding card) + content (KB boarding article) |
| S-22 | `photo-1541599540903` | Dog sleeping | 2 | Boarding (dog day-in-life + sibling link) |
| S-23 | `photo-1535294435445` | Dog with toy | 2 | Content (seasonal care guide) + boarding (cat sibling link) |
| S-24 | `photo-1526336024174` | Cat with blue eyes | 2 | Content (cat care article) + boarding (cat day-in-life) |
| S-25 | `photo-1518717758536` | Dog | 2 | Content (separation anxiety article) + pricing (checklist hero) |
| S-26 | `photo-1516734212186` | Dog being groomed | 2 | Home (grooming card) + content (grooming KB article) |
| S-27 | `photo-1514888286974` | Orange tabby | 2 | Home (vet care card) + boarding (cat sibling link) |
| S-28 | `photo-1456926631375` | Parrot | 2 | Boarding (exotic hero) + pricing (guide hero) |
| S-29 | `photo-1450778869180` | Variety of pets | 2 | Pricing (blog hero) + services (relocation card) |
| S-30 | `photo-1437409368301` | Small mammal/exotic | 2 | Services (exotic card) + boarding (exotic day-in-life) |
| S-31 | `photo-1436491865332` | Dog with documents | 2 | Relocation (index hero) + pricing (pricing hero) |
| S-32 | `photo-1628009368231` | Vet with dog | 1 | Services (vet care card) |

## Temporary (Needs Replacement)

Local `public/service-hero-*.jpg` files. Valid JPEGs (all 1344×768, all created same day). Used as CSS `background-image` by the `HeroImage` component. Provenance unverified — may be original Waggies photos or batch-processed placeholders. Client must confirm or replace.

| ID | Page | Component | Purpose | Dimensions | Source | Notes |
|----|------|-----------|---------|------------|--------|-------|
| T-01 | /services, /services/boarding | `HeroImage` | Services index + boarding index hero | 1344×768 (104 KB) | `public/service-hero-boarding.jpg` | Dual-use: both services hub and boarding page hero |
| T-02 | /services/grooming | `HeroImage` via `SimpleServicePage` | Grooming page hero | 1344×768 (107 KB) | `public/service-hero-grooming.jpg` | |
| T-03 | /services/vet-care | `HeroImage` via `SimpleServicePage` | Vet care page hero | 1344×768 (85 KB) | `public/service-hero-vet-care.jpg` | Smallest file |
| T-04 | /services/training | `HeroImage` via `SimpleServicePage` | Training page hero | 1344×768 (109 KB) | `public/service-hero-training.jpg` | |
| T-05 | /services/transport | `HeroImage` via `SimpleServicePage` | Transport page hero | 1344×768 (121 KB) | `public/service-hero-transport.jpg` | |
| T-06 | — | Unused | Boarding cats hero | 1344×768 (114 KB) | `public/service-hero-boarding-cats.jpg` | **Not referenced** in any data file |
| T-07 | — | Unused | Boarding dogs hero | 1344×768 (153 KB) | `public/service-hero-boarding-dogs.jpg` | **Not referenced** in any data file |
| T-08 | — | Unused | Boarding exotic hero | 1344×768 (135 KB) | `public/service-hero-boarding-exotic.jpg` | **Not referenced** in any data file |
| T-09 | — | Unused | Relocation hero | 1344×768 (124 KB) | `public/service-hero-relocation.jpg` | **Not referenced** — relocation uses Unsplash |

### Note on Unused Hero Images
T-06 through T-09 exist in `public/` but are **not referenced** by any data file or component. The boarding subpages (`/dogs`, `/cats`, `/exotic`) and relocation pages use Unsplash URLs for their heroes. These files are dead assets that could be removed or repurposed.

## Missing (Client Asset Required)

All entries with empty `src`, `imageSrc`, `image`, or `imagePaths` values. Components handle these gracefully (placeholder icons, empty states, or gradient-only heroes).

| ID | Page | Component | Purpose | Dimensions | Notes |
|----|------|-----------|---------|------------|-------|
| M-01 | /about | `HeroGradient` | About page hero image | Flexible | `aboutHero.imageSrc = ""` — HeroGradient hides image slot when empty |
| M-02 | /about | `WaggiesImage` | Clinic interior photo (philosophy mosaic) | 400×256 | `aboutMosaicImages[0].src = ""` — Shows placeholder icon |
| M-03 | /about | `WaggiesImage` | Grooming session photo (philosophy mosaic) | 400×256 | `aboutMosaicImages[1].src = ""` — Shows placeholder icon |
| M-04 | /about | `AboutTeamCard` | Team member photo (Dr. Amara Okeke) | 4:5 aspect | `aboutTeamMembers[0].image = ""` — Shows person icon |
| M-05 | /services/boarding | `<img>` conditional | Boarding \"Certified Safe Space\" facility photo | 500px height | `boardingSafeSpaceCard.imageSrc = ""` — Image hidden, gradient-only card |
| M-06 | /services/boarding/dogs | `WaggiesImage` | Dog boarding activity photo | 800×600 | `dogDayInLife.images[2]` — Shows placeholder icon |
| M-07 | /services/boarding/cats | `WaggiesImage` | Cat enrichment activity photo | 800×600 | `catDayInLife.images[1]` — Shows placeholder icon |
| M-08 | /services/boarding/cats | `WaggiesImage` | Cat in boarding condo photo | 800×600 | `catDayInLife.images[2]` — Shows placeholder icon |
| M-09 | /services/boarding/exotic | `WaggiesImage` | Exotic pet in boarding | 800×600 | `exoticDayInLife.images[0]` — Shows placeholder icon |
| M-10 | /services/boarding/exotic | `WaggiesImage` | Exotic pet enclosure | 800×600 | `exoticDayInLife.images[1]` — Shows placeholder icon |
| M-11 | /services/boarding/exotic | `WaggiesImage` | Exotic pet habitat | 800×600 | `exoticDayInLife.images[2]` — Shows placeholder icon |
| M-12 | /services/boarding (siblings) | `WaggiesImage` | Exotic boarding card image | 600 | `boardingSiblings[2].image = ""` — Shows placeholder icon |
| M-13 | /faq | `HeroImage` via `HeroHub` | FAQ page hero | Full-bleed | `heroImages.faq = ""` + `heroHubPresets.faq.image = ""` — Gradient overlay only |
| M-14 | /knowledge-base | `HeroImage` via `HeroHub` | Knowledge base hero | Full-bleed | `heroImages.kb = ""` — Gradient overlay only |
| M-15–M-22 | /about/gallery | `GalleryLightbox` | Gallery: 8 boarding + 4 grooming + 8 guest photos | Square (aspect-ratio) | `galleryGroups[*].imagePaths = []` — Gallery renders empty, no broken images |

## Broken

None. The previously-broken favicon.ico (B-01) was fixed in a prior task.

---

## Component Fallback Behaviour

All components that receive images handle empty/missing sources gracefully:

| Component | Empty `src` Behaviour |
|-----------|----------------------|
| `WaggiesImage` | Shows `bg-surface-purple` + camera icon placeholder with `aria-label` |
| `HeroImage` | CSS `background-image: url('')` ignored; gradient overlay still renders |
| `HeroGradient` | Conditionally hides right-side image slot entirely |
| `AboutTeamCard` | Shows person icon placeholder in `bg-surface-purple` |
| Boarding safe space card (`boarding/page.tsx`) | Conditional render: `img` only shown if `imageSrc` is truthy |
| `GalleryLightbox` | Empty `allImages` array renders nothing — no broken images |
| OG images (`next/og`) | Code-generated — never broken, no external dependencies |

---

## Unsplash URL Duplication Summary

After Task 6-f diversification, **all Unsplash photos appear ≤2 times** across the site.

| Max Uses | Count of Photos |
|----------|---------------|
| 2 | 31 photos |
| 1 | 1 photo |

Previously, `photo-1587300003388` was used 7 times, `photo-1436491865332` 5 times, and several others 3–4 times.

---

## Recommendations

1. **Gallery photos** (M-15–M-22): These MUST come from the client. No stock photos acceptable per `gallery.ts` comment.
2. **Team photos** (M-04): Real staff photographs required — currently a single placeholder card.
3. **About mosaic** (M-02, M-03): Clinic interior and grooming session photos needed for credibility.
4. **Boarding day-in-life** (M-06–M-12): Mixed stock + empty slots — fill empty slots or replace all with Waggies originals.
5. **FAQ/KB heroes** (M-13, M-14): Gradient-only is acceptable for now; add atmospheric images later.
6. **Unused hero JPGs** (T-06–T-09): Consider removing or using for the boarding subpages / relocation instead of Unsplash.
7. **All Unsplash images are temporary**: Replace with authentic Waggies photography when available. The 2x max rule ensures no single stock photo dominates the visual identity.
