# Waggies Design System

Light-mode only. No dark mode.
Brand: Purple #6B2C91, Secondary #E8D5B5, Surface #FDFBF7
Fonts: DM Sans (body), Cormorant Garamond (headings)
Icons: Material Symbols Outlined
Design Read: Nigerian premium pet-care service, warm trust-first language
Dials: DESIGN_VARIANCE:4, MOTION_INTENSITY:2, VISUAL_DENSITY:4

---

## Colors (OKLCH Canonical)

### Brand
| Token | OKLCH | Hex Equivalent | Role |
|-------|-------|---------------|------|
| `--color-waggies-primary` | `oklch(0.332 0.155 305)` | #6B2C91 | Primary brand purple |
| `--color-waggies-primary-light` | `oklch(0.489 0.145 305)` | #9D5CC0 | Lighter purple accent |
| `--color-waggies-primary-dark` | `oklch(0.196 0.108 310)` | #3E1A57 | Dark purple (text, dark sections) |
| `--color-waggies-secondary` | `oklch(0.849 0.037 80)` | #E8D5B5 | Warm cream accent |
| `--color-waggies-secondary-hover` | `oklch(0.79 0.042 80)` | #D4BDA1 | Secondary hover state |
| `--color-waggies-surface` | `oklch(0.985 0.005 90)` | #FDFBF7 | Page background |
| `--color-waggies-surface-purple` | `oklch(0.955 0.018 305)` | #F5F0FA | Tinted surface |

### Semantic (Tailwind-ready)
| Token | Value | Usage |
|-------|-------|-------|
| `--color-primary` | = waggies-primary | Buttons, links, accents |
| `--color-primary-light` | = waggies-primary-light | Lighter accent states |
| `--color-primary-dark` | = waggies-primary-dark | Headings, dark sections |
| `--color-secondary` | = waggies-secondary | Secondary CTAs, labels |
| `--color-surface` | = waggies-surface | Page background |
| `--color-surface-purple` | = waggies-surface-purple | Tinted section bg |
| `--color-text-body` | `oklch(0.332 0.108 310 / 0.7)` | Body paragraph text |
| `--color-text-secondary` | `oklch(0.332 0.108 310 / 0.65)` | Secondary/supporting text |
| `--color-text-muted` | `oklch(0.332 0.108 310 / 0.5)` | Captions, metadata |
| `--color-border-subtle` | `oklch(0.332 0.155 305 / 0.12)` | Subtle borders |
| `--color-focus` | `oklch(0.332 0.155 305 / 0.5)` | Focus ring color |

### Feedback
| Token | OKLCH | Role |
|-------|-------|------|
| `--color-success` | `oklch(0.52 0.17 145)` | Positive states |
| `--color-error` | `oklch(0.55 0.22 25)` | Errors, destructive |
| `--color-warning` | `oklch(0.68 0.16 75)` | Warnings |
| `--color-whatsapp` | `oklch(0.72 0.18 145)` | WhatsApp FAB |

---

## Typography

### Font Stack
- **Body**: DM Sans (400, 500, 600, 700) via `next/font/google`
- **Headings**: Cormorant Garamond (400, 600, 700, italic) via `next/font/google`
- **Icons**: Material Symbols Outlined (opsz 24, wght 400)
- **Mono**: ui-monospace, SFMono-Regular, monospace

### Type Scale
| Class | Font | Weight | Size | Line-height | Letter-spacing |
|-------|------|--------|------|-------------|---------------|
| `.text-display` | Serif | 700 | clamp(2.25rem, 5vw, 3.5rem) | 1.15 | -0.02em |
| `.text-h2` | Serif | 700 | clamp(1.75rem, 3.5vw, 2.5rem) | 1.2 | -0.01em |
| `.text-h3` | Serif | 600 | 1.35rem | 1.3 | - |
| `.text-h4` | Serif | 600 | 1.15rem | 1.4 | - |
| `.text-body` | Sans | 400 | 1rem | 1.7 | - | max-w: 65ch |
| `.text-body-sm` | Sans | 400 | 0.875rem | 1.6 | - |
| `.text-meta` | Sans | 400 | 0.8125rem | 1.5 | - |
| `.text-label` | Sans | 600 | 0.75rem | - | 0.05em, uppercase |
| `.text-nav` | Sans | 500 | 0.9375rem | 1.4 | - |
| `.text-btn` | Sans | 600 | 0.9375rem | 1 | - |

---

## Spacing

### Content Widths
- Max content: `max-w-7xl` (80rem)
- Section heading: `max-w-lg` or `max-w-xl`
- Body text: `max-w-65ch` (via `.text-body`)
- Narrow panels: `max-w-3xl` (FAQ, inline content)

### Section Padding
- Standard: `py-20` (5rem)
- Compact: `py-12` (3rem)
- Hero: `py-12 md:py-16`

### Container Padding
- Mobile: `px-4`
- Tablet: `md:px-10`
- Desktop: `lg:px-12`

### Grid Gaps
- Cards: `gap-6`
- Feature lists: `gap-4` to `gap-8`
- Accordion items: `gap-3`

---

## Layout

### Radii (Shape Consistency Lock)
| Token | Value | Usage |
|-------|-------|-------|
| `--radius-xs` | 0.125rem | - |
| `--radius-sm` | 0.375rem | Inputs |
| `--radius-md` | 0.5rem | - |
| `--radius-lg` | 0.75rem | Cards |
| `--radius-xl` | 1rem | Panels |
| `--radius-2xl` | 1.25rem | Large panels |
| Buttons/CTAs | `rounded-full` | All primary/secondary buttons |
| Badges | `rounded-full` | Eyebrow labels, status badges |

### Shadows
All shadows use purple-tinted oklch values (no pure black):
- `--shadow-xs` through `--shadow-xl`: Standard elevation scale
- `--shadow-soft`: Purple-tinted ambient shadow for featured elements

---

## Components

### Buttons
- Primary: `bg-primary hover:bg-primary-dark text-white rounded-full font-bold`
- Secondary: `bg-secondary hover:bg-secondary-hover text-primary-dark rounded-full font-bold`
- Ghost: `border border-primary/25 text-primary-dark rounded-full hover:bg-surface-purple`
- All buttons: min 44px touch target, `transition-colors`

### Cards
- Default: `bg-white rounded-xl (or rounded-2xl) shadow-sm hover:shadow-md transition-shadow`
- Surface: `bg-surface-purple rounded-2xl`

### Navigation
- Desktop: Single-line, max 80px height, dropdown flyouts
- Mobile: Hamburger drawer with accordion groups + fixed bottom nav (4 items)
- Dropdown: `nav-dropdown` class, `rounded-xl`, `border`, `shadow-lg`

### Forms
- Labels above inputs (not placeholder-as-label)
- Input: `rounded-lg border border-surface-purple focus:ring-2 focus:ring-primary/40`
- Error: Uses `--color-error`

### FAQ
- Accordion: `<details>` with custom summary styling
- Tabs: `role="tablist"` with keyboard navigation (Arrow, Home, End)

---

## Motion (MOTION_INTENSITY: 2)

### Rules
- No continuous/looping animations
- No decorative animation (every animation must serve hierarchy/feedback/state)
- All JS-driven animations gated by `useReducedMotion()` from framer-motion
- CSS animations gated by `@media (prefers-reduced-motion: reduce)` in globals.css
- Allowed: FadeIn on scroll, stagger entrance, tab panel transitions
- Banned: parallax, scroll-hijack, magnetic hover, continuous pulse/float

### Duration
- Standard enter: 0.4-0.6s
- Stagger delay: 0.04-0.08s per item, max 0.4s total
- Hover: CSS `transition` (no duration override needed)

---

## Responsive Rules

### Breakpoints
- Mobile: < 640px (default)
- sm: 640px
- md: 768px
- lg: 1024px
- xl: 1280px
- 2xl: 1536px

### Mobile-First Patterns
- Hero text: `clamp()` for fluid sizing, no fixed breakpoints in hero
- Cards: `grid-cols-1 sm:grid-cols-2 lg:grid-cols-3`
- Tables: Desktop table hidden on mobile, replaced with card layout
- Navigation: Hamburger drawer below lg, bottom nav on mobile
- Padding: `px-4` on mobile, `md:px-10`, `lg:px-12`

### Viewport Stability
- Always use `min-h-[100dvh]` never `h-screen`
- Body: `min-h-screen flex flex-col` with `flex-1` on main

---

## Accessibility

- Skip link: `SkipLink` component, focuses `#main-content`
- Focus: `:focus-visible` with 2px solid primary, 2px offset
- Reduced motion: `@media (prefers-reduced-motion: reduce)` kills all animations
- Color contrast: WCAG AA 4.5:1 for body text verified
- Touch targets: Minimum 44x44px on all interactive elements
- ARIA: Proper roles on tabs, accordions, modals, dialogs
- Images: All have alt text or `role="img"` + `aria-label` for placeholders
- Safe area: `.safe-bottom` class for iOS bottom inset

---

## Imagery Conventions

- Authoritative Waggies images: Used as-is when available
- Generic atmospheric stock (Unsplash): Acceptable for hero backgrounds, service card thumbnails
- Waggies-specific missing: Controlled placeholder (purple bg, camera icon, `TODO(client)` comment)
- Never replace Waggies-specific imagery with misleading stock
- `WaggiesImage` component handles empty/missing sources gracefully

---

## Copy Conventions

- Nigerian English conventions ("it is" not "it's" in formal copy)
- No AI-slop phrases (elevate, seamless, holistic, innovative, etc.)
- Concrete verbs, specific details, no vague claims
- Service names and pricing tier names preserved verbatim
- Client testimonial quotes preserved verbatim
- Eyebrow labels: max 1 per 3 sections
- CTA labels: specific, action-oriented, no duplicate intent on same page
