"use client";

/**
 * HeroFullscreen — Full-viewport photographic hero with dark overlay.
 *
 * Premium, warm, credible hero for the homepage.
 * Full-bleed background image with gradient overlay for text readability.
 * Text sits on the left (desktop) or bottom (mobile).
 */

import { useReducedMotion, motion } from "framer-motion";
import Link from "next/link";
import { WaggiesImage } from "./waggies-image";

export interface HeroFullscreenProps {
  headline: string;
  subtitle: string;
  imageSrc: string;
  imageAlt: string;
  primaryLabel: string;
  primaryHref: string;
  secondaryLabel: string;
  secondaryHref: string;
  eyebrow?: string;
}

export function HeroFullscreen({
  headline,
  subtitle,
  imageSrc,
  imageAlt,
  primaryLabel,
  primaryHref,
  secondaryLabel,
  secondaryHref,
  eyebrow,
}: HeroFullscreenProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <section
      className="relative min-h-[85vh] flex items-end lg:items-center overflow-hidden bg-primary-dark"
      aria-label="Hero"
    >
      {/* ── Background image with subtle scale animation ── */}
      <motion.div
        className="absolute inset-0 will-change-transform"
        initial={prefersReducedMotion ? undefined : { scale: 1.06 }}
        animate={prefersReducedMotion ? undefined : { scale: 1 }}
        transition={
          prefersReducedMotion
            ? undefined
            : { duration: 2, ease: [0.25, 0.1, 0.25, 1] }
        }
        aria-hidden="true"
      >
        <WaggiesImage
          src={imageSrc}
          alt=""
          fill
          priority
          sizes="100vw"
          className="!absolute inset-0"
        />
      </motion.div>

      {/* ── Dark gradient overlay: bottom-left heavy for text readability ── */}
      <div
        className="absolute inset-0
          bg-gradient-to-t from-black/75 via-black/45 to-black/20
          lg:bg-gradient-to-br lg:from-black/70 lg:via-black/35 lg:to-transparent"
        aria-hidden="true"
      />

      {/* ── Text content ── */}
      <div className="relative z-10 w-full">
        <div className="max-w-7xl mx-auto px-6 md:px-10 lg:px-12 py-16 md:py-20 lg:py-0">
          <div className="max-w-xl lg:max-w-lg">
            {/* Eyebrow */}
            {eyebrow && (
              <span
                className="inline-block mb-5 text-xs font-bold uppercase tracking-[0.2em] text-white/70"
              >
                {eyebrow}
              </span>
            )}

            {/* Headline */}
            <h1 className="font-serif text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-[1.1] mb-5">
              {headline}
            </h1>

            {/* Subtitle */}
            <p className="text-base sm:text-lg text-white/75 leading-relaxed mb-8 max-w-md">
              {subtitle}
            </p>

            {/* CTAs */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Link
                href={primaryHref}
                className="inline-flex items-center justify-center
                  bg-secondary hover:bg-secondary-hover text-primary-dark
                  px-8 py-3.5 rounded-full font-bold
                  transition-colors duration-200
                  focus:outline-none focus:ring-2 focus:ring-secondary/70 focus:ring-offset-2 focus:ring-offset-black"
              >
                {primaryLabel}
              </Link>
              <Link
                href={secondaryHref}
                className="inline-flex items-center justify-center
                  border border-white/30 text-white
                  px-8 py-3.5 rounded-full font-semibold
                  hover:bg-white/10 transition-colors duration-200
                  focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-black"
              >
                {secondaryLabel}
              </Link>
            </div>
          </div>
        </div>
      </div>

      {/* Screen-reader-only image description */}
      <span className="sr-only">{imageAlt}</span>
    </section>
  );
}
