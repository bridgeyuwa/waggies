"use client";

import { useState, useMemo } from "react";
import { cn } from "@/lib/utils";
import { businessInfo } from "@/lib/business-info";

const SPECIES = ["Dog", "Cat"] as const;
type Species = (typeof SPECIES)[number];

const LIFE_STAGES = {
  Dog: ["Puppy (under 1 year)", "Adult (1-7 years)", "Senior (7+ years)"],
  Cat: ["Kitten (under 1 year)", "Adult (1-10 years)", "Senior (10+ years)"],
} as const;

const ACTIVITY_LEVELS = ["Low", "Moderate", "High"] as const;

/** RER multipliers by life stage and activity */
const MULTIPLIERS: Record<string, number> = {
  "Puppy": 3.0,
  "Kitten": 2.5,
  "Adult Low": 1.2,
  "Adult Moderate": 1.6,
  "Adult High": 2.0,
  "Senior Low": 1.0,
  "Senior Moderate": 1.4,
  "Senior High": 1.8,
};

function getMultiplier(lifeStage: string, activity: string): number {
  const stageKey = lifeStage.split(" ")[0]; // "Puppy", "Adult", "Senior", "Kitten"
  const key = `${stageKey} ${activity}`;
  return MULTIPLIERS[key] ?? 1.4;
}

export function NutritionCalculatorClient() {
  const [species, setSpecies] = useState<Species>("Dog");
  const [weight, setWeight] = useState("");
  const [unit, setUnit] = useState<"kg" | "lb">("kg");
  const [lifeStage, setLifeStage] = useState(LIFE_STAGES.Dog[1]);
  const [activity, setActivity] = useState<(typeof ACTIVITY_LEVELS)[number]>("Moderate");

  const weightKg = useMemo(() => {
    const w = parseFloat(weight);
    if (isNaN(w) || w <= 0) return null;
    return unit === "lb" ? w * 0.453592 : w;
  }, [weight, unit]);

  const result = useMemo(() => {
    if (weightKg === null) return null;
    const rer = 70 * Math.pow(weightKg, 0.75);
    const multiplier = getMultiplier(lifeStage, activity);
    const dailyCalories = Math.round(rer * multiplier);
    return { rer: Math.round(rer), dailyCalories, multiplier };
  }, [weightKg, lifeStage, activity]);

  const handleSpeciesChange = (s: Species) => {
    setSpecies(s);
    setLifeStage(LIFE_STAGES[s][1]); // default to Adult
  };

  return (
    <div className="space-y-8">
      {/* Species */}
      <div>
        <label className="block text-sm font-semibold text-primary-dark mb-2">
          Species
        </label>
        <div className="grid grid-cols-2 gap-3">
          {SPECIES.map((s) => (
            <button
              key={s}
              type="button"
              onClick={() => handleSpeciesChange(s)}
              className={cn(
                "rounded-xl border p-3 text-sm font-semibold transition text-center",
                species === s
                  ? "border-primary bg-surface-purple text-primary"
                  : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30"
              )}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      {/* Weight */}
      <div>
        <label
          htmlFor="weight"
          className="block text-sm font-semibold text-primary-dark mb-2"
        >
          Weight
        </label>
        <div className="flex gap-3">
          <input
            id="weight"
            type="number"
            min="0.1"
            step="0.1"
            value={weight}
            onChange={(e) => setWeight(e.target.value)}
            placeholder={species === "Dog" ? "e.g. 15" : "e.g. 4"}
            className="flex-1 rounded-xl border border-primary/10 bg-white px-4 py-3 text-sm text-primary-dark placeholder:text-primary-dark/30 focus:outline-none focus:ring-2 focus:ring-primary/40"
          />
          <div className="flex rounded-xl border border-primary/10 overflow-hidden">
            {(["kg", "lb"] as const).map((u) => (
              <button
                key={u}
                type="button"
                onClick={() => setUnit(u)}
                className={cn(
                  "px-4 py-3 text-sm font-semibold transition",
                  unit === u
                    ? "bg-primary text-white"
                    : "bg-white text-primary-dark/60 hover:bg-primary/5"
                )}
              >
                {u}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Life Stage */}
      <div>
        <label className="block text-sm font-semibold text-primary-dark mb-2">
          Life Stage
        </label>
        <div className="flex flex-wrap gap-2">
          {LIFE_STAGES[species].map((stage) => (
            <button
              key={stage}
              type="button"
              onClick={() => setLifeStage(stage)}
              className={cn(
                "rounded-full border px-4 py-2 text-sm font-medium transition",
                lifeStage === stage
                  ? "border-primary bg-surface-purple text-primary"
                  : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30"
              )}
            >
              {stage}
            </button>
          ))}
        </div>
      </div>

      {/* Activity Level */}
      <div>
        <label className="block text-sm font-semibold text-primary-dark mb-2">
          Activity Level
        </label>
        <div className="flex flex-wrap gap-2">
          {ACTIVITY_LEVELS.map((level) => (
            <button
              key={level}
              type="button"
              onClick={() => setActivity(level)}
              className={cn(
                "rounded-full border px-4 py-2 text-sm font-medium transition",
                activity === level
                  ? "border-primary bg-surface-purple text-primary"
                  : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30"
              )}
            >
              {level}
            </button>
          ))}
        </div>
      </div>

      {/* Result */}
      {result && (
        <div className="bg-white border border-primary/10 rounded-2xl p-6">
          <h3 className="font-serif text-lg font-bold text-primary-dark">
            Estimated Daily Calorie Need
          </h3>
          <p className="text-primary-dark/50 text-sm mt-1">
            Resting Energy Requirement (RER): {result.rer} kcal/day
          </p>
          <p className="text-primary-dark/50 text-sm">
            Multiplier (life stage + activity): {result.multiplier}x
          </p>
          <div className="mt-4 text-center">
            <span className="text-4xl font-bold text-primary">
              {result.dailyCalories}
            </span>
            <span className="text-primary-dark/50 text-sm ml-2">
              kcal / day
            </span>
          </div>
          <p className="text-xs text-primary-dark/60 mt-3 text-center leading-relaxed">
            This is an estimate based on the RER formula (70 x body_weight_kg^0.75).
            Actual needs vary based on breed, health status, and food quality.
          </p>
        </div>
      )}

      {/* Veterinary guidance notice */}
      <div className="bg-amber-50 border border-amber-200/60 rounded-xl p-4">
        <p className="text-xs text-amber-900 leading-relaxed">
          <strong>For pets with medical conditions (diabetes, kidney disease, obesity, etc.):</strong>{" "}
          calorie needs differ significantly from standard estimates. Please consult
          your veterinarian for a personalised feeding plan.
        </p>
      </div>

      {/* Book Appointment CTA */}
      <div className="text-center bg-primary-dark rounded-2xl p-8">
        <h3 className="font-serif text-lg font-bold text-white">
          Need a Personalised Nutrition Plan?
        </h3>
        <p className="text-white/70 text-sm mt-2">
          Our veterinary team can create a feeding plan tailored to your pet.
        </p>
        <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-6">
          <a
            href="/contact"
            className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark font-bold px-8 py-3.5 rounded-full transition text-sm"
          >
            Book an Appointment
          </a>
          <a
            href={businessInfo.phoneHref}
            className="inline-flex items-center gap-2 border border-white/30 text-white hover:bg-white/10 font-semibold px-8 py-3.5 rounded-full transition text-sm"
          >
            Call {businessInfo.phoneLocal}
          </a>
        </div>
      </div>
    </div>
  );
}
