/**
 * Testimonial submission form - multi-step wizard with 3 steps:
 *   1. Your Experience (rating, service, title, story)
 *   2. About You & Your Pet (name, location, pet name, pet type)
 *   3. Photos & Submit (optional photo preview, consent checkbox, submit)
 *
 * Features:
 *   - Zod validation per step (inline errors)
 *   - framer-motion step transitions (slide left/right via AnimatePresence)
 *   - Interactive 5-star rating (gold #F59E0B)
 *   - Photo preview from FileReader (no actual upload)
 *   - Success animation (SVG checkmark pathLength draw)
 *   - sonner toast.success on submit
 *   - Auto-reset form after 3 seconds
 *   - Console-logs submitted payload
 *
 * Waggies purple theme (#6B2C91) throughout.
 */

"use client";

import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import { z } from "zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

// ── Types ─────────────────────────────────────────────────────────────────

export type TestimonialSubmission = {
  rating: number;
  service: string;
  title: string;
  story: string;
  authorName: string;
  authorLocation: string;
  petName: string;
  petType: string;
  photoUrl?: string; // data URL from file preview
  consent: boolean;
};

type StepKey = "experience" | "about" | "submit";

const STEP_ORDER: StepKey[] = ["experience", "about", "submit"];
const STEP_INDEX: Record<StepKey, number> = {
  experience: 0,
  about: 1,
  submit: 2,
};

const SERVICES = [
  "Boarding",
  "Grooming",
  "Vet Care",
  "Training",
  "Transport",
  "Relocation",
] as const;

const PET_TYPES = ["Dog", "Cat", "Bird", "Rabbit", "Reptile", "Other"] as const;

const initialSubmission: TestimonialSubmission = {
  rating: 0,
  service: "",
  title: "",
  story: "",
  authorName: "",
  authorLocation: "",
  petName: "",
  petType: "",
  photoUrl: undefined,
  consent: false,
};

// ── Zod schemas (one per step) ─────────────────────────────────────────────

const experienceSchema = z.object({
  rating: z
    .number({ message: "Please select a star rating." })
    .int()
    .min(1, "Please select a star rating.")
    .max(5, "Rating must be between 1 and 5."),
  service: z
    .string()
    .min(1, "Please select the service you used.")
    .refine((v) => SERVICES.includes(v as (typeof SERVICES)[number]), {
      message: "Please choose a valid service.",
    }),
  title: z
    .string()
    .min(1, "Please give your experience a short title.")
    .max(80, "Title should be 80 characters or less."),
  story: z
    .string()
    .min(50, "Please share at least 50 characters about your experience.")
    .max(2000, "Story should be 2000 characters or less."),
});

const aboutSchema = z.object({
  authorName: z
    .string()
    .min(2, "Please enter your name (min 2 characters).")
    .max(60, "Name should be 60 characters or less."),
  authorLocation: z
    .string()
    .min(2, "Please enter your area (e.g. Maitama, Abuja).")
    .max(80, "Location should be 80 characters or less."),
  petName: z
    .string()
    .max(60, "Pet name should be 60 characters or less.")
    .optional()
    .or(z.literal("")),
  petType: z
    .string()
    .min(1, "Please select your pet type.")
    .refine((v) => PET_TYPES.includes(v as (typeof PET_TYPES)[number]), {
      message: "Please choose a valid pet type.",
    }),
});

const submitSchema = z.object({
  consent: z
    .boolean()
    .refine((v) => v === true, {
      message: "Please agree to let Waggies use your testimonial.",
    }),
});

// ── Helpers ────────────────────────────────────────────────────────────────

function validateStep(
  step: StepKey,
  data: TestimonialSubmission,
): Record<string, string> {
  let result;
  if (step === "experience") {
    result = experienceSchema.safeParse({
      rating: data.rating,
      service: data.service,
      title: data.title,
      story: data.story,
    });
  } else if (step === "about") {
    result = aboutSchema.safeParse({
      authorName: data.authorName,
      authorLocation: data.authorLocation,
      petName: data.petName,
      petType: data.petType,
    });
  } else {
    result = submitSchema.safeParse({ consent: data.consent });
  }
  if (result.success) return {};
  const errs: Record<string, string> = {};
  for (const issue of result.error.issues) {
    const key = issue.path[0];
    if (typeof key === "string" && !errs[key]) errs[key] = issue.message;
  }
  return errs;
}

// ── Component ─────────────────────────────────────────────────────────────

export function TestimonialForm() {
  const [step, setStep] = useState<StepKey>("experience");
  const [direction, setDirection] = useState<1 | -1>(1);
  const [data, setData] = useState<TestimonialSubmission>(initialSubmission);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // After showing the success animation, auto-reset after 3s.
  useEffect(() => {
    if (!submitted) return;
    const t = setTimeout(() => {
      setSubmitted(false);
      setStep("experience");
      setDirection(-1);
      setData(initialSubmission);
      setErrors({});
      if (fileInputRef.current) fileInputRef.current.value = "";
    }, 3000);
    return () => clearTimeout(t);
  }, [submitted]);

  const currentStepIndex = STEP_INDEX[step];

  function update<K extends keyof TestimonialSubmission>(
    field: K,
    value: TestimonialSubmission[K],
  ) {
    setData((prev) => ({ ...prev, [field]: value }));
    // Clear the inline error for this field as the user edits.
    if (errors[field as string]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[field as string];
        return next;
      });
    }
  }

  function goNext() {
    const errs = validateStep(step, data);
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setErrors({});
    const idx = STEP_INDEX[step];
    if (idx < STEP_ORDER.length - 1) {
      setDirection(1);
      setStep(STEP_ORDER[idx + 1]);
    }
  }

  function goBack() {
    const idx = STEP_INDEX[step];
    if (idx === 0) return;
    setDirection(-1);
    setErrors({});
    setStep(STEP_ORDER[idx - 1]);
  }

  function handlePhotoChange(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) {
      update("photoUrl", undefined);
      return;
    }
    if (!file.type.startsWith("image/")) {
      setErrors((prev) => ({
        ...prev,
        photoUrl: "Please choose an image file.",
      }));
      return;
    }
    if (file.size > 4 * 1024 * 1024) {
      setErrors((prev) => ({
        ...prev,
        photoUrl: "Please choose an image under 4 MB.",
      }));
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const result = typeof reader.result === "string" ? reader.result : undefined;
      update("photoUrl", result);
    };
    reader.readAsDataURL(file);
  }

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const errs = validateStep("submit", data);
    if (Object.keys(errs).length > 0) {
      setErrors(errs);
      return;
    }
    setErrors({});
    // Log the testimonial data exactly as specified by the task.
     
    console.log("Testimonial submitted:", data);
    setSubmitted(true);
    toast.success("Thank you! Your testimonial has been submitted.", {
      duration: 4000,
    });
  }

  // Pre-compute slide variants so we can flip direction on back/next.
  const variants = useMemo(
    () => ({
      enter: (dir: 1 | -1) => ({
        x: dir === 1 ? 80 : -80,
        opacity: 0,
      }),
      center: { x: 0, opacity: 1 },
      exit: (dir: 1 | -1) => ({
        x: dir === 1 ? -80 : 80,
        opacity: 0,
      }),
    }),
    [],
  );

  return (
    <div className="relative">
      {/* Card-style container */}
      <div className="bg-white rounded-3xl shadow-[0_20px_60px_-20px_rgba(107,44,145,0.35)] border border-surface-purple/60 overflow-hidden">
        {/* Progress indicator */}
        <div className="bg-gradient-to-r from-primary to-primary-light px-6 sm:px-10 py-5">
          <div className="flex items-center justify-between gap-4">
            {STEP_ORDER.map((s, i) => {
              const isActive = i === currentStepIndex;
              const isComplete = i < currentStepIndex;
              return (
                <div
                  key={s}
                  className="flex items-center gap-3 flex-1 last:flex-none"
                >
                  <div className="flex flex-col items-center gap-1.5">
                    <motion.div
                      layout
                      className={`relative w-9 h-9 rounded-full grid place-items-center text-sm font-bold transition-colors duration-300 ${
                        isActive
                          ? "bg-white text-primary"
                          : isComplete
                            ? "bg-white/25 text-white"
                            : "bg-white/10 text-white/70"
                      }`}
                    >
                      {isComplete ? (
                        <MaterialSymbol
                          name="check"
                          className="text-base"
                        />
                      ) : (
                        i + 1
                      )}
                      {isActive ? (
                        <motion.span
                          layoutId="step-ring"
                          className="absolute -inset-1 rounded-full border-2 border-white/80"
                          transition={{
                            type: "spring",
                            damping: 22,
                            stiffness: 280,
                          }}
                        />
                      ) : null}
                    </motion.div>
                    <span
                      className={`text-[10px] sm:text-xs font-semibold uppercase tracking-wide transition-colors ${
                        isActive
                          ? "text-white"
                          : isComplete
                            ? "text-white/80"
                            : "text-white/60"
                      }`}
                    >
                      {s === "experience"
                        ? "Experience"
                        : s === "about"
                          ? "About You"
                          : "Photos"}
                    </span>
                  </div>
                  {i < STEP_ORDER.length - 1 ? (
                    <div className="flex-1 h-0.5 bg-white/20 rounded-full overflow-hidden hidden sm:block">
                      <motion.div
                        className="h-full bg-white"
                        initial={{ width: 0 }}
                        animate={{ width: isComplete ? "100%" : "0%" }}
                        transition={{ duration: 0.4 }}
                      />
                    </div>
                  ) : null}
                </div>
              );
            })}
          </div>
        </div>

        {/* Form body with step transitions */}
        <div className="px-6 sm:px-10 py-8 sm:py-10 min-h-[28rem] relative">
          <AnimatePresence mode="wait" custom={direction}>
            {submitted ? (
              <motion.div
                key="success"
                initial={{ opacity: 0, scale: 0.94 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.94 }}
                transition={{ duration: 0.35, ease: [0.25, 0.1, 0.25, 1] }}
                className="flex flex-col items-center justify-center text-center py-10"
                role="status"
                aria-live="polite"
              >
                <AnimatedCheck />
                <h3 className="font-serif text-2xl font-bold text-primary-dark mt-4">
                  Thank you!
                </h3>
                <p className="text-primary-dark/60 max-w-sm mt-1.5">
                  Your testimonial has been submitted. We&apos;ll review it and
                  share it with the Waggies community soon.
                </p>
              </motion.div>
            ) : (
              <motion.form
                key={step}
                onSubmit={handleSubmit}
                custom={direction}
                variants={variants}
                initial="enter"
                animate="center"
                exit="exit"
                transition={{
                  x: { type: "spring", damping: 26, stiffness: 280 },
                  opacity: { duration: 0.2 },
                }}
                noValidate
                className="space-y-5"
              >
                {step === "experience" ? (
                  <StepExperience
                    data={data}
                    errors={errors}
                    update={update}
                  />
                ) : step === "about" ? (
                  <StepAbout data={data} errors={errors} update={update} />
                ) : (
                  <StepSubmit
                    data={data}
                    errors={errors}
                    update={update}
                    onPhotoChange={handlePhotoChange}
                    fileInputRef={fileInputRef}
                  />
                )}

                {/* Navigation */}
                <div className="flex items-center justify-between gap-3 pt-4">
                  <Button
                    type="button"
                    variant="ghost"
                    onClick={goBack}
                    disabled={currentStepIndex === 0}
                    className="text-primary-dark hover:text-primary hover:bg-surface-purple/60 disabled:opacity-40 disabled:cursor-not-allowed"
                  >
                    <MaterialSymbol name="arrow_back" className="text-base mr-1" />
                    Back
                  </Button>

                  {step !== "submit" ? (
                    <Button
                      type="button"
                      onClick={goNext}
                      className="bg-primary hover:bg-primary-dark text-white font-semibold rounded-full px-7 shadow-sm"
                    >
                      Continue
                      <MaterialSymbol name="arrow_forward" className="text-base ml-1" />
                    </Button>
                  ) : (
                    <Button
                      type="submit"
                      className="bg-primary hover:bg-primary-dark text-white font-bold rounded-full px-7 shadow-sm"
                    >
                      <MaterialSymbol name="send" className="text-base mr-1" />
                      Submit Testimonial
                    </Button>
                  )}
                </div>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </div>
  );
}

// ── Step 1: Your Experience ───────────────────────────────────────────────

function StepExperience({
  data,
  errors,
  update,
}: {
  data: TestimonialSubmission;
  errors: Record<string, string>;
  update: <K extends keyof TestimonialSubmission>(
    field: K,
    value: TestimonialSubmission[K],
  ) => void;
}) {
  return (
    <div className="space-y-5">
      <div>
        <h3 className="font-serif text-xl font-bold text-primary-dark">
          Your Experience
        </h3>
        <p className="text-sm text-primary-dark/60 mt-0.5">
          Tell us how Waggies helped you and your pet.
        </p>
      </div>

      {/* Star rating */}
      <div className="space-y-1.5">
        <Label className="text-primary-dark font-semibold">
          Overall rating
        </Label>
        <div className="flex items-center gap-2">
          <div
            className="flex items-center gap-1"
            role="radiogroup"
            aria-label="Overall rating"
          >
            {[1, 2, 3, 4, 5].map((n) => {
              const active = data.rating >= n;
              return (
                <motion.button
                  key={n}
                  type="button"
                  onClick={() => update("rating", n)}
                  onMouseEnter={(e) => {
                    e.currentTarget
                      .querySelector("[data-star]")
                      ?.setAttribute("data-hover", "1");
                  }}
                  onMouseLeave={(e) => {
                    e.currentTarget
                      .querySelector("[data-star]")
                      ?.removeAttribute("data-hover");
                  }}
                  whileTap={{ scale: 0.85 }}
                  whileHover={{ scale: 1.12 }}
                  className="p-1 -m-1 focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 rounded-full"
                  aria-label={`${n} star${n > 1 ? "s" : ""}`}
                  aria-checked={data.rating === n}
                  role="radio"
                >
                  <MaterialSymbol
                    name="star"
                    filled={active}
                    className={`text-3xl transition-colors duration-150 ${
                      active
                        ? "text-[#F59E0B]"
                        : "text-primary-dark/20 hover:text-[#F59E0B]/60"
                    }`}
                  />
                </motion.button>
              );
            })}
          </div>
          {data.rating > 0 ? (
            <span className="text-sm font-semibold text-primary-dark/70 ml-1">
              {data.rating} of 5
            </span>
          ) : null}
        </div>
        {errors.rating ? (
          <p className="text-red-500 text-xs font-medium" role="alert">
            {errors.rating}
          </p>
        ) : null}
      </div>

      {/* Service */}
      <div className="space-y-1.5">
        <Label className="text-primary-dark font-semibold">
          Service used
        </Label>
        <Select
          value={data.service}
          onValueChange={(v) => update("service", v)}
        >
          <SelectTrigger
            className={`w-full bg-white ${
              errors.service ? "border-red-400" : "border-surface-purple"
            } focus:ring-primary/30`}
          >
            <SelectValue placeholder="Choose a service" />
          </SelectTrigger>
          <SelectContent>
            {SERVICES.map((s) => (
              <SelectItem key={s} value={s}>
                {s}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        {errors.service ? (
          <p className="text-red-500 text-xs font-medium" role="alert">
            {errors.service}
          </p>
        ) : null}
      </div>

      {/* Title */}
      <div className="space-y-1.5">
        <Label htmlFor="title" className="text-primary-dark font-semibold">
          Experience title
        </Label>
        <Input
          id="title"
          placeholder="e.g. Bruno loved his stay!"
          value={data.title}
          onChange={(e) => update("title", e.target.value)}
          maxLength={80}
          className={`bg-white ${
            errors.title ? "border-red-400" : "border-surface-purple"
          } focus-visible:border-primary focus-visible:ring-primary/30`}
        />
        <div className="flex items-center justify-between text-[11px] text-primary-dark/60">
          <span>A short headline for your story.</span>
          <span>{data.title.length}/80</span>
        </div>
        {errors.title ? (
          <p className="text-red-500 text-xs font-medium" role="alert">
            {errors.title}
          </p>
        ) : null}
      </div>

      {/* Story */}
      <div className="space-y-1.5">
        <Label htmlFor="story" className="text-primary-dark font-semibold">
          Your story
        </Label>
        <Textarea
          id="story"
          placeholder="Share what happened, how the team treated your pet, and what you loved most..."
          rows={5}
          value={data.story}
          onChange={(e) => update("story", e.target.value)}
          maxLength={2000}
          className={`bg-white resize-none ${
            errors.story ? "border-red-400" : "border-surface-purple"
          } focus-visible:border-primary focus-visible:ring-primary/30`}
        />
        <div className="flex items-center justify-between text-[11px] text-primary-dark/60">
          <span>Minimum 50 characters.</span>
          <span>{data.story.length}/2000</span>
        </div>
        {errors.story ? (
          <p className="text-red-500 text-xs font-medium" role="alert">
            {errors.story}
          </p>
        ) : null}
      </div>
    </div>
  );
}

// ── Step 2: About You & Your Pet ──────────────────────────────────────────

function StepAbout({
  data,
  errors,
  update,
}: {
  data: TestimonialSubmission;
  errors: Record<string, string>;
  update: <K extends keyof TestimonialSubmission>(
    field: K,
    value: TestimonialSubmission[K],
  ) => void;
}) {
  return (
    <div className="space-y-5">
      <div>
        <h3 className="font-serif text-xl font-bold text-primary-dark">
          About You &amp; Your Pet
        </h3>
        <p className="text-sm text-primary-dark/60 mt-0.5">
          So we can attribute your testimonial properly.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label htmlFor="authorName" className="text-primary-dark font-semibold">
            Your name <span className="text-red-500">*</span>
          </Label>
          <Input
            id="authorName"
            placeholder="e.g. Adaeze O."
            value={data.authorName}
            onChange={(e) => update("authorName", e.target.value)}
            className={`bg-white ${
              errors.authorName ? "border-red-400" : "border-surface-purple"
            } focus-visible:border-primary focus-visible:ring-primary/30`}
          />
          {errors.authorName ? (
            <p className="text-red-500 text-xs font-medium" role="alert">
              {errors.authorName}
            </p>
          ) : null}
        </div>

        <div className="space-y-1.5">
          <Label
            htmlFor="authorLocation"
            className="text-primary-dark font-semibold"
          >
            Your area
          </Label>
          <Input
            id="authorLocation"
            placeholder="e.g. Maitama, Abuja"
            value={data.authorLocation}
            onChange={(e) => update("authorLocation", e.target.value)}
            className={`bg-white ${
              errors.authorLocation ? "border-red-400" : "border-surface-purple"
            } focus-visible:border-primary focus-visible:ring-primary/30`}
          />
          {errors.authorLocation ? (
            <p className="text-red-500 text-xs font-medium" role="alert">
              {errors.authorLocation}
            </p>
          ) : null}
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="space-y-1.5">
          <Label htmlFor="petName" className="text-primary-dark font-semibold">
            Pet name
          </Label>
          <Input
            id="petName"
            placeholder="Your pet's name"
            value={data.petName}
            onChange={(e) => update("petName", e.target.value)}
            className={`bg-white ${
              errors.petName ? "border-red-400" : "border-surface-purple"
            } focus-visible:border-primary focus-visible:ring-primary/30`}
          />
          {errors.petName ? (
            <p className="text-red-500 text-xs font-medium" role="alert">
              {errors.petName}
            </p>
          ) : null}
        </div>

        <div className="space-y-1.5">
          <Label className="text-primary-dark font-semibold">Pet type</Label>
          <Select
            value={data.petType}
            onValueChange={(v) => update("petType", v)}
          >
            <SelectTrigger
              className={`w-full bg-white ${
                errors.petType ? "border-red-400" : "border-surface-purple"
              } focus:ring-primary/30`}
            >
              <SelectValue placeholder="Select pet type" />
            </SelectTrigger>
            <SelectContent>
              {PET_TYPES.map((t) => (
                <SelectItem key={t} value={t}>
                  {t}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {errors.petType ? (
            <p className="text-red-500 text-xs font-medium" role="alert">
              {errors.petType}
            </p>
          ) : null}
        </div>
      </div>
    </div>
  );
}

// ── Step 3: Photos & Submit ───────────────────────────────────────────────

function StepSubmit({
  data,
  errors,
  update,
  onPhotoChange,
  fileInputRef,
}: {
  data: TestimonialSubmission;
  errors: Record<string, string>;
  update: <K extends keyof TestimonialSubmission>(
    field: K,
    value: TestimonialSubmission[K],
  ) => void;
  onPhotoChange: (e: React.ChangeEvent<HTMLInputElement>) => void;
  fileInputRef: React.RefObject<HTMLInputElement | null>;
}) {
  return (
    <div className="space-y-5">
      <div>
        <h3 className="font-serif text-xl font-bold text-primary-dark">
          Photos &amp; Submit
        </h3>
        <p className="text-sm text-primary-dark/60 mt-0.5">
          Add an optional photo and review your consent before submitting.
        </p>
      </div>

      {/* Photo upload + preview */}
      <div className="space-y-1.5">
        <Label className="text-primary-dark font-semibold">
          Photo <span className="text-primary-dark/60 font-normal">(optional)</span>
        </Label>

        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <label
            htmlFor="photo"
            className="cursor-pointer inline-flex items-center gap-2 px-4 py-2.5 rounded-full border border-dashed border-primary/40 bg-surface-purple/40 text-primary font-semibold text-sm hover:bg-surface-purple/80 transition"
          >
            <MaterialSymbol name="add_a_photo" className="text-base" />
            {data.photoUrl ? "Change photo" : "Choose a photo"}
          </label>
          <input
            ref={fileInputRef}
            id="photo"
            type="file"
            accept="image/*"
            onChange={onPhotoChange}
            className="sr-only"
          />

          {data.photoUrl ? (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="relative"
            >
              { }
              <img
                src={data.photoUrl}
                alt="Selected preview"
                className="w-24 h-24 object-cover rounded-xl border border-surface-purple"
              />
              <button
                type="button"
                onClick={() => {
                  update("photoUrl", undefined);
                  if (fileInputRef.current) fileInputRef.current.value = "";
                }}
                className="absolute -top-2 -right-2 w-11 h-11 rounded-full bg-red-500 text-white text-xs grid place-items-center shadow hover:bg-red-600"
                aria-label="Remove photo"
              >
                <MaterialSymbol name="close" className="text-sm" />
              </button>
            </motion.div>
          ) : (
            <span className="text-xs text-primary-dark/60">
              JPG, PNG or WebP - max 4 MB. We&apos;ll preview it here.
            </span>
          )}
        </div>

        {errors.photoUrl ? (
          <p className="text-red-500 text-xs font-medium" role="alert">
            {errors.photoUrl}
          </p>
        ) : null}
      </div>

      {/* Consent */}
      <div className="space-y-1.5">
        <label
          htmlFor="consent"
          className={`flex items-start gap-3 p-4 rounded-xl border cursor-pointer transition ${
            errors.consent
              ? "border-red-400 bg-red-50/40"
              : "border-surface-purple bg-surface-purple/40 hover:bg-surface-purple/70"
          }`}
        >
          <Checkbox
            id="consent"
            checked={data.consent}
            onCheckedChange={(v) => update("consent", v === true)}
            className="mt-0.5 data-[state=checked]:bg-primary data-[state=checked]:border-primary"
          />
          <span className="text-sm text-primary-dark/80 leading-relaxed">
            I agree to Waggies using my testimonial on their website and
            marketing materials.
          </span>
        </label>
        {errors.consent ? (
          <p className="text-red-500 text-xs font-medium" role="alert">
            {errors.consent}
          </p>
        ) : null}
      </div>

      {/* Summary preview */}
      <div className="mt-2 rounded-xl border border-surface-purple bg-white p-4">
        <p className="text-[11px] font-semibold uppercase tracking-wide text-primary-dark/50 mb-2">
          Your submission
        </p>
        <div className="flex items-center gap-3 text-sm">
          <div className="flex items-center gap-0.5">
            {[1, 2, 3, 4, 5].map((n) => (
              <MaterialSymbol
                key={n}
                name="star"
                filled={data.rating >= n}
                className={`text-base ${
                  data.rating >= n ? "text-[#F59E0B]" : "text-primary-dark/20"
                }`}
              />
            ))}
          </div>
          <span className="text-primary-dark/60">·</span>
          <span className="font-semibold text-primary-dark">
            {data.service || " - "}
          </span>
          <span className="text-primary-dark/60">·</span>
          <span className="text-primary-dark/70">
            {data.authorName || "Your name"}
            {data.authorLocation ? ` · ${data.authorLocation}` : ""}
          </span>
        </div>
        {data.title ? (
          <p className="font-serif text-base font-bold text-primary-dark mt-2">
            {data.title}
          </p>
        ) : null}
        {data.story ? (
          <p className="text-sm text-primary-dark/70 mt-1 line-clamp-2">
            {data.story}
          </p>
        ) : null}
      </div>
    </div>
  );
}

// ── Animated checkmark (SVG path drawing) ─────────────────────────────────

function AnimatedCheck() {
  return (
    <svg
      width="64"
      height="64"
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden
    >
      <motion.circle
        cx="32"
        cy="32"
        r="28"
        stroke="#6B2C91"
        strokeWidth="3"
        fill="#F5F0FA"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 0.5, ease: "easeOut" }}
      />
      <motion.path
        d="M20 33 L28 41 L44 24"
        stroke="#6B2C91"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.4, delay: 0.3, ease: "easeOut" }}
      />
    </svg>
  );
}
