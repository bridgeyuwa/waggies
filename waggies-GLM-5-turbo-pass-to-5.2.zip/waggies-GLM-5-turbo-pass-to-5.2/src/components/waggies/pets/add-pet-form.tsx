"use client";

import { useState } from "react";
import type { Pet } from "@/store/pet-store";
import { usePetStore } from "@/store/pet-store";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type AddPetFormProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** If provided, the form is in edit mode */
  editingPet?: Pet | null;
};

const SPECIES_OPTIONS = [
  { value: "dog" as const, label: "Dog" },
  { value: "cat" as const, label: "Cat" },
  { value: "bird" as const, label: "Bird" },
  { value: "rabbit" as const, label: "Rabbit" },
  { value: "other" as const, label: "Other" },
];

const SEX_OPTIONS = [
  { value: "male" as const, label: "Male" },
  { value: "female" as const, label: "Female" },
  { value: "unknown" as const, label: "Unknown" },
];

const EMPTY_FORM = {
  name: "",
  species: "dog" as Pet["species"],
  breed: "",
  dateOfBirth: "",
  sex: "male" as Pet["sex"],
  weight: "",
  notes: "",
  vaccinationNotes: "",
};

export function AddPetForm({ open, onOpenChange, editingPet }: AddPetFormProps) {
  const { addPet, updatePet } = usePetStore();
  const isEditing = !!editingPet;
  const dialogTitle = isEditing ? `Edit ${editingPet.name}` : "Add a Pet";
  const dialogDescription = isEditing
    ? "Update your pet’s details."
    : "Fill in your pet’s details to save their profile.";

  // Derive initial form state from editingPet (no useEffect needed).
  // The parent uses a `key` to force remount when the editing pet changes.
  const [form, setForm] = useState(() =>
    editingPet
      ? {
          name: editingPet.name,
          species: editingPet.species,
          breed: editingPet.breed,
          dateOfBirth: editingPet.dateOfBirth,
          sex: editingPet.sex,
          weight: editingPet.weight,
          notes: editingPet.notes,
          vaccinationNotes: editingPet.vaccinationNotes,
        }
      : EMPTY_FORM,
  );
  const [errors, setErrors] = useState<Record<string, string>>({});

  function updateField<K extends keyof typeof form>(key: K, value: (typeof form)[K]) {
    setForm((prev) => ({ ...prev, [key]: value }));
    // Clear error on change
    if (errors[key]) {
      setErrors((prev) => {
        const next = { ...prev };
        delete next[key];
        return next;
      });
    }
  }

  function validate(): boolean {
    const newErrors: Record<string, string> = {};
    if (!form.name.trim()) newErrors.name = "Name is required.";
    if (!form.breed.trim()) newErrors.breed = "Breed is required.";
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!validate()) return;

    if (isEditing && editingPet) {
      updatePet(editingPet.id, form);
    } else {
      addPet(form);
    }
    onOpenChange(false);
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-white rounded-2xl max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="font-serif text-xl text-primary-dark">
            <MaterialSymbol name={isEditing ? "edit" : "add_circle"} className="text-primary mr-2 text-xl align-middle" ariaHidden={false} />
            {dialogTitle}
          </DialogTitle>
          <DialogDescription className="text-primary-dark/60">
            {dialogDescription}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4 py-2">
          {/* Name */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="pet-name" className="text-sm font-medium text-primary-dark">
              Name <span className="text-red-500">*</span>
            </Label>
            <Input
              id="pet-name"
              value={form.name}
              onChange={(e) => updateField("name", e.target.value)}
              placeholder="e.g. Buddy"
              className="bg-surface border-primary/10 focus-visible:ring-primary/30"
            />
            {errors.name && (
              <p className="text-xs text-red-500">{errors.name}</p>
            )}
          </div>

          {/* Species + Sex row */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="pet-species" className="text-sm font-medium text-primary-dark">
                Species <span className="text-red-500">*</span>
              </Label>
              <Select
                value={form.species}
                onValueChange={(v) => updateField("species", v as Pet["species"])}
              >
                <SelectTrigger id="pet-species" className="bg-surface border-primary/10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  {SPECIES_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="pet-sex" className="text-sm font-medium text-primary-dark">
                Sex
              </Label>
              <Select
                value={form.sex}
                onValueChange={(v) => updateField("sex", v as Pet["sex"])}
              >
                <SelectTrigger id="pet-sex" className="bg-surface border-primary/10">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent className="bg-white">
                  {SEX_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>
                      {opt.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Breed */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="pet-breed" className="text-sm font-medium text-primary-dark">
              Breed <span className="text-red-500">*</span>
            </Label>
            <Input
              id="pet-breed"
              value={form.breed}
              onChange={(e) => updateField("breed", e.target.value)}
              placeholder="e.g. Golden Retriever"
              className="bg-surface border-primary/10 focus-visible:ring-primary/30"
            />
            {errors.breed && (
              <p className="text-xs text-red-500">{errors.breed}</p>
            )}
          </div>

          {/* Date of Birth + Weight row */}
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-1.5">
              <Label htmlFor="pet-dob" className="text-sm font-medium text-primary-dark">
                Date of Birth
              </Label>
              <Input
                id="pet-dob"
                type="date"
                value={form.dateOfBirth}
                onChange={(e) => updateField("dateOfBirth", e.target.value)}
                className="bg-surface border-primary/10 focus-visible:ring-primary/30"
              />
            </div>

            <div className="flex flex-col gap-1.5">
              <Label htmlFor="pet-weight" className="text-sm font-medium text-primary-dark">
                Weight
              </Label>
              <Input
                id="pet-weight"
                value={form.weight}
                onChange={(e) => updateField("weight", e.target.value)}
                placeholder="e.g. 12 kg"
                className="bg-surface border-primary/10 focus-visible:ring-primary/30"
              />
            </div>
          </div>

          {/* Vaccination notes */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="pet-vax" className="text-sm font-medium text-primary-dark">
              Vaccination Notes
            </Label>
            <Textarea
              id="pet-vax"
              value={form.vaccinationNotes}
              onChange={(e) => updateField("vaccinationNotes", e.target.value)}
              placeholder="e.g. Rabies - March 2025, DHPP - due July 2025"
              rows={2}
              className="bg-surface border-primary/10 focus-visible:ring-primary/30 resize-none"
            />
          </div>

          {/* General notes */}
          <div className="flex flex-col gap-1.5">
            <Label htmlFor="pet-notes" className="text-sm font-medium text-primary-dark">
              Notes
            </Label>
            <Textarea
              id="pet-notes"
              value={form.notes}
              onChange={(e) => updateField("notes", e.target.value)}
              placeholder="Any other details about your pet"
              rows={2}
              className="bg-surface border-primary/10 focus-visible:ring-primary/30 resize-none"
            />
          </div>

          <DialogFooter className="pt-2">
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
              className="rounded-full border-primary/20 text-primary-dark hover:bg-surface-purple"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              className="rounded-full bg-primary hover:bg-primary-dark text-white"
            >
              {isEditing ? "Save Changes" : "Add Pet"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
