"use client";

import { useEffect, useState } from "react";
import { usePetStore, type Pet } from "@/store/pet-store";
import { PetProfileCard } from "./pet-profile-card";
import { AddPetForm } from "./add-pet-form";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

export function MyPetsClient() {
  const { pets, initialized, init, deletePet } = usePetStore();
  const [formOpen, setFormOpen] = useState(false);
  const [editingPet, setEditingPet] = useState<Pet | null>(null);
  const [deleteId, setDeleteId] = useState<string | null>(null);

  // Initialize store from localStorage on mount
  useEffect(() => {
    init();
  }, [init]);

  function handleEdit(pet: Pet) {
    setEditingPet(pet);
    setFormOpen(true);
  }

  function handleFormOpenChange(open: boolean) {
    setFormOpen(open);
    if (!open) setEditingPet(null);
  }

  function handleConfirmDelete() {
    if (deleteId) {
      deletePet(deleteId);
      setDeleteId(null);
    }
  }

  // Show a skeleton/loading state until initialized
  if (!initialized) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {[1, 2].map((i) => (
              <div key={i} className="bg-surface rounded-xl p-6 animate-pulse">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-full bg-primary/10" />
                  <div className="flex-1">
                    <div className="h-5 bg-primary/10 rounded w-24 mb-2" />
                    <div className="h-3 bg-primary/10 rounded w-36" />
                  </div>
                </div>
                <div className="grid grid-cols-3 gap-3">
                  <div className="h-4 bg-primary/10 rounded w-16" />
                  <div className="h-4 bg-primary/10 rounded w-16" />
                  <div className="h-4 bg-primary/10 rounded w-16" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <>
      <section className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="mb-8 flex items-start gap-3 bg-surface-purple rounded-xl p-4 border border-primary/5">
            <MaterialSymbol name="info" className="text-primary text-lg shrink-0 mt-0.5" />
            <p className="text-sm text-primary-dark/70">
              Pet profiles are saved locally on this device.{" "}
              <span className="font-medium text-primary-dark">Sign in to sync across devices.</span>
            </p>
          </div>

          {pets.length === 0 ? (
            <div className="text-center py-16">
              <div className="w-20 h-20 rounded-full bg-surface-purple flex items-center justify-center mx-auto mb-6">
                <MaterialSymbol name="pets" className="text-4xl text-primary/50" />
              </div>
              <h2 className="font-serif text-2xl font-bold text-primary-dark mb-2">
                No pets yet
              </h2>
              <p className="text-primary-dark/60 mb-8 max-w-md mx-auto">
                Add your first pet profile to keep track of their details, vaccination records, and more.
              </p>
              <button
                type="button"
                onClick={() => setFormOpen(true)}
                className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
              >
                <MaterialSymbol name="add" className="text-lg" />
                Add Your First Pet
              </button>
            </div>
          ) : (
            <>
              <div className="flex items-center justify-between mb-6">
                <p className="text-sm text-primary-dark/60">
                  {pets.length} pet{pets.length !== 1 ? "s" : ""} saved
                </p>
                <button
                  type="button"
                  onClick={() => setFormOpen(true)}
                  className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-5 py-2.5 rounded-full text-sm font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
                >
                  <MaterialSymbol name="add" className="text-base" />
                  Add Pet
                </button>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {pets.map((pet) => (
                  <PetProfileCard
                    key={pet.id}
                    pet={pet}
                    onEdit={handleEdit}
                    onDelete={setDeleteId}
                  />
                ))}
              </div>
            </>
          )}
        </div>
      </section>

      <AddPetForm
        key={editingPet?.id ?? "new"}
        open={formOpen}
        onOpenChange={handleFormOpenChange}
        editingPet={editingPet}
      />

      <AlertDialog open={!!deleteId} onOpenChange={(open) => !open && setDeleteId(null)}>
        <AlertDialogContent className="bg-white rounded-2xl">
          <AlertDialogHeader>
            <AlertDialogTitle className="font-serif text-xl text-primary-dark">
              Delete pet profile?
            </AlertDialogTitle>
            <AlertDialogDescription className="text-primary-dark/60">
              This will permanently remove this pet’s profile from this device. This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="rounded-full border-primary/20">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleConfirmDelete}
              className="rounded-full bg-red-500 hover:bg-red-600 text-white"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}
