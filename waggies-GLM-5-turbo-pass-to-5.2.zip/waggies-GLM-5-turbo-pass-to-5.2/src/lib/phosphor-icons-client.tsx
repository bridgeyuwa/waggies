"use client";

import React from "react";
import {
  Info,
  Check,
  CheckCircle,
  Warning,
  WarningCircle,
  Minus,
  Plus,
  ArrowCounterClockwise,
  Wallet,
  Confetti,
  Eye,
  Ear,
  Smiley,
  Sparkle,
  Footprints,
  Wind,
  Heart,
  // Re-export commonly needed icons
  PawPrint,
  Cat,
  Brain,
  ForkKnife,
  Heartbeat,
  MagnifyingGlass,
  Syringe,
  Stethoscope,
  Scissors,
  GraduationCap,
  Building,
  Camera,
  Star,
  ArrowRight,
  Clock,
  CaretDown,
  Phone,
  Question,
  Calculator,
  ShieldCheck,
  Truck,
  Bird,
  BugBeetle,
  ClipboardText,
  Pill,
} from "@phosphor-icons/react";

const PHOSPHOR_ICONS: Record<
  string,
  React.ComponentType<{
    size?: number;
    weight?: string;
    className?: string;
  }>
> = {
  // Direct Phosphor names
  info: Info,
  check: Check,
  "check-circle": CheckCircle,
  check_circle: CheckCircle,
  warning: Warning,
  "warning-circle": WarningCircle,
  warning_circle: WarningCircle,
  minus: Minus,
  plus: Plus,
  "arrow-counter-clockwise": ArrowCounterClockwise,
  arrow_counter_clockwise: ArrowCounterClockwise,
  refresh: ArrowCounterClockwise,
  wallet: Wallet,
  payments: Wallet,
  confetti: Confetti,
  celebration: Confetti,
  eye: Eye,
  visibility: Eye,
  ear: Ear,
  hearing: Ear,
  smiley: Smiley,
  sentiment_satisfied: Smiley,
  sparkle: Sparkle,
  spa: Sparkle,
  footprints: Footprints,
  directions_walk: Footprints,
  wind: Wind,
  air: Wind,
  heart: Heart,
  cruelty_free: Heart,

  // Animal icons
  dog: PawPrint,
  cat: Cat,
  pets: PawPrint,

  // Body / health
  psychology: Brain,
  brain: Brain,
  monitor_heart: Heartbeat,
  heartbeat: Heartbeat,
  stethoscope: Stethoscope,
  "medical-information": Info,
  medical_information: Info,
  "medical-services": Stethoscope,
  medical_services: Stethoscope,
  syringe: Syringe,
  vaccines: Syringe,
  "fork-knife": ForkKnife,
  restaurant: ForkKnife,

  // Service / utility
  "paw-print": PawPrint,
  calculator: Calculator,
  shield: ShieldCheck,
  "local_shipping": Truck,
  flutter_dash: Bird,
  "pest_control": BugBeetle,
  "clipboard-text": ClipboardText,
  clipboard_text: ClipboardText,
  pill: Pill,
  toys: Star,
  dentistry: Heart,
  content_cut: Scissors,
  "flight_takeoff": ArrowRight,
  apartment: Building,
  hotel: Building,
  building: Building,
  scissors: Scissors,
  "graduation-cap": GraduationCap,
  school: GraduationCap,
  camera: Camera,
  star: Star,
  "arrow-right": ArrowRight,
  arrow_forward: ArrowRight,
  clock: Clock,
  schedule: Clock,
  "caret-down": CaretDown,
  expand_more: CaretDown,
  phone: Phone,
  call: Phone,
  question: Question,

  // Search
  search: MagnifyingGlass,
  "magnifying-glass": MagnifyingGlass,

  // Emergency
  emergency: WarningCircle,
};

/**
 * Client-side Phosphor icon renderer.
 * Mirrors phosphor-icons.ts but uses the client bundle.
 */
export function PhosphorIcon({
  name,
  size = 20,
  weight = "regular",
  className,
}: {
  name: string;
  size?: number;
  weight?: string;
  className?: string;
}) {
  const Comp = PHOSPHOR_ICONS[name] ?? Question;
  return React.createElement(
    Comp,
    { size, weight, className } as Record<string, unknown>,
  );
}
