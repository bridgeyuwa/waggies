/**
 * Waggies site-level data.
 *
 * All content in this file is extracted verbatim from the Laravel source
 * (resources/views/components/navbar.blade.php, footer.blade.php,
 * whatsapp-fab.blade.php, layouts/app.blade.php, config/waggies.php).
 *
 * Do NOT paraphrase, modernize, or "clean up" this content. The Laravel
 * application is the source of truth for Phase 1 of the migration.
 *
 */

/**
 * Resolve the deployment public origin from environment configuration.
 *
 * The site URL is read from the `NEXT_PUBLIC_SITE_URL` environment variable
 * (documented in `.env.example`). It MUST be set for any deployment - there
 * is no hardcoded production domain in source code.
 *
 * ── Distinguishing four concepts ─────────────────────────────────────────
 *
 *   1. Server listen address  - `0.0.0.0:3000` (Next.js standalone default;
 *      overridable via `PORT` / `HOSTNAME`). This is WHERE the server
 *      listens. It is NOT the public origin.
 *
 *   2. Browser origin         - whatever origin the browser used to reach
 *      the server. In local dev this is `http://localhost:3000`; behind a
 *      preview proxy it could be `https://preview-xxx.space-z.ai`; in
 *      production it is the deployment's public URL. The application does
 *      NOT control this; the deployment infrastructure does.
 *
 *   3. Canonical/OG/JSON-LD   - the absolute URL emitted in <link
 *      rel="canonical">, Open Graph tags, and JSON-LD structured data.
 *      This is what `siteConfig.siteUrl` controls. It MUST be a stable,
 *      absolute URL - search engines and social platforms require it.
 *
 *   4. Deployment config      - `NEXT_PUBLIC_SITE_URL`, supplied by the
 *      deployment environment at BUILD time. This is the only source of
 *      the canonical origin in source code.
 *
 * ── Why NEXT_PUBLIC_* (build-time inlined) ───────────────────────────────
 *
 * `NEXT_PUBLIC_*` (rather than a non-prefixed server-only variable) is used
 * because:
 *
 *   1. Next.js statically inlines `NEXT_PUBLIC_*` vars at BUILD time into
 *      both server and client bundles. Non-prefixed vars are only available
 *      at request time on the server. Since 35 of our 41 routes are
 *      statically prerendered (`○ Static`), the metadata export in
 *      `src/app/layout.tsx` (which reads `siteConfig.siteUrl` to set
 *      `metadataBase`) is evaluated at BUILD time. A non-prefixed var would
 *      be `undefined` during static prerender, breaking canonical/OG/JSON-LD
 *      URLs on every static page.
 *
 *   2. The deployment public origin is not a secret - it is published in
 *      `<link rel="canonical">`, Open Graph tags, JSON-LD structured data,
 *      and sitemap entries on every page. Exposing it to the client bundle
 *      (the trade-off of `NEXT_PUBLIC_*`) carries no security risk.
 *
 *   3. Using a single variable name keeps configuration simple: the operator
 *      sets `NEXT_PUBLIC_SITE_URL` once in `.env` (or the deployment
 *      platform's environment configuration) and every consumer - server
 *      component, client component, and metadata export - reads the same
 *      value via `siteConfig.siteUrl`.
 *
 * ── Dev-only fallback (NOT a public identity) ────────────────────────────
 *
 * If `NEXT_PUBLIC_SITE_URL` is unset, we fall back to `http://localhost:3000`.
 * This is a DEV-ONLY convenience - it lets `bun run dev` produce valid
 * absolute canonical/OG/JSON-LD URLs without forcing the developer to
 * create a `.env` file first.
 *
 * IMPORTANT: This fallback is NOT the application's permanent public
 * identity. It is the loopback dev-server address, used ONLY when no
 * deployment origin is supplied. It must NEVER be treated as the expected
 * canonical origin in production. In production, an unset variable causes
 * canonical URLs to point at localhost - a visible misconfiguration the
 * operator must fix by setting the env var. There is no scenario in which
 * a real production domain is silently used as a fallback.
 *
 * This fallback is the documented Next.js convention for `metadataBase`
 * (see `create-next-app` defaults and the Next.js metadata API docs). It
 * is NOT a Waggies-specific invention.
 *
 * ── Validation ───────────────────────────────────────────────────────────
 *
 * The resolved URL is parsed with `new URL()` to catch malformed values
 * early. A malformed `NEXT_PUBLIC_SITE_URL` will throw at module load time,
 * failing loudly rather than emitting broken canonical URLs.
 *
 * ── Verification philosophy ──────────────────────────────────────────────
 *
 * Tests/audits must verify CONFIGURATION BEHAVIOR (origin X → canonical X),
 * NOT assert that `http://localhost:3000` is "the expected origin". The
 * dev fallback is acceptable in the no-env-var case, but the regression
 * suite must also prove that arbitrary deployment origins
 * (e.g. `https://example-deployment.invalid`, `https://preview.example.test`)
 * produce matching canonical/OG/JSON-LD URLs without source changes.
 */
const RAW_SITE_URL = process.env.NEXT_PUBLIC_SITE_URL;
const SITE_URL: string = (() => {
  // Dev-only fallback. See the JSDoc above for why this exists and what it
  // is NOT. In production, NEXT_PUBLIC_SITE_URL must be set explicitly.
  const devFallback = "http://localhost:3000";
  const raw =
    RAW_SITE_URL && RAW_SITE_URL.trim().length > 0
      ? RAW_SITE_URL.trim()
      : devFallback;
  // Validate the URL format. Throws on malformed input - intentional, so the
  // operator sees the error at build/start time rather than serving broken
  // canonical URLs in production. The result is discarded; the call exists
  // purely for its validation side-effect.
  void new URL(raw);
  return raw;
})();

export const siteConfig = {
  name: "Waggies",
  /** Default <title> when no page title is supplied. */
  defaultTitle: "Waggies - Pet Care, Abuja",
  /** Default meta description (matches Laravel fallback). */
  defaultDescription:
    "Waggies provides pet boarding, grooming, vet care, training, relocation and local transport services in Abuja, Nigeria.",
  /** OpenGraph description (Laravel uses a slightly shorter fallback for OG). */
  defaultOgDescription:
    "Pet boarding, grooming, vet care and relocation services in Abuja, Nigeria.",
  /**
   * Deployment public origin - the absolute URL emitted in <link
   * rel="canonical">, Open Graph tags, and JSON-LD structured data.
   *
   * Resolved from `NEXT_PUBLIC_SITE_URL` at module load time (BUILD time
   * for static prerender). When unset, falls back to `http://localhost:3000`
   * as a DEV-ONLY convenience - see the URL-resolution block above for why
   * this fallback exists and what it is NOT.
   *
   * For any deployment, set `NEXT_PUBLIC_SITE_URL` to the fully-qualified
   * public URL (e.g. `https://your-production-domain.example`). It is NOT
   * hardcoded in source. See `.env.example` and
   * `scripts/deployment-procedure.md`.
   */
  siteUrl: SITE_URL,
  locale: "en_NG",
  twitterHandle: undefined,
  /** Default OG image - Laravel layout does not set one by default. */
  defaultOgImage: undefined,
} as const;

/**
 * Social profile links with inline SVG paths.
 *
 * @deprecated This array contains hand-drawn SVG paths that violate the icon policy.
 *             It is NOT imported by any live component — the footer (footer.tsx)
 *             renders social icons directly from @phosphor-icons/react/dist/ssr
 *             (InstagramLogo, FacebookLogo, etc.) using businessInfo.socials.
 *             Kept here for reference only; do NOT import this in new code.
 */
export const socialLinks: ReadonlyArray<{
  label: string;
  href: string;
  /** Inline SVG path content (matches Laravel footer.blade.php). */
  svg: React.ReactNode;
}> = [
  {
    label: "Instagram",
    href: "#",
    svg: (
      <path
        fillRule="evenodd"
        d="M12.315 2c2.43 0 2.784.013 3.808.06 1.064.049 1.791.218 2.427.465a4.902 4.902 0 011.772 1.153 4.902 4.902 0 011.153 1.772c.247.636.416 1.363.465 2.427.048 1.067.06 1.407.06 4.123v.08c0 2.643-.012 2.987-.06 4.043-.049 1.064-.218 1.791-.465 2.427a4.902 4.902 0 01-1.153 1.772 4.902 4.902 0 01-1.772 1.153c-.636.247-1.363.416-2.427.465-1.067.048-1.407.06-4.123.06h-.08c-2.643 0-2.987-.012-4.043-.06-1.064-.049-1.791-.218-2.427-.465a4.902 4.902 0 01-1.772-1.153 4.902 4.902 0 01-1.153-1.772c-.247-.636-.416-1.363-.465-2.427-.047-1.024-.06-1.379-.06-3.808v-.63c0-2.43.013-2.784.06-3.808.049-1.064.218-1.791.465-2.427a4.902 4.902 0 011.153-1.772A4.902 4.902 0 015.45 2.525c.636-.247 1.363-.416 2.427-.465C8.901 2.013 9.256 2 11.685 2h.63zm-.081 1.802h-.468c-2.456 0-2.784.011-3.807.058-.975.045-1.504.207-1.857.344-.467.182-.8.398-1.15.748-.35.35-.566.683-.748 1.15-.137.353-.3.882-.344 1.857-.047 1.023-.058 1.351-.058 3.807v.468c0 2.456.011 2.784.058 3.807.045.975.207 1.504.344 1.857.182.466.399.8.748 1.15.35.35.683.566 1.15.748.353.137.882.3 1.857.344 1.054.048 1.37.058 4.041.058h.08c2.597 0 2.917-.01 3.96-.058.976-.045 1.505-.207 1.858-.344.466-.182.8-.398 1.15-.748.35-.35.566-.683.748-1.15.137-.353.3-.882.344-1.857.048-1.055.058-1.37.058-4.041v-.08c0-2.597-.01-2.917-.058-3.96-.045-.976-.207-1.505-.344-1.858a3.097 3.097 0 00-.748-1.15 3.098 3.098 0 00-1.15-.748c-.353-.137-.882-.3-1.857-.344-1.023-.047-1.351-.058-3.807-.058zM12 6.865a5.135 5.135 0 110 10.27 5.135 5.135 0 010-10.27zm0 1.802a3.333 3.333 0 100 6.666 3.333 3.333 0 000-6.666zm5.338-3.205a1.2 1.2 0 110 2.4 1.2 1.2 0 010-2.4z"
        clipRule="evenodd"
      />
    ),
  },
  {
    label: "Facebook",
    href: "#",
    // Laravel dark variant path (we render the dark footer verbatim).
    svg: (
      <path
        fillRule="evenodd"
        d="M22 12c0-5.523-4.477-10-10-10S2 6.477 2 12c0 4.991 3.657 9.128 8.438 9.878v-6.987h-2.54V12h2.54V9.797c0-2.506 1.492-3.89 3.777-3.89 1.094 0 2.238.195 2.238.195v2.46h-1.26c-1.243 0-1.63.771-1.62 1.562V12h2.773l-.443 2.89h-2.33v6.988C18.343 21.128 22 16.991 22 12z"
        clipRule="evenodd"
      />
    ),
  },
  {
    label: "TikTok",
    href: "#",
    svg: (
      <path d="M16.656 1.029c1.637-0.025 3.262-0.012 4.886-0.025 0.054 2.031 0.878 3.859 2.189 5.213l-0.002-0.002c1.411 1.271 3.247 2.095 5.271 2.235l0.028 0.002v5.036c-1.912-0.048-3.71-0.489-5.331-1.247l0.082 0.034c-0.784-0.377-1.447-0.764-2.077-1.196l0.052 0.034c-0.012 3.649 0.012 7.298-0.025 10.934-0.103 1.853-0.719 3.543-1.707 4.954l0.020-0.031c-1.652 2.366-4.328 3.919-7.371 4.011l-0.014 0c-0.123 0.006-0.268 0.009-0.414 0.009-1.73 0-3.347-0.482-4.725-1.319l0.040 0.023c-2.508-1.509-4.238-4.091-4.558-7.094l-0.004-0.041c-0.025-0.625-0.037-1.25-0.012-1.862 0.49-4.779 4.494-8.476 9.361-8.476 0.547 0 1.083 0.047 1.604 0.136l-0.056-0.008c0.025 1.849-0.050 3.699-0.050 5.548-0.423-0.153-0.911-0.242-1.42-0.242-1.868 0-3.457 1.194-4.045 2.861l-0.009 0.030c-0.133 0.427-0.21 0.918-0.21 1.426 0 0.206 0.013 0.41 0.037 0.61l-0.002-0.024c0.332 2.046 2.086 3.59 4.201 3.59 0.061 0 0.121-0.001 0.181-0.004l-0.009 0c1.463-0.044 2.733-0.831 3.451-1.994l0.010-0.018c0.267-0.372 0.45-0.822 0.511-1.311l0.001-0.014c0.125-2.237 0.075-4.461 0.087-6.698 0.012-5.036-0.012-10.060 0.025-15.083z" />
    ),
  },
  {
    label: "X",
    href: "#",
    svg: (
      <path d="M13.6823 10.6218L20.2391 3H18.6854L12.9921 9.61788L8.44486 3H3.2002L10.0765 13.0074L3.2002 21H4.75404L10.7663 14.0113L15.5685 21H20.8131L13.6819 10.6218H13.6823ZM11.5541 13.0956L10.8574 12.0991L5.31391 4.16971H7.70053L12.1742 10.5689L12.8709 11.5655L18.6861 19.8835H16.2995L11.5541 13.096V13.0956Z" />
    ),
  },
  {
    label: "YouTube",
    href: "#",
    svg: (
      <path
        fillRule="evenodd"
        d="M19.812 5.418c.861.23 1.538.907 1.768 1.768C21.998 8.746 22 12 22 12s0 3.255-.418 4.814a2.504 2.504 0 0 1-1.768 1.768c-1.56.419-7.814.419-7.814.419s-6.255 0-7.814-.419a2.505 2.505 0 0 1-1.768-1.768C2 15.255 2 12 2 12s0-3.255.417-4.814a2.507 2.507 0 0 1 1.768-1.768C5.744 5 11.998 5 11.998 5s6.255 0 7.814.418ZM15.194 12 10 15V9l5.194 3Z"
        clipRule="evenodd"
      />
    ),
  },
];

/**
 * Desktop mega-menu link (single row inside a flyout panel).
 * Mirrors x-navbar.mega-link Blade component exactly.
 */
export type MegaLink = {
  href: string;
  /** Phosphor icon component name (e.g. "house-line", "dog", "stethoscope"). */
  icon: string;
  title: string;
  subtitle: string;
};

/**
 * Mobile accordion link (simple bullet row).
 * Mirrors x-navbar.mobile-link Blade component exactly.
 */
export type MobileLink = {
  href: string;
  label: string;
};

/**
 * Mobile accordion group (heading + nested links).
 * Mirrors x-navbar.mobile-group Blade component exactly.
 */
export type MobileGroup = {
  heading: string;
  links: MobileLink[];
};

/**
 * Top-level desktop menu definition.
 *
 * `services`, `about`, `resources` are the three menus that have flyout panels
 * (Alpine-controlled). `shop` is a plain link with no panel.
 *
 * The original Alpine state machine supports `services | about | resources` as
 * the only values for `activeMenu` / `pinnedMenu`. We preserve that invariant.
 */
export type DesktopMenuKey = "services" | "about" | "resources" | "tools";

/**
 * Services mega-menu (3-column grid). Order matters - preserved verbatim from
 * navbar.blade.php lines 130–158.
 */
export const servicesMenuColumns: ReadonlyArray<{
  groupLabel: string;
  links: MegaLink[];
}> = [
  {
    groupLabel: "Boarding",
    links: [
      { href: "/services/boarding", icon: "house-line", title: "Boarding", subtitle: "Overnight stays" },
      { href: "/services/boarding/dogs", icon: "dog", title: "Dog Boarding", subtitle: "Tailored for your dog" },
      { href: "/services/boarding/cats", icon: "cat", title: "Cat Boarding", subtitle: "Calm feline retreat" },
      { href: "/services/boarding/exotic", icon: "bug", title: "Exotic Pets", subtitle: "Specialist care" },
    ],
  },
  {
    groupLabel: "Wellness",
    links: [
      { href: "/services/grooming", icon: "scissors", title: "Grooming", subtitle: "Breed-specific treatments" },
      { href: "/services/vet-care", icon: "heartbeat", title: "Vet Care", subtitle: "On-site veterinary support" },
      { href: "/services/training", icon: "graduation-cap", title: "Dog Training", subtitle: "Positive-reinforcement methods" },
    ],
  },
  {
    groupLabel: "Relocation",
    links: [
      { href: "/relocation", icon: "airplane-tilt", title: "Relocation", subtitle: "International pet moves" },
      { href: "/relocation/import", icon: "airplane-landing", title: "Pet Import", subtitle: "Bringing pets into Nigeria" },
      { href: "/relocation/export", icon: "airplane-takeoff", title: "Pet Export", subtitle: "Moving pets abroad" },
      { href: "/relocation/transport", icon: "truck", title: "Local Transport", subtitle: "Door-to-door pickup" },
    ],
  },
];

/**
 * About menu (stacked single-column flyout). Order preserved from
 * navbar.blade.php lines 192–198.
 */
export const aboutMenuLinks: MegaLink[] = [
  { href: "/about", icon: "info", title: "About Us", subtitle: "Our story and mission" },
  { href: "/about/testimonials", icon: "chat-circle-text", title: "Testimonials", subtitle: "What pet owners say" },
  { href: "/about/gallery", icon: "images", title: "Gallery", subtitle: "Moments at Waggies" },
  { href: "/about/careers", icon: "briefcase", title: "Careers", subtitle: "Join our team" },
  { href: "/about/partnerships", icon: "handshake", title: "Partnerships", subtitle: "Grow with us" },
];

/**
 * Resources menu (stacked single-column flyout). Order preserved from
 * navbar.blade.php lines 232–237.
 */
export const resourcesMenuLinks: MegaLink[] = [
  { href: "/faq", icon: "question", title: "FAQ", subtitle: "Quick answers" },
  { href: "/blog", icon: "article", title: "Blog", subtitle: "Pet care articles & tips" },
  { href: "/guides", icon: "book-open", title: "Guides", subtitle: "In-depth pet care guides" },
  { href: "/knowledge-base", icon: "book-bookmark", title: "Knowledge Base", subtitle: "Pet care answers" },
];

/**
 * Tools menu grouped for the desktop mega-menu (3-column grid).
 * Icons are semantically appropriate Phosphor icons.
 */
export const toolsMenuColumns: ReadonlyArray<{
  groupLabel: string;
  links: MegaLink[];
}> = [
  {
    groupLabel: "Pet Health",
    links: [
      { href: "/tools/symptom-checker", icon: "stethoscope", title: "Symptom Checker", subtitle: "Check symptoms and get guidance" },
      { href: "/tools/vaccination-schedule", icon: "syringe", title: "Vaccination Schedule", subtitle: "Recommended vaccination timeline" },
      { href: "/tools/parasite-schedule", icon: "bug-beetle", title: "Parasite & Deworming", subtitle: "Prevention schedule" },
      { href: "/tools/emergency-guide", icon: "warning-circle", title: "Emergency & Poison Guide", subtitle: "Urgent care reference" },
    ],
  },
  {
    groupLabel: "Pet Care",
    links: [
      { href: "/tools/pet-age-calculator", icon: "paw-print", title: "Pet Age Calculator", subtitle: "Pet-to-human age conversion" },
      { href: "/tools/nutrition-calculator", icon: "fork-knife", title: "Diet & Nutrition Calculator", subtitle: "Diet & feeding estimates" },
      { href: "/tools/behavior-tips", icon: "brain", title: "Behavior & Training Tips", subtitle: "Practical pet behavior advice" },
      { href: "/tools/breed-finder", icon: "magnifying-glass", title: "Breed Info Finder", subtitle: "Explore dog & cat breeds" },
    ],
  },
  {
    groupLabel: "Planning",
    links: [
      { href: "/tools/cost-calculator", icon: "calculator", title: "Cost Calculator", subtitle: "Estimate service costs" },
      { href: "/tools/medication-dosage-guide", icon: "pill", title: "Medication Dosage Guide", subtitle: "Veterinary-reviewed reference" },
      { href: "/tools/new-pet-checklist", icon: "clipboard-text", title: "New Pet Checklist", subtitle: "Everything for a new pet" },
    ],
  },
];

/**
 * Tools menu (stacked single-column flyout — kept for reference / backward compat).
 */
export const toolsMenuLinks: MegaLink[] = [
  { href: "/tools/symptom-checker", icon: "stethoscope", title: "Symptom Checker", subtitle: "Check symptoms and get guidance" },
  { href: "/tools/pet-age-calculator", icon: "paw-print", title: "Pet Age Calculator", subtitle: "Pet-to-human age conversion" },
  { href: "/tools/vaccination-schedule", icon: "syringe", title: "Vaccination Schedule", subtitle: "Recommended vaccination timeline" },
  { href: "/tools/cost-calculator", icon: "calculator", title: "Cost Calculator", subtitle: "Estimate service costs" },
  { href: "/tools/medication-dosage-guide", icon: "pill", title: "Medication Dosage Guide", subtitle: "Veterinary-reviewed reference" },
  { href: "/tools/nutrition-calculator", icon: "fork-knife", title: "Nutrition Calculator", subtitle: "Diet & feeding estimates" },
  { href: "/tools/emergency-guide", icon: "warning-circle", title: "Emergency & Poison Guide", subtitle: "Urgent care reference" },
  { href: "/tools/new-pet-checklist", icon: "clipboard-text", title: "New Pet Checklist", subtitle: "Everything for a new pet" },
  { href: "/tools/parasite-schedule", icon: "bug-beetle", title: "Parasite & Deworming", subtitle: "Prevention schedule" },
  { href: "/tools/behavior-tips", icon: "brain", title: "Behavior & Training Tips", subtitle: "Practical pet behavior advice" },
  { href: "/tools/breed-finder", icon: "magnifying-glass", title: "Breed Info Finder", subtitle: "Explore dog & cat breeds" },
];

/**
 * Mobile drawer Services accordion content.
 * Mirrors navbar.blade.php lines 355–373.
 */
export const mobileServicesGroups: MobileGroup[] = [
  {
    heading: "Boarding",
    links: [
      { href: "/services/boarding", label: "Boarding" },
      { href: "/services/boarding/dogs", label: "Dog Boarding" },
      { href: "/services/boarding/cats", label: "Cat Boarding" },
      { href: "/services/boarding/exotic", label: "Exotic Pet Boarding" },
    ],
  },
  {
    heading: "Wellness",
    links: [
      { href: "/services/grooming", label: "Grooming" },
      { href: "/services/vet-care", label: "Vet Care" },
      { href: "/services/training", label: "Dog Training" },
    ],
  },
  {
    heading: "Relocation",
    links: [
      { href: "/relocation", label: "Relocation" },
      { href: "/relocation/import", label: "Pet Import" },
      { href: "/relocation/export", label: "Pet Export" },
      { href: "/relocation/checklist", label: "Doc Checklist" },
      { href: "/relocation/transport", label: "Local Transport" },
    ],
  },
];

/**
 * Mobile drawer About accordion content.
 * Mirrors navbar.blade.php lines 399–405.
 */
export const mobileAboutGroups: MobileGroup[] = [
  {
    heading: "About Waggies",
    links: [
      { href: "/about", label: "About Us" },
      { href: "/about/testimonials", label: "Testimonials" },
      { href: "/about/gallery", label: "Gallery" },
      { href: "/about/careers", label: "Careers" },
      { href: "/about/partnerships", label: "Partnerships" },
    ],
  },
];

/**
 * Mobile drawer Resources accordion content.
 * Mirrors navbar.blade.php lines 432–441.
 */
export const mobileResourcesLinks: MobileLink[] = [
  { href: "/faq", label: "FAQ" },
  { href: "/blog", label: "Blog" },
  { href: "/guides", label: "Guides" },
  { href: "/knowledge-base", label: "Knowledge Base" },
];

/**
 * Mobile drawer Tools accordion content.
 */
export const mobileToolsLinks: MobileLink[] = [
  { href: "/tools", label: "All Tools" },
  { href: "/tools/symptom-checker", label: "Symptom Checker" },
  { href: "/tools/pet-age-calculator", label: "Pet Age Calculator" },
  { href: "/tools/vaccination-schedule", label: "Vaccination Schedule" },
  { href: "/tools/cost-calculator", label: "Cost Calculator" },
  { href: "/tools/medication-dosage-guide", label: "Medication Dosage Guide" },
  { href: "/tools/nutrition-calculator", label: "Nutrition Calculator" },
  { href: "/tools/emergency-guide", label: "Emergency & Poison Guide" },
  { href: "/tools/new-pet-checklist", label: "New Pet Checklist" },
  { href: "/tools/parasite-schedule", label: "Parasite & Deworming" },
  { href: "/tools/behavior-tips", label: "Behavior & Training Tips" },
  { href: "/tools/breed-finder", label: "Breed Info Finder" },
];

/**
 * Footer link columns — Stage 6 IA.
 *
 * Groups: Services, Company, Resources, Support, Legal.
 * Support includes Contact, Booking, Phone, WhatsApp, compact hours.
 */
export const footerLinkColumns: ReadonlyArray<{
  heading: string;
  /** Legal column uses plain links (no bullet); other columns use bullets. */
  variant: "bulleted" | "plain";
  links: ReadonlyArray<{ label: string; href: string }>;
}> = [
  {
    heading: "Services",
    variant: "bulleted",
    links: [
      { label: "Boarding", href: "/services/boarding" },
      { label: "Grooming", href: "/services/grooming" },
      { label: "Veterinary Care", href: "/services/vet-care" },
      { label: "Training", href: "/services/training" },
      { label: "Relocation", href: "/relocation" },
    ],
  },
  {
    heading: "Company",
    variant: "bulleted",
    links: [
      { label: "About", href: "/about" },
      { label: "Testimonials", href: "/about/testimonials" },
      { label: "Gallery", href: "/about/gallery" },
      { label: "Careers", href: "/about/careers" },
      { label: "Partnerships", href: "/about/partnerships" },
    ],
  },
  {
    heading: "Resources",
    variant: "bulleted",
    links: [
      { label: "FAQ", href: "/faq" },
      { label: "Blog", href: "/blog" },
      { label: "Guides", href: "/guides" },
      { label: "Knowledge Base", href: "/knowledge-base" },
      { label: "Tools", href: "/tools" },
    ],
  },
  {
    heading: "Support",
    variant: "bulleted",
    links: [
      { label: "Contact", href: "/contact" },
      { label: "Book Appointment", href: "/contact?intent=book" },
      { label: "Phone", href: "tel:+2349080811902" },
      { label: "WhatsApp", href: "https://wa.me/2349080811902" },
    ],
  },
  {
    heading: "Legal",
    variant: "plain",
    links: [
      { label: "Privacy Policy", href: "/privacy-policy" },
      { label: "Terms of Service", href: "/terms-of-service" },
      { label: "Cookies Policy", href: "/cookies-policy" },
    ],
  },
];

/**
 * Footer brand tagline. Preserved verbatim from footer.blade.php line 35.
 */
export const footerTagline =
  "Pet boarding, grooming, vet care, training, and relocation services in Abuja, Nigeria.";

/**
 * Footer copyright text. Preserved verbatim from footer.blade.php line 184.
 */
export const footerCopyright = "© 2026 Waggies Pet Services. All rights reserved.";

/**
 * WhatsApp floating action button.
 *
 * The Laravel component defines default props (href + tooltip) but does NOT
 * override them at any call site. Preserved verbatim from
 * whatsapp-fab.blade.php lines 2–4.
 */
export const whatsappFab = {
  href: "https://wa.me/2349080811902",
  tooltip: "Chat on WhatsApp",
} as const;

/**
 * Cookie banner localStorage key. The Laravel cookie-banner uses this exact
 * key. Preserved verbatim from cookie-banner.blade.php line 5.
 */
export const cookieStorageKey = "waggies-cookies";

/**
 * Page-section keys supported by the navbar's `nav-section` prop.
 *
 * The Laravel layout passes a `navSection` string into the navbar; the navbar
 * uses it to highlight the active top-level item. We type it here so that
 * individual page migrations in later phases can opt in by importing this type.
 */
export type NavSection =
  | ""
  | "home"
  | "services"
  | "relocation"
  | "about"
  | "tools"
  | "resources"
  | "shop"
  | "my-pets"
  | "contact"
  | "legal";
