"use client";

import { create } from "zustand";

export interface Pet {
  id: string;
  name: string;
  species: "dog" | "cat" | "bird" | "rabbit" | "other";
  breed: string;
  dateOfBirth: string; // ISO date
  sex: "male" | "female" | "unknown";
  weight: string; // e.g. "12 kg"
  notes: string;
  vaccinationNotes: string;
}

const STORAGE_KEY = "waggies-pets";

function loadPets(): Pet[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function savePets(pets: Pet[]) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(pets));
  } catch {
    // localStorage full or unavailable - silently fail
  }
}

interface PetState {
  pets: Pet[];
  initialized: boolean;
  init: () => void;
  addPet: (pet: Omit<Pet, "id">) => void;
  updatePet: (id: string, updates: Partial<Omit<Pet, "id">>) => void;
  deletePet: (id: string) => void;
}

function generateId(): string {
  return `pet_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
}

export const usePetStore = create<PetState>((set, get) => ({
  pets: [],
  initialized: false,

  init: () => {
    if (get().initialized) return;
    const pets = loadPets();
    set({ pets, initialized: true });
  },

  addPet: (pet) => {
    const newPet: Pet = { ...pet, id: generateId() };
    const pets = [...get().pets, newPet];
    set({ pets });
    savePets(pets);
  },

  updatePet: (id, updates) => {
    const pets = get().pets.map((p) =>
      p.id === id ? { ...p, ...updates } : p,
    );
    set({ pets });
    savePets(pets);
  },

  deletePet: (id) => {
    const pets = get().pets.filter((p) => p.id !== id);
    set({ pets });
    savePets(pets);
  },
}));

/**
 * Compute approximate age from an ISO date of birth string.
 * Returns something like "2 years, 3 months".
 */
export function computeAge(dateOfBirth: string): string {
  if (!dateOfBirth) return "Age unknown";
  const dob = new Date(dateOfBirth);
  if (isNaN(dob.getTime())) return "Age unknown";

  const now = new Date();
  let years = now.getFullYear() - dob.getFullYear();
  let months = now.getMonth() - dob.getMonth();

  if (months < 0) {
    years -= 1;
    months += 12;
  }

  const parts: string[] = [];
  if (years > 0) parts.push(`${years} year${years !== 1 ? "s" : ""}`);
  if (months > 0) parts.push(`${months} month${months !== 1 ? "s" : ""}`);

  if (parts.length === 0) {
    const days = Math.floor(
      (now.getTime() - dob.getTime()) / (1000 * 60 * 60 * 24),
    );
    return `${days} day${days !== 1 ? "s" : ""}`;
  }

  return parts.join(", ");
}

/** Species label for display */
export function speciesLabel(species: Pet["species"]): string {
  const map: Record<Pet["species"], string> = {
    dog: "Dog",
    cat: "Cat",
    bird: "Bird",
    rabbit: "Rabbit",
    other: "Other",
  };
  return map[species] ?? species;
}

/** Species icon name for Material Symbols */
export function speciesIcon(species: Pet["species"]): string {
  const map: Record<Pet["species"], string> = {
    dog: "cruelty_free",
    cat: "pets",
    bird: "flutter",
    rabbit: "cruelty_free",
    other: "pest_control",
  };
  return map[species] ?? "pets";
}

/** Sex label for display */
export function sexLabel(sex: Pet["sex"]): string {
  const map: Record<Pet["sex"], string> = {
    male: "Male",
    female: "Female",
    unknown: "Unknown",
  };
  return map[sex] ?? sex;
}
