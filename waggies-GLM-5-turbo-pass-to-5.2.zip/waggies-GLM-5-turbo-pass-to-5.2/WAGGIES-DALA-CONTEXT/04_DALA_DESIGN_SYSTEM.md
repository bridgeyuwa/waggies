# 04 — Dala Design System: Waggies

> **Audience**: Application-building agent. Implementation-oriented design system with intent explanations.
> **Philosophy**: Warm trust-first Nigerian premium. Refactoring UI principles — clear hierarchy, generous whitespace, restrained decoration.
> **Light mode only. No dark mode.**

---

## 1. OKLCH Colors

All brand colors use OKLCH in `globals.css @theme` for perceptual uniformity.

### Brand

| Token | OKLCH | Hex Reference | Intent |
|-------|-------|--------------|--------|
| `--color-primary` | `oklch(0.332 0.155 305)` | #6B2C91 | **Primary purple** — brand identity, CTAs, active states, links. Deep enough for text on white. |
| `--color-primary-dark` | `oklch(0.196 0.108 310)` | #3E1A57 | **Deep purple** — hover states on primary elements, footer background accent. |
| `--color-primary-light` | `oklch(0.489 0.145 305)` | #9D5CC0 | **Medium purple** — subtle highlights, secondary accents, badges. |
| `--color-secondary` | `oklch(0.849 0.037 80)` | #E8D5B5 | **Warm sand** — secondary buttons, section backgrounds, warm accents. Evokes premium natural warmth. |
| `--color-surface` | `oklch(0.985 0.005 90)` | #FDFBF7 | **Off-white cream** — page background. Warmer than pure white, creates a welcoming feel without looking yellow. |
| `--color-surface-purple` | `oklch(0.955 0.018 305)` | #F5F0FA | **Lavender tint** — card backgrounds, highlighted sections, subtle brand presence without heavy purple. |

### Semantic

| Token | Intent |
|-------|--------|
| Foreground/text | Near-black for body text on light backgrounds |
| Muted text | Reduced-contrast for secondary info, meta text |
| Border | Subtle dividers, card borders |
| Input border | Form field borders, slightly more visible than dividers |
| Focus ring | Purple-tinted for WCAG-visible keyboard focus |

### Feedback

| Token | Intent |
|-------|--------|
| Success | Confirmation states — green |
| Warning | Caution states — amber |
| Error | Error states, form validation — red |
| Info | Informational states — blue |

**Design intent**: The purple + sand + cream palette communicates *premium warmth*. Purple is authoritative but approachable. Sand provides organic texture. Cream avoids clinical white. This is NOT a generic SaaS palette — it's intentionally warm for a pet care brand in a market that values personal touch.

---

## 2. Typography

### Font Families

| Role | Font | Source | Weights | Notes |
|------|------|--------|---------|-------|
| **Body** | DM Sans | `next/font/google` | 400, 500, 600, 700 | Clean geometric sans-serif. Highly legible at small sizes. Not overused like Inter/Roboto. |
| **Headings** | Cormorant Garamond | `next/font/google` | 400, 600, 700 | Elegant serif. Normal and italic variants. Creates editorial, premium feel. High contrast with DM Sans body. |

### Type Scale

| Token | Size | Weight | Family | Max-width | Intent |
|-------|------|--------|--------|-----------|--------|
| `text-display` | `clamp(2.25rem, 5vw, 3.5rem)` | 700 | Serif | — | **Hero headlines**. Largest text. Commands attention. Fluid scaling via clamp. |
| `text-h2` | `clamp(1.75rem, 3.5vw, 2.5rem)` | 700 | Serif | — | **Section headings**. Establishes hierarchy. Fluid scaling. |
| `text-h3` | `1.35rem` | 600 | Serif | — | **Subsection headings**. Fixed size, still prominent. |
| `text-h4` | `1.15rem` | 600 | Serif | — | **Card titles, minor headings**. |
| `text-body` | `1rem` | 400 | Sans | `max-w-65ch` | **Primary body text**. 65-character max for optimal line length. |
| `text-body-sm` | `0.875rem` | 400 | Sans | — | **Secondary text, descriptions**. |
| `text-meta` | `0.8125rem` | 400 | Sans | — | **Timestamps, labels, metadata**. |
| `text-label` | `0.75rem` | 600 | Sans | — | **Uppercase labels**, 0.05em letter-spacing. Badges, categories, tags. |
| `text-nav` | `0.9375rem` | 500 | Sans | — | **Navigation items**. Medium weight for scannability. |
| `text-btn` | `0.9375rem` | 600 | Sans | — | **Button text**. Semibold for clear call-to-action. |

**Design intent**: The serif/sans pairing creates an *editorial premium* feel — like a high-end magazine. Display and headings in Cormorant Garamond lend sophistication; DM Sans body ensures readability. The 65ch max-width on body text prevents eye fatigue. Fluid clamp on display/h2 ensures the hero looks right at every viewport.

---

## 3. Spacing

| Context | Value | Intent |
|---------|-------|--------|
| **Content max-width** | `max-w-7xl` (80rem) | Wide enough for content but narrow enough to maintain focus on desktop |
| **Section padding** | `py-20` (5rem) | Generous vertical breathing room between sections. Creates rhythm and prevents visual clutter. |
| **Container horizontal padding** | `px-4` / `md:px-10` / `lg:px-12` | Progressive padding increase. Mobile: tight. Desktop: comfortable margins. |
| **Card grid gaps** | `gap-6` (1.5rem) | Consistent spacing in card grids. Not too tight, not too loose. |
| **Page-level padding** | Section-based, not page-level | Each section manages its own padding. No global page wrapper padding. |

**Design intent**: Generous whitespace signals *premium and unhurried*. The progressive horizontal padding keeps content breathable at every breakpoint without wasting space on mobile.

---

## 4. Radii

| Token | Value | Usage |
|-------|-------|-------|
| `--radius-xs` | `0.125rem` (2px) | Subtle rounding on small elements |
| `--radius-sm` | `0.375rem` (6px) | Small inputs, tags |
| `--radius-md` | `0.5rem` (8px) | Form inputs, select dropdowns |
| `--radius-lg` | `0.75rem` (12px) | Default card rounding |
| `--radius-xl` | `1rem` (16px) | Larger cards, panels |
| `--radius-2xl` | `1.25rem` (20px) | Feature cards, hero elements |
| Buttons / Badges | `rounded-full` | Pill shape for all buttons and badges. Warm, friendly, approachable. |

**Design intent**: Rounded-full buttons are *deliberately friendly* — they feel approachable, which matches the pet care brand. Cards use larger radii (xl/2xl) to feel soft and modern rather than boxy and corporate.

---

## 5. Shadows

| Token | Intent |
|-------|--------|
| `--shadow-xs` | Barely-there elevation for flat elements that need subtle separation |
| `--shadow-sm` | Default card shadow — visible but not heavy |
| `--shadow-md` | Hover state for cards — interactive feedback through elevation change |
| `--shadow-lg` | Elevated elements (modals, dropdowns) |
| `--shadow-xl` | Highest elevation (floating elements like chatbot panel) |
| `--shadow-soft` | Featured elements — purple-tinted, more atmospheric than functional |

All shadows are **purple-tinted** to maintain brand coherence. Shadows scale smoothly from xs to xl.

**Design intent**: Shadows serve *interaction feedback*, not decoration. The sm→md elevation change on card hover tells the user "this is tappable." The purple tint keeps shadows on-brand rather than generic gray.

---

## 6. Button Principles

### Variants

| Variant | Style | Intent |
|---------|-------|--------|
| **Primary** | `bg-primary text-white rounded-full` | Primary action — Book Now, Submit, Add to Cart. High visibility. |
| **Secondary** | `bg-secondary rounded-full` | Secondary action — Learn More, View All. Softer presence. |
| **Ghost** | `border rounded-full` | Tertiary action — Skip, Cancel. Minimal visual weight. |

### Rules
- **Minimum touch target**: 44×44px (WCAG 2.2 AA)
- **All buttons** use `rounded-full` (pill shape)
- **Font**: `text-btn` (DM Sans, 600, 0.9375rem)
- **Hover**: Slight elevation or color shift, never jarring
- **Focus**: Visible purple-tinted focus ring

**Design intent**: Pill-shaped buttons feel *warm and approachable*. The three-tier variant system (primary/secondary/ghost) creates clear visual hierarchy — the user always knows which action is most important.

---

## 7. Cards

| Property | Value | Intent |
|----------|-------|--------|
| Background | `bg-white` | Clean canvas against cream surface |
| Border radius | `rounded-xl` or `rounded-2xl` | Soft, modern feel |
| Shadow | `shadow-sm` → `hover:shadow-md` | Elevation change on hover signals interactivity |
| Padding | Generous internal padding | Content breathes |
| Image | Top or left image with `rounded-xl/2xl` overflow hidden | Images integrate seamlessly into card shape |

**Design intent**: Cards are the *primary content unit*. White on cream creates subtle depth. The shadow elevation on hover is the primary interactive signal — no color changes, no border changes, just a gentle lift.

---

## 8. Forms

| Property | Specification | Intent |
|----------|--------------|--------|
| Labels | Above inputs, `text-body-sm` or `text-label` | Clear association, not placeholder-only |
| Input borders | `rounded-lg`, border color from semantic tokens | Soft but visible boundaries |
| Focus state | Purple-tinted ring (2px offset) | WCAG-required visible focus |
| Error state | Red border + error message below field | Inline validation feedback |
| Required fields | Visual indicator (asterisk or label) | User knows what's mandatory |

**Design intent**: Forms should feel *simple and unintimidating*. Labels above inputs (not inside) ensure clarity even after the user types. Generous sizing reduces errors. Error messages appear inline near the relevant field.

---

## 9. Navigation

### Desktop
- **Top bar** with: Logo | Services (flyout) | About (flyout) | Tools (flyout) | Resources (flyout) | Shop (link) | [Book Now CTA]
- **Flyout panels**: Full-width dropdown panels below the nav item. Service flyout shows grouped links (Boarding group, Wellness group, Relocation group). Other flyouts show simple link lists.
- **Behavior**: Hover to open, keyboard accessible, click-to-navigate links within.

### Mobile
- **Hamburger menu**: Opens a full-height drawer from the right with accordion groups matching desktop flyout structure.
- **Fixed bottom nav**: 4 items — Services | Tools | Shop | Book — always visible at bottom of viewport.
- **Two navigation systems** coexist: drawer for full site navigation, bottom nav for quick access to primary actions.

**Design intent**: Desktop flyouts allow *progressive disclosure* — users see options without navigating away. Mobile's dual system (drawer + bottom nav) addresses the fact that mobile users need both full navigation access and quick action shortcuts.

---

## 10. Footer

### Layout Structure

```
┌─────────────────────────────────────────────┐
│  [Waggies Logo + Tagline]                    │
│  [Instagram] [Facebook] [X] [LinkedIn]       │
│  [TikTok] [YouTube]                          │
├──────────┬──────────┬──────────┬──────────┬────┤
│ Services │ Company  │Resources │ Support  │Legal│
│ ...      │ ...      │ ...      │ ...      │ ... │
├──────────┴──────────┴──────────┴──────────┴────┤
│  [Newsletter: email input + subscribe]         │
├───────────────────────────────────────────────┤
│  © 2025 Waggies. All rights reserved.          │
└───────────────────────────────────────────────┘
```

- **Brand/Follow Us** block is positioned **above** the navigation columns
- **5 navigation columns**: Services, Company, Resources, Support, Legal
- **6 social icons**: Instagram, Facebook, X/Twitter, LinkedIn, TikTok, YouTube
- **Newsletter** email signup with submit button
- **Copyright** bar at the bottom

**Design intent**: The footer is *a secondary navigation system*, not an afterthought. Placing the brand and social links above the nav columns reinforces identity before utility. The 5-column structure mirrors the main navigation hierarchy.

---

## 11. Hero Principles

- **Image-led**: Heroes lead with visual impact, not text walls
- **6 variants** available in the component system (different layout configurations)
- **Editorial split** (preferred for homepage): Asymmetric layout with image on one side, headline + subtitle + CTA on the other. Creates a magazine-quality first impression.
- **Copy**: Single clear value proposition, not a list of features. One CTA.
- **Responsive**: Stack vertically on mobile (image above, text below).

**Design intent**: The hero is the *first impression* and must communicate "premium pet care" in under 3 seconds. The editorial split feels refined. A single CTA prevents decision paralysis.

---

## 12. Imagery

| Rule | Specification |
|------|--------------|
| Temporary stock | Permitted. Use high-quality stock that plausibly represents the content. |
| Empty slots | Never. Every image slot must be populated. |
| Visible labels | No "placeholder," "stock," or "coming soon" overlays on images. |
| Component | Use `WaggiesImage` component (Next.js Image wrapper with brand defaults). |
| Style | Warm, well-lit, natural. Avoid sterile studio shots when possible. |

**Design intent**: Imagery must feel *real and inviting*. Even temporary stock should feel like it belongs. Empty image slots break trust; visible labels look unfinished.

---

## 13. Motion

| Principle | Specification |
|-----------|--------------|
| Library | Framer Motion |
| Intensity | `MOTION_INTENSITY: 2` (restrained — purposeful, not decorative) |
| Entry animations | 0.4–0.6s duration. Fade + slight translate. |
| Stagger | 0.04–0.08s per item in lists/grids. |
| Continuous/looping | **Never.** No infinite animations. |
| Hover | Subtle elevation or color shift, not bouncing or pulsing. |
| Reduced motion | `prefers-reduced-motion` media query disables or minimizes all animations. |

**Design intent**: Motion serves *clarity*, not entertainment. Entry animations guide the eye. Stagger creates rhythm. The absence of looping animations respects the user's attention and reduces distraction. `prefers-reduced-motion` is non-negotiable for accessibility.

---

## 14. Responsive

| Aspect | Specification |
|--------|--------------|
| Approach | Mobile-first — base styles for mobile, progressive enhancement for larger viewports |
| Breakpoints | `sm`: 640px, `md`: 768px, `lg`: 1024px, `xl`: 1280px, `2xl`: 1536px |
| Fluid typography | `clamp()` for display and h2 — scales smoothly without breakpoint jumps |
| Chatbot height | `dvh` (dynamic viewport height) — handles mobile browser chrome correctly |
| Navigation | Desktop: flyout panels. Mobile: hamburger drawer + fixed bottom nav. |
| Layout | Single column mobile → multi-column tablet/desktop |
| Images | Responsive via Next.js Image with `sizes` attribute |
| Testing | Must render correctly from 320px to 1536px+. Responsive is **release-blocking**. |

**Design intent**: Mobile-first ensures the smallest screens get the most attention. `clamp()` eliminates jarring type size jumps between breakpoints. `dvh` on the chatbot prevents the panel from being cut off by mobile browser UI. Responsive bugs block release.

---

## 15. Icon Strategy

| Aspect | Specification |
|--------|--------------|
| Primary library | `@phosphor-icons/react` v2.1.10 |
| Style | One family, unified look — Phosphor's duotone or regular weight |
| Usage | Navigation items, service cards, feature lists, tool icons, social links, UI controls |
| Lucide | Discouraged. Do not introduce new Lucide icons. |
| Material Symbols | Legacy only — existing uses may remain but do not add new ones. |
| Custom SVG | No hand-drawn or custom SVG icons. Stick to Phosphor for consistency. |

**Design intent**: A single icon family ensures **visual consistency** across the entire product. Mixing icon libraries (Phosphor + Lucide + Material + custom SVG) creates visual noise. Phosphor's design language is clean, modern, and sufficiently expressive for all Waggies use cases.

---

## Summary of Design Principles

1. **Warm premium, not corporate cold** — purple, sand, cream palette
2. **Editorial hierarchy** — serif headings, sans body, clear type scale
3. **Generous whitespace** — signals confidence and premium positioning
4. **Pill-shaped everything** — buttons, badges feel approachable
5. **Elevation = interaction** — shadow changes on hover, not color changes
6. **Restrained motion** — purposeful entry, no loops, reduced-motion respected
7. **One icon family** — Phosphor only, no mixing
8. **Mobile-first, release-blocking responsive** — every viewport must work
9. **Accessibility non-negotiable** — WCAG 2.2 AA, 44px touch targets, visible focus rings
10. **No dark mode** — light mode only, designed for warmth not versatility