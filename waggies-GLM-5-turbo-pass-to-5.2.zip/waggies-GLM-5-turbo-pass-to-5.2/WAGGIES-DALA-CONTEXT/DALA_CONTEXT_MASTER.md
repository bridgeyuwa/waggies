# Waggies — Master Context for Dala/Gebeya

> Concise, high-signal product context for building the Waggies application.
> This synthesises all authoritative documents. ~6,000 words.

---

## 1. Product Identity

**Waggies** is a premium, full-service pet care business in **Abuja, Nigeria**. It provides boarding (dogs, cats, exotic pets), grooming, on-site veterinary care, positive-reinforcement dog training, and pet relocation services (international import/export and local transport). Waggies also offers 11 free pet care tools, an online shop, a gallery, and educational content (blog, guides, knowledge base, FAQ).

**Brand character**: Warm, trustworthy, Nigerian, premium but approachable. Light mode only. Brand colours: purple (#6B2C91), warm cream (#E8D5B5), off-white surface (#FDFBF7).

**Target users**: Pet owners in Abuja and Nigeria; expats relocating internationally with pets; prospective pet owners researching breeds, costs, and preparation.

---

## 2. Business Facts

| Field | Value |
|-------|-------|
| Name | Waggies |
| Address | Life Camp, Efab City Estate, 65 1st Ave, Abuja 900108, FCT, Nigeria |
| Phone | 0908 081 1902 / +234 908 081 1902 |
| WhatsApp | 2349080811902 (`https://wa.me/2349080811902`) |
| Email | hello@waggies.ng |
| Hours | Mon–Fri 9:00 AM – 5:00 PM, Sat–Sun 10:00 AM – 2:00 PM |
| Locale | en_NG |

Source of truth: `src/lib/business-info.ts`.

---

## 3. Information Architecture

### Primary Navigation (desktop)

1. **Services** (flyout: Boarding, Wellness, Relocation)
2. **About** (flyout: About Us, Testimonials, Gallery, Careers, Partnerships)
3. **Tools** (flyout: all 11 tools)
4. **Resources** (flyout: FAQ, Blog, Guides, Knowledge Base)
5. **Shop** (plain link)
6. **Book Now** (CTA button)

Mobile: hamburger drawer with accordion groups + fixed bottom nav (Services, Tools, Shop, Book).

### Services Hierarchy

```
Services
├── Boarding
│   ├── Boarding (hub)
│   ├── Dog Boarding
│   ├── Cat Boarding
│   └── Exotic Pet Boarding
├── Wellness (label only — no page)
│   ├── Grooming
│   ├── Veterinary Care
│   └── Training
└── Relocation
    ├── Relocation (hub)
    ├── Pet Import
    ├── Pet Export
    ├── Local Transport  ← canonical: /relocation/transport
    └── Doc Checklist     ← canonical: /relocation/checklist (hybrid)
```

**Critical IA rules:**
- Wellness is a grouping label only; there is no `/services/wellness` page.
- Local Transport is under Relocation, not Services. Canonical: `/relocation/transport`.
- `/services/transport` must 301 redirect to `/relocation/transport`.
- Relocation Checklist is hybrid: discoverable from both Relocation and Tools. One canonical implementation.
- My Pets is removed from the product. Route may exist but must NOT be in navigation, sitemap, or robots.

---

## 4. Routes

### Services
`/services` (hub) → `/services/boarding` → `/services/boarding/dogs`, `/cats`, `/exotic`
`/services/grooming`, `/services/vet-care`, `/services/training`, `/services/pricing`

### Relocation
`/relocation` (hub) → `/relocation/import`, `/relocation/export`, `/relocation/transport`, `/relocation/checklist`

**Redirect:** `/services/transport` → 301 → `/relocation/transport`

### About
`/about` → `/about/testimonials`, `/about/gallery`, `/about/careers`, `/about/partnerships`

### Tools (11)
`/tools` (hub) → `/tools/symptom-checker`, `/tools/pet-age-calculator`, `/tools/vaccination-schedule`, `/tools/cost-calculator`, `/tools/medication-dosage-guide`, `/tools/nutrition-calculator`, `/tools/emergency-guide`, `/tools/new-pet-checklist`, `/tools/parasite-schedule`, `/tools/behavior-tips`, `/tools/breed-finder`

### Resources
`/blog`, `/blog/[slug]`, `/guides`, `/guides/[slug]`, `/knowledge-base`, `/knowledge-base/[slug]`, `/faq`

### Shop
`/shop`, `/shop/[id]`

### Other
`/contact`, `/loyalty`, `/privacy-policy`, `/terms-of-service`, `/cookies-policy`

### Excluded
`/my-pets` — exists but NOT in nav, NOT in sitemap, robots disallow.

---

## 5. Feature Inventory (Summary)

| Feature | Route | Backend | State |
|---------|-------|---------|-------|
| Homepage | `/` | Static data | Complete |
| Services hub + 5 service pages | `/services/*` | Static data | Complete |
| Boarding + 3 subtypes | `/services/boarding/*` | Static data | Complete |
| Relocation + 3 services + checklist | `/relocation/*` | Static data | Complete |
| Pricing | `/services/pricing` | Static data | Complete |
| 11 Tools | `/tools/*` | Static/local | Complete |
| Contact (map, form→WhatsApp) | `/contact` | Form→WhatsApp | Complete |
| Booking Request | Multiple pages | WhatsApp only | Request-only |
| WhatsApp Request Composer | Multiple pages | WhatsApp only | Required |
| Shop + Cart + Recently Viewed | `/shop/*` | localStorage | Complete |
| Gallery (lightbox, 23 images) | `/about/gallery` | Static data | Complete |
| Blog/Guides/KB | `/blog/*`, `/guides/*`, `/kb/*` | Static data | Complete |
| FAQ (searchable) | `/faq` | Static data | Complete |
| Search (command palette) | Global | Static index | Complete |
| Chatbot (prototype) | Floating FAB | None (keyword) | Prototype |
| Loyalty | `/loyalty` | Static page | Page only |
| Newsletter | Footer | None | Form only |
| Testimonials | `/about/testimonials` + inline | Static data | Complete |

---

## 6. Design System

### Colours (OKLCH)
- **Brand primary**: `oklch(0.332 0.155 305)` = #6B2C91 (purple)
- **Brand primary light**: `oklch(0.489 0.145 305)` = #9D5CC0
- **Brand primary dark**: `oklch(0.196 0.108 310)` = #3E1A57
- **Brand secondary**: `oklch(0.849 0.037 80)` = #E8D5B5 (cream)
- **Surface**: `oklch(0.985 0.005 90)` = #FDFBF7
- **Surface purple**: `oklch(0.955 0.018 305)` = #F5F0FA
- **Success**: `oklch(0.52 0.17 145)`, **Error**: `oklch(0.55 0.22 25)`, **Warning**: `oklch(0.68 0.16 75)`
- **WhatsApp**: `oklch(0.72 0.18 145)`

Semantic tokens map to brand tokens. Text body at 0.7 opacity, muted at 0.5 opacity (minimum /60 for contrast).

### Typography
- **Body**: DM Sans (400/500/600/700) via `next/font/google`
- **Headings**: Cormorant Garamond (400/600/700, normal/italic) via `next/font/google`
- Display: serif 700, `clamp(2.25rem, 5vw, 3.5rem)`, -0.02em tracking
- H2: serif 700, `clamp(1.75rem, 3.5vw, 2.5rem)`
- Body: sans 400, 1rem, max-w-65ch, line-height 1.7
- Label: sans 600, 0.75rem, uppercase, 0.05em tracking

### Spacing & Layout
- Content: max-w-7xl (80rem)
- Sections: py-20 (5rem)
- Containers: px-4 / md:px-10 / lg:px-12
- Cards: gap-6, rounded-xl/2xl, shadow-sm

### Buttons
- Primary: `bg-primary text-white rounded-full font-bold`
- Secondary: `bg-secondary text-primary-dark rounded-full font-bold`
- Ghost: `border border-primary/25 text-primary-dark rounded-full`
- All: min 44px touch target, `transition-colors`

### Icons
- **Phosphor** (`@phosphor-icons/react`) is the primary and preferred icon family.
- One family unified across the entire application.
- No hand-drawn SVGs. Lucide is discouraged. Material Symbols are legacy.

### Motion
- Framer Motion, restrained (MOTION_INTENSITY: 2)
- No continuous/looping animations. No parallax or scroll-hijack.
- Enter: 0.4–0.6s. Stagger: 0.04–0.08s per item, max 0.4s.
- `prefers-reduced-motion`: CSS media query + `useReducedMotion()` hook.

### Responsive
- Mobile-first. Breakpoints: sm(640), md(768), lg(1024), xl(1280), 2xl(1536).
- Desktop: flyout navigation. Mobile: hamburger drawer + fixed bottom nav.
- Chatbot panel: `dvh` sizing for viewport containment.
- Typography: `clamp()` for fluid sizing.

---

## 7. Imagery Rules

1. **No intended image slot should be empty.** All ~70+ slots have Unsplash stock URLs.
2. **Temporary stock imagery is allowed.** Do not visibly label as stock.
3. **Do not imply** stock photos show actual Waggies staff, facilities, or patients.
4. **Gallery must remain populated** (23 images in 5 groups: Boarding Suites, Grooming Spa, Vet Clinic, Training, Relocation/Transport).
5. **Team portraits**: Temporary stock acceptable. Replace when authentic photos are available.
6. **Hero images**: Image-led, visually distinctive. Taste Skill decides final composition.
7. When authentic photos arrive, replace slot-by-slot per the Golden Asset Inventory.

---

## 8. WhatsApp-First Conversion

### Canonical WhatsApp Number
`2349080811902` → `https://wa.me/2349080811902`

### Service Request Composer
A reusable component that collects:
- Service, service category, pet name, pet type, breed
- Package, options, dates (check-in/check-out/preferred), duration
- Location (pickup, drop-off, route, destination)
- Estimate, pricing mode (FIXED/ESTIMATED/QUOTE_REQUIRED)
- Customer name, phone, email
- Additional message/instructions

### Flow
1. User configures service on page
2. Composer opens with pre-populated context
3. User reviews, edits, adds instructions
4. "Continue to WhatsApp" → message constructed as readable plain text
5. URL-encoded into `wa.me/2349080811902?text=...`
6. WhatsApp opens with pre-filled, user-editable message

### State Machine
Prepared → WhatsApp opened → message sent → request received → booking confirmed (NOT automatic)

### Integration Points
- Contact page form
- Booking modal
- Service page CTAs ("Book a Groom", "Book Appointment", etc.)
- Pricing page "Get Estimate" CTA

---

## 9. Pricing Model

| Mode | Definition | UI Treatment | When to Use |
|------|-----------|-------------|------------|
| **FIXED** | Exact known price | Show price ("₦5,000") | Standard packages with known costs |
| **ESTIMATED** | Price range | Show range ("₦10,000 – ₦25,000") | Variable-factor services |
| **QUOTE_REQUIRED** | No price | Show "Request a Quote" CTA | Complex/custom services |

**Get Estimate flow**: `/services/pricing?service=X` → preselected service → estimator → result → composer → WhatsApp.

**Critical**: Never invent pricing. If Waggies has not provided pricing, use QUOTE_REQUIRED.

---

## 10. Tools (11)

| Tool | Route | Medical? | Disclaimer? |
|------|-------|----------|-------------|
| Symptom Checker | `/tools/symptom-checker` | Yes | Yes |
| Pet Age Calculator | `/tools/pet-age-calculator` | No | No |
| Vaccination Schedule | `/tools/vaccination-schedule` | Yes | Yes |
| Cost Calculator | `/tools/cost-calculator` | No | No |
| Medication Dosage Guide | `/tools/medication-dosage-guide` | Yes | Yes |
| Nutrition Calculator | `/tools/nutrition-calculator` | No | No |
| Emergency & Poison Guide | `/tools/emergency-guide` | Yes | Yes |
| New Pet Checklist | `/tools/new-pet-checklist` | No | No |
| Parasite Schedule | `/tools/parasite-schedule` | Yes-adjacent | Yes |
| Behavior Tips | `/tools/behavior-tips` | No | No |
| Breed Finder | `/tools/breed-finder` | No | No |

**Medical safety rules**: Do NOT fabricate veterinary doses, protocols, credentials, medical claims, or regulatory requirements. Medical tools must include a `MedicalDisclaimer` component stating the tool is not a substitute for professional veterinary advice.

---

## 11. Chatbot

**Current**: Deterministic keyword-matching prototype embedded in the floating actions component. No LLM. No conversation persistence. Capabilities: greetings, service info, hours, location, WhatsApp redirect. Provider-agnostic.

**Future direction** (NOT implemented): User → Intent/Safety Router → Waggies RAG → Optional LLM → Safety/Factuality Validation → Response. Medical questions escalate immediately to phone/WhatsApp.

---

## 12. Team

### Verified (authoritative)
1. **Dr. Nguhemen Doose Yuwa** (DVM) — Head Veterinarian and Director
2. **Aifuwa Bob Osaze** — Director
3. **Oghomwen Oyuki Obaseki** — Secretary

### Placeholders
4. Chukwuma Eze — Veterinary Support
5. Amina Bello — Lead Groomer
6. Dayo Adekunle — Boarding Manager
7. Kemi Ogunleye — Pet Trainer
8. Suleiman Ahmadu — Relocation & Transport Coordinator

Team is NOT artificially limited. Do NOT invent credentials. Verified credentials only. Temporary portraits acceptable.

---

## 13. Accessibility (WCAG 2.2 AA — Mandatory, Release-Blocking)

- Keyboard: all interactive elements reachable via Tab, flyout Arrow/Escape navigation, dialog focus traps
- Focus: `:focus-visible` with 2px solid primary, 2px offset. Skip link component.
- Touch targets: minimum 44×44px on all interactive elements
- Contrast: 4.5:1 for body text. Muted text minimum /60 opacity.
- Reduced motion: CSS `@media (prefers-reduced-motion: reduce)` + Framer Motion `useReducedMotion()`
- 200% reflow: no horizontal scrolling at 200% zoom
- Semantic HTML: `<main>`, `<header>`, `<nav>`, `<section>`, `<article>`, `<footer>`. Proper heading hierarchy.
- Forms: labels above inputs, error messages associated with fields, required indicators
- ARIA: roles on tabs, accordions, modals, dialogs. `aria-live` for status messages.

---

## 14. Responsive (Release-Blocking)

Required viewport checkpoints: 320, 360, 375, 390, 414, 430, 768, 820, 1024, 1280, 1440, 1920, 2560.

Also: portrait/landscape, touch, keyboard, virtual keyboard, mobile browser UI, safe areas.

No horizontal overflow, clipping, overlap, or unusable controls at any width.

---

## 15. SEO

- Sitemap: dynamic, ~35+ public routes, excludes `/my-pets`
- Robots: allow `/`, disallow `/my-pets`
- Canonical URLs from `NEXT_PUBLIC_SITE_URL` (must be set for production)
- Title template: `%s - Waggies`
- Breadcrumbs: JSON-LD on all inner pages
- Open Graph: type, locale (en_NG), url, siteName set. og:image not yet configured.
- Local Transport: `/relocation/transport` canonical, `/services/transport` 301 redirect

---

## 16. Future Backend

**Database schema may be prepared, but production backend is deferred.**

The frontend must work WITHOUT a production backend:
- Cart → localStorage (Zustand persist)
- Tools → local state
- Booking → request/WhatsApp
- Chatbot → local/deterministic

Future entities: users, pets, bookings, products, orders, cart, loyalty, testimonials, newsletter, contact requests, content, medical tool content, chatbot conversations, staff, services, pricing tiers, appointments.

---

## 17. Footer

Structure (top to bottom):
1. **Brand / Follow Us** block (logo, tagline, 5 social icons) — positioned ABOVE the nav columns
2. Navigation columns: **Services**, **Company**, **Resources**, **Support**, **Legal** (separate groups)
3. Copyright: "© 2026 Waggies Pet Services. All rights reserved."

---

## 18. Contact

Contact is the **canonical location/contact hub**. Includes:
- Google Maps embed (full map)
- Contact form (routes to WhatsApp with structured context)
- Full business hours (7-day table)
- Phone, email, WhatsApp links
- Directions CTA

---

## 19. Tech Stack

- Next.js 16.1.1, React 19, TypeScript 5
- Tailwind CSS 4, shadcn/ui (New York style)
- Prisma + SQLite (schema preparation only)
- Zustand (cart, pet stores)
- Framer Motion (restrained)
- `@phosphor-icons/react` v2.1.10
- `bun` package manager
