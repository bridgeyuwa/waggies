# 02 — Dala Feature Catalog: Waggies

> **Audience**: Application-building agent. Complete feature inventory with implementation context.
> **Note**: "My Pets" is excluded from this catalog. It exists in the codebase but is not in navigation, sitemap, or robots.

---

## Format

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |

---

## Homepage

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Hero Section | Communicate value proposition and primary CTA | `/` | View, click CTA | Asymmetric split hero with image, headline, subtitle, Book Now CTA | Single editorial split hero implemented | Static content; could personalise by referrer in future | WaggiesImage component, CTA routing to booking | Must be visually compelling; image-led |
| Service Cards | Quick access to all 5 service categories | `/` | Click to navigate | 3–5 cards with icon, title, brief description | Grid of service cards linking to service hubs | Backend could personalise card order | Service data from `/data/services.ts` | Accurate service count (5 categories) |
| Trust Features | Build credibility (certifications, standards, experience) | `/` | View | Horizontal band with icons and short text | Trust indicators displayed | May pull from CMS in future | Business data | No fabricated claims |
| Testimonials | Social proof from real customers | `/` | Read, click to full testimonials page | Carousel or card row with quotes and names | Testimonial cards from data file | Could integrate reviews platform | Testimonial data | Must use real testimonials or clearly marked placeholders |

---

## Services

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Services Hub | Overview of all service categories | `/services` | Browse, click category | Grid of service category cards with icons and descriptions | Service cards grid with standards band and FAQ | Static | Service data, FAQ data | Must show all 5 categories |
| Boarding Hub | Boarding overview with links to subtypes | `/services/boarding` | Read, navigate to subtype | Hub page with boarding philosophy, safety, links to dog/cat/exotic | Implemented with hub content and subtype links | May add real-time availability | Service data | Three subtype links required |
| Dog Boarding | Canine boarding service details | `/services/boarding/dogs` | Read, click Book Now | Service page with features, benefits, CTA | Implemented as service page | Static | Booking modal | Service-specific content |
| Cat Boarding | Feline boarding service details | `/services/boarding/cats` | Read, click Book Now | Service page with features, benefits, CTA | Implemented as service page | Static | Booking modal | Separate from dog boarding |
| Exotic Pet Boarding | Exotic animal boarding details | `/services/boarding/exotic` | Read, click Book Now | Service page with features, benefits, CTA | Implemented as service page | Static | Booking modal | Species-specific content |
| Grooming | Grooming service details | `/services/grooming` | Read, click Book Now | Service page with grooming features, pricing tier, CTA | Implemented | Static | Booking modal | May show FIXED or ESTIMATED pricing |
| Veterinary Care | Vet service details | `/services/vet-care` | Read, click Book Now | Service page with care offerings, consultation info, CTA | Implemented | Static | Booking modal | QUOTE_REQUIRED likely for many services |
| Training | Dog training service details | `/services/training` | Read, click Book Now | Service page with training types, class info, CTA | Implemented | Static | Booking modal | Package-based pricing possible |
| Pricing Page | Display all service pricing tiers | `/services/pricing` | Compare pricing | Table/grid with service tiers and FIXED/ESTIMATED/QUOTE_REQUIRED labels | Implemented with tier display | Could pull from backend pricing engine | All service data | NEVER invent pricing. Use FIXED, ESTIMATED, or QUOTE_REQUIRED labels. |

---

## Relocation

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Relocation Hub | Overview of relocation services | `/relocation` | Browse, click sub-service | Cards for Import, Export, Transport, Checklist | Implemented with overview content and service cards | Static | Relocation data | Four sub-service cards |
| Pet Import | Import service details | `/relocation/import` | Read, click Book Now | Service page with import process, documentation, CTA | Implemented | Static | Booking modal, WhatsApp | Complex process; needs clear steps |
| Pet Export | Export service details | `/relocation/export` | Read, click Book Now | Service page with export process, documentation, CTA | Implemented | Static | Booking modal, WhatsApp | Airline compliance info important |
| Local Transport | In-Nigeria pet transport | `/relocation/transport` | Read, click Book Now | Service page with transport options, CTA | Implemented. **Canonical URL.** | Static | Booking modal | `/services/transport` 301-redirects here |
| Relocation Checklist | Interactive document checklist | `/relocation/checklist` | Check off documents, read guidance | Checklist UI with sections, checkboxes, guidance text | Implemented as hybrid tool | Could save progress to backend | Relocation data | Discoverable from both Relocation and Tools sections. One canonical implementation. |

---

## Booking & WhatsApp

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Booking Request Modal | Collect service request details | Multiple pages (service pages, homepage) | Fill form, submit | Modal/drawer with service selection, pet info, dates, notes | Opens on "Book Now" click, form fields present | Will integrate with backend booking system | WhatsApp URL construction | REQUEST ONLY. Not auto-confirmed. |
| WhatsApp Request Composer | Build structured WhatsApp message | Booking modal (on submit) | Review, edit, send | Opens wa.me link with prepopulated message | Constructs URL-encoded message, opens WhatsApp | Could use WhatsApp Business API in future | Phone: 2349080811902 | Message must be user-editable in WhatsApp. Fallback if WhatsApp unavailable. |

---

## Tools (11)

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Tools Hub | Browse all 11 tools | `/tools` | Click tool card | Grid of tool cards with icon, title, description | Implemented with all 11 tools | May categorise/filter in future | All tool data | All 11 tools must be listed |
| Symptom Checker | Help users assess pet symptoms | `/tools/symptom-checker` | Select symptoms, get assessment | Multi-step form → results with recommendation | Implemented (deterministic) | Could integrate LLM for richer assessment | Symptom data | MEDICAL TOOL — disclaimer required |
| Pet Age Calculator | Convert pet age to human equivalent | `/tools/pet-age-calculator` | Enter pet age, species, breed | Input fields → calculated result display | Implemented | Static calculation, no backend needed | Species/breed data | Non-medical |
| Vaccination Schedule | Show vaccination timelines | `/tools/vaccination-schedule` | Select species, age | Timeline/schedule display | Implemented | Could personalise with pet profile | Vaccination data | MEDICAL TOOL — disclaimer required |
| Cost Calculator | Estimate service costs | `/tools/cost-calculator` | Select services, parameters | Input form → estimated cost range | Implemented | Could pull live pricing | Service/pricing data | Non-medical. May show ESTIMATED pricing. |
| Medication Dosage Guide | Provide dosage guidance | `/tools/medication-dosage-guide` | Select pet weight, medication | Guided form → dosage information | Implemented | Should NEVER replace vet consultation | Medication data | MEDICAL TOOL — disclaimer required. NOT a prescription tool. |
| Nutrition Calculator | Calculate pet nutritional needs | `/tools/nutrition-calculator` | Enter pet details | Form → nutritional recommendations | Implemented | Static calculation | Species/breed/weight data | Non-medical |
| Emergency Guide | Provide emergency response guidance | `/tools/emergency-guide` | Browse emergency scenarios | Categorized emergency cards with step-by-step actions | Implemented | Could add location-aware vet finder | Emergency data | MEDICAL TOOL — disclaimer required |
| New Pet Checklist | Guide new pet owners | `/tools/new-pet-checklist` | Check off preparation items | Interactive checklist with categories | Implemented | Could save progress | Checklist data | Non-medical |
| Parasite Schedule | Show parasite prevention timelines | `/tools/parasite-schedule` | Select species, region | Schedule display with prevention products | Implemented | Could integrate with shop products | Parasite/prevention data | MEDICAL TOOL — disclaimer required |
| Behavior Tips | Address common pet behavior issues | `/tools/behavior-tips` | Select behavior issue | Categorized tips with actionable advice | Implemented | Could integrate with training booking | Behavior data | Non-medical |
| Breed Finder | Help users find suitable breeds | `/tools/breed-finder` | Answer preference questions | Quiz-style → breed recommendations | Implemented | Could use ML matching | Breed database | Non-medical |

---

## About & Company

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| About Page | Tell Waggies' story and mission | `/about` | Read, navigate to sub-pages | Story section, team section with cards, mosaic/grid layout | Implemented with story and team | CMS could manage content | Team data, business story | Team section includes verified + placeholder members |
| Team Section | Display team members | `/about` (section) | View profiles | Card grid with photo, name, role, credentials | 3 verified + 5 placeholder cards | Will add real bios as team grows | Team data (`/data/team.ts`) | NOT limited to 7. Verified credentials only for verified members. |
| Gallery | Showcase facility and pets | `/about/gallery` | Browse, filter, view in lightbox | 5 groups of images, lightbox with prev/next navigation | Implemented with 23 images in 5 groups | Could integrate with cloud storage | Image data | Must remain populated. Temporary stock OK. No visible labels. |
| Testimonials | Customer reviews and stories | `/about/testimonials` | Read reviews | Carousel or card layout with quotes, names, ratings | Implemented | Could integrate reviews platform | Testimonial data | Real testimonials or clearly marked placeholders |
| Careers | List open positions | `/about/careers` | Browse roles, apply | Job listing cards with title, description, apply CTA | Implemented | Could integrate ATS | Job data | Only show genuinely open roles or mark as coming soon |
| Partnerships | Partnership information | `/about/partnerships` | Read, inquire | Partnership types, benefits, CTA to contact | Implemented | Static | Contact/WhatsApp | Business partnership info |

---

## Resources & Content

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| FAQ | Answer common questions | `/faq` | Search, expand/collapse answers | Searchable accordion with categorized questions | Implemented with search | Could integrate with AI answers | FAQ data | Searchable, keyboard accessible |
| Blog Listing | Browse blog articles | `/blog` | Browse, click article | Card grid with featured image, title, excerpt, date | Implemented | CMS in future | Blog data | 
| Blog Article | Read individual blog post | `/blog/[slug]` | Read, share, navigate related | Full article with hero image, body, related posts, share links | Implemented from markdown/data | CMS with rich editing | Slug-specific data | 
| Guides Listing | Browse care guides | `/guides` | Browse, click guide | Card grid with category filters | Implemented | CMS in future | Guide data | 
| Guide Detail | Read individual guide | `/guides/[slug]` | Read, follow steps | Structured guide with steps, tips, related content | Implemented | CMS in future | Slug-specific data | 
| Knowledge Base Listing | Browse KB articles | `/knowledge-base` | Browse, search, click | Categorized article list with search | Implemented | Could integrate with chatbot RAG | KB data | 
| Knowledge Base Article | Read KB article | `/knowledge-base/[slug]` | Read, navigate | Structured article with table of contents, related articles | Implemented | RAG source for future chatbot | Slug-specific data | 

---

## Search

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Global Search (Cmd+K) | Find any page, tool, or content | Overlay (no route) | Open palette, type query, select result | Command palette with search input, filtered results list, keyboard navigation | Implemented as Cmd+K overlay | Could use Algolia/Meilisearch | Page/tool/content data | Must work across pages, tools, and content |

---

## Shop

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Shop Listing | Browse products | `/shop` | Filter, sort, click product | Product grid with category filters, search, sort | Implemented | E-commerce backend in future | Product data | 
| Product Detail | View product information | `/shop/[id]` | Read details, add to cart | Product images, description, price, add-to-cart, related products | Implemented | Inventory management in future | Product data, cart store | 
| Cart Drawer | Manage selected products | Overlay (no route) | Add/remove items, update quantity | Slide-in drawer from right, item list, subtotal, CTA | Implemented with Zustand + localStorage | Checkout in future | Zustand cart store | No online checkout. Contact for purchase. |
| Recently Viewed | Show products user has viewed | `/shop` (section) | Click to revisit | Horizontal scroll of product thumbnails | Tracked in localStorage | Persistent tracking in future | localStorage | Display on shop pages |

---

## Loyalty

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Loyalty Programme | Reward repeat customers | `/loyalty` | View tiers, learn about programme | Tier cards (Bronze/Silver/Gold), points explanation, benefits | Implemented as informational page | Backend points tracking in future | Loyalty data | Informational only in current build |

---

## Chatbot

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| AI Chatbot | Assist users with questions and navigation | Floating button (all pages) | Click to open, type message, read response | Floating button bottom-right, chat panel with message bubbles, input field | Deterministic keyword-matching prototype, production UI | Intent router → RAG → LLM pipeline planned | Chat data, tool routing | Provider-agnostic. dvh for height. Must work without AI backend. |

---

## Newsletter & Footer

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Newsletter Signup | Collect email for marketing | Footer (all pages) | Enter email, submit | Email input with submit button in footer | Implemented | Email service integration in future | Footer component | 
| Footer Navigation | Site-wide navigation and information | Footer (all pages) | Click links | Brand block + Follow Us, then 5 nav columns (Services, Company, Resources, Support, Legal) | Implemented with 5-column layout | Static | Link data | Brand/Follow Us ABOVE nav columns. 5 social icons. |

---

## Contact

| Feature | Purpose | Primary Route | User Action | Expected UI | Current Frontend Behavior | Future/Backend Status | Important Dependencies | Important Constraints |
|---------|---------|---------------|-------------|-------------|--------------------------|-----------------------|---------------------|-------------------|
| Contact Page | Canonical location and contact hub | `/contact` | View map, fill form, get directions | Google Maps embed, address, phone, email, hours, contact form, directions | Implemented with map and form→WhatsApp | Form backend in future | Google Maps API, WhatsApp | Contact form routes to WhatsApp. Full operating hours. |

---

## Excluded

| Feature | Status | Reason |
|---------|--------|--------|
| My Pets (`/my-pets`) | EXISTS but EXCLUDED from product | Not in navigation, not in sitemap, robots disallow. Route exists in codebase but is not part of the public product. |
