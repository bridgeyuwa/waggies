# Dala Context 09 — Chatbot Architecture

> **Status**: Authoritative context document for Waggies chatbot.
> **Last updated**: Batch 3 creation.

---

## 1. Current Implementation

### Architecture Type
- **Pattern**: Deterministic / pattern-based keyword matching.
- **No LLM dependency**: Provider-agnostic, no vendor lock-in.
- **No server**: All logic runs client-side in the browser.

### Code Location
- Embedded directly in the floating-actions component (`floating-actions.tsx`).
- Keyword-response pairs are hardcoded within the component file.
- No external data fetching, no API calls, no WebSocket.

### Trigger & Panel
- **Trigger**: Floating action button (FAB), persistent across all pages.
- **Panel**: Opens as a side or bottom panel.
- **Sizing**: Uses `dvh` (dynamic viewport height) to stay within viewport bounds.
- **Icons**: Phosphor icon set (consistent with rest of UI).
- **UI quality**: Production-grade at the visual/interaction level.

### Current Capabilities
| Capability | Details |
|---|---|
| Greetings | Responds to hello, hi, hey, good morning/afternoon/evening |
| Service info | Keyword matches for boarding, grooming, vet, training, relocation |
| Business hours | Returns operating hours when asked |
| Location & phone | Returns Abuja address and phone number |
| WhatsApp redirect | Detects complex/booking intent → suggests WhatsApp |

### Current Limitations
| Limitation | Impact |
|---|---|
| No NLU | Cannot understand paraphrased or ambiguous queries |
| No context memory | Each message is treated independently; no multi-turn conversation |
| Limited coverage | Only responds to pre-programmed keyword patterns |
| No personalization | Cannot reference user's pets, past bookings, or preferences |
| No multi-turn | Cannot follow up on previous messages in the session |
| No persistence | Conversation resets on every page reload |
| Single-component | All chatbot logic coupled into floating-actions.tsx |

### Current State
```
User message
    ↓
Keyword pattern matching (if/else or regex)
    ↓
Hardcoded response OR "Let me connect you to WhatsApp"
    ↓
Display response in panel
```

---

## 2. Future Direction (NOT Implemented)

### Target Architecture

```
User message
    ↓
┌─────────────────────────┐
│  Intent / Safety Router   │  ← Classify intent + detect medical/emergency
└───────────┬─────────────┘
            ↓
    ┌───────┴───────┐
    │ Medical?      │──YES──→ Immediate escalation (phone + WhatsApp)
    │ Emergency?    │──YES──→ Immediate escalation (phone + WhatsApp)
    └───────┬───────┘
            │ NO
            ↓
┌─────────────────────────┐
│  Waggies RAG             │  ← Retrieve from approved knowledge sources
└───────────┬─────────────┘
            ↓
┌─────────────────────────┐
│  Optional LLM            │  ← Natural language understanding & generation
│  (Provider-agnostic)     │     Any LLM API — no vendor lock-in
└───────────┬─────────────┘
            ↓
┌─────────────────────────┐
│  Safety / Factuality     │  ← Validate response against approved knowledge
│  Validation              │     Flag uncertain answers, never fabricate
└───────────┬─────────────┘
            ↓
       Response to user
```

### Pipeline Components

#### 2.1 Intent / Safety Router
- **Purpose**: Classify the user's message into an intent category before any response generation.
- **Intent categories**:
  - `booking` — wants to schedule or start a booking
  - `service_info` — asking about a specific service
  - `emergency` — indicates an urgent/medical emergency
  - `medical` — asking health-related questions about a pet
  - `general` — general inquiry about Waggies
  - `pricing` — asking about costs
  - `location` — asking about address/directions
  - `hours` — asking about operating times
- **Safety rule**: `emergency` and `medical` intents are routed to escalation IMMEDIATELY — no RAG, no LLM.

#### 2.2 Waggies RAG (Retrieval-Augmented Generation)
- **Purpose**: Retrieve relevant factual content from approved, curated knowledge sources.
- **Knowledge sources** (all currently exist as static data files):
  - Service page content — `src/data/services.ts`, `src/data/relocation.ts`
  - FAQ data — `src/data/faqs.ts`
  - Business info — `src/lib/business-info.ts`
  - Tools data — `src/data/tools-data.ts` (and related tool files)
  - Pricing data — `src/data/pricing.ts`
- **Constraint**: Only retrieve from these approved sources. Never hallucinate or use external knowledge.

#### 2.3 Optional LLM
- **Purpose**: Natural language understanding and fluent response generation.
- **Provider-agnostic**: Any LLM API (OpenAI, Anthropic, local model, etc.).
- **Not required**: RAG alone could power simple responses without an LLM.
- **Constraint**: LLM must be guided by RAG context, not free-form generation.

#### 2.4 Safety / Factuality Validation
- **Purpose**: Verify the generated response against approved knowledge before showing to user.
- **Rules**:
  - Never fabricate information not in the knowledge sources.
  - Flag responses with low confidence — offer WhatsApp escalation instead.
  - Never provide specific medical diagnoses.
  - Never provide specific medication dosages.

---

## 3. Medical Safety Boundaries

This is the highest-priority constraint for any future chatbot evolution.

### Immediate Escalation
- Detect medical urgency keywords (e.g., "bleeding", "not breathing", "poison", "seizure", "can't walk", "collapsed").
- Route to phone call: **+234 908 081 1902**.
- Route to WhatsApp as fallback.

### Never Do
| Prohibited Action | Reason |
|---|---|
| Provide specific diagnoses | Veterinary medical advice requires examination |
| Provide medication dosages | Dosages depend on weight, species, condition, history |
| Recommend specific treatments | Must come from Dr. Yuwa or on-site veterinarian |
| Downplay symptoms | Could delay necessary care |

### Always Do
- Recommend consulting **Dr. Yuwa** or the **on-site veterinarian**.
- Include a clear disclaimer in every medical-adjacent response.
- Escalate to phone/WhatsApp when in doubt.

### Disclaimer Template
> "This information is for general guidance only and does not replace professional veterinary advice. Please consult Dr. Yuwa or our veterinary team at +234 908 081 1902 for medical concerns about your pet."

---

## 4. Design Principles

| Principle | Detail |
|---|---|
| Provider-agnostic | No lock-in to any LLM vendor |
| Knowledge-bounded | Only answer from approved Waggies data |
| Safety-first | Medical/emergency always escalates |
| Graceful degradation | Works without LLM (current keyword matching is the floor) |
| Progressive enhancement | Future RAG/LLM adds capability without breaking current behavior |
| No persistence required | Conversation can remain stateless |
|

---

## 5. Integration Notes

- Chatbot is part of the floating-actions component — if extracted, maintain the FAB trigger pattern.
- Panel uses `dvh` sizing — must remain viewport-contained.
- Phosphor icons — maintain icon consistency.
- WhatsApp redirect uses the phone number from `business-info.ts`.
- Chatbot does NOT require any backend to function (current or future).
- Future RAG can use the same static data files that power the website content.
