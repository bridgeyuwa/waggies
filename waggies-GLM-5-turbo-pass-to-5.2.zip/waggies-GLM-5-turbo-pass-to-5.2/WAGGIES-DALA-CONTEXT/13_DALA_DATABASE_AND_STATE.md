# Dala Context 13 — Database and State Management

> **Status**: Authoritative context document for Waggies data architecture.
> **Last updated**: Batch 3 creation.
> **Critical rule**: The frontend MUST work WITHOUT a production backend. All features are functional with local state and static data.

---

## 1. Core Principle

**The Waggies website is a fully functional frontend application that does not require a production backend.**

All current features work with:
- Local browser state (React state, zustand stores)
- localStorage persistence (cart, pet profiles)
- Static TypeScript data files (services, pricing, FAQ, tools)
- WhatsApp as the conversion channel (no server-side form submission)

This is not a limitation — it is the current architecture. Do not convert any of these into backend requirements.

---

## 2. Current State Management

### 2.1 Cart

| Aspect | Detail |
|---|---|
| **Store** | `cart-store.ts` (zustand) |
| **Persistence** | localStorage via zustand `persist` middleware |
| **Sync** | Client-side only, no server sync |
| **Operations** | Add item, remove item, update quantity, clear cart |

### 2.2 Tools

| Aspect | Detail |
|---|---|
| **State** | React local state (`useState`) |
| **Data source** | Static TypeScript files (`tools-data.ts`, etc.) |
| **Server interaction** | None |
| **Persistence** | None (calculations are stateless) |

### 2.3 Booking

| Aspect | Detail |
|---|---|
| **Flow** | Request-only (no server submission) |
| **Process** | Form data → ServiceRequestComposer → WhatsApp message |
| **Output** | Pre-filled WhatsApp message opened in user's WhatsApp app |
| **Server interaction** | None |

### 2.4 Chatbot

| Aspect | Detail |
|---|---|
| **Logic** | Deterministic keyword matching |
| **Persistence** | None (resets on page reload) |
| **Server interaction** | None |
| **State** | Message array in React component state |

### 2.5 Pet Profiles

| Aspect | Detail |
|---|---|
| **Store** | `pet-store.ts` (zustand) |
| **Persistence** | localStorage |
| **Status** | Deferred from product — NOT in navigation |
| **Server interaction** | None |

### 2.6 Newsletter

| Aspect | Detail |
|---|---|
| **Form** | Email input + submit button |
| **Submission** | No backend endpoint |
| **Persistence** | None |
| **Status** | Deferred — form exists but does nothing on submit |

### 2.7 Loyalty

| Aspect | Detail |
|---|---|
| **Page** | Static page showing tier structure |
| **Points tracking** | None (static display only) |
| **Backend** | None |

### 2.8 Search

| Aspect | Detail |
|---|---|
| **Index** | `search-index.ts` |
| **Scope** | All public pages, indexed at build time |
| **UI** | Command palette (Cmd+K) |
| **Backend** | None (client-side search) |

### 2.9 Content (Blog / Guides / Knowledge Base)

| Aspect | Detail |
|---|---|
| **Data source** | Static data files (`content-data.ts`) |
| **CMS** | None |
| **Backend** | None |

---

## 3. Static Data Files (Current Sources of Truth)

| File | Contains |
|---|---|
| `src/data/services.ts` | Service definitions, descriptions, features |
| `src/data/relocation.ts` | Relocation service data, transport info |
| `src/data/faqs.ts` | Frequently asked questions and answers |
| `src/data/pricing.ts` | Pricing tiers and pricing mode data |
| `src/data/tools-data.ts` | All 11 tool definitions |
| `src/data/content-data.ts` | Blog/guide content |
| `src/lib/business-info.ts` | Business name, address, phone, email, hours |

---

## 4. Future Database Architecture

> **IMPORTANT**: This is SCHEMA PREPARATION ONLY. The current application does NOT require a production backend to function. Do NOT treat this as a current requirement.

### 4.1 Proposed Tables / Entities

#### `users`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| email | string | Unique |
| name | string | |
| phone | string | |
| role | enum | user, admin, staff |
| createdAt | datetime | |
| updatedAt | datetime | |

#### `pets`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| userId | string | FK → users |
| name | string | Pet name |
| species | enum | dog, cat, bird, other |
| breed | string | |
| dateOfBirth | date | |
| gender | enum | male, female, unknown |
| notes | text | |

#### `bookings`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| userId | string | FK → users |
| petId | string | FK → pets |
| service | string | Service slug |
| serviceCategory | string | Service category |
| status | enum | pending, confirmed, in_progress, completed, cancelled |
| checkIn | datetime | |
| checkOut | datetime | |
| notes | text | |
| totalPrice | decimal | |
| pricingMode | enum | FIXED, ESTIMATED, QUOTE_REQUIRED |

#### `products`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| name | string | |
| description | text | |
| price | decimal | |
| category | string | |
| imageUrl | string | |
| inStock | boolean | |

#### `orders`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| userId | string | FK → users |
| status | enum | pending, paid, shipped, delivered, cancelled |
| totalAmount | decimal | |

#### `cart` (or keep localStorage)
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| userId | string | FK → users |
| productId | string | FK → products |
| quantity | integer | |

#### `loyalty`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| userId | string | FK → users |
| points | integer | |
| tier | enum | bronze, silver, gold, platinum |

#### `contact_requests`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| name | string | |
| email | string | |
| phone | string | |
| service | string | Service of interest |
| message | text | |
| intent | string | general, booking, complaint, other |

#### `content`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| slug | string | Unique, URL-safe |
| title | string | |
| body | text | |
| type | enum | blog, guide, faq, kb |
| status | enum | draft, published, archived |
| authorId | string | FK → users or staff |
| publishedAt | datetime | |

#### `medical_tool_content`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| toolSlug | string | Which tool this belongs to |
| condition | string | Condition name |
| symptoms | text | |
| advice | text | |
| severity | enum | low, medium, high, emergency |

#### `chat_conversations`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| userId | string | FK → users (nullable) |
| sessionId | string | Browser session ID |
| startedAt | datetime | |
| endedAt | datetime | |

#### `chat_messages`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| conversationId | string | FK → chat_conversations |
| role | enum | user, assistant, system |
| content | text | |
| timestamp | datetime | |

#### `staff`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| name | string | |
| role | string | Job title |
| credential | string | e.g., DVM (nullable) |
| bio | text | |
| imageUrl | string | |
| verified | boolean | Whether info is confirmed |
| sortOrder | integer | Display order on team page |

#### `services`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| slug | string | Unique, URL-safe |
| name | string | |
| description | text | |
| category | string | Service category |
| basePrice | decimal | Nullable (QUOTE_REQUIRED) |
| pricingMode | enum | FIXED, ESTIMATED, QUOTE_REQUIRED |

#### `pricing_tiers`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| serviceId | string | FK → services |
| name | string | e.g., "Standard", "Premium" |
| description | text | |
| price | decimal | |
| features | text[] | List of included features |

#### `appointments`
| Field | Type | Notes |
|---|---|---|
| id | string/UUID | Primary key |
| bookingId | string | FK → bookings |
| staffId | string | FK → staff |
| date | date | |
| time | time | |
| duration | integer | Minutes |
| status | enum | scheduled, completed, cancelled |

---

## 5. Current Prisma Schema

The current `schema.prisma` file is the **Next.js template default** (User + Post models only). It is NOT Waggies-specific.

**Do not** use the current Prisma schema as a reference for Waggies data models. Use Section 2 (current state) and Section 4 (future schema) in this document instead.

---

## 6. State Management Summary

| Feature | Storage | Backend Required | Persistence |
|---|---|---|---|
| Cart | zustand + localStorage | No | Cross-session |
| Tools | React state | No | Session only |
| Booking | WhatsApp (no storage) | No | None (external) |
| Chatbot | React state | No | None |
| Pet Profiles | zustand + localStorage | No | Cross-session |
| Newsletter | None | No (deferred) | None |
| Loyalty | Static display | No | N/A |
| Search | Build-time index | No | N/A |
| Content | Static TS files | No | N/A |