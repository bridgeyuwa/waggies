# 06 — Dala WhatsApp & Booking Architecture

> **Purpose**: Define the complete WhatsApp-first conversion model, Service Request Composer, message construction, page integration, and booking state machine.
>
> **Priority**: HIGH — this is the core business conversion funnel.
>
> **Audience**: AI coding agents building booking flows, CTAs, contact forms.

---

## Core Principle

Waggies is **WhatsApp-first**. Every booking or service inquiry funnels through WhatsApp (wa.me/2349080811902). There is no server-side booking, no payment gateway, no in-app booking confirmation. The website prepares a message; the user sends it via WhatsApp; Waggies staff respond and confirm manually.

---

## WhatsApp Contact Details

| Channel | Value | URL |
|---|---|---|
| WhatsApp | 2349080811902 | `https://wa.me/2349080811902` |
| Phone | 0908 081 1902 | `tel:+2349080811902` |
| Email | hello@waggies.ng | `mailto:hello@waggies.ng` |

---

## Service Request Composer

The Service Request Composer is the central data structure that collects all context for a WhatsApp message. It is NOT a form in the traditional sense — it is a structured data object that gets serialized into human-readable plain text.

### Schema

```typescript
interface ServiceRequestComposer {
  // Service identification
  service: ServiceType;
  serviceCategory: ServiceCategory;

  // Pet information
  petName?: string;           // optional
  petType: PetType;
  breed?: string;             // optional

  // Package & options
  package?: PackageType;      // service-dependent (standard, premium, basic)
  options?: string[];         // e.g. ["bath-and-dry", "nail-trim", "private-suite"]

  // Dates & timing
  dates: {
    checkIn?: string;         // ISO date or friendly format
    checkOut?: string;        // ISO date or friendly format
    preferredDate?: string;
    preferredTime?: string;
  };

  duration?: string;          // e.g. "3 nights", "1 hour", "2 weeks"

  // Location
  location: {
    pickup?: string;
    dropoff?: string;
    route?: string;
    destination?: string;
  };

  // Pricing
  estimate?: string;          // e.g. "₦15,000 - ₦25,000" or "₦5,000"
  pricingMode: PricingMode;   // FIXED | ESTIMATED | QUOTE_REQUIRED

  // Customer details
  customerName: string;
  phone: string;
  email?: string;

  // Additional
  additionalMessage?: string;

  // Attribution
  source: RequestSource;
}
```

### Enums

```typescript
type ServiceType =
  | 'boarding'
  | 'grooming'
  | 'vet-care'
  | 'training'
  | 'relocation-import'
  | 'relocation-export'
  | 'local-transport';

type ServiceCategory = 'Boarding' | 'Wellness' | 'Relocation';

type PetType = 'dog' | 'cat' | 'exotic' | 'other';

type PackageType = 'standard' | 'premium' | 'basic';

type PricingMode = 'FIXED' | 'ESTIMATED' | 'QUOTE_REQUIRED';

type RequestSource =
  | 'contact-form'
  | 'booking-modal'
  | 'service-page-cta';
```

---

## User Flow

```
1. User selects/configures a service on a page
         │
         ▼
2. Service Request Composer opens (modal or inline)
         │
         ▼
3. Fields pre-populated from page context
   (e.g., service page auto-fills service, category, package)
         │
         ▼
4. User reviews pre-filled fields, edits, adds instructions
         │
         ▼
5. User clicks "Continue to WhatsApp"
         │
         ▼
6. Message constructed as readable plain text
         │
         ▼
7. Message URL-encoded into wa.me/2349080811902?text=...
         │
         ▼
8. WhatsApp opens (app or web) with pre-filled, user-editable message
         │
         ▼
9. User reviews message in WhatsApp and sends (or edits first, or doesn't send)
```

**Critical**: At no point does the website assume the message was sent. The site opens WhatsApp with a prepared message. Whether the user sends it is entirely up to them.

---

## Message Construction

### Format Rules

1. **Plain text only** — never JSON, never structured data formats
2. **Structured with clear sections** — use line breaks, headers, and bullet points
3. **Professional tone** — warm but business-appropriate
4. **Include all relevant context** — every field that has a value should appear
5. **Omit empty fields** — don't show "Breed: " with nothing after it
6. **Include source attribution** — so Waggies staff knows which page generated the request

### Example Output

```
🐕 Waggies Pet Care - Service Request

Service: Grooming (Wellness)
Package: Premium
Options: Bath & Dry, Nail Trim, Ear Cleaning

Pet: Dog (Golden Retriever), name: Buddy

Preferred Date: Monday, 15 Jan 2025
Preferred Time: 10:00 AM
Duration: ~2 hours

Estimate: ₦12,000 - ₦18,000

Customer: Adaora Okafor
Phone: 08012345678
Email: adaora@example.com

Additional: Buddy is anxious around loud noises, please handle gently.

Source: service-page-cta
```

### Technical Implementation

```typescript
function buildWhatsAppUrl(composer: ServiceRequestComposer): string {
  const message = composeMessage(composer); // returns plain text string
  const encoded = encodeURIComponent(message);
  return `https://wa.me/2349080811902?text=${encoded}`;
}
```

The resulting URL opens WhatsApp (native app on mobile, WhatsApp Web on desktop) with the message pre-filled in the text input. The user can edit before sending.

---

## Page Integration Points

### Contact Page Form
- **Source**: `contact-form`
- **Trigger**: Form submission
- **Pre-populated fields**: None (user fills all fields)
- **Flow**: User fills form → reviews → "Send via WhatsApp" → composer builds message → opens WhatsApp

### Booking Modal
- **Source**: `booking-modal`
- **Trigger**: "Book Now" buttons across the site
- **Pre-populated fields**: Service and category from the triggering page context
- **Flow**: Modal opens with service pre-selected → user fills remaining → reviews → "Continue to WhatsApp" → composer → WhatsApp

### Service Page CTAs
- **Source**: `service-page-cta`
- **Trigger**: "Book a Groom", "Book Appointment", "Get Started", "Request a Quote" etc.
- **Pre-populated fields**: Service, category, package (if user selected one on the page), options (if user toggled any)
- **Flow**: CTA click → composer opens with context → user fills remaining → reviews → "Continue to WhatsApp" → composer → WhatsApp

---

## Booking State Machine

The booking funnel has 5 distinct states. The website can only advance to state 2. States 3-5 happen entirely outside the website.

```
┌─────────────┐
│  PREPARED   │  ← Website has composed the message
└──────┬──────┘
       │
       │  User clicks "Continue to WhatsApp"
       ▼
┌──────────────────┐
│ WHATSAPP OPENED  │  ← WhatsApp app/web opened with pre-filled message
└──────┬───────────┘
       │
       │  User taps Send in WhatsApp
       ▼
┌──────────────────┐
│  MESSAGE SENT    │  ← Message delivered to Waggies WhatsApp number
└──────┬───────────┘
       │
       │  Waggies staff reads the message
       ▼
┌──────────────────────┐
│ REQUEST RECEIVED     │  ← Waggies acknowledges the inquiry
└──────┬───────────────┘
       │
       │  Waggies confirms availability, pricing, details
       ▼
┌─────────────────────┐
│ BOOKING CONFIRMED   │  ← Manual confirmation by Waggies staff
└─────────────────────┘
```

### Critical Implications

- **The website does NOT track booking status.** There is no dashboard, no booking ID, no status page.
- **"Continue to WhatsApp" ≠ "Booking confirmed".** The CTA opens WhatsApp. Nothing more.
- **Never promise confirmation.** UI copy must not imply that clicking the CTA completes a booking.
- **Never show "Booking successful" after CTA click.** The furthest the site can go is "WhatsApp opened with your message."
- **No server-side booking storage.** The website is stateless regarding bookings.

---

## UI Copy Guidelines

| Scenario | Correct | Incorrect |
|---|---|---|
| CTA button | "Continue to WhatsApp" | "Confirm Booking" |
| After CTA click | "WhatsApp has been opened with your service request. Please review and send the message." | "Your booking has been confirmed!" |
| Pricing section | "Estimated cost" | "Total price" |
| Form submission | "Send via WhatsApp" | "Submit Booking" |
| Quote request | "Request a Quote via WhatsApp" | "Get Your Quote" (without channel) |

---

## Security & Privacy Notes

- Customer phone number and email are included in the WhatsApp message at the user's discretion.
- The website does not store customer data from the composer (no localStorage, no cookies for booking data).
- The WhatsApp message is transient — it exists only in the user's and Waggies' chat history.
- No analytics tracking of message content. Standard page analytics (which CTA was clicked) is acceptable.
