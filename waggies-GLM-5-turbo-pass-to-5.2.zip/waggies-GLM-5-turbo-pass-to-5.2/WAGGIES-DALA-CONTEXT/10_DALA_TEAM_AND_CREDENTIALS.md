# Dala Context 10 — Team and Credentials

> **Status**: Authoritative context document for Waggies staff information.
> **Last updated**: Batch 3 creation.

---

## 1. Verified Staff (Authoritative)

These are confirmed staff members with verified information. **Do NOT modify their names, roles, or credentials.**

### 1.1 Dr. Nguhemen Doose Yuwa

| Field | Value |
|---|---|
| **Name** | Dr. Nguhemen Doose Yuwa |
| **Credential** | DVM (Doctor of Veterinary Medicine) |
| **Role** | Head Veterinarian and Director |
| **Responsibility** | Leads all veterinary services and oversees clinical operations at Waggies |
| **Portrait** | Temporary stock (replace with real photo when available) |
| **Verified** | ✅ Yes |

This is the only staff member with a verified professional credential. All veterinary references on the site should reference Dr. Yuwa by name and title.

### 1.2 Aifuwa Bob Osaze

| Field | Value |
|---|---|
| **Name** | Aifuwa Bob Osaze |
| **Credential** | None specified beyond "Director" |
| **Role** | Director |
| **Responsibility** | Oversees business strategy, partnerships, and overall operations at Waggies |
| **Portrait** | Temporary stock |
| **Verified** | ✅ Yes (role only, no credential) |

### 1.3 Oghomwen Oyuki Obaseki

| Field | Value |
|---|---|
| **Name** | Oghomwen Oyuki Obaseki |
| **Credential** | None specified beyond "Secretary" |
| **Role** | Secretary |
| **Responsibility** | Manages administrative operations, scheduling, and client communications |
| **Portrait** | Temporary stock |
| **Verified** | ✅ Yes (role only, no credential) |

---

## 2. Placeholder Staff (Names Acceptable, Not Verified)

These staff members have names and assigned roles but are **not yet confirmed** by Waggies. Treat as placeholders until verified information is provided.

| # | Name | Role | Notes |
|---|---|---|---|
| 4 | Chukwuma Eze | Veterinary Support | Assists head veterinarian |
| 5 | Amina Bello | Lead Groomer | Grooming team lead |
| 6 | Dayo Adekunle | Boarding Manager | Boarding operations |
| 7 | Kemi Ogunleye | Pet Trainer | Training programmes |
| 8 | Suleiman Ahmadu | Relocation & Transport Coordinator | Logistics coordination |

---

## 3. Professional Roles Waggies Should Represent

The team structure should reflect the actual service organization. Roles the website must represent:

| Role | Category | Reporting / Relationship |
|---|---|---|
| Head Veterinarian / Director | Clinical Leadership | Top-level; leads veterinary services |
| Director | Business Leadership | Top-level; business strategy & partnerships |
| Secretary | Administration | Administrative operations, scheduling, client comms |
| Veterinary Support | Veterinary | Assists Head Veterinarian |
| Lead Groomer | Grooming | Leads the grooming team |
| Grooming Assistants | Grooming | Support the Lead Groomer (unnamed placeholders acceptable) |
| Boarding Manager | Boarding | Manages boarding operations |
| Boarding Attendants | Boarding | Day-to-day pet care during stays (unnamed placeholders acceptable) |
| Pet Trainer | Training | Runs training programmes |
| Relocation & Transport Coordinator | Relocation | Coordinates logistics |
| Transport Driver / Handler | Relocation | Handles pet transport (unnamed placeholders acceptable) |

---

## 4. Critical Rules

### R1: Team Is NOT Artificially Limited
The team is not capped at 8 people. Additional roles should be created as needed to accurately represent Waggies' service organization. If a service page implies staff that don't exist yet (e.g., "Grooming Assistants"), unnamed placeholders are acceptable.

### R2: Verified Credentials ONLY
Do NOT fabricate, invent, or imply any credentials, licenses, registrations, or certifications that are not explicitly confirmed. Specifically:
- Do NOT add "CVN" or veterinary council registration numbers.
- Do NOT add grooming certifications.
- Do NOT add training accreditations.
- Do NOT add years of experience numbers unless provided.

### R3: Temporary Portraits Are Acceptable
Unsplash stock photos are acceptable as temporary placeholders until real staff photos are provided. Portrait images should:
- Show professional appearance.
- Be consistent in style across the team section.
- Be clearly marked for replacement.

### R4: Placeholder Names Are Acceptable
Where real staff names are not yet provided, Nigerian-sounding placeholder names are acceptable. These must be clearly flagged as placeholders in the codebase and replaced when confirmed.

### R5: Replacement Workflow
When real staff information is confirmed:
1. Update this document with verified details.
2. Replace placeholder names with confirmed names.
3. Replace stock portraits with real photos.
4. Update any credentials to match verified information.
5. Remove the placeholder flag.

---

## 5. Team Page / Section Guidance

### Display Order
1. Dr. Nguhemen Doose Yuwa (Head Veterinarian / Director) — highest visibility
2. Aifuwa Bob Osaze (Director)
3. Oghomwen Oyuki Obaseki (Secretary)
4. Service leads (Veterinary Support, Lead Groomer, Boarding Manager, Pet Trainer, Relocation Coordinator)
5. Support staff (Grooming Assistants, Boarding Attendants, Transport Handlers)

### Card Content
- Name
- Role title
- Credential (if verified — currently only Dr. Yuwa has DVM)
- Short bio / responsibility description
- Portrait image
- No social media links unless provided
- No email addresses unless provided

### Do NOT Include
- Fabricated credentials or certifications
- Years of experience (unless confirmed)
- Personal social media profiles
- Academic institution names (unless confirmed)
- License numbers (unless confirmed)
