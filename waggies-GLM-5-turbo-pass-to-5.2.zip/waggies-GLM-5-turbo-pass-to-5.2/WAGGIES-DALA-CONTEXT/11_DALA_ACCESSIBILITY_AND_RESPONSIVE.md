# Dala Context 11 — Accessibility and Responsive Design

> **Status**: Authoritative context document. Both sections are MANDATORY and RELEASE-BLOCKING.
> **Last updated**: Batch 3 creation.
> **Standard**: WCAG 2.2 AA.

---

## Part A: Accessibility (WCAG 2.2 AA)

### A1. Keyboard Navigation

All interactive elements must be reachable and operable via keyboard.

| Requirement | Detail |
|---|---|
| Tab reachability | Every interactive element (links, buttons, inputs, selects) reachable via Tab key |
| Visible focus indicator | 2px solid brand primary color, 2px offset from element |
| Focus on mouse click | Use `:focus-visible`, NOT `:focus` — no focus ring shown on mouse click |
| Skip link | `SkipLink` component → focuses `#main-content` on activation |
| Flyout menus | ArrowUp / ArrowDown / Escape navigation through menu items |
| Dialogs | Focus trap when open; return focus to trigger element on close |
| Forms | Tab through all fields in logical order; Enter to submit |

### A2. Focus Management

- `:focus-visible` styles on **all** interactive elements.
- No focus outline on mouse click (use `:focus-visible`, not `:focus`).
- Focus ring must be visible against ALL backgrounds (brand-purple, white, secondary, surface).
- Skip link (`SkipLink` component) must be the first focusable element on the page.

### A3. Dialogs

- Use shadcn Dialog (Radix UI) for all modal dialogs.
- Radix provides built-in focus trap.
- Close on Escape key.
- ARIA attributes: `role="dialog"`, `aria-modal="true"`, `aria-labelledby` pointing to dialog title.
- On close, focus returns to the element that triggered the dialog.

### A4. Flyout Menus

- Keyboard navigation: ArrowUp/ArrowDown to move between items, Escape to close.
- ARIA: `role="menu"` on container, `role="menuitem"` on items.
- `aria-expanded` on the trigger button.
- Close on outside click AND Escape.
- Focus remains on trigger when flyout closes (unless item was activated).

### A5. Forms

- Labels **ABOVE** inputs — never use placeholder-as-label.
- Error messages associated with fields via `aria-describedby`.
- Required field indicators (visual asterisk + `aria-required="true"`).
- Validation on **submit** — not on every keystroke (no aggressive inline validation).
- Inputs have proper `type` attributes (email, tel, url, etc.).

### A6. Error Handling

- Form validation errors clearly associated with their fields (`aria-describedby` pointing to error element).
- Error summary at top of form if multiple errors exist.
- Toast notifications (sonner) for success/error actions that are not form-field-specific.
- Error messages use clear, actionable language.

### A7. Status Messages

- `aria-live="polite"` for non-urgent updates (e.g., "Cart updated", "Search results loaded").
- `aria-live="assertive"` for critical alerts (e.g., "Session expired", "Payment failed").
- Toast notifications for action confirmations.

### A8. Touch Targets

- **Minimum 44×44px** on ALL interactive elements.
- **Minimum 44×44px** on ALL clickable elements.
- Adequate spacing between adjacent touch targets (no accidental taps).
- Applies to: buttons, links, icon buttons, form inputs, checkboxes, radio buttons, toggles.

### A9. Color Contrast

| Element | Requirement |
|---|---|
| Body text | Minimum 4.5:1 contrast ratio against background |
| Muted / secondary text | `/60` opacity minimum — NEVER `/40` or `/50` |
| Text on brand-purple background | Use white or secondary cream only |
| Focus ring | Visible against all backgrounds |
| Interactive elements | Sufficient contrast in both default and hover/focus states |
| Decorative elements | Exempt from contrast requirements |

### A10. Reduced Motion

**CSS level:**
```css
@media (prefers-reduced-motion: reduce) {
  /* Disable ALL CSS animations and transitions */
}
```

**JavaScript level (Framer Motion):**
- Use `useReducedMotion()` hook to gate ALL JS animations.
- If reduced motion is preferred, skip or instantly complete animations.

**Prohibited always (regardless of preference):**
- Continuous or looping animations.
- Parallax effects.
- Scroll hijacking.
- Magnetic hover effects.

### A11. 200% Reflow

- All content must be readable and functional at 200% browser zoom.
- No horizontal scrolling at any zoom level.
- No content overflow or clipping.
- Forms must be fully usable at 200% zoom.
- Layout must reflow (not require horizontal scroll).

### A12. Semantic HTML

| Element | Usage |
|---|---|
| `<main>` | Primary page content (one per page, `id="main-content"`) |
| `<header>` | Top navigation / page header |
| `<nav>` | Navigation blocks |
| `<section>` | Content sections |
| `<article>` | Self-contained content (blog posts, service cards) |
| `<aside>` | Supplementary content |
| `<footer>` | Page footer |
| Heading hierarchy | h1 → h2 → h3, never skip levels |

### A13. Screen Reader Compatibility

- All images have `alt` text or `aria-label`.
- Decorative images: `alt=""` (empty alt, not missing alt).
- Interactive elements have accessible names (visible label or `aria-label`).
- Icon-only buttons: `aria-label` with descriptive text.
- Status indicators: `aria-live` for dynamic content.
- Links have descriptive text (no "click here", no bare URLs).

---

## Part B: Responsive Design

> **Status**: MANDATORY, RELEASE-BLOCKING.
> The site must work correctly at every width from 320px to 2560px.

### B1. Required Viewport Checkpoints

| Width | Device Category |
|---|---|
| 320px | Small phone (Samsung Galaxy Fold cover screen) |
| 360px | Small phone (Samsung Galaxy S series) |
| 375px | Standard phone (iPhone SE, iPhone 12/13/14) |
| 390px | Phone (iPhone 14/15 Pro) |
| 414px | Phone (iPhone Plus/Max) |
| 430px | Phone (iPhone 15/16 Pro Max) |
| 768px | Tablet portrait (iPad Mini, iPad) |
| 820px | Tablet (iPad Air) |
| 1024px | Tablet landscape / small laptop |
| 1280px | Laptop |
| 1440px | Desktop |
| 1920px | Full HD desktop |
| 2560px | Large / ultra-wide display |

### B2. Additional Test Conditions

| Condition | What to Verify |
|---|---|
| Portrait orientation | Layout, navigation, content flow |
| Landscape orientation | Navigation, hero, content width |
| Touch interaction | Tap targets, gestures, swipe |
| Keyboard-only navigation | Tab order, focus visibility, flyouts, dialogs |
| Virtual keyboard | Address bar, form input — content not hidden behind keyboard |
| Mobile browser UI | Safe areas, notch handling, bottom bar |
| Intermediate widths | All widths between breakpoints — no broken layouts |

### B3. Hard Requirements

| Requirement | Detail |
|---|---|
| No horizontal overflow | At any width, any zoom level |
| No content clipping | All content fully visible |
| No element overlap | No overlapping text, buttons, or content |
| No unusable controls | Buttons too small, off-screen, or unreachable |

### B4. Navigation Behavior by Viewport

| Width | Navigation Pattern |
|---|---|
| < 768px | Hamburger drawer + bottom navigation bar |
| 768–1023px | Same as mobile or hybrid (depending on content width) |
| ≥ 1024px | Full horizontal navigation with flyout dropdowns |

### B5. Component-Specific Responsive Rules

| Component | Rule |
|---|---|
| Chatbot panel | `dvh` sizing, viewport-contained, does not cause page overflow |
| Images | Responsive (`object-cover`, maintained aspect ratios) |
| Tables | Responsive — card layout on mobile if needed |
| Cards | Stack vertically on mobile, grid on tablet/desktop |
| Forms | Single column on mobile, multi-column on desktop where appropriate |
| Hero | Responsive text sizing, image stacking on mobile |
| Service pages | Content reflows, CTAs remain accessible |
| Tools | Calculator/tool UI fits mobile width without horizontal scroll |
| Mobile drawer | No horizontal scroll within drawer |
| Bottom nav | Fixed to bottom, 44px+ touch targets, does not obscure content |
