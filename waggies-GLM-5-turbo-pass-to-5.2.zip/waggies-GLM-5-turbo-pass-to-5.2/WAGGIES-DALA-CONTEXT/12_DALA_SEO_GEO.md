# Dala Context 12 — SEO and Geo-Targeting

> **Status**: Authoritative context document for Waggies SEO strategy.
> **Last updated**: Batch 3 creation.

---

## 1. Page Metadata

### Title Template
- **Pattern**: `%s - Waggies`
- **Set in**: `layout.tsx` root layout
- **Example**: `Pet Boarding in Abuja - Waggies`
- **Default title**: `Waggies - Pet Care, Abuja`

### Default Description
Pet boarding, grooming, veterinary care, training, and relocation services in Abuja, Nigeria.

### Per-Page Metadata
Each page should define unique `title` and `description` via:
- Static pages: `metadata` export
- Dynamic pages: `generateMetadata()` function

---

## 2. Canonical URLs

- `metadataBase` is set from `NEXT_PUBLIC_SITE_URL` environment variable in `layout.tsx`.
- Each page inherits its canonical URL from `metadataBase` + route path.
- **Dev caveat**: `NEXT_PUBLIC_SITE_URL` currently defaults to localhost in development.
- **Production requirement**: `NEXT_PUBLIC_SITE_URL` must be set to the production domain.

---

## 3. Sitemap

- **File**: `src/app/sitemap.ts`
- **Type**: Dynamic generation
- **Coverage**: ~35+ public routes
- **Excludes**: `/my-pets` (user-private, noindex)
- **Per-route config**: Each entry has `priority` and `changeFrequency`

---

## 4. Robots

- **File**: `src/app/robots.ts`
- **Configuration**:
  ```
  User-agent: *
  Allow: /
  Disallow: /my-pets
  Sitemap: /sitemap.xml
  ```

---

## 5. Breadcrumbs (Structured Data)

- **Component**: `BreadcrumbSchema`
- **Format**: JSON-LD
- **Applied to**: All inner pages (not homepage)
- **Hierarchy**: Home > Section > Page
  - Example: `Home > Services > Boarding`
  - Example: `Home > Relocation > Transport`
  - Example: `Home > Tools > Pet Symptom Checker`

---

## 6. JSON-LD Structured Data

- `breadcrumb-schema.tsx` — Breadcrumb markup (see Section 5)
- `json-ld.tsx` — Additional structured data where applicable

---

## 7. Internal Linking

| Source | Target | Purpose |
|---|---|---|
| Service pages | Related service pages | Cross-service discovery |
| Footer | All major sections | Global navigation coverage |
| Navigation flyouts | All pages | Full site discoverability |
| Tools hub | All 11 tools | Tool discovery |
| Service pages | Relevant tools | Contextual tool promotion |

---

## 8. Tools SEO

- Each tool page has a `metadata` export with unique title and description.
- **Geo-targeted queries**: Tool pages target location-specific search intent.
  - Example: "pet symptom checker Abuja"
  - Example: "dog vaccination schedule Nigeria"
- Structured data (JSON-LD) where applicable.
- Internal links from service pages and tools hub.

---

## 9. Service SEO

- Each service page has metadata (`title`, `description`, `keywords`).
- Service hero section includes a relevant image.
- Internal links between related services.
- Service pages link to relevant tools.

---

## 10. Search Indexing (Command Palette)

- `search-index.ts` indexes all public pages at build time.
- Command palette (`Cmd+K`) provides full-text search across all indexed pages.
- Search results include page title, route, and description.
- Excludes private routes (e.g., `/my-pets`).

---

## 11. Local Transport Canonicalization

- **Canonical route**: `/relocation/transport`
- **Legacy route**: `/services/transport` → **301 permanent redirect** to `/relocation/transport`
- **Rule**: All internal links must point to `/relocation/transport`.
- **Sitemap**: Must include `/relocation/transport`, NOT `/services/transport`.
- **Reason**: Transport is a sub-service of Relocation, not a top-level service.

---

## 12. Open Graph

| Property | Value |
|---|---|
| `og:type` | `website` |
| `og:locale` | `en_NG` |
| `og:url` | Derived from metadataBase + route |
| `og:site_name` | Waggies |
| `og:title` | Page title |
| `og:description` | Page description |
| `og:image` | **NOT currently set** (`defaultOgImage: undefined`) |

### Twitter Card

| Property | Value |
|---|---|
| `twitter:card` | `summary_large_image` |
| `twitter:title` | Page title |
| `twitter:description` | Page description |

---

## 13. Geo-Targeting Strategy

Waggies serves **Abuja, Nigeria**. All SEO efforts should reflect this.

### Keywords
- Include "Abuja" and "Nigeria" in page titles and descriptions where natural.
- Service pages: "[service] in Abuja" pattern.
- Tools: geo-specific query targeting (see Section 8).

### Locale
- `og:locale`: `en_NG`
- Language: English (Nigerian English conventions acceptable in copy)
- Currency: Nigerian Naira (₦) for pricing content.

### Local SEO Signals
- Business address on every page (footer, contact page, location in Google Business integration if applicable).
- Phone number prominently displayed: `+234 908 081 1902`.
- WhatsApp as primary conversion channel.

---

## 14. Known SEO Gaps

| Gap | Status | Impact |
|---|---|---|
| No `og:image` configured | Open | Social sharing shows no preview image |
| Canonical URLs default to localhost in dev | Expected in dev | No production impact if `NEXT_PUBLIC_SITE_URL` is set |
| Dynamic routes (e.g., `blog/[slug]`) may need `generateMetadata` | Future | Per-page SEO for blog content |
| No FAQ schema markup | Open | Could improve search result rich snippets |
| No LocalBusiness schema | Open | Could improve Google Business / map results |
