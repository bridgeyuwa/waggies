# 07 — Dala Pricing Model

> **Purpose**: Define the three pricing modes (FIXED, ESTIMATED, QUOTE_REQUIRED), their UI treatment, WhatsApp behavior, and the Get Estimate flow.
>
> **Priority**: HIGH — incorrect pricing presentation is a business-critical error.
>
> **Audience**: AI coding agents building pricing pages, service cards, and booking flows.

---

## Overview

Waggies uses three pricing modes to handle the range of services offered — from standard grooming packages with known costs to complex international relocations that require custom quoting. Every service and package must be assigned exactly one pricing mode.

---

## Mode 1: FIXED

### Definition
An exact, known price displayed to the user. The price is authoritative and will not change (barring Waggies updating their pricing).

### When to Use
- Standard packages with well-defined costs
- Services where all variables are known upfront
- Examples:
  - Basic Grooming Package: ₦5,000
  - Standard Boarding (per night): ₦8,000
  - Vaccination consultation: ₦3,000

### UI Treatment
- Show the exact price prominently: **"₦5,000"**
- Use the `text-h3` or `text-body` typography scale depending on context
- Price should be visually prominent on service cards and pricing tables
- No qualifiers needed (no "starting from", no "approximately")
- The price IS the price

### WhatsApp Behavior
- Include the exact price in the Service Request Composer message
- Example: `Price: ₦5,000`
- No asterisks, no disclaimers about price changes

---

## Mode 2: ESTIMATED

### Definition
A price range shown to the user. The actual cost may vary based on factors not known at the time of browsing (e.g., pet size, condition, specific needs, distance).

### When to Use
- Services with variable factors that affect cost
- Where a range provides useful guidance without committing to a price
- Examples:
  - Grooming (custom): ₦7,000 - ₦15,000 (depends on breed, coat condition, size)
  - Local transport: ₦10,000 - ₦25,000 (depends on distance, pet size, duration)
  - Vet consultation: ₦5,000 - ₦10,000 (depends on type of consultation)

### UI Treatment
- Show the range: **"₦7,000 - ₦15,000"**
- Include a brief note explaining variability: "Actual cost may vary based on [relevant factor]"
- The note should be subtle (meta/label typography) but readable
- Do NOT use "From ₦7,000" — show the full range

### WhatsApp Behavior
- Include the estimate range in the message
- Example: `Estimated cost: ₦7,000 - ₦15,000 (actual cost may vary based on pet size and coat condition)`

---

## Mode 3: QUOTE_REQUIRED

### Definition
No price is shown to the user. The user must contact Waggies (via WhatsApp) to receive a custom quote.

### When to Use
- Complex or custom services where pricing cannot be estimated
- Services with too many variable factors to provide a meaningful range
- Examples:
  - International relocation (import/export)
  - Custom training programs
  - Specialized veterinary procedures

### UI Treatment
- Show NO price
- Display a "Request a Quote" CTA instead of a price
- The CTA opens the Service Request Composer with `pricingMode: "QUOTE_REQUIRED"`
- An estimate range MAY be shown as optional supplementary info, but it is not required
- If no range is available, show nothing — just the CTA

### WhatsApp Behavior
- Include "Quote requested" in the message, not a price
- Example: `Pricing: Quote requested for International Relocation`
- The message should still include all service context so Waggies can provide an accurate quote

---

## Pricing Mode Decision Matrix

| Factor | FIXED | ESTIMATED | QUOTE_REQUIRED |
|---|---|---|---|
| Cost is known upfront | ✅ | ❌ | ❌ |
| Cost has minor variability | ❌ | ✅ | ❌ |
| Cost has major variability | ❌ | Maybe | ✅ |
| Cost depends on custom factors | ❌ | ❌ | ✅ |
| Standard package | ✅ | ✅ | ❌ |
| Custom/complex service | ❌ | Maybe | ✅ |
| International service | ❌ | ❌ | ✅ |

---

## Get Estimate Flow

The pricing page (`/services/pricing`) includes an interactive estimator.

``
User navigates to /services/pricing
           │
           ▼
URL may include ?service=SERVICE query param
           │
           ▼
If ?service present → preselect that service's tab
           │
           ▼
User configures estimator:
  - Selects service
  - Selects pet type
  - Selects duration/quantity
  - Toggles options/add-ons
           │
           ▼
Result display:
  - FIXED → shows exact price
  - ESTIMATED → shows range with note
  - QUOTE_REQUIRED → shows "Request a Quote" CTA
           │
           ▼
User clicks "Get Estimate" or "Request a Quote"
           │
           ▼
Service Request Composer opens
  (pre-populated with all estimator selections)
           │
           ▼
"Continue to WhatsApp" → opens WhatsApp with composed message
```

---

## Critical Rules

### R1: NEVER Invent Pricing Data
This is the most important rule. If a price, range, or cost figure is not provided by Waggies (via golden reference documents, explicit instructions, or the existing codebase), **do not fabricate it**.

### R2: NEVER Fabricate Cost Figures
Do not guess, estimate, extrapolate, or derive pricing from context clues. If the codebase has `₦0` or a placeholder, treat it as unknown and use QUOTE_REQUIRED.

### R3: Use QUOTE_REQUIRED as Fallback
If pricing is not provided by Waggies for a service, the correct behavior is:
1. Do NOT show any price
2. Set `pricingMode: "QUOTE_REQUIRED"`
3. Show "Request a Quote" CTA
4. Let the WhatsApp flow handle it

### R4: Authoritative Source Only
All pricing must come from an authoritative source:
- Waggies-provided price lists
- Existing codebase pricing data (if verified)
- Direct instruction from the Waggies team
- The GOLDEN_ASSET_INVENTORY or golden reference documents

NOT from:
- Market research
- Competitor pricing
- AI hallucination
- "Reasonable" guesses

### R5: Currency
All prices are in Nigerian Naira (₦). Use the ₦ symbol. No currency conversion. No USD equivalent.

---

## Implementation Notes

### Service Card Price Display

```tsx
// Pseudocode for how a service card handles pricing
function ServiceCardPrice({ mode, price, range }: PriceProps) {
  switch (mode) {
    case 'FIXED':
      return <span className="text-h3 font-bold">{price}</span>;
    case 'ESTIMATED':
      return (
        <div>
          <span className="text-h3 font-bold">{range.min} - {range.max}</span>
          <span className="text-meta text-muted">Actual cost may vary</span>
        </div>
      );
    case 'QUOTE_REQUIRED':
      return <Button>Request a Quote</Button>;
  }
}
```

### Pricing Page Estimator

The estimator on `/services/pricing` should:
- Default to the service specified in `?service=` query param
- Allow switching between services via tabs
- Dynamically update the result display as the user changes inputs
- Pass all selections to the Service Request Composer when CTA is clicked
- Handle all three pricing modes in the result area
