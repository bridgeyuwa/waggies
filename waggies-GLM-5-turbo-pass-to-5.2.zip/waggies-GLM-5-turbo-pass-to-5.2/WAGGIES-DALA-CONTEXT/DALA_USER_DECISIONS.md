# Waggies — Explicit User Decisions

> Only decisions explicitly made by the user. Organised by category.
> Agent recommendations are NOT included here.

---

## Navigation

| # | Decision |
|---|----------|
| 1 | Primary navigation order: **Services → About → Tools → Resources → Shop → Book Now** |
| 2 | My Pets is **removed** from the current product. The route may exist but must NOT appear in navigation, sitemap, or public indexing. |

## Information Architecture

| # | Decision |
|---|----------|
| 3 | **Wellness** is a grouping label only. There is no Wellness overview page. |
| 4 | **Local Transport** belongs under **Relocation**, not under Services. |
| 5 | Local Transport canonical route: **/relocation/transport**. |
| 6 | Old route /services/transport must 301 redirect to /relocation/transport. |
| 7 | **Relocation Checklist** is a hybrid capability, canonical at **/relocation/checklist**, discoverable from both Relocation and Tools sections. One implementation, not duplicate pages. |

## Services

| # | Decision |
|---|----------|
| 8 | The five core services are: **Boarding, Grooming, Veterinary Care, Training, Relocation**. |
| 9 | Boarding has three subtypes: Dogs, Cats, Exotic Pets. |
| 10 | Relocation contains three independently requestable services: **Pet Import, Pet Export, Local Transport**. |

## Tools

| # | Decision |
|---|----------|
| 11 | All **11 tools** remain in the product. |
| 12 | Medical-risk tools (Symptom Checker, Vaccination Schedule, Medication Dosage Guide, Emergency Guide, Parasite Schedule) require a **MedicalDisclaimer**. |
| 13 | Do NOT fabricate veterinary doses, protocols, credentials, medical claims, or legal/regulatory requirements in tool content. |

## Booking

| # | Decision |
|---|----------|
| 14 | Booking is a **Booking Request**, not an automatically confirmed appointment. |
| 15 | A reusable **Service Request Composer** is required. |

## WhatsApp

| # | Decision |
|---|----------|
| 16 | WhatsApp is a **major Waggies conversion channel**. |
| 17 | Contact and booking/request flows should generate **structured WhatsApp messages**. |
| 18 | Users must be able to **add additional instructions/requests** before opening WhatsApp. |
| 19 | The prepared WhatsApp number is **2349080811902**. |

## Pricing

| # | Decision |
|---|----------|
| 20 | Pricing supports three modes: **FIXED, ESTIMATED, QUOTE_REQUIRED**. |
| 21 | **Never invent pricing.** If pricing is not provided by Waggies, use QUOTE_REQUIRED. |

## Chatbot

| # | Decision |
|---|----------|
| 22 | Chatbot should be **production-quality at the UI level** but remain **provider-agnostic**. |
| 23 | Production RAG/LLM infrastructure is **not required now**. |
| 24 | Future chatbot direction: Intent/Safety Router → Waggies RAG → optional LLM → safety/factuality validation. |

## Images

| # | Decision |
|---|----------|
| 25 | **Temporary stock imagery** is allowed until authentic Waggies originals exist. |
| 26 | **No intended image slot should be empty.** |
| 27 | Do **not visibly label** stock photos as stock. |
| 28 | Do **not imply** that stock photos show actual Waggies staff, facilities, or patients. |
| 29 | Homepage hero must be **image-led and visually distinctive**. |

## Gallery

| # | Decision |
|---|----------|
| 30 | Gallery **must remain populated** with images across all groups. |

## Team

| # | Decision |
|---|----------|
| 31 | Team is **not artificially limited** to seven people. |
| 32 | The three verified staff are authoritative and must remain accurate: **Dr. Nguhemen Doose Yuwa (DVM)**, **Aifuwa Bob Osaze**, **Oghomwen Oyuki Obaseki**. |
| 33 | Do **not invent credentials or licenses**. Verified credentials only. |
| 34 | Additional professional roles should cover the actual service organization. |
| 35 | Temporary portrait placeholders are acceptable. |

## Contact

| # | Decision |
|---|----------|
| 36 | Contact is the **canonical location/contact hub**. |
| 37 | Contact page includes the **full map** (Google Maps embed). |

## Footer

| # | Decision |
|---|----------|
| 38 | **Brand / Follow Us block** is positioned **above** the navigation-column row. |
| 39 | Follow Us uses **five social icons**. |
| 40 | Footer groups: **Services, Company, Resources, Support, Legal**. |
| 41 | Resources and Legal must remain **separate** groups. |

## Design

| # | Decision |
|---|----------|
| 42 | **Light mode only.** No dark mode. |
| 43 | Waggies brand colours remain canonical in **OKLCH**. |
| 44 | **Phosphor** is the preferred application icon family. |
| 45 | Taste Skill v2 design language is the design quality authority. |

## Accessibility

| # | Decision |
|---|----------|
| 46 | **WCAG 2.2 AA** is mandatory. |

## Responsive

| # | Decision |
|---|----------|
| 47 | Cross-device responsive quality is a **release-blocking requirement**. |

## SEO

| # | Decision |
|---|----------|
| 48 | Proper sitemap, robots, canonical URLs, breadcrumbs, and JSON-LD are required. |

## Backend

| # | Decision |
|---|----------|
| 49 | Database schema may be prepared now, but **production backend is deferred**. |
| 50 | All relevant future entities can be represented in the schema architecture. |
