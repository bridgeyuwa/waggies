# 05 — Dala Imagery Guide

> **Purpose**: Document every major intended image category, its specifications, current status, and the rules governing image use across the Waggies website.
>
> **Audience**: AI coding agents, designers, content editors.

---

## Image Categories

### 1. Homepage Hero Image

- **Slot**: 1
- **Dimensions**: ~1200×600 (responsive, scales down on mobile)
- **Content intent**: Dog with owner or premium pet-care facility; warm, trustworthy, Nigerian context
- **Current status**: Temporary Unsplash stock
- **Replacement priority**: HIGH — first impression
- **Notes**: Should feel premium. No text overlay on the image itself; text is rendered by HTML over the hero.

### 2. Homepage Service Card Images (6 cards)

- **Slot**: 6 images
- **Dimensions**: ~600×400 each
- **Services depicted**:
  1. Boarding
  2. Grooming
  3. Vet Care
  4. Training
  5. Relocation (import/export)
  6. Local Transport
- **Current status**: Temporary Unsplash stock
- **Notes**: Each card thumbnail should clearly represent its service category. Consistent style across all 6.

### 3. Homepage Trust Feature Icons

- **Slot**: Icon-driven (no photos)
- **Content intent**: Trust signals (verified, insured, licensed, etc.)
- **Implementation**: Phosphor Icons or similar icon library
- **Notes**: NOT image slots. These are SVG/icon components. No Unsplash needed.

### 4. Services Hub Hero

- **Slot**: 1
- **Dimensions**: ~1200×600
- **Content intent**: Overview of all services; could be a collage or single aspirational shot
- **Current status**: Temporary Unsplash stock
- **Notes**: Less critical than homepage hero but should still feel premium.

### 5. Services Hub Service Card Images (6 cards)

- **Slot**: 6 images
- **Dimensions**: ~600×400 each
- **Content intent**: Same 6 service categories as homepage cards but may use different images for variety
- **Current status**: Temporary Unsplash stock
- **Notes**: Can reuse homepage card images or use alternatives. Must remain consistent per service.

### 6. Boarding Hub

- **Slots**: 4
  - **Hero**: ~1200×600, boarding facility or comfortable kennel environment
  - **Subtype Card 1** (Standard): ~600×400
  - **Subtype Card 2** (Premium): ~600×400
  - **Subtype Card 3** (VIP/Executive): ~600×400
  - **Safe Space floating card**: ~400×300, cozy reassuring image
- **Current status**: Temporary Unsplash stock
- **Notes**: Subtype cards should show increasing premium feel from Standard → Premium → VIP.

### 7. Grooming Hero Image

- **Slot**: 1
- **Dimensions**: ~1200×600
- **Content intent**: Professional grooming in progress or before/after result
- **Current status**: Temporary Unsplash stock

### 8. Vet Care Hero Image

- **Slot**: 1
- **Dimensions**: ~1200×600
- **Content intent**: Clinical but warm veterinary setting
- **Current status**: Temporary Unsplash stock
- **Notes**: Should convey professionalism and care, not cold/sterile.

### 9. Training Hero Image

- **Slot**: 1
- **Dimensions**: ~1200×600
- **Content intent**: Dog training session, trainer with dog
- **Current status**: Temporary Unsplash stock

### 10. Transport / Local Transport Hero Image

- **Slot**: 1 (shared across transport-related pages)
- **Dimensions**: ~1200×600
- **Content intent**: Pet in transport carrier or vehicle, safe travel
- **Current status**: Temporary Unsplash stock

### 11. Relocation Hub

- **Slots**: 4+
  - **Hero**: ~1200×600, pet travel/relocation concept
  - **Import card**: ~600×400
  - **Export card**: ~600×400
  - **Transport card**: ~600×400
  - **Checklist card**: ~600×400
- **Current status**: Temporary Unsplash stock

### 12. About Page

- **Slots**: 3
  - **Hero**: ~1200×600, team or facility overview
  - **Mosaic Image 1**: ~600×400
  - **Mosaic Image 2**: ~600×400
- **Current status**: Temporary Unsplash stock
- **Notes**: Mosaic images show company culture, facility, or team at work.

### 13. Team Portraits (8 total)

- **Slot**: 8 images
- **Dimensions**: ~400×400 each
- **Composition**:
  - 3 verified (real or near-final team members)
  - 5 placeholder (temporary stock portraits)
- **Current status**: All temporary stock
- **Replacement priority**: MEDIUM-HIGH
- **Notes**: Temporary stock is acceptable until real photos are available. All 8 slots must remain populated.

### 14. Gallery (23 images in 5 groups)

- **Slot**: 23 images total
- **Dimensions**: Various (responsive grid, mixed aspect ratios acceptable)
- **Groups**:
  1. **Boarding Suites** (~5 images)
  2. **Grooming Spa** (~5 images)
  3. **Vet Clinic** (~5 images)
  4. **Training** (~4 images)
  5. **Relocation/Transport** (~4 images)
- **Current status**: All 23 are temporary Unsplash stock with valid URLs
- **Minimum per group**: Each group MUST retain at least its allocated count
- **Notes**: Gallery is a trust-building showcase. All slots must be populated at all times.

### 15. Blog / Guides / Knowledge Base Article Images

- **Slot**: Per-article (variable, grows with content)
- **Dimensions**: ~800×400 (article hero) + in-body images as needed
- **Current status**: Temporary Unsplash stock per article
- **Notes**: Each published article needs at minimum a hero/cover image.

### 16. Shop Product Images

- **Slot**: Per-product (variable, grows with catalog)
- **Dimensions**: ~400×400 product shot, with optional additional angles
- **Current status**: Temporary Unsplash stock per product
- **Notes**: Product images should be on clean/neutral backgrounds for consistency.

---

## Image Slot Summary

| Category | Slots | Current Source | Replacement Priority |
|---|---|---|---|
| Homepage hero | 1 | Unsplash stock | HIGH |
| Homepage service cards | 6 | Unsplash stock | HIGH |
| Homepage trust icons | 0 (icon-driven) | Phosphor Icons | N/A |
| Services hub hero | 1 | Unsplash stock | MEDIUM |
| Services hub cards | 6 | Unsplash stock | MEDIUM |
| Boarding hub | 4 | Unsplash stock | HIGH |
| Grooming hero | 1 | Unsplash stock | MEDIUM |
| Vet Care hero | 1 | Unsplash stock | MEDIUM |
| Training hero | 1 | Unsplash stock | MEDIUM |
| Transport hero | 1 | Unsplash stock | MEDIUM |
| Relocation hub | 4+ | Unsplash stock | MEDIUM |
| About page | 3 | Unsplash stock | MEDIUM |
| Team portraits | 8 | Unsplash stock (3 verified + 5 placeholder) | MEDIUM-HIGH |
| Gallery | 23 | Unsplash stock | LOW (functional) |
| Blog/Guides/KB | Per-article | Unsplash stock | LOW (functional) |
| Shop products | Per-product | Unsplash stock | LOW (functional) |

**Total fixed slots**: ~60+ (excluding per-article and per-product)

---

## Rules

### R1: Temporary Stock Is Allowed
Temporary Unsplash stock images are acceptable and expected in the current build phase. The site ships with stock; this is intentional, not a gap.

### R2: No Empty Image Slots
No intended image slot should ever be empty (no broken images, no blank areas where an image is expected). Every slot defined above must have a valid image source at all times.

### R3: Do Not Label Stock as Stock
Do NOT add visible labels, watermarks, badges, or captions indicating an image is stock photography. The user should see a polished, complete site.

### R4: Do Not Imply Stock Shows Reality
Do NOT imply, state, or suggest that stock photos depict actual Waggies staff, facilities, patients, or operations. Image alt text should be generic (e.g., "Dog being groomed" not "Waggies groomer bathing a client's dog"). Copy near images should not claim the photo is of Waggies.

### R5: Gallery Must Remain Populated
Each gallery group must maintain at least its allocated minimum image count. If a group drops below minimum, it must be replenished (with stock if necessary) before deployment.

### R6: Team Portraits
Temporary stock portraits are acceptable for all 8 team slots. The 3 "verified" slots have been reviewed for tone/appropriateness. The 5 "placeholder" slots are acknowledged as interim. When real team photos arrive, all 8 slots should be replaced.

### R7: Hero Imagery Tone
All hero images should feel:
- **Premium**: High-quality, well-composed, good lighting
- **Warm**: Inviting, emotional connection with pets
- **Trustworthy**: Clean, professional, not overly stylized
- **Nigerian context-appropriate**: Not incongruous with Abuja/Nigeria setting (avoid snow, autumn leaves, etc.)

### R8: WaggiesImage Component
The codebase uses a `WaggiesImage` component that handles:
- Missing or empty `src` gracefully (placeholder or fallback)
- Responsive `srcSet` where available
- Loading states
- Alt text propagation

When building or editing components that display images, always use `WaggiesImage` — never raw `<img>` tags.

### R9: Image Replacement Workflow
When authentic Waggies photography becomes available:
1. Refer to `GOLDEN_ASSET_INVENTORY.md` for the canonical list of all image slots
2. Replace images **slot by slot** — do not do bulk replacements that might miss slots
3. Update the inventory document to mark each slot as "authentic"
4. Ensure new images match the dimensions and aspect ratios specified above
5. Verify responsive behavior after replacement
6. Do not remove stock images from the codebase until replacements are verified live

---

## Image Audit Status

- **Total audited slots**: ~70
- **Valid URLs**: All
- **Empty slots**: None
- **Audit date**: Current build
- **Next audit**: When authentic photos arrive
