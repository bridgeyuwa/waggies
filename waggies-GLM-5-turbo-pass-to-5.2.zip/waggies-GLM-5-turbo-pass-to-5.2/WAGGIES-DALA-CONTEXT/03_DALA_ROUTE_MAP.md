# 03 — Dala Route Map: Waggies

> **Audience**: Application-building agent. Complete route inventory with navigation, canonical, redirect, and SEO metadata.
> **Total public routes**: 46 page.tsx files
> **Excluded**: `/my-pets` (exists but not in nav, not in sitemap, robots disallow)

---

## Format

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |

---

## Home

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |
|-------|---------|-------------------|-----------------|-----------------|---------------|-------------------|
| `/` | Homepage — hero, services, trust, testimonials | Top-level (logo click returns here) | Canonical (self) | None | HIGH | Home |

---

## Services

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |
|-------|---------|-------------------|-----------------|-----------------|---------------|-------------------|
| `/services` | Services hub — all 5 service categories | Nav → Services (flyout header) | Canonical (self) | None | HIGH | Home > Services |
| `/services/boarding` | Boarding hub — overview + links to 3 subtypes | Nav → Services → Boarding | Canonical (self) | None | HIGH | Home > Services > Boarding |
| `/services/boarding/dogs` | Dog boarding service page | Nav → Services → Boarding → Dog Boarding | Canonical (self) | None | MEDIUM | Home > Services > Boarding > Dog Boarding |
| `/services/boarding/cats` | Cat boarding service page | Nav → Services → Boarding → Cat Boarding | Canonical (self) | None | MEDIUM | Home > Services > Boarding > Cat Boarding |
| `/services/boarding/exotic` | Exotic pet boarding service page | Nav → Services → Boarding → Exotic Pet Boarding | Canonical (self) | None | MEDIUM | Home > Services > Boarding > Exotic Pet Boarding |
| `/services/grooming` | Grooming service page | Nav → Services → Wellness → Grooming | Canonical (self) | None | MEDIUM | Home > Services > Grooming |
| `/services/vet-care` | Veterinary care service page | Nav → Services → Wellness → Veterinary Care | Canonical (self) | None | MEDIUM | Home > Services > Veterinary Care |
| `/services/training` | Dog training service page | Nav → Services → Wellness → Training | Canonical (self) | None | MEDIUM | Home > Services > Training |
| `/services/pricing` | Pricing tiers for all services | Nav → Services → (inline link or footer) | Canonical (self) | None | MEDIUM | Home > Services > Pricing |

---

## Relocation

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |
|-------|---------|-------------------|-----------------|-----------------|---------------|-------------------|
| `/relocation` | Relocation hub — overview + 4 sub-service cards | Nav → Services → Relocation | Canonical (self) | None | HIGH | Home > Relocation |
| `/relocation/import` | Pet import service page | Nav → Services → Relocation → Pet Import | Canonical (self) | None | MEDIUM | Home > Relocation > Pet Import |
| `/relocation/export` | Pet export service page | Nav → Services → Relocation → Pet Export | Canonical (self) | None | MEDIUM | Home > Relocation > Pet Export |
| `/relocation/transport` | Local pet transport service page | Nav → Services → Relocation → Local Transport | **CANONICAL** for transport | **Receives** 301 from `/services/transport` | MEDIUM | Home > Relocation > Local Transport |
| `/relocation/checklist` | Relocation document checklist (hybrid tool) | Nav → Services → Relocation → Doc Checklist AND Nav → Tools → Doc Checklist | Canonical (self) | None | MEDIUM | Home > Relocation > Document Checklist |

---

## About

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |
|-------|---------|-------------------|-----------------|-----------------|---------------|-------------------|
| `/about` | About Waggies — story, team mosaic | Nav → About → About Us | Canonical (self) | None | HIGH | Home > About |
| `/about/testimonials` | Customer testimonials | Nav → About → Testimonials | Canonical (self) | None | MEDIUM | Home > About > Testimonials |
| `/about/gallery` | Photo gallery with lightbox | Nav → About → Gallery | Canonical (self) | None | LOW | Home > About > Gallery |
| `/about/careers` | Open positions | Nav → About → Careers | Canonical (self) | None | LOW | Home > About > Careers |
| `/about/partnerships` | Partnership information | Nav → About → Partnerships | Canonical (self) | None | LOW | Home > About > Partnerships |

---

## Tools

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |
|-------|---------|-------------------|-----------------|-----------------|---------------|-------------------|
| `/tools` | Tools hub — grid of all 11 tools | Nav → Tools (flyout header) | Canonical (self) | None | HIGH | Home > Tools |
| `/tools/symptom-checker` | Assess pet symptoms | Nav → Tools → Symptom Checker | Canonical (self) | None | MEDIUM | Home > Tools > Symptom Checker |
| `/tools/pet-age-calculator` | Convert pet age to human years | Nav → Tools → Pet Age Calculator | Canonical (self) | None | MEDIUM | Home > Tools > Pet Age Calculator |
| `/tools/vaccination-schedule` | Vaccination timeline by species/age | Nav → Tools → Vaccination Schedule | Canonical (self) | None | MEDIUM | Home > Tools > Vaccination Schedule |
| `/tools/cost-calculator` | Estimate service costs | Nav → Tools → Cost Calculator | Canonical (self) | None | MEDIUM | Home > Tools > Cost Calculator |
| `/tools/medication-dosage-guide` | Medication dosage guidance | Nav → Tools → Medication Dosage Guide | Canonical (self) | None | MEDIUM | Home > Tools > Medication Dosage Guide |
| `/tools/nutrition-calculator` | Pet nutritional needs calculator | Nav → Tools → Nutrition Calculator | Canonical (self) | None | MEDIUM | Home > Tools > Nutrition Calculator |
| `/tools/emergency-guide` | Emergency response guidance | Nav → Tools → Emergency Guide | Canonical (self) | None | MEDIUM | Home > Tools > Emergency Guide |
| `/tools/new-pet-checklist` | New pet preparation checklist | Nav → Tools → New Pet Checklist | Canonical (self) | None | MEDIUM | Home > Tools > New Pet Checklist |
| `/tools/parasite-schedule` | Parasite prevention schedule | Nav → Tools → Parasite Schedule | Canonical (self) | None | MEDIUM | Home > Tools > Parasite Schedule |
| `/tools/behavior-tips` | Common behavior issue tips | Nav → Tools → Behavior Tips | Canonical (self) | None | MEDIUM | Home > Tools > Behavior Tips |
| `/tools/breed-finder` | Breed recommendation quiz | Nav → Tools → Breed Finder | Canonical (self) | None | MEDIUM | Home > Tools > Breed Finder |

---

## Resources

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |
|-------|---------|-------------------|-----------------|-----------------|---------------|-------------------|
| `/blog` | Blog article listing | Nav → Resources → Blog | Canonical (self) | None | MEDIUM | Home > Blog |
| `/blog/[slug]` | Individual blog article | Blog listing → click article | Canonical (self) | None | MEDIUM | Home > Blog > [Article Title] |
| `/guides` | Care guides listing | Nav → Resources → Guides | Canonical (self) | None | MEDIUM | Home > Guides |
| `/guides/[slug]` | Individual guide | Guides listing → click guide | Canonical (self) | None | MEDIUM | Home > Guides > [Guide Title] |
| `/knowledge-base` | Knowledge base article listing | Nav → Resources → Knowledge Base | Canonical (self) | None | MEDIUM | Home > Knowledge Base |
| `/knowledge-base/[slug]` | Individual KB article | KB listing → click article | Canonical (self) | None | MEDIUM | Home > Knowledge Base > [Article Title] |
| `/faq` | Frequently asked questions | Nav → Resources → FAQ | Canonical (self) | None | MEDIUM | Home > FAQ |

---

## Shop

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |
|-------|---------|-------------------|-----------------|-----------------|---------------|-------------------|
| `/shop` | Product listing with filters | Nav → Shop (direct link) | Canonical (self) | None | MEDIUM | Home > Shop |
| `/shop/[id]` | Individual product detail | Shop listing → click product | Canonical (self) | None | MEDIUM | Home > Shop > [Product Name] |

---

## Other Pages

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |
|-------|---------|-------------------|-----------------|-----------------|---------------|-------------------|
| `/contact` | Canonical contact/location hub | Footer → Support → Contact | Canonical (self) | None | HIGH | Home > Contact |
| `/loyalty` | Loyalty programme information | Footer → Support → Loyalty | Canonical (self) | None | LOW | Home > Loyalty |

---

## Legal Pages

| Route | Purpose | Navigation Location | Canonical Status | Redirect Status | SEO Importance | Breadcrumb Hierarchy |
|-------|---------|-------------------|-----------------|-----------------|---------------|-------------------|
| `/privacy-policy` | Privacy policy | Footer → Legal → Privacy Policy | Canonical (self) | None | LOW | Home > Privacy Policy |
| `/terms-of-service` | Terms of service | Footer → Legal → Terms of Service | Canonical (self) | None | LOW | Home > Terms of Service |
| `/cookies-policy` | Cookies policy | Footer → Legal → Cookies Policy | Canonical (self) | None | LOW | Home > Cookies Policy |

---

## Redirects

| From Route | To Route | Redirect Type | Notes |
|------------|-----------|---------------|-------|
| `/services/transport` | `/relocation/transport` | 301 (Permanent) | Local Transport's canonical home is under Relocation |

---

## Excluded Routes

| Route | Status | Reason |
|-------|--------|--------|
| `/my-pets` | EXISTS but EXCLUDED | Not in navigation. Not in sitemap. `robots.ts` disallows. Route and page exist in codebase but are not part of the public-facing product. |

---

## SEO Importance Legend

- **HIGH**: Core business pages that drive organic traffic — homepage, service hubs, contact, relocation hub
- **MEDIUM**: Inner service pages, individual tools, content pages, shop — important for long-tail SEO
- **LOW**: Legal pages, gallery, careers, partnerships, loyalty — necessary but not primary SEO targets

---

## Route Count Summary

| Section | Count |
|---------|-------|
| Home | 1 |
| Services | 8 |
| Relocation | 5 |
| About | 5 |
| Tools | 12 (hub + 11 tools) |
| Resources | 7 (blog×2, guides×2, kb×2, faq) |
| Shop | 2 |
| Other | 2 (contact, loyalty) |
| Legal | 3 |
| Redirects | 1 |
| Excluded | 1 |
| **Total page.tsx** | **46** |