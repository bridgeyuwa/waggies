# 08 — Dala Tools Catalog

> **Purpose**: Complete catalog of all 11 Waggies tools with technical specs, medical safety rules, and booking/WhatsApp relationships.
>
> **Audience**: AI coding agents building tool pages, integrating medical disclaimers, and wiring booking CTAs.

---

## Tools Overview

| # | Tool | Route | Category | Medical? | Disclaimer? |
|---|---|---|---|---|---|
| 1 | Symptom Checker | `/tools/symptom-checker` | Diagnostic | YES | YES |
| 2 | Pet Age Calculator | `/tools/pet-age-calculator` | Utility | NO | NO |
| 3 | Vaccination Schedule | `/tools/vaccination-schedule` | Preventive | YES | YES |
| 4 | Cost Calculator | `/tools/cost-calculator` | Financial | NO | NO |
| 5 | Medication Dosage Guide | `/tools/medication-dosage-guide` | Medical Reference | YES | YES |
| 6 | Nutrition Calculator | `/tools/nutrition-calculator` | Nutritional | NO | NO |
| 7 | Emergency & Poison Guide | `/tools/emergency-guide` | Emergency | YES | YES |
| 8 | New Pet Checklist | `/tools/new-pet-checklist` | Preparation | NO | NO |
| 9 | Parasite Schedule | `/tools/parasite-schedule` | Preventive | YES | YES |
| 10 | Behavior Tips | `/tools/behavior-tips` | Behavioral | NO | NO |
| 11 | Breed Finder | `/tools/breed-finder` | Reference | NO | NO |

---

## Medical Safety Rules

These rules apply to ALL tools marked "Medical: YES" and MUST be enforced without exception.

### M1: No Fabricated Veterinary Doses
Do NOT invent, guess, or derive medication dosages. All dosage data must come from the tool's static data source, which must be vet-reviewed.

### M2: No Fabricated Protocols
Do NOT invent treatment protocols, vaccination schedules, or care procedures. Only present data from the tool's authoritative static data.

### M3: No Fabricated Credentials
Do NOT claim the tool is "vet-approved," "clinically tested," or endorsed by any veterinary body unless explicitly stated by Waggies.

### M4: No Fabricated Medical Claims
Do NOT claim the tool diagnoses, treats, or cures any condition. Tools provide **guidance** and **references**, not diagnoses or treatments.

### M5: No Fabricated Legal/Regulatory Requirements
Do NOT invent Nigerian veterinary regulations, import requirements, or legal obligations. If regulatory data is not in the static data, omit it.

### M6: MedicalDisclaimer Component Required
Every medical tool (6 tools total) MUST render the `MedicalDisclaimer` component. The disclaimer must:
- Be clearly visible (not hidden in a collapsed section)
- State: **"This tool is for informational purposes only and is not a substitute for professional veterinary advice. Always consult a qualified veterinarian for medical decisions about your pet."**
- Appear at or near the top of the tool output, or at minimum before any medical guidance is displayed
- Use appropriate styling (warning/intent color, not buried in fine print)

### M7: Symptom Checker Specific
The Symptom Checker must NEVER output a diagnosis. It outputs:
- Possible conditions (not "you have X")
- Severity indicator (general guidance)
- Recommended action (e.g., "consult a veterinarian promptly")

The output language must use qualifiers: "may indicate," "could be associated with," "consider consulting."

---

## Tools Hub

- **Route**: `/tools`
- **Purpose**: Landing page listing all 11 tools with descriptions, category badges, and medical indicators
- **Layout**: Card grid, each card linking to its tool page
- **Medical tools** should display a small medical/cross indicator or badge

---

## Individual Tool Specifications

### 1. Symptom Checker

| Field | Value |
|---|---|
| **Name** | Symptom Checker |
| **Route** | `/tools/symptom-checker` |
| **Purpose** | Help pet owners identify potential health issues based on symptoms via interactive body-part selection |
| **Category** | Diagnostic |
| **Medical?** | YES |
| **Disclaimer Required?** | YES |
| **Inputs** | Pet type (dog/cat), body part selection (interactive diagram or list), symptom choices per body part |
| **Outputs** | Possible conditions list, severity indicator (mild/moderate/urgent), recommended action (NOT a diagnosis) |
| **SEO Intent** | "pet symptom checker Abuja", "dog symptom checker Nigeria", "is my pet sick" |
| **Booking/WhatsApp Relationship** | May recommend booking a vet consultation via WhatsApp CTA |
| **Backend Status** | Static data, no backend. All symptom→condition mappings are hardcoded. |
| **Interaction Model** | Interactive — user selects body part, then picks symptoms from a filtered list, then sees results |
| **Key UI Element** | Body part selector (could be a simple visual diagram or a categorized list) |

---

### 2. Pet Age Calculator

| Field | Value |
|---|---|
| **Name** | Pet Age Calculator |
| **Route** | `/tools/pet-age-calculator` |
| **Purpose** | Convert pet age to human-equivalent age using breed-specific conversion tables |
| **Category** | Utility |
| **Medical?** | NO |
| **Disclaimer Required?** | NO |
| **Inputs** | Pet type (dog/cat), age (years, months), size category (for dogs: small/medium/large/giant) |
| **Outputs** | Human-equivalent age, brief life stage description (puppy, adult, senior, etc.) |
| **SEO Intent** | "pet age calculator", "dog years to human years", "cat age calculator" |
| **Booking/WhatsApp Relationship** | No direct relationship. Utility tool only. |
| **Backend Status** | Client-side calculation. No API calls. Conversion tables embedded in component. |
| **Interaction Model** | Simple form — user fills inputs, result appears immediately |

---

### 3. Vaccination Schedule

| Field | Value |
|---|---|
| **Name** | Vaccination Schedule |
| **Route** | `/tools/vaccination-schedule` |
| **Purpose** | Show recommended vaccination timeline for dogs and cats by age |
| **Category** | Preventive |
| **Medical?** | YES |
| **Disclaimer Required?** | YES |
| **Inputs** | Pet type (dog/cat), current age |
| **Outputs** | Timeline/schedule of recommended vaccines by age milestone, with vaccine names and descriptions |
| **SEO Intent** | "dog vaccination schedule Nigeria", "puppy vaccination timeline", "cat vaccines Abuja" |
| **Booking/WhatsApp Relationship** | May recommend booking a vaccination appointment via WhatsApp CTA |
| **Backend Status** | Static data. Vaccination schedules hardcoded per pet type. No backend. |
| **Interaction Model** | User selects pet type and age → schedule displayed as timeline or table |
| **Note** | Data should be general/reputable veterinary guidelines, not Waggies-specific protocols |

---

### 4. Cost Calculator

| Field | Value |
|---|---|
| **Name** | Cost Calculator |
| **Route** | `/tools/cost-calculator` |
| **Purpose** | Estimate Waggies service costs based on service type, pet, and duration |
| **Category** | Financial |
| **Medical?** | NO |
| **Disclaimer Required?** | NO |
| **Inputs** | Service selection, pet type, duration/quantity, add-on options |
| **Outputs** | Estimated cost (FIXED or ESTIMATED per pricing model) |
| **SEO Intent** | "pet care cost Abuja", "dog grooming price Nigeria", "pet boarding cost" |
| **Booking/WhatsApp Relationship** | Direct link to booking request — "Book Now" or "Get Estimate" CTA connects to Service Request Composer → WhatsApp |
| **Backend Status** | Static data. Pricing tables embedded. No real-time backend. |
| **Interaction Model** | Multi-step form or single-page with dynamic results. Similar to pricing page estimator but standalone tool. |
| **Note** | Must respect pricing modes (FIXED/ESTIMATED/QUOTE_REQUIRED). See 07_DALA_PRICING_MODEL.md. |

---

### 5. Medication Dosage Guide

| Field | Value |
|---|---|
| **Name** | Medication Dosage Guide |
| **Route** | `/tools/medication-dosage-guide` |
| **Purpose** | Reference for common pet medications with general dosage information |
| **Category** | Medical Reference |
| **Medical?** | YES |
| **Disclaimer Required?** | YES |
| **Inputs** | Medication name (search or browse), pet weight |
| **Outputs** | General dosage reference, medication description, important notes/warnings |
| **SEO Intent** | "pet medication guide", "dog medicine dosage", "pet drug reference" |
| **Booking/WhatsApp Relationship** | MUST recommend consulting a veterinarian. May include WhatsApp CTA for vet consultation. |
| **Backend Status** | Static data, vet-reviewed. Medication database embedded. No backend API. |
| **Interaction Model** | Search/browse medications → select → enter pet weight → see reference dosage |
| **Critical Rule** | Output must include prominent text: "Always consult your veterinarian before administering any medication." This is in addition to the MedicalDisclaimer component. |

---

### 6. Nutrition Calculator

| Field | Value |
|---|---|
| **Name** | Nutrition Calculator |
| **Route** | `/tools/nutrition-calculator` |
| **Purpose** | Estimate daily calorie needs and food portions for pets |
| **Category** | Nutritional |
| **Medical?** | NO |
| **Disclaimer Required?** | NO |
| **Inputs** | Pet type (dog/cat), weight, age, activity level, body condition |
| **Outputs** | Estimated daily calorie needs, suggested food portion ranges |
| **SEO Intent** | "pet nutrition calculator", "how much to feed my dog", "cat food portions" |
| **Booking/WhatsApp Relationship** | No direct relationship. May link to shop for pet food products. |
| **Backend Status** | Client-side calculation. Formulas embedded in component. No backend. |
| **Interaction Model** | Form with sliders/inputs → real-time result calculation |
| **Note** | Should include a gentle note that these are estimates and individual needs may vary |

---

### 7. Emergency & Poison Guide

| Field | Value |
|---|---|
| **Name** | Emergency & Poison Guide |
| **Route** | `/tools/emergency-guide` |
| **Purpose** | Quick-reference for pet emergency care and common poisons/toxins |
| **Category** | Emergency |
| **Medical?** | YES |
| **Disclaimer Required?** | YES |
| **Inputs** | Search or browse (emergency type, poison/toxin name) |
| **Outputs** | Step-by-step emergency first-aid instructions, poison toxicity info, when to seek immediate vet care |
| **SEO Intent** | "pet emergency Abuja", "dog poison emergency", "pet first aid Nigeria" |
| **Booking/WhatsApp Relationship** | MUST show emergency phone/WhatsApp contact IMMEDIATELY and prominently. This is the one tool where the WhatsApp CTA is urgent/life-safety. |
| **Backend Status** | Static data. Emergency protocols and poison database embedded. No backend. |
| **Interaction Model** | Search/browse → emergency info card → prominent "Call/WhatsApp Now" CTA |
| **Critical Rules** |
| | - Emergency contact (WhatsApp + phone) must be visible WITHOUT scrolling past the emergency content |
| | - Use urgent/intent styling for the contact CTA |
| | - Do NOT gate emergency contact behind a form or modal |

---

### 8. New Pet Checklist

| Field | Value |
|---|---|
| **Name** | New Pet Checklist |
| **Route** | `/tools/new-pet-checklist` |
| **Purpose** | Interactive checklist of everything needed when bringing a new pet home |
| **Category** | Preparation |
| **Medical?** | NO |
| **Disclaimer Required?** | NO |
| **Inputs** | Pet type (dog/cat) |
| **Outputs** | Categorized checklist with checkboxes (food, bedding, vet, training, safety, etc.) |
| **SEO Intent** | "new pet checklist", "what do I need for a new puppy", "new kitten supplies" |
| **Booking/WhatsApp Relationship** | May link to shop for supplies. May suggest booking first vet visit. |
| **Backend Status** | localStorage persistence. Checklist state saved per pet type so user can return and continue. No backend. |
| **Interaction Model** | Select pet type → categorized checklist appears → user checks items → progress saved to localStorage → can print or share |
| **Note** | Categories should include: Essentials, Food & Water, Bedding & Comfort, Health & Vet, Training, Safety, Grooming, Identification |

---

### 9. Parasite Schedule

| Field | Value |
|---|---|
| **Name** | Parasite Schedule |
| **Route** | `/tools/parasite-schedule` |
| **Purpose** | Prevention schedule for deworming, flea, and tick treatments |
| **Category** | Preventive |
| **Medical?** | YES (Medical-adjacent) |
| **Disclaimer Required?** | YES |
| **Inputs** | Pet type (dog/cat), age, location (Abuja/other — may affect parasite risk) |
| **Outputs** | Recommended deworming, flea, and tick prevention schedule by age/frequency |
| **SEO Intent** | "parasite prevention pets", "dog deworming schedule", "flea prevention Nigeria" |
| **Booking/WhatsApp Relationship** | May recommend booking a vet consultation for parasite prevention products/treatments |
| **Backend Status** | Static data. Prevention schedules embedded. No backend. |
| **Interaction Model** | Select pet type and age → schedule displayed as timeline/table with product type recommendations |
| **Note** | Medical-adjacent but NOT diagnostic. Provides preventive care schedules, not treatment. |

---

### 10. Behavior Tips

| Field | Value |
|---|---|
| **Name** | Behavior Tips |
| **Route** | `/tools/behavior-tips` |
| **Purpose** | Practical pet behavior advice and training tips |
| **Category** | Behavioral |
| **Medical?** | NO |
| **Disclaimer Required?** | NO |
| **Inputs** | Browse/search by topic or behavior issue |
| **Outputs** | Tips and advice articles (static content) |
| **SEO Intent** | "dog behavior tips", "how to stop dog barking", "cat behavior problems" |
| **Booking/WhatsApp Relationship** | May recommend booking a training session via WhatsApp CTA for persistent behavioral issues |
| **Backend Status** | Static content. Articles/tips embedded. No backend. |
| **Interaction Model** | Browse by category or search → read tip cards/articles |
| **Topics might include** | Excessive barking, chewing, separation anxiety, litter training, leash pulling, socialization |

---

### 11. Breed Finder

| Field | Value |
|---|---|
| **Name** | Breed Finder |
| **Route** | `/tools/breed-finder` |
| **Purpose** | Explore dog and cat breeds with filtering by characteristics |
| **Category** | Reference |
| **Medical?** | NO |
| **Disclaimer Required?** | NO |
| **Inputs** | Species (dog/cat), size filter, temperament filter, activity level filter |
| **Outputs** | Breed profiles with characteristics (size, temperament, grooming needs, exercise needs, lifespan) |
| **SEO Intent** | "dog breed finder", "best dog breeds for families Nigeria", "cat breed selector" |
| **Booking/WhatsApp Relationship** | No direct relationship. Purely informational. |
| **Backend Status** | Static data. Breed database embedded. No backend. |
| **Interaction Model** | Filter controls → breed grid/list → click breed → detailed profile |
| **Note** | Should include both common and less-common breeds. Profiles should be factual, not promotional. |

---

## Summary: Medical Disclaimer Requirements

6 tools require the MedicalDisclaimer component:

1. **Symptom Checker** — diagnostic guidance
2. **Vaccination Schedule** — preventive health
3. **Medication Dosage Guide** — drug reference (also needs per-output vet consultation reminder)
4. **Emergency & Poison Guide** — emergency care (also needs immediate WhatsApp/phone CTA)
5. **Parasite Schedule** — preventive health (medical-adjacent)

5 tools do NOT require medical disclaimers:

1. Pet Age Calculator — pure utility
2. Cost Calculator — financial
3. Nutrition Calculator — general wellness estimates
4. New Pet Checklist — preparation
5. Behavior Tips — behavioral advice
6. Breed Finder — reference

---

## Summary: WhatsApp/Booking Integration

| Tool | Booking CTA? | CTA Type |
|---|---|---|
| Symptom Checker | Yes | "Book Vet Consultation" (non-urgent) |
| Pet Age Calculator | No | — |
| Vaccination Schedule | Yes | "Book Vaccination" |
| Cost Calculator | Yes | "Book Now" / "Get Estimate" |
| Medication Dosage Guide | Yes | "Consult a Vet" (recommendation, not urgent) |
| Nutrition Calculator | No | May link to shop |
| Emergency & Poison Guide | Yes | "Call/WhatsApp Now" (URGENT, life-safety) |
| New Pet Checklist | Maybe | "Book First Vet Visit", link to shop |
| Parasite Schedule | Yes | "Book Vet Consultation" |
| Behavior Tips | Yes | "Book Training Session" |
| Breed Finder | No | — |