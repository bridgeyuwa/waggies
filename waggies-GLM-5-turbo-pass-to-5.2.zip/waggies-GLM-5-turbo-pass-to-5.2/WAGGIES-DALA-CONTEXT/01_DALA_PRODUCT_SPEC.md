# 01 — Dala Product Specification: Waggies

> **Audience**: Application-building agent (Dala/Gebeya context package). This document describes *what to build* and *why*.
> **Version**: 1.0 | **Source of truth**: Project context (see worklog.md)

---

## 1. What Waggies Is

Waggies is a **premium pet care business** headquartered in Life Camp, Efab City Estate, 65 1st Ave, Abuja 900108, FCT, Nigeria. It operates as both a physical service provider and a digital presence designed to convert visitors into WhatsApp-qualified service requests.

The business offers **five service categories**:

- **Boarding** — overnight and extended-stay care for dogs, cats, and exotic pets
- **Grooming** — professional grooming services
- **Veterinary Care** — wellness exams, vaccinations, diagnostics, treatment
- **Dog Training** — obedience, behavior modification, socialisation
- **Pet Relocation** — import, export, and local transport of animals within and beyond Nigeria

Beyond services, Waggies provides **11 free interactive pet care tools**, a **product shop**, a **content library** (blog, guides, knowledge base, FAQ), a **gallery**, and an **AI chatbot prototype**.

The website is the primary digital touchpoint. It must convey trust, warmth, and professionalism to Nigerian pet owners, expatriate families relocating with pets, and prospective pet owners exploring tools and educational content.

---

## 2. Target Users

### Primary: Pet Owners in Abuja / Nigeria
- Already own a dog, cat, or exotic pet
- Need boarding while traveling, grooming, vet care, or training
- May discover Waggies through search, social media, or word of mouth
- Expect WhatsApp-based communication

### Secondary: Expats Relocating With Pets
- Moving into or out of Nigeria
- Need import/export documentation guidance and logistics
- High-value customers; relocation is complex and premium-priced
- Will use the Relocation Checklist tool and Relocation service pages

### Tertiary: Prospective Pet Owners
- Considering getting a pet and researching costs, care requirements, and breed suitability
- Engage with tools (cost calculator, breed finder, new pet checklist)
- May convert to paying customers after adoption

---

## 3. Business Model

Waggies generates revenue through:

1. **Service Fees** — boarding rates (per night), grooming sessions, vet consultations, training packages, relocation logistics. Pricing is fixed, estimated, or quote-required depending on the service.
2. **Shop Products** — physical pet products sold through the online shop. Cart is localStorage-based; purchase is completed via WhatsApp or in-store.
3. **Loyalty Programme** — Bronze / Silver / Gold tiers that reward repeat customers with points and perks.

**Conversion Strategy**: WhatsApp-first. Every booking flow terminates in a prepopulated WhatsApp message. There is no online payment, no auto-confirmed booking, and no server-side booking system in the current frontend-only build.

---

## 4. Primary User Journeys

### Journey A: Service Discovery → Booking
1. User lands on homepage or a service page via search/social
2. Explores service category (e.g., Boarding → Dog Boarding)
3. Reviews service details, standards, pricing tier
4. Clicks "Book Now" → Booking Request modal opens
5. Fills in service details, pet info, preferred dates
6. Submits → prepopulated WhatsApp message opens in wa.me with structured service request
7. User reviews/edits the message in WhatsApp and sends
8. Waggies team responds to confirm availability and finalize

### Journey B: Tool Usage → Education → Potential Booking
1. User discovers a tool via /tools hub, search, or a blog article
2. Uses the tool (e.g., Symptom Checker, Cost Calculator)
3. Reads related educational content linked from the tool
4. May click a CTA to book a relevant service (e.g., Vet Care after symptom check)
5. Same WhatsApp booking flow as Journey A

### Journey C: Shop Browse → Purchase
1. User browses /shop listing page (filters, categories)
2. Clicks a product → product detail page with images, description, price
3. Adds to cart (Zustand store, persisted to localStorage)
4. Opens cart drawer → reviews items
5. Contact for purchase (WhatsApp or in-store); no online checkout

---

## 5. Information Architecture

```
Desktop Navigation:
Services (flyout) → About (flyout) → Tools (flyout) → Resources (flyout) → Shop (link) → [Book Now CTA]

Mobile Navigation:
Hamburger drawer with accordion groups
Fixed bottom nav: Services | Tools | Shop | Book

Services flyout:
  Boarding (group) → Boarding hub, Dog Boarding, Cat Boarding, Exotic Pet Boarding
  Wellness (label only, no page) → Grooming, Veterinary Care, Training
  Relocation (group) → Relocation hub, Pet Import, Pet Export, Local Transport, Doc Checklist

About flyout:
  About Us, Testimonials, Gallery, Careers, Partnerships

Tools flyout:
  All 11 tools listed

Resources flyout:
  FAQ, Blog, Guides, Knowledge Base
```

---

## 6. Services Detail

### Boarding
- **Hub** (`/services/boarding`): Overview of boarding philosophy, safety standards, facility highlights. Links to three subtypes.
- **Dog Boarding** (`/services/boarding/dogs`): Specifics for canine boarding — exercise, socialisation, feeding, overnight care.
- **Cat Boarding** (`/services/boarding/cats`): Feline-specific boarding — separate quarters, reduced stimulation, litter care.
- **Exotic Pet Boarding** (`/services/boarding/exotic`): Birds, reptiles, small mammals — species-specific habitats and care protocols.

### Wellness (grouping label, no dedicated page)
- **Grooming** (`/services/grooming`): Full grooming services — bath, haircut, nail trim, ear cleaning, breed-specific styling.
- **Veterinary Care** (`/services/vet-care`): Consultations, vaccinations, diagnostics, surgery referrals, emergency triage.
- **Training** (`/services/training`): Obedience classes, puppy socialisation, behavior modification, one-on-one sessions.

### Relocation
- **Hub** (`/relocation`): Overview of Waggies' relocation capabilities. Cards linking to Import, Export, Transport, and Checklist.
- **Pet Import** (`/relocation/import`): Bringing pets into Nigeria — documentation, quarantine, customs, logistics.
- **Pet Export** (`/relocation/export`): Moving pets out of Nigeria — export permits, health certificates, airline compliance.
- **Local Transport** (`/relocation/transport`): Moving pets within Nigeria. **Canonical URL** — `/services/transport` 301-redirects here.
- **Doc Checklist** (`/relocation/checklist`): Interactive checklist for relocation documents. Hybrid feature — discoverable from both the Relocation section and the Tools section. One canonical implementation.

### Pricing
- **Pricing page** (`/services/pricing`): Displays pricing tiers. Three categories: **FIXED** (set price), **ESTIMATED** (range provided), **QUOTE_REQUIRED** (request needed). Never invent or fabricate pricing values.

---

## 7. Tools (11 Interactive Pet Care Tools)

All tools live under `/tools/[slug]` and are listed on the hub at `/tools`.

| Tool | Route | Medical? | Disclaimer Required? |
|------|-------|----------|---------------------|
| Symptom Checker | `/tools/symptom-checker` | Yes | Yes |
| Pet Age Calculator | `/tools/pet-age-calculator` | No | No |
| Vaccination Schedule | `/tools/vaccination-schedule` | Yes | Yes |
| Cost Calculator | `/tools/cost-calculator` | No | No |
| Medication Dosage Guide | `/tools/medication-dosage-guide` | Yes | Yes |
| Nutrition Calculator | `/tools/nutrition-calculator` | No | No |
| Emergency Guide | `/tools/emergency-guide` | Yes | Yes |
| New Pet Checklist | `/tools/new-pet-checklist` | No | No |
| Parasite Schedule | `/tools/parasite-schedule` | Yes | Yes |
| Behavior Tips | `/tools/behavior-tips` | No | No |
| Breed Finder | `/tools/breed-finder` | No | No |

Medical tools **must** display a disclaimer: the tool provides general guidance only and does not replace professional veterinary advice.

---

## 8. Booking Flow

Booking is a **request**, not a confirmation. The flow:

1. User clicks "Book Now" (global CTA button in navigation, or inline CTA on service pages)
2. Booking Request modal opens — user selects service type, provides pet details, preferred dates, notes
3. On submit, the system constructs a **structured WhatsApp message** and opens `wa.me/2349080811902` with prepopulated text
4. The message is **user-editable** before sending
5. Waggies team responds manually via WhatsApp to confirm availability, pricing, and scheduling
6. No online payment, no auto-confirmation, no server-side booking in the current build

---

## 9. WhatsApp Integration

- **Phone**: +234 908 081 1902
- **WhatsApp URL**: `https://wa.me/2349080811902`
- **Message format**: Structured service request with fields for service type, pet name, breed, preferred dates, and additional notes
- **Prepopulation**: The frontend constructs the message and URL-encodes it into the `wa.me` link
- **User control**: The message opens in WhatsApp where the user can review, edit, and send
- **Fallback**: If WhatsApp fails to open (desktop without app), show the phone number and message template for manual use

---

## 10. Chatbot

- **Current state**: Deterministic keyword-matching prototype with production-quality UI
- **Position**: Floating button (bottom-right), opens a chat panel
- **Height unit**: `dvh` for proper mobile viewport handling
- **Design**: Provider-agnostic architecture — the UI layer does not depend on any specific AI backend
- **Future vision**: Intent router → RAG over Waggies content → LLM response → safety guardrails → conversation persistence → multi-turn context
- **Constraint**: Must remain functional and useful even without AI backend (keyword matching fallback)

---

## 11. Shop

- **Listing** (`/shop`): Grid of products with category filters, search, and sort options
- **Detail** (`/shop/[id]`): Product images, description, price, "Add to Cart" button, related products
- **Cart**: Zustand store persisted to localStorage. Drawer UI slides in from the right. Add/remove/update quantity.
- **Recently Viewed**: Tracked in localStorage, displayed on shop pages
- **Loyalty**: Points earned on purchases, redeemable across Bronze/Silver/Gold tiers
- **Purchase flow**: No online checkout. User contacts Waggies via WhatsApp or visits in-store to complete purchase.

---

## 12. Gallery

- **Route**: `/about/gallery`
- **Content**: 23 images organised into 5 groups (e.g., Boarding, Grooming, Facility, Events, Pets)
- **UI**: Lightbox with navigation between images, group filtering
- **Imagery**: Temporary stock photography is permitted. No empty slots. No visible "stock" or "placeholder" labels on images.

---

## 13. Team

Three **verified** team members with real credentials:
- **Dr. Nguhemen Doose Yuwa** — DVM, Head Veterinarian & Director
- **Aifuwa Bob Osaze** — Director
- **Oghomwen Oyuki Obaseki** — Secretary

Five **placeholder** team members (names assigned, roles defined, no verified credentials):
- Chukwuma Eze (Vet Support), Amina Bello (Lead Groomer), Dayo Adekunle (Boarding Manager), Kemi Ogunleye (Pet Trainer), Suleiman Ahmadu (Relocation & Transport Coordinator)

**Important**: The team is NOT artificially limited to 7 members. Display verified credentials only for the three verified individuals. Placeholder profiles should look complete but must not imply verified credentials.

---

## 14. Contact

- **Route**: `/contact`
- **Purpose**: Canonical location and contact hub
- **Contents**: Google Maps embed (full-width), business address, phone, email, operating hours (Mon–Fri 9AM–5PM, Sat–Sun 10AM–2PM), contact form
- **Form behavior**: Submission routes to WhatsApp (same prepopulated message pattern as booking)
- **Directions**: Include driving/transit directions to the Life Camp, Efab City Estate location

---

## 15. Footer

Layout hierarchy:
1. **Brand block** (top-left): Waggies logo/name, tagline, social media links (5 icons: Instagram, Facebook, X/Twitter, LinkedIn, TikTok, YouTube)
2. **Navigation columns** (below brand block, 5 columns):
   - Services (all service links)
   - Company (About, Testimonials, Gallery, Careers, Partnerships)
   - Resources (FAQ, Blog, Guides, Knowledge Base)
   - Support (Contact, Shop, Loyalty)
   - Legal (Privacy Policy, Terms of Service, Cookies Policy)
3. **Newsletter**: Email signup input
4. **Copyright bar**: © Waggies, current year

---

## 16. SEO

- **Sitemap**: Generated via `sitemap.ts` (Next.js built-in). Includes all 46 public routes. Excludes `/my-pets`.
- **Robots**: `robots.ts` disallows `/my-pets` and `/api/*`.
- **Canonical URLs**: Set on every page. `/relocation/transport` is canonical; `/services/transport` 301-redirects.
- **Breadcrumbs**: Structured breadcrumb navigation on every interior page.
- **JSON-LD**: LocalBusiness schema on homepage/contact. Service schema on service pages. FAQ schema on FAQ page. BreadcrumbList on all interior pages.
- **Meta**: Title, description, and Open Graph tags on every page.

---

## 17. Accessibility

- **Standard**: WCAG 2.2 AA — mandatory, release-blocking
- **Focus management**: Visible focus rings (purple-tinted), logical tab order, focus trapping in modals
- **Skip link**: Hidden skip-to-content link on every page
- **Color contrast**: All text/background combinations must meet 4.5:1 (normal) or 3:1 (large text)
- **Touch targets**: Minimum 44×44px for all interactive elements
- **Motion**: `prefers-reduced-motion` respected — all Framer Motion animations disabled or reduced
- **Images**: Meaningful alt text. Decorative images use `alt=""`.
- **Forms**: Labels associated with inputs, error messages linked to fields, ARIA live regions for dynamic feedback
- **Keyboard**: Full keyboard navigation for all interactive components

---

## 18. Responsive

- **Approach**: Mobile-first. Responsive is release-blocking.
- **Breakpoints**: sm (640px), md (768px), lg (1024px), xl (1280px), 2xl (1536px)
- **Fluid type**: `clamp()` used for display and heading sizes
- **Chatbot**: Uses `dvh` (dynamic viewport height) for proper mobile browser handling
- **Navigation**: Desktop gets flyout panels; mobile gets hamburger drawer with accordion groups plus fixed bottom nav bar
- **Layout**: Single column on mobile, multi-column grids on tablet/desktop
- **Testing**: Must render correctly across all viewport widths from 320px to 1536px+

---

## Key Decisions Reference

| Decision | Resolution |
|----------|-----------|
| My Pets feature | Removed from product, route excluded from sitemap, robots disallow |
| Booking confirmation | Request-only, not auto-confirmed |
| Conversion channel | WhatsApp-first |
| Wellness overview page | Does not exist; Wellness is a nav grouping label only |
| Local Transport URL | Canonical: `/relocation/transport`. `/services/transport` → 301 |
| Relocation Checklist | Hybrid tool, one canonical implementation at `/relocation/checklist` |
| Gallery images | Must remain populated; temporary stock imagery allowed |
| Pricing data | FIXED, ESTIMATED, or QUOTE_REQUIRED — never invent values |
| Chatbot | Production-quality UI, provider-agnostic, deterministic currently |
| Team size | Not artificially limited to any number |
| Dark mode | Not supported. Light mode only. |
| Icon library | Phosphor (`@phosphor-icons/react`) primary. Lucide discouraged. |
