"use client";

/**
 * AboutTeamCard - Dedicated team profile card for the About page.
 *
 * Renders: image (portrait 3:4), name, role, credential (verified only),
 * responsibility line, and optional placeholder badge.
 * Uses WaggiesImage for consistent lazy-loading and Phosphor User icon
 * for fallback placeholders.
 */

import { User } from "@phosphor-icons/react";
import { WaggiesImage } from "@/components/waggies/waggies-image";

export type AboutTeamCardProps = {
  name: string;
  role: string;
  image: string;
  /** Verified credential (e.g. 'DVM'). Only shown for confirmed staff. */
  credential?: string;
  /** Concise responsibility description. */
  responsibility?: string;
  /** If true, shows a 'Pending confirmation' badge and dashed border. */
  placeholder?: boolean;
};

export function AboutTeamCard({
  name,
  role,
  image,
  credential,
  responsibility,
  placeholder = false,
}: AboutTeamCardProps) {
  return (
    <div
      className={`
        relative bg-white rounded-2xl overflow-hidden
        ${placeholder
          ? "border-2 border-dashed border-primary/25"
          : "border border-surface-purple"
        }
        shadow-sm hover:shadow-soft transition-shadow
      `}
    >
      {/* Portrait image (3:4 aspect ratio) */}
      <div className="relative aspect-[3/4] overflow-hidden bg-surface-purple">
        {image ? (
          <WaggiesImage
            src={image}
            alt={`Portrait of ${name}`}
            fill
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 50vw, 25vw"
          />
        ) : (
          <div
            className="w-full h-full flex items-center justify-center"
            role="img"
            aria-label={`Photo of ${name}`}
          >
            <User className="text-primary/20" size={64} weight="thin" />
          </div>
        )}

        {/* Placeholder badge */}
        {placeholder && (
          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur text-primary-dark/60 text-[10px] uppercase tracking-wide font-medium px-2.5 py-1 rounded-full">
            Pending confirmation
          </div>
        )}
      </div>

      {/* Card content */}
      <div className="p-5 space-y-1.5">
        <h3 className="text-h3 text-primary-dark leading-tight">{name}</h3>

        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-label text-primary font-medium">{role}</span>
          {credential && (
            <span className="text-[10px] uppercase tracking-wide text-primary-dark/60 border border-primary/20 px-2 py-0.5 rounded-lg">
              {credential}
            </span>
          )}
        </div>

        {responsibility && (
          <p className="text-meta text-primary-dark/60 leading-relaxed pt-1">
            {responsibility}
          </p>
        )}
      </div>
    </div>
  );
}
