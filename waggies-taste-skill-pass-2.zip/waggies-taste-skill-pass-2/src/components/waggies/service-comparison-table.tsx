"use client";

import { useRef } from "react";
import { motion, useInView, useReducedMotion } from "framer-motion";
import { MaterialSymbol } from "./material-symbol";

/**
 * ServiceComparisonTable - side-by-side comparison of Waggies' 6 services.
 *
 * Desktop: HTML table with sticky first column.
 * Mobile:  card-based layout (each service is a card).
 * Rows stagger in on scroll via framer-motion useInView.
 */

// ── Data ──────────────────────────────────────────────────────────────────

const SERVICES = [
  { key: "boarding", label: "Boarding", icon: "apartment", price: "₦8,000/night" },
  { key: "grooming", label: "Grooming", icon: "spa", price: "₦8,000/session" },
  { key: "vet-care", label: "Vet Care", icon: "medical_services", price: "₦12,000" },
  { key: "training", label: "Training", icon: "school", price: "₦80,000/programme" },
  { key: "relocation", label: "Relocation", icon: "flight_takeoff", price: "₦25,000" },
  { key: "transport", label: "Local Transport", icon: "local_shipping", price: "₦5,000/trip" },
] as const;

type ServiceKey = (typeof SERVICES)[number]["key"];

const FEATURES: { label: string; supported: ServiceKey[] }[] = [
  { label: "24/7 Care", supported: ["boarding"] },
  { label: "On-site Vet", supported: ["boarding", "vet-care"] },
  { label: "Home Visit", supported: ["vet-care", "transport"] },
  { label: "International", supported: ["relocation"] },
  { label: "Group Sessions", supported: ["training"] },
  { label: "Pickup & Dropoff", supported: ["transport", "relocation"] },
  { label: "Daily Updates", supported: ["boarding", "grooming"] },
  { label: "Online Booking", supported: ["boarding", "grooming", "vet-care", "training", "relocation", "transport"] },
  { label: "Loyalty Points", supported: ["boarding", "grooming", "vet-care", "training", "relocation", "transport"] },
];

// ── Cell icons ────────────────────────────────────────────────────────────

function CheckCell() {
  return (
    <MaterialSymbol
      name="check_circle"
      filled
      className="text-emerald-500 text-lg"
    />
  );
}

function DashCell() {
  return (
    <MaterialSymbol
      name="remove_circle_outline"
      className="text-primary-dark/20 text-lg"
    />
  );
}

// ── Desktop table ─────────────────────────────────────────────────────────

function DesktopTable({ isInView, reduceMotion }: { isInView: boolean; reduceMotion: boolean }) {
  return (
    <div className="overflow-x-auto">
      <table className="w-full border-collapse min-w-[640px]">
        <thead>
          <tr>
            <th className="sticky left-0 z-10 bg-surface-purple/80 backdrop-blur-sm p-4 text-left text-sm font-semibold text-primary-dark min-w-[140px]">
              Feature
            </th>
            {SERVICES.map((svc) => (
              <th
                key={svc.key}
                className="p-4 text-center min-w-[120px]"
              >
                <div className="flex flex-col items-center gap-1">
                  <MaterialSymbol
                    name={svc.icon}
                    className="text-primary text-xl"
                  />
                  <span className="text-sm font-semibold text-primary-dark">
                    {svc.label}
                  </span>
                  <span className="text-xs text-primary-dark/50">
                    {svc.price}
                  </span>
                </div>
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {FEATURES.map((feat, rowIdx) => (
            <motion.tr
              key={feat.label}
              initial={reduceMotion ? false : { opacity: 0, x: -20 }}
              animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: -20 }}
              transition={{
                duration: reduceMotion ? 0 : 0.4,
                delay: reduceMotion ? 0 : rowIdx * 0.06,
                ease: "easeOut",
              }}
              className="border-t border-primary/10 even:bg-surface-purple/30"
            >
              <td className="sticky left-0 z-10 bg-white p-4 text-sm font-medium text-primary-dark">
                {feat.label}
              </td>
              {SERVICES.map((svc) => (
                <td
                  key={svc.key}
                  className="p-4 text-center"
                >
                  {feat.supported.includes(svc.key) ? (
                    <CheckCell />
                  ) : (
                    <DashCell />
                  )}
                </td>
              ))}
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ── Mobile cards ──────────────────────────────────────────────────────────

function MobileCards({ isInView, reduceMotion }: { isInView: boolean; reduceMotion: boolean }) {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
      {SERVICES.map((svc, svcIdx) => (
        <motion.div
          key={svc.key}
          initial={reduceMotion ? false : { opacity: 0, y: 20 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
          transition={{
            duration: reduceMotion ? 0 : 0.4,
            delay: reduceMotion ? 0 : svcIdx * 0.08,
            ease: "easeOut",
          }}
          className="rounded-2xl border border-primary/10 bg-white p-5"
        >
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-surface-purple">
              <MaterialSymbol name={svc.icon} className="text-primary text-xl" />
            </div>
            <div>
              <p className="font-semibold text-primary-dark text-sm">
                {svc.label}
              </p>
              <p className="text-xs text-primary-dark/50">
                {svc.price}
              </p>
            </div>
          </div>
          <ul className="space-y-2.5">
            {FEATURES.map((feat) => {
              const supported = feat.supported.includes(svc.key);
              return (
                <li
                  key={feat.label}
                  className="flex items-center gap-2 text-sm"
                >
                  {supported ? <CheckCell /> : <DashCell />}
                  <span
                    className={
                      supported
                        ? "text-primary-dark"
                        : "text-primary-dark/40"
                    }
                  >
                    {feat.label}
                  </span>
                </li>
              );
            })}
          </ul>
        </motion.div>
      ))}
    </div>
  );
}

// ── Main component ────────────────────────────────────────────────────────

export function ServiceComparisonTable({ className = "" }: { className?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const isInView = useInView(ref, { once: true, margin: "-80px" });
  const shouldReduceMotion = useReducedMotion();

  return (
    <section ref={ref} className={`py-16 bg-white ${className}`}>
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <div className="text-center mb-10">
          <span className="text-primary font-bold tracking-widest uppercase text-xs block mb-3">
            Compare Services
          </span>
          <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark leading-tight">
            Find the Right Fit for Your Pet
          </h2>
          <p className="text-primary-dark/60 max-w-2xl mx-auto mt-3">
            See which services include the features you care about most - at a glance.
          </p>
        </div>

        {/* Desktop: table (hidden on mobile) */}
        <div className="hidden lg:block">
          <DesktopTable isInView={isInView} reduceMotion={!!shouldReduceMotion} />
        </div>

        {/* Mobile/Tablet: cards (hidden on desktop) */}
        <div className="block lg:hidden">
          <MobileCards isInView={isInView} reduceMotion={!!shouldReduceMotion} />
        </div>
      </div>
    </section>
  );
}
