"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import Link from "next/link";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  ChatCircleDots,
  WhatsappLogo,
  ArrowUp,
  X,
} from "@phosphor-icons/react/dist/ssr";
import { businessInfo } from "@/lib/business-info";
import { whatsappFab } from "@/lib/site";

// ── Chat types & data ─────────────────────────────────────────────────────

interface ChatMessage {
  id: string;
  role: "bot" | "user";
  text: string;
}

const WELCOME_MESSAGE: ChatMessage = {
  id: "welcome",
  role: "bot",
  text: "Hi! I\u2019m the Waggies assistant. I can help you with information about our services, booking, and pet care. How can I help?",
};

// ── Bot response logic (preserved from chatbot-widget.tsx) ─────────────────

function getBotResponse(input: string): string {
  const lower = input.toLowerCase().trim();

  if (/^(hi|hello|hey|good morning|good afternoon|good evening|howdy)\b/.test(lower)) {
    return "Hello! How can I help you today?";
  }
  if (/\b(boarding|board|overnight|stay|kennel)\b/.test(lower)) {
    return "We offer comfortable boarding for dogs, cats, and exotic pets in Abuja. Our suites are climate-controlled with daily playtime and feeding. Learn more on our boarding page: ";
  }
  if (/\b(groom|grooming|bath|haircut|nail|trim|wash)\b/.test(lower)) {
    return "Our professional groomers provide breed-specific treatments including baths, haircuts, nail trims, and more. We use pet-safe products. See our grooming services: ";
  }
  if (/\b(pric|cost|how much|rate|fee|estimate|quote)\b/.test(lower)) {
    return "We have a pricing tool where you can get an estimate based on your needs. You can also request a quote on our pricing page: ";
  }
  if (/\b(contact|phone|whatsapp|call|reach|number|telephone)\b/.test(lower)) {
    return `You can reach us at ${businessInfo.phoneInternational} or chat with us on WhatsApp. You can also visit our contact page for more ways to reach us: `;
  }
  if (/\b(hour|open|close|time|schedule|when|available)\b/.test(lower)) {
    return "We\u2019re open Mon-Fri 9am-5pm, Sat-Sun 10am-2pm. Boarding guests receive 24/7 supervision regardless of office hours.";
  }
  if (/\b(vet|veterinary|doctor|health|medical|check.?up|vaccin)\b/.test(lower)) {
    return "We have on-site veterinary support for routine check-ups, vaccinations, and minor treatments. For more details, visit our vet care page: ";
  }
  if (/\b(train|obedience|behavio?r|puppy|class)\b/.test(lower)) {
    return "We offer positive-reinforcement dog training for puppies and adult dogs. Check out our training page: ";
  }
  if (/\b(relocat|move|travel|flight|import|export|international|nigeria|abroad)\b/.test(lower)) {
    return "We help with international pet relocation including import, export, and document preparation. Visit our relocation page for details: ";
  }
  if (/\b(transport|pickup|drop.?off|delivery|door.?to.?door|shuttle)\b/.test(lower)) {
    return "We offer door-to-door pet transport within Abuja as part of our relocation services. Visit our transport page: ";
  }

  return "I\u2019d love to help with that! For detailed questions, please contact us directly at +234 908 081 1902 or visit our contact page.";
}

function responseNeedsLink(
  text: string
): { linkText: string; href: string } | null {
  if (text.includes("boarding page")) {
    return { linkText: "View Boarding Services", href: "/services/boarding" };
  }
  if (text.includes("grooming services")) {
    return { linkText: "View Grooming Services", href: "/services/grooming" };
  }
  if (text.includes("pricing page")) {
    return { linkText: "View Pricing", href: "/services/pricing" };
  }
  if (text.includes("contact page")) {
    return { linkText: "Contact Us", href: "/contact" };
  }
  if (text.includes("vet care page")) {
    return { linkText: "View Vet Care", href: "/services/vet-care" };
  }
  if (text.includes("training page")) {
    return { linkText: "View Training", href: "/services/training" };
  }
  if (text.includes("relocation page")) {
    return { linkText: "View Relocation", href: "/relocation" };
  }
  if (text.includes("transport page")) {
    return { linkText: "View Local Transport", href: "/services/transport" };
  }
  return null;
}

let messageCounter = 0;
function nextId(): string {
  messageCounter += 1;
  return `msg_${messageCounter}`;
}

// ── Animation variants ─────────────────────────────────────────────────────

const fabVariants = {
  hidden: { opacity: 0, scale: 0.8, y: 10 },
  visible: { opacity: 1, scale: 1, y: 0 },
  exit: { opacity: 0, scale: 0.8, y: 10 },
};

const chatPanelVariants = {
  hidden: { opacity: 0, scale: 0.95, y: 12 },
  visible: { opacity: 1, scale: 1, y: 0 },
  exit: { opacity: 0, scale: 0.95, y: 12 },
};

// ── Main component ─────────────────────────────────────────────────────────

export function FloatingActions() {
  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME_MESSAGE]);
  const [input, setInput] = useState("");
  const [showBackToTop, setShowBackToTop] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const shouldReduceMotion = useReducedMotion();

  const motionTransition = shouldReduceMotion
    ? { duration: 0 }
    : { type: "spring" as const, damping: 20, stiffness: 300 };

  // Scroll listener for back-to-top
  useEffect(() => {
    if (typeof window === "undefined") return;

    function handleScroll() {
      setShowBackToTop(window.scrollY > 400);
    }

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (shouldReduceMotion) {
      messagesEndRef.current?.scrollIntoView({ behavior: "auto" });
    } else {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, shouldReduceMotion]);

  // Focus input when chat opens
  useEffect(() => {
    if (chatOpen) {
      const t = setTimeout(() => inputRef.current?.focus(), 100);
      return () => clearTimeout(t);
    }
  }, [chatOpen]);

  // Escape key to close chat
  useEffect(() => {
    if (!chatOpen) return;

    function handleKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        setChatOpen(false);
      }
    }

    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [chatOpen]);

  const scrollToTop = useCallback(() => {
    if (typeof window === "undefined") return;
    window.scrollTo({ top: 0, behavior: shouldReduceMotion ? "auto" : "smooth" });
  }, [shouldReduceMotion]);

  function handleSend() {
    const text = input.trim();
    if (!text) return;

    const userMsg: ChatMessage = { id: nextId(), role: "user", text };
    const botResponse = getBotResponse(text);
    const botMsg: ChatMessage = { id: nextId(), role: "bot", text: botResponse };

    setMessages((prev) => [...prev, userMsg, botMsg]);
    setInput("");
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  return (
    <>
      {/* ── Chat panel (z-46, rendered above the button column) ── */}
      <AnimatePresence>
        {chatOpen && (
          <motion.div
            initial={shouldReduceMotion ? false : chatPanelVariants.hidden}
            animate={chatPanelVariants.visible}
            exit={shouldReduceMotion ? undefined : chatPanelVariants.exit}
            transition={motionTransition}
            className="fixed bottom-20 right-4 md:bottom-6 z-[46] flex flex-col overflow-hidden bg-white rounded-2xl shadow-xl border border-primary/10"
            style={{
              width: "min(360px, calc(100vw - 3rem))",
              height: "max(min(480px, 70dvh))",
            }}
            role="dialog"
            aria-label="Chat assistant"
            aria-modal="false"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 bg-primary shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                  <ChatCircleDots size={18} weight="fill" className="text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">
                    Waggies Assistant
                  </h3>
                  <p className="text-xs text-white/70">
                    Typically replies instantly
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setChatOpen(false)}
                aria-label="Close chat"
                className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
              >
                <X size={18} weight="bold" className="text-white" />
              </button>
            </div>

            {/* Messages area */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
              {messages.map((msg) => {
                const linkInfo =
                  msg.role === "bot" ? responseNeedsLink(msg.text) : null;
                return (
                  <div
                    key={msg.id}
                    className={`flex ${
                      msg.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                        msg.role === "user"
                          ? "bg-primary text-white rounded-br-md"
                          : "bg-surface-purple text-primary-dark rounded-bl-md"
                      }`}
                    >
                      {msg.text}
                      {linkInfo && (
                        <Link
                          href={linkInfo.href}
                          className="inline-block mt-1.5 text-xs font-semibold underline underline-offset-2 text-primary"
                        >
                          {linkInfo.linkText} &rarr;
                        </Link>
                      )}
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input area - respects safe area on iOS */}
            <div className="safe-bottom px-4 py-3 border-t border-primary/5 flex items-center gap-2 shrink-0">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type a message..."
                aria-label="Chat message"
                className="flex-1 bg-surface border border-primary/10 rounded-full px-4 py-2.5 text-sm text-primary-dark placeholder:text-primary-dark/40 focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
              <button
                type="button"
                onClick={handleSend}
                disabled={!input.trim()}
                aria-label="Send message"
                className="w-10 h-10 rounded-full bg-primary hover:bg-primary-dark text-white flex items-center justify-center transition-colors disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
              >
                <ArrowUp size={18} weight="bold" className="rotate-45" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Unified button column (z-45) ── */}
      <div
        className="fixed bottom-20 right-4 md:bottom-6 z-[45] flex flex-col items-end gap-3 safe-bottom"
        aria-label="Floating actions"
      >
        {/* Back-to-Top (top of stack) - hidden when chat is open */}
        <AnimatePresence>
          {!chatOpen && showBackToTop && (
            <motion.button
              initial={shouldReduceMotion ? false : fabVariants.hidden}
              animate={fabVariants.visible}
              exit={shouldReduceMotion ? undefined : fabVariants.exit}
              transition={motionTransition}
              onClick={scrollToTop}
              aria-label="Scroll to top"
              className="w-11 h-11 rounded-full bg-primary hover:bg-primary-dark text-primary-foreground shadow-lg hover:shadow-xl flex items-center justify-center transition-colors focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2"
            >
              <ArrowUp size={24} weight="bold" />
            </motion.button>
          )}
        </AnimatePresence>

        {/* WhatsApp FAB (middle) - hidden when chat is open */}
        <AnimatePresence>
          {!chatOpen && (
            <motion.div
              initial={shouldReduceMotion ? false : fabVariants.hidden}
              animate={fabVariants.visible}
              exit={shouldReduceMotion ? undefined : fabVariants.exit}
              transition={motionTransition}
              className="relative group"
            >
              <a
                href={whatsappFab.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={whatsappFab.tooltip}
                className="w-14 h-14 bg-[#25D366] hover:bg-[#20BD5A] rounded-full shadow-2xl flex items-center justify-center text-white transition duration-200 hover:scale-110 hover:ring-4 hover:ring-white block"
              >
                <WhatsappLogo size={28} weight="fill" />
              </a>
              {/* Tooltip */}
              <div className="absolute bottom-full right-0 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
                <div className="bg-primary-dark text-white text-xs font-semibold px-3 py-1.5 rounded-full whitespace-nowrap shadow-md">
                  {whatsappFab.tooltip}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Chatbot FAB (bottom of stack) - always visible */}
        <motion.button
          initial={false}
          animate={{ rotate: chatOpen ? 180 : 0 }}
          transition={
            shouldReduceMotion ? { duration: 0 } : { duration: 0.2 }
          }
          onClick={() => setChatOpen((v) => !v)}
          aria-label={
            chatOpen ? "Close chat assistant" : "Open chat assistant"
          }
          className="w-14 h-14 rounded-full bg-primary hover:bg-primary-dark text-primary-foreground shadow-2xl flex items-center justify-center transition-colors focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2"
        >
          {chatOpen ? (
            <X size={28} weight="bold" />
          ) : (
            <ChatCircleDots size={28} weight="fill" />
          )}
        </motion.button>
      </div>
    </>
  );
}
