/**
 * Waggies Footer — complete IA refactor.
 *
 * Structure (6-column desktop grid):
 *   Col 1: Brand (logo + tagline + compact hours + Follow Us)
 *   Col 2: Services
 *   Col 3: Company
 *   Col 4: Resources
 *   Col 5: Support
 *   Col 6: Legal
 *
 * Social icons sourced from businessInfo.socials (real URLs).
 * Uses @phosphor-icons/react for social icons.
 * No MaterialSymbol usage.
 */

import Link from "next/link";
import {
  InstagramLogo,
  FacebookLogo,
  XLogo,
  TiktokLogo,
  YoutubeLogo,
} from "@phosphor-icons/react/dist/ssr";
import { BackToTopLink } from "./back-to-top-link";
import { NewsletterForm } from "./newsletter-form";
import {
  footerCopyright,
  footerLinkColumns,
  footerTagline,
} from "@/lib/site";
import { businessInfo } from "@/lib/business-info";

/** Social links using real URLs from businessInfo. */
const SOCIALS: { label: string; href: string; icon: typeof InstagramLogo }[] = [
  { label: "Instagram", href: businessInfo.socials.instagram, icon: InstagramLogo },
  { label: "Facebook", href: businessInfo.socials.facebook, icon: FacebookLogo },
  { label: "X (Twitter)", href: businessInfo.socials.x, icon: XLogo },
  { label: "TikTok", href: businessInfo.socials.tiktok, icon: TiktokLogo },
  { label: "YouTube", href: businessInfo.socials.youtube, icon: YoutubeLogo },
];

export function Footer() {
  return (
    <footer className="bg-primary-dark border-t border-white/10 mt-auto">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 pt-12 pb-8 sm:pt-16 lg:px-8 lg:pt-20">
        {/* ── Newsletter strip ──────────────────────────────── */}
        <div className="mb-10 lg:mb-12 rounded-2xl p-6 sm:p-8 border bg-white/5 border-white/10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 items-center">
            <div>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold mb-2 text-secondary">
                Newsletter
              </h3>
              <p className="text-sm sm:text-base max-w-md text-white/70">
                Pet care tips and updates from Waggies. No spam, unsubscribe anytime.
              </p>
            </div>
            <div>
              <NewsletterForm variant="inline" theme="dark" />
            </div>
          </div>
        </div>

        {/* ── Main footer grid ──────────────────────────────── */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-6">
          {/* Column 1: Brand + compact hours + Follow Us */}
          <div className="col-span-2 space-y-5">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center">
                <svg
                  className="w-5 h-5 text-white"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  aria-hidden="true"
                >
                  <path d="M4.5 9.5a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zm15 0a1.5 1.5 0 1 1 0-3 1.5 1.5 0 0 1 0 3zM12 2C6.48 2 2 5.81 2 10.5c0 1.54.42 3 1.15 4.25L2 22l3.7-1.47A10.44 10.44 0 0 0 12 22c5.52 0 10-3.81 10-8.5S17.52 2 12 2z" />
                </svg>
              </div>
              <span className="font-serif font-bold text-white text-xl">Waggies</span>
            </Link>

            <p className="text-sm text-white/70 max-w-xs">{footerTagline}</p>

            {/* Compact hours summary */}
            <p className="text-xs text-white/50">
              <span className="font-medium text-white/60">Hours:</span>{" "}
              {businessInfo.hoursString}
            </p>

            {/* Follow Us social icons */}
            <div>
              <h4 className="text-label text-secondary mb-3">Follow Us</h4>
              <div className="flex gap-x-3">
                {SOCIALS.map((social) => {
                  const Icon = social.icon;
                  return (
                    <a
                      key={social.label}
                      href={social.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-9 h-9 rounded-full bg-white/10 border border-white/10 text-white/70 hover:bg-primary hover:text-white hover:border-primary transition-colors flex items-center justify-center"
                      aria-label={social.label}
                    >
                      <Icon className="text-lg" weight="fill" />
                    </a>
                  );
                })}
              </div>
            </div>
          </div>

          {/* Column 2: Services — footerLinkColumns[0] */}
          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Services
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[0].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                  >
                    <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Company — footerLinkColumns[1] */}
          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Company
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[1].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                  >
                    <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 4: Resources — footerLinkColumns[2] */}
          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Resources
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[2].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                  >
                    <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 5: Support — footerLinkColumns[3] */}
          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Support
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[3].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                  >
                    <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 6: Legal — footerLinkColumns[4] */}
          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Legal
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[4].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-white/60 hover:text-white transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </div>

      {/* ── Bottom bar ─────────────────────────────────────── */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs sm:text-sm/6 text-white/50">{footerCopyright}</p>
          <BackToTopLink className="text-xs sm:text-sm text-white/60 hover:text-white" />
        </div>
      </div>
    </footer>
  );
}
