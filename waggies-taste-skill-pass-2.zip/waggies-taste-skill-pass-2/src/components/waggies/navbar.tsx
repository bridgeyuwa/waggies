"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { motion, useScroll, useMotionValueEvent } from "framer-motion";
import { cn } from "@/lib/utils";
import { useFocusTrap } from "@/lib/use-focus-trap";
import { MaterialSymbol } from "./material-symbol";
import { SearchTrigger } from "./search-trigger";
import { CartButton } from "./shop/cart-button";
import {
  aboutMenuLinks,
  mobileAboutGroups,
  mobileResourcesLinks,
  mobileServicesGroups,
  mobileToolsLinks,
  resourcesMenuLinks,
  servicesMenuColumns,
  toolsMenuLinks,
  type DesktopMenuKey,
  type NavSection,
} from "@/lib/site";
import { NavFlyout } from "./nav-flyout";

/**
 * Derive the active Waggies nav-section from the current URL pathname.
 *
 * The Laravel layout passes a `nav-section` prop from each route's controller
 * (e.g. `nav-section="services"` for `/services/boarding`). In Next.js App
 * Router, the root layout cannot easily receive per-page props - so we infer
 * the section from `usePathname()`. This mirrors the Laravel site's behaviour
 * exactly: the section key controls which top-level nav item is highlighted.
 *
 * Mapping preserved verbatim from the original `nav-section=` props in
 * the Laravel blade page templates:
 *
 *   ""                       → no highlight (homepage)
 *   /services/*              → "services"
 *   /relocation/*            → "relocation"
 *   /about/*                 → "about"
 *   /blog/*                  → "blog"
 *   /guides/*                → "guides"
 *   /knowledge-base/*        → "kb"
 *   /faq                     → "" (Laravel uses nav-section="" for FAQ)
 *   /contact                 → "contact"
 *   /shop                    → "shop"
 *   /privacy-policy, etc.    → "legal"
 */
function inferNavSection(pathname: string): NavSection {
  if (pathname === "/" || pathname === "") return "";
  if (pathname.startsWith("/services")) return "services";
  if (pathname.startsWith("/relocation")) return "relocation";
  if (pathname.startsWith("/about")) return "about";
  if (pathname.startsWith("/tools")) return "tools";
  if (pathname.startsWith("/blog")) return "resources";
  if (pathname.startsWith("/guides")) return "resources";
  if (pathname.startsWith("/knowledge-base")) return "resources";
  if (pathname === "/faq") return "resources";
  if (pathname.startsWith("/shop")) return "shop";
  if (pathname.startsWith("/my-pets")) return "my-pets";
  if (pathname.startsWith("/contact")) return "contact";

  if (
    pathname.startsWith("/privacy-policy") ||
    pathname.startsWith("/terms-of-service") ||
    pathname.startsWith("/cookies-policy")
  )
    return "legal";
  return "";
}

/**
 * Waggies Navbar - faithful React reproduction of the Alpine-controlled navbar
 * in resources/views/components/navbar.blade.php.
 *
 * State machine (mirrors the Alpine `x-data` block):
 *
 *   mobileOpen:   boolean     - mobile drawer visibility
 *   servicesOpen: boolean     - mobile accordion: Services sub-section
 *   aboutOpen:    boolean     - mobile accordion: About sub-section
 *   resourcesOpen:boolean     - mobile accordion: Resources sub-section
 *   activeMenu:   key | null  - which desktop flyout panel is currently shown
 *   pinnedMenu:   key | null  - which desktop flyout is "pinned" open by click
 *
 * Hover timing:
 *   - scheduleOpen(menu)  waits 150ms before activating the menu, unless a
 *     different menu is pinned (in which case the hover is suppressed).
 *   - scheduleClose(menu) waits 150ms before closing, unless the menu is
 *     pinned.
 *   - Any new schedule cancels the previous timer.
 *
 * Click behavior (togglePin):
 *   - Clicking a trigger button toggles the pinned state of that menu.
 *   - If pinned == clicked, unpin and close.
 *   - Otherwise pin and activate the clicked menu.
 *
 * Keyboard:
 *   - Escape: closes mobile drawer first; if mobile is closed, closes desktop
 *     menus and restores focus to the trigger of the closed menu.
 *   - ArrowDown on a trigger: opens the menu and focuses the first menuitem.
 *   - ArrowUp/Down inside the Services panel: cycles focus among menuitems.
 *     (The Laravel source only wires this for the services panel - preserved.)
 *
 * Click-outside:
 *   - Clicks anywhere outside the desktop <ul> close desktop menus.
 *   - Clicks on the mobile overlay close the mobile drawer.
 *
 * Body scroll lock:
 *   - While the mobile drawer is open, body.overflow is set to hidden.
 *
 * Focus trap:
 *   - While the mobile drawer is open, Tab/Shift-Tab cycles within it; the
 *     previously-focused element is restored on close.
 */
export function Navbar({ navSection }: { navSection?: NavSection } = {}) {
  const pathname = usePathname();
  // Per-page prop wins; otherwise infer from the URL (matches Laravel's
  // `nav-section=` prop on each Blade page).
  const section = navSection ?? inferNavSection(pathname);
  const servicesActive = section === "services" || section === "relocation";
  const toolsActive = section === "tools";
  const resourcesActive = section === "resources";
  const aboutActive = section === "about";
  const shopActive = section === "shop";
  const myPetsActive = section === "my-pets";

  // --- Alpine state ------------------------------------------------------
  const [mobileOpen, setMobileOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [resourcesOpen, setResourcesOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [activeMenu, setActiveMenu] = useState<DesktopMenuKey | null>(null);
  const [pinnedMenu, setPinnedMenu] = useState<DesktopMenuKey | null>(null);

  // --- Scroll-based navbar style ------------------------------------------
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();
  useMotionValueEvent(scrollY, "change", (latest) => {
    setScrolled(latest > 40);
  });

  // --- Refs --------------------------------------------------------------
  const hoverTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const navRootRef = useRef<HTMLDivElement | null>(null);
  const desktopUlRef = useRef<HTMLUListElement | null>(null);
  const servicesTriggerRef = useRef<HTMLButtonElement | null>(null);
  const aboutTriggerRef = useRef<HTMLButtonElement | null>(null);
  const resourcesTriggerRef = useRef<HTMLButtonElement | null>(null);
  const toolsTriggerRef = useRef<HTMLButtonElement | null>(null);
  const servicesPanelRef = useRef<HTMLDivElement | null>(null);
  const aboutPanelRef = useRef<HTMLDivElement | null>(null);
  const resourcesPanelRef = useRef<HTMLDivElement | null>(null);
  const toolsPanelRef = useRef<HTMLDivElement | null>(null);

  // Mobile drawer focus trap (matches Alpine x-trap="mobileOpen").
  const mobileDrawerRef = useFocusTrap<HTMLDivElement>(mobileOpen);

  // --- Alpine method equivalents ----------------------------------------

  const clearHoverTimer = useCallback(() => {
    if (hoverTimerRef.current !== null) {
      clearTimeout(hoverTimerRef.current);
      hoverTimerRef.current = null;
    }
  }, []);

  const scheduleOpen = useCallback(
    (menu: DesktopMenuKey) => {
      clearHoverTimer();
      hoverTimerRef.current = setTimeout(() => {
        setPinnedMenu((current) => {
          // Suppress hover activation when a different menu is pinned.
          if (current && current !== menu) return current;
          setActiveMenu(menu);
          return current;
        });
      }, 150);
    },
    [clearHoverTimer],
  );

  const scheduleClose = useCallback(
    (menu: DesktopMenuKey) => {
      clearHoverTimer();
      hoverTimerRef.current = setTimeout(() => {
        setPinnedMenu((pinned) => {
          if (pinned === menu) return pinned; // pinned menus stay open
          setActiveMenu((active) => (active === menu ? null : active));
          return pinned;
        });
      }, 150);
    },
    [clearHoverTimer],
  );

  const togglePin = useCallback(
    (menu: DesktopMenuKey) => {
      clearHoverTimer();
      setPinnedMenu((current) => {
        if (current === menu) {
          // Unpin and close.
          setActiveMenu(null);
          return null;
        }
        setActiveMenu(menu);
        return menu;
      });
    },
    [clearHoverTimer],
  );

  const closeDesktopMenus = useCallback(() => {
    clearHoverTimer();
    setPinnedMenu(null);
    setActiveMenu(null);
  }, [clearHoverTimer]);

  const focusFirstMenuItem = useCallback(
    (menu: DesktopMenuKey) => {
      setActiveMenu(menu);
      requestAnimationFrame(() => {
        const panelRef =
          menu === "services"
            ? servicesPanelRef.current
            : menu === "about"
              ? aboutPanelRef.current
              : menu === "tools"
                ? toolsPanelRef.current
                : resourcesPanelRef.current;
        panelRef?.querySelector<HTMLElement>("[role=menuitem]")?.focus();
      });
    },
    [],
  );

  /**
   * Reproduces `focusMenuItem(direction)` from the Alpine source - which is
   * hard-wired to scan the Services panel only (it only fires from
   * @keydown.arrow-down/up on servicesPanel). We preserve that scope.
   */
  const focusMenuItem = useCallback((direction: 1 | -1) => {
    const panel = servicesPanelRef.current;
    if (!panel) return;
    const items = Array.from(panel.querySelectorAll<HTMLElement>("[role=menuitem]"));
    if (items.length === 0) return;
    const idx = items.indexOf(document.activeElement as HTMLElement);
    let next = idx + direction;
    if (next < 0) next = items.length - 1;
    if (next >= items.length) next = 0;
    items[next]?.focus();
  }, []);

  // --- Body scroll lock + Escape handling (x-effect + @keydown.escape) --

  useEffect(() => {
    if (typeof document === "undefined") return;
    // x-effect="document.body.classList.toggle('overflow-hidden', mobileOpen)"
    document.body.classList.toggle("overflow-hidden", mobileOpen);
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [mobileOpen]);

  useEffect(() => {
    const handleKeydown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      if (mobileOpen) {
        setMobileOpen(false);
      } else if (activeMenu !== null) {
        closeDesktopMenus();
        // Restore focus to the trigger of the closed menu (matches Alpine
        // @keydown.escape.prevent on the panel: closeDesktopMenus();
        // $refs.servicesTrigger?.focus()).
        const triggerRef =
          activeMenu === "services"
            ? servicesTriggerRef.current
            : activeMenu === "about"
              ? aboutTriggerRef.current
              : activeMenu === "tools"
                ? toolsTriggerRef.current
                : resourcesTriggerRef.current;
        triggerRef?.focus();
      }
    };
    window.addEventListener("keydown", handleKeydown);
    return () => window.removeEventListener("keydown", handleKeydown);
  }, [mobileOpen, activeMenu, closeDesktopMenus]);

  // --- Click-outside for desktop menus (@click.outside on <ul>) ---------

  useEffect(() => {
    if (activeMenu === null && pinnedMenu === null) return;
    const handleClick = (event: MouseEvent) => {
      const ul = desktopUlRef.current;
      if (!ul) return;
      if (ul.contains(event.target as Node)) return;
      closeDesktopMenus();
    };
    // Defer one tick so the click that opened the menu doesn't immediately
    // close it.
    const id = setTimeout(() => {
      document.addEventListener("click", handleClick);
    }, 0);
    return () => {
      clearTimeout(id);
      document.removeEventListener("click", handleClick);
    };
  }, [activeMenu, pinnedMenu, closeDesktopMenus]);

  // --- Helpers for trigger button classes (preserve Blade ternaries) ---

  const triggerClass = (isActive: boolean) =>
    cn(
      "flex items-center gap-1 px-4 py-2 text-sm font-medium uppercase tracking-wide rounded-lg transition-colors",
      isActive
        ? "text-primary font-semibold bg-surface-purple"
        : "text-primary-dark/60 hover:text-primary hover:bg-surface-purple",
    );

  const caretClass = (menu: DesktopMenuKey) =>
    cn(
      "material-symbols-outlined text-sm transition-transform duration-200",
      activeMenu === menu && "rotate-180",
    );

  return (
    <div className="contents" ref={navRootRef}>
      {/* ── Desktop header (sticky) ─────────────────────────────────────── */}
      <motion.header
        className={cn(
          "sticky top-0 z-50 w-full overflow-visible transition-all duration-300",
          scrolled
            ? "bg-white/90 backdrop-blur-lg border-b border-surface-purple/60 shadow-[0_2px_20px_rgba(107,44,145,0.06)] supports-[backdrop-filter]:bg-white/85"
            : "bg-white/60 backdrop-blur-sm border-b border-transparent shadow-none supports-[backdrop-filter]:bg-white/50",
        )}
        initial={false}
        animate={{ opacity: 1 }}
      >
        <nav
          className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 h-16 flex items-center justify-between overflow-visible"
          aria-label="Main navigation"
        >
          {/* Logo */}
          <Link
            href="/"
            className="flex items-center gap-2 shrink-0"
            aria-label="Waggies - home"
          >
            <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center shadow-sm">
              <MaterialSymbol name="pets" filled className="text-white text-lg" />
            </div>
            <span className="font-serif text-xl font-bold text-primary-dark tracking-tight">
              Waggies
            </span>
          </Link>

          {/* Desktop nav */}
          <ul
            ref={desktopUlRef}
            className="hidden lg:flex items-center gap-1 overflow-visible"
            role="list"
          >
            {/* Services mega-menu */}
            <li
              className="relative overflow-visible"
              onMouseEnter={() => scheduleOpen("services")}
              onMouseLeave={() => scheduleClose("services")}
            >
              <button
                ref={servicesTriggerRef}
                type="button"
                aria-haspopup="true"
                aria-expanded={activeMenu === "services"}
                onClick={(e) => {
                  e.preventDefault();
                  togglePin("services");
                }}
                onKeyDown={(e) => {
                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    focusFirstMenuItem("services");
                  }
                }}
                className={triggerClass(servicesActive)}
                {...(servicesActive ? { "aria-current": "page" as const } : {})}
              >
                Services
                <span className={caretClass("services")}>expand_more</span>
              </button>
              <div
                ref={servicesPanelRef}
                role="menu"
                aria-label="Services menu"
                className={cn(
                  "nav-dropdown nav-dropdown--services absolute top-full mt-1 left-1/2 -translate-x-1/2 transition ease-out duration-150",
                  activeMenu === "services"
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 -translate-y-1 pointer-events-none",
                )}
                style={{ display: activeMenu === "services" ? "block" : "none" }}
                onKeyDown={(e) => {
                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    focusMenuItem(1);
                  } else if (e.key === "ArrowUp") {
                    e.preventDefault();
                    focusMenuItem(-1);
                  } else if (e.key === "Escape") {
                    e.preventDefault();
                    closeDesktopMenus();
                    servicesTriggerRef.current?.focus();
                  }
                }}
              >
                <div className="bg-gradient-to-r from-primary-dark to-primary px-5 py-2.5">
                  <p className="text-white/80 text-xs font-bold uppercase tracking-widest">
                    Our Services
                  </p>
                </div>
                <div className="nav-dropdown__columns nav-dropdown__columns--services">
                  {servicesMenuColumns.map((column) => (
                    <div key={column.groupLabel} role="group" aria-label={column.groupLabel}>
                      <p className="text-xs font-bold uppercase tracking-widest text-primary/60 mb-2 px-2">
                        {column.groupLabel}
                      </p>
                      <div className="flex flex-col gap-0.5">
                        {column.links.map((link) => (
                          <MegaLink
                            key={link.href}
                            href={link.href}
                            icon={link.icon}
                            title={link.title}
                            subtitle={link.subtitle}
                          />
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </li>

            {/* Tools */}
            <li
              className="relative overflow-visible"
              onMouseEnter={() => scheduleOpen("tools")}
              onMouseLeave={() => scheduleClose("tools")}
            >
              <button
                ref={toolsTriggerRef}
                type="button"
                aria-haspopup="true"
                aria-expanded={activeMenu === "tools"}
                onClick={(e) => {
                  e.preventDefault();
                  togglePin("tools");
                }}
                className={triggerClass(toolsActive)}
                {...(toolsActive ? { "aria-current": "page" as const } : {})}
              >
                Tools
                <span className={caretClass("tools")}>expand_more</span>
              </button>
              <NavFlyout
                links={toolsMenuLinks}
                isOpen={activeMenu === "tools"}
                onClose={closeDesktopMenus}
                triggerRef={toolsTriggerRef}
                panelRef={toolsPanelRef}
                align="left"
                label="Pet Care Tools"
              />
            </li>

            {/* Resources */}
            <li
              className="relative overflow-visible"
              onMouseEnter={() => scheduleOpen("resources")}
              onMouseLeave={() => scheduleClose("resources")}
            >
              <button
                ref={resourcesTriggerRef}
                type="button"
                aria-haspopup="true"
                aria-expanded={activeMenu === "resources"}
                onClick={(e) => {
                  e.preventDefault();
                  togglePin("resources");
                }}
                className={triggerClass(resourcesActive)}
                {...(resourcesActive ? { "aria-current": "page" as const } : {})}
              >
                Resources
                <span className={caretClass("resources")}>expand_more</span>
              </button>
              <NavFlyout
                links={resourcesMenuLinks}
                isOpen={activeMenu === "resources"}
                onClose={closeDesktopMenus}
                triggerRef={resourcesTriggerRef}
                panelRef={resourcesPanelRef}
                align="right"
                label="Resources"
              />
            </li>

            {/* About */}
            <li
              className="relative overflow-visible"
              onMouseEnter={() => scheduleOpen("about")}
              onMouseLeave={() => scheduleClose("about")}
            >
              <button
                ref={aboutTriggerRef}
                type="button"
                aria-haspopup="true"
                aria-expanded={activeMenu === "about"}
                onClick={(e) => {
                  e.preventDefault();
                  togglePin("about");
                }}
                className={triggerClass(aboutActive)}
                {...(aboutActive ? { "aria-current": "page" as const } : {})}
              >
                About
                <span className={caretClass("about")}>expand_more</span>
              </button>
              <NavFlyout
                links={aboutMenuLinks}
                isOpen={activeMenu === "about"}
                onClose={closeDesktopMenus}
                triggerRef={aboutTriggerRef}
                panelRef={aboutPanelRef}
                align="right"
                label="About Waggies"
              />
            </li>

            {/* Shop - plain link, no flyout */}
            <li>
              <Link
                href="/shop"
                className={cn(
                  "flex items-center gap-1 px-4 py-2 text-sm font-medium uppercase tracking-wide rounded-lg transition-colors",
                  shopActive
                    ? "text-primary font-semibold bg-surface-purple"
                    : "text-primary-dark/60 hover:text-primary hover:bg-surface-purple",
                )}
                {...(shopActive ? { "aria-current": "page" as const } : {})}
              >
                Shop
              </Link>
            </li>

            {/* My Pets - plain link, no flyout */}
            <li>
              <Link
                href="/my-pets"
                className={cn(
                  "flex items-center gap-1 px-4 py-2 text-sm font-medium uppercase tracking-wide rounded-lg transition-colors",
                  myPetsActive
                    ? "text-primary font-semibold bg-surface-purple"
                    : "text-primary-dark/60 hover:text-primary hover:bg-surface-purple",
                )}
                {...(myPetsActive ? { "aria-current": "page" as const } : {})}
              >
                My Pets
              </Link>
            </li>
          </ul>

          {/* Desktop CTA + Hamburger */}
          <div className="flex items-center gap-3">
            <div className="hidden lg:flex items-center gap-2">
              <CartButton />
              <SearchTrigger />
            </div>
            <Link
              href="/contact"
              className="hidden lg:flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-2.5 rounded-full text-sm font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
            >
              Get a Quote
              <MaterialSymbol name="arrow_forward" className="text-base" />
            </Link>

            <button
              type="button"
              onClick={() => setMobileOpen((v) => !v)}
              aria-expanded={mobileOpen}
              aria-label={mobileOpen ? "Close navigation menu" : "Open navigation menu"}
              aria-controls="mobile-menu"
              className="lg:hidden flex flex-col gap-[5px] p-2 rounded-lg hover:bg-surface-purple transition-colors"
            >
              <span
                className={cn(
                  "block w-5 h-0.5 bg-primary-dark rounded-full transition-all duration-300 origin-center",
                  mobileOpen && "translate-y-[7px] rotate-45",
                )}
                aria-hidden="true"
              />
              <span
                className={cn(
                  "block w-5 h-0.5 bg-primary-dark rounded-full transition-all duration-300",
                  mobileOpen && "opacity-0",
                )}
                aria-hidden="true"
              />
              <span
                className={cn(
                  "block w-5 h-0.5 bg-primary-dark rounded-full transition-all duration-300 origin-center",
                  mobileOpen && "-translate-y-[7px] -rotate-45",
                )}
                aria-hidden="true"
              />
            </button>
          </div>
        </nav>
      </motion.header>

      {/* ── Mobile overlay ─────────────────────────────────────────────── */}
      <div
        className={cn(
          "fixed inset-0 bg-primary-dark/40 backdrop-blur-sm z-40 lg:hidden transition duration-300",
          mobileOpen ? "opacity-100" : "opacity-0 pointer-events-none",
        )}
        onClick={() => setMobileOpen(false)}
        aria-hidden="true"
      />

      {/* ── Mobile menu ───────────────────────────────────────────────── */}
      <aside
        id="mobile-menu"
        ref={mobileDrawerRef}
        role="navigation"
        aria-label="Main navigation"
        tabIndex={-1}
        className={cn(
          "fixed top-0 right-0 h-full w-80 max-w-[90vw] bg-white z-50 shadow-2xl flex flex-col lg:hidden transition-transform duration-300 ease-out",
          mobileOpen ? "translate-x-0" : "translate-x-full",
        )}
        aria-hidden={!mobileOpen}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-surface-purple">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
              <MaterialSymbol name="pets" filled className="text-white text-base" />
            </div>
            <span className="font-serif text-lg font-bold text-primary-dark">Waggies</span>
          </div>
          <button
            type="button"
            onClick={() => setMobileOpen(false)}
            aria-label="Close navigation menu"
            className="p-2 rounded-lg hover:bg-surface-purple transition-colors"
          >
            <MaterialSymbol name="close" className="text-primary-dark" />
          </button>
        </div>

        <nav
          className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-1"
          aria-label="Mobile navigation links"
        >
          {/* Search trigger (top row) - opens the global command palette */}
          <div className="mb-2">
            <SearchTrigger
              variant="row"
              onOpen={() => setMobileOpen(false)}
            />
          </div>

          {/* Services accordion */}
          <div>
            <button
              type="button"
              onClick={() => setServicesOpen((v) => !v)}
              aria-expanded={servicesOpen}
              aria-controls="mobile-services-submenu"
              className="w-full flex items-center justify-between px-3 py-3 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-xl transition-colors"
            >
              Services
              <MaterialSymbol
                name="expand_more"
                className={cn(
                  "text-sm transition-transform duration-200",
                  servicesOpen && "rotate-180",
                )}
              />
            </button>
            <div
              id="mobile-services-submenu"
              className={cn(
                "pl-3 pb-1 transition duration-200 ease-out overflow-hidden",
                servicesOpen ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
              )}
            >
              {mobileServicesGroups.map((group) => (
                <MobileGroup key={group.heading} heading={group.heading}>
                  {group.links.map((link) => (
                    <MobileLinkRow
                      key={link.href}
                      href={link.href}
                      label={link.label}
                      onNavigate={() => setMobileOpen(false)}
                    />
                  ))}
                </MobileGroup>
              ))}
            </div>
          </div>

          {/* Tools accordion */}
          <div>
            <button
              type="button"
              onClick={() => setToolsOpen((v) => !v)}
              aria-expanded={toolsOpen}
              aria-controls="mobile-tools-submenu"
              className="w-full flex items-center justify-between px-3 py-3 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-xl transition-colors"
            >
              Tools
              <MaterialSymbol
                name="expand_more"
                className={cn(
                  "text-sm transition-transform duration-200",
                  toolsOpen && "rotate-180",
                )}
              />
            </button>
            <div
              id="mobile-tools-submenu"
              className={cn(
                "pl-3 transition duration-200 ease-out overflow-hidden",
                toolsOpen ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
              )}
            >
              <div className="flex flex-col gap-0.5 py-1">
                {mobileToolsLinks.map((link) => (
                  <MobileLinkRow
                    key={link.href}
                    href={link.href}
                    label={link.label}
                    onNavigate={() => setMobileOpen(false)}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Resources accordion */}
          <div>
            <button
              type="button"
              onClick={() => setResourcesOpen((v) => !v)}
              aria-expanded={resourcesOpen}
              aria-controls="mobile-resources-submenu"
              className="w-full flex items-center justify-between px-3 py-3 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-xl transition-colors"
            >
              Resources
              <MaterialSymbol
                name="expand_more"
                className={cn(
                  "text-sm transition-transform duration-200",
                  resourcesOpen && "rotate-180",
                )}
              />
            </button>
            <div
              id="mobile-resources-submenu"
              className={cn(
                "pl-3 transition duration-200 ease-out overflow-hidden",
                resourcesOpen ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
              )}
            >
              <div className="flex flex-col gap-0.5 py-1">
                {mobileResourcesLinks.map((link) => (
                  <MobileLinkRow
                    key={link.href}
                    href={link.href}
                    label={link.label}
                    onNavigate={() => setMobileOpen(false)}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* About accordion */}
          <div>
            <button
              type="button"
              onClick={() => setAboutOpen((v) => !v)}
              aria-expanded={aboutOpen}
              aria-controls="mobile-about-submenu"
              className="w-full flex items-center justify-between px-3 py-3 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-xl transition-colors"
            >
              About
              <MaterialSymbol
                name="expand_more"
                className={cn(
                  "text-sm transition-transform duration-200",
                  aboutOpen && "rotate-180",
                )}
              />
            </button>
            <div
              id="mobile-about-submenu"
              className={cn(
                "pl-3 pb-1 transition duration-200 ease-out overflow-hidden",
                aboutOpen ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
              )}
            >
              {mobileAboutGroups.map((group) => (
                <MobileGroup key={group.heading} heading={group.heading}>
                  {group.links.map((link) => (
                    <MobileLinkRow
                      key={link.href}
                      href={link.href}
                      label={link.label}
                      onNavigate={() => setMobileOpen(false)}
                    />
                  ))}
                </MobileGroup>
              ))}
            </div>
          </div>

          {/* Shop - plain link */}
          <MobileLinkRow
            href="/shop"
            label="Shop"
            onNavigate={() => setMobileOpen(false)}
          />

          {/* My Pets - plain link */}
          <MobileLinkRow
            href="/my-pets"
            label="My Pets"
            onNavigate={() => setMobileOpen(false)}
          />

        </nav>

        <div className="px-4 py-4 border-t border-surface-purple space-y-3">
          <Link
            href="/contact"
            onClick={() => setMobileOpen(false)}
            className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-white py-3 rounded-full font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
          >
            Get a Quote
            <MaterialSymbol name="arrow_forward" className="text-base" />
          </Link>
        </div>
      </aside>
    </div>
  );
}

/**
 * Desktop flyout link row. Mirrors x-navbar.mega-link Blade component.
 */
function MegaLink({
  href,
  icon,
  title,
  subtitle,
}: {
  href: string;
  icon: string;
  title: string;
  subtitle: string;
}) {
  return (
    <Link
      href={href}
      role="menuitem"
      tabIndex={-1}
      className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-surface-purple transition-colors group"
    >
      <div className="w-8 h-8 rounded-lg bg-surface-purple group-hover:bg-primary group-hover:text-white flex items-center justify-center text-primary transition-colors shrink-0">
        <MaterialSymbol name={icon} className="text-base" />
      </div>
      <div>
        <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors leading-snug">
          {title}
        </p>
        {subtitle ? (
          <p className="text-xs text-primary-dark/50 leading-snug mt-0.5">{subtitle}</p>
        ) : null}
      </div>
    </Link>
  );
}

/**
 * Mobile accordion group container. Mirrors x-navbar.mobile-group.
 */
function MobileGroup({
  heading,
  children,
}: {
  heading: string;
  children: React.ReactNode;
}) {
  return (
    <div role="group" aria-label={heading} className="py-2 first:pt-0">
      <p className="px-3 py-1.5 text-xs font-bold uppercase tracking-widest text-primary/60">
        {heading}
      </p>
      <div className="flex flex-col gap-0.5">{children}</div>
    </div>
  );
}

/**
 * Mobile link row. Mirrors x-navbar.mobile-link.
 *
 * The Blade component includes `@click="mobileOpen = false"` - we accept an
 * `onNavigate` callback so the parent can close the drawer.
 */
function MobileLinkRow({
  href,
  label,
  onNavigate,
}: {
  href: string;
  label: string;
  onNavigate: () => void;
}) {
  return (
    <Link
      href={href}
      onClick={onNavigate}
      className="flex items-center gap-2 px-3 py-2.5 text-sm text-primary-dark/70 hover:text-primary hover:bg-surface-purple rounded-lg transition-colors"
    >
      <span className="w-1 h-1 rounded-full bg-primary/40 shrink-0" aria-hidden="true" />
      {label}
    </Link>
  );
}
