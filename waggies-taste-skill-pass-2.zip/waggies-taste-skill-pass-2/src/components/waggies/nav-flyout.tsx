"use client";

import Link from "next/link";
import { type RefObject, useEffect } from "react";
import { cn } from "@/lib/utils";
import { type MegaLink } from "@/lib/site";
import { MaterialSymbol } from "./material-symbol";

/**
 * NavFlyout — reusable single-column stacked flyout panel.
 *
 * Used for About, Tools, and Resources desktop flyouts which share
 * an identical structure (gradient header + stacked MegaLink rows).
 */
export function NavFlyout({
  links,
  isOpen,
  onClose,
  triggerRef,
  panelRef,
  align = "left",
  label,
}: {
  links: MegaLink[];
  isOpen: boolean;
  onClose: () => void;
  triggerRef: RefObject<HTMLElement | null>;
  panelRef: RefObject<HTMLDivElement | null>;
  align?: "left" | "right";
  /** Header label shown in the gradient bar. */
  label: string;
}) {
  const ref = panelRef;

  // Escape key handling local to this panel.
  useEffect(() => {
    if (!isOpen) return;
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        triggerRef.current?.focus();
      }
    };
    const el = ref.current;
    el?.addEventListener("keydown", handleKey);
    return () => el?.removeEventListener("keydown", handleKey);
  }, [isOpen, onClose, triggerRef, ref]);

  return (
    <div
      ref={ref}
      role="menu"
      aria-label={`${label} menu`}
      className={cn(
        "nav-dropdown nav-dropdown--stacked absolute top-full mt-1 transition ease-out duration-150",
        align === "left" ? "left-1/2 -translate-x-1/2" : "right-0",
        isOpen
          ? "opacity-100 translate-y-0"
          : "opacity-0 -translate-y-1 pointer-events-none",
      )}
      style={{ display: isOpen ? "block" : "none" }}
    >
      <div className="bg-gradient-to-r from-primary-dark to-primary px-5 py-2.5">
        <p className="text-white/80 text-xs font-bold uppercase tracking-widest">
          {label}
        </p>
      </div>
      <div className="p-3 flex flex-col gap-0.5">
        {links.map((link) => (
          <NavFlyoutLink
            key={link.href}
            href={link.href}
            icon={link.icon}
            title={link.title}
            subtitle={link.subtitle}
          />
        ))}
      </div>
    </div>
  );
}

/**
 * Single link row inside a NavFlyout panel.
 * Identical to the MegaLink sub-component in navbar.tsx.
 */
function NavFlyoutLink({
  href,
  icon,
  title,
  subtitle,
}: {
  href: string;
  icon: string;
  title: string;
  subtitle: string;
}) {
  return (
    <Link
      href={href}
      role="menuitem"
      tabIndex={-1}
      className="flex items-center gap-3 px-2 py-2 rounded-xl hover:bg-surface-purple transition-colors group"
    >
      <div className="w-8 h-8 rounded-lg bg-surface-purple group-hover:bg-primary group-hover:text-white flex items-center justify-center text-primary transition-colors shrink-0">
        <MaterialSymbol name={icon} className="text-base" />
      </div>
      <div>
        <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors leading-snug">
          {title}
        </p>
        {subtitle ? (
          <p className="text-xs text-primary-dark/50 leading-snug mt-0.5">
            {subtitle}
          </p>
        ) : null}
      </div>
    </Link>
  );
}
