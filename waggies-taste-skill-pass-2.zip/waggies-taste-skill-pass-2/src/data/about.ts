/**
 * About page content.
 *
 * Team data, stats, philosophy, story, and HQ contact information.
 * Address, phone, email, and hours are sourced from business-info.ts
 * to avoid duplication.
 */

import { businessInfo } from '@/lib/business-info';

// ── Hero ──────────────────────────────────────────────────────────────────

export type AboutHero = {
  title: string;
  subtitle: string;
  primaryCta: { label: string; href: string };
  secondaryCta: { label: string; href: string };
  imageSrc: string;
};

export const aboutHero: AboutHero = {
  title: "Complete Veterinary & Pet Care in Abuja",
  subtitle:
    "Vet care, boarding, grooming, training, and relocation - all in one place.",
  primaryCta: { label: "Book a Free Consultation", href: "/contact" },
  secondaryCta: { label: "Explore Services", href: "/services" },
  /* TODO(client): Replace with authoritative Waggies facility photo */
  imageSrc: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=1200&h=600&fit=crop&q=80",
} as const;

// ── Stats band (4) ────────────────────────────────────────────────────────

export type AboutStat = { value: string; label: string };

export const aboutStats: AboutStat[] = [
  { value: "500+", label: "Clients Served" },
  { value: "24/7", label: "Concierge Vet Care" },
  { value: "15+", label: "Global Specialists" },
  { value: "100%", label: "Protocol-Based Handling" },
];

// ── Philosophy section ────────────────────────────────────────────────────

export type AboutPhilosophyFeature = {
  icon: string;
  title: string;
  description: string;
};

export type AboutPhilosophy = {
  eyebrow: string;
  title: string;
  body: string[];
  features: AboutPhilosophyFeature[];
};

export const aboutPhilosophy: AboutPhilosophy = {
  eyebrow: "Our Philosophy",
  title: "Pet Care Standards in West Africa",
  body: [
    "Founded to bridge the gap in dedicated pet services, Waggies has grown into Abuja's most comprehensive pet care centre. We believe thorough, consistent care matters.",
    "Our facility combines proper medical equipment with comfortable, clean spaces. Whether it is a routine check-up, a grooming session, or international relocation, we handle every detail with care and precision.",
    "Pet Care Should Never Be Reactive: We believe animals benefit from the same structure and planning as human healthcare - not rushed decisions, not inconsistent handling, but deliberate care built around long-term wellbeing."
  ],
  features: [
    {
      icon: "diamond",
      title: "High Standards",
      description: "Climate-controlled suites & quality amenities.",
    },
    {
      icon: "public",
      title: "Global Mobility",
      description: "Experienced in straightforward international pet travel.",
    },
    {
      icon: "verified_user",
      title: "Expert Supervision",
      // TODO(client): verify specific qualification credentials
      description: "Veterinary staff on site during all operating hours.",
    },
    {
      icon: "schedule",
      title: "24/7 Concierge Care",
      description: "We never sleep so they can.",
    },
  ],
};

// ── Image mosaic (2 images) ───────────────────────────────────────────────

export type AboutMosaicImage = {
  src: string;
  alt: string;
  wrapperClass: string;
  imgClass: string;
};

export const aboutMosaicImages: AboutMosaicImage[] = [
  {
    /* TODO(client): Replace with authoritative Waggies clinic interior photo */
    src: "" as string,
    alt: "Waggies clinic interior [image required from client]",
    wrapperClass: "img-zoom-wrap rounded-2xl shadow-sm hover:shadow-soft transition mt-8",
    imgClass: "w-full h-64 object-cover rounded-2xl",
  },
  {
    /* TODO(client): Replace with authoritative Waggies grooming session photo */
    src: "" as string,
    alt: "Waggies grooming session [image required from client]",
    wrapperClass: "img-zoom-wrap rounded-2xl shadow-sm hover:shadow-soft transition",
    imgClass: "w-full h-64 object-cover rounded-2xl",
  },
];

// ── Our Story section ─────────────────────────────────────────────────────

export type AboutStoryStat = { value: string; label: string };

export type AboutStory = {
  eyebrow: string;
  /** Raw HTML  -  Blade renders via `{!! $title !!}`. Contains <br />. */
  title: string;
  paragraphs: string[];
  stats: AboutStoryStat[];
};

export const aboutStory: AboutStory = {
  eyebrow: "Our Story",
  title: "Built by Pet Lovers,<br />for Pet Owners",
  paragraphs: [
    "Waggies was born from a personal experience  -  a pet owner in Abuja struggling to find a boarding facility that matched the standard of care they gave their own dog at home. What started as a small dog hotel has grown into Abuja's most comprehensive pet care centre.",
    "Today, we offer boarding, grooming, vet care, training, and relocation services (including local transport)  -  all under one roof, all to the same consistent standard.",
    "Every member of our team is an animal lover first. We believe the best pet care comes from genuine passion  -  not just process.",
    "Waggies began with a simple but frustrating reality - pet owners in Abuja had to choose between basic boarding facilities or expensive, fragmented services with no continuity of care. The idea was not to “start a pet business.” It was to remove the inconsistency between grooming, boarding, and veterinary handling by putting everything under one controlled system. What exists today is not a collection of separate services - but a unified care environment designed to reduce the risks created by fragmentation.",
  ],
  stats: [
    { value: "500+", label: "Happy Clients" },
    { value: "7", label: "Years in Business" },
    { value: "4.9", label: "Average Rating" },
    { value: "15+", label: "Team Members" },
  ],
};

// ── Operating Standards (feature-band) ────────────────────────────────────

export type AboutOperatingStandard = {
  icon: string;
  title: string;
  description: string;
};

export type AboutOperatingStandards = {
  eyebrow: string;
  /** Raw HTML  -  Blade renders via `{!! $title !!}`. Contains <br/> + <span>. */
  title: string;
  subtitle: string;
  features: AboutOperatingStandard[];
};

export const aboutOperatingStandards: AboutOperatingStandards = {
  eyebrow: "Operating Standards",
  title:
    'Our Standard of Handling<br/><span class="text-secondary italic">Across All Services</span>',
  subtitle:
    "Whether it is boarding, grooming, vet care, training, or relocation - our decisions follow one rule: what is best for the animal comes first.",
  features: [
    {
      icon: "volunteer_activism",
      title: "Supervised Pet-First Care",
      description:
        "Every service is designed around comfort, safety, and wellbeing  -  never convenience or speed.",
    },
    {
      icon: "sync",
      title: "Consistency Across Services",
      description:
        "Boarding, grooming, and medical care follow the same documented handling standards and staff procedures.",
    },
    {
      icon: "shield",
      title: "Controlled Safety Protocols",
      description:
        "Pets are separated by risk level, monitored during movement, and handled under strict safety procedures.",
    },
    {
      icon: "visibility",
      title: "Transparent Owner Communication",
      description:
        "Owners receive clear updates on condition, progress, and any incidents  -  with no hidden details.",
    },
  ],
};

// ── Meet the Team (team cards) ──────────────────────────────────────────

export type AboutTeamMember = {
  name: string;
  role: string;
  image: string;
  /** Verified credential (e.g. 'DVM'). Only for confirmed, credentialed staff. */
  credential?: string;
  /** Concise responsibility line, shown where useful. */
  responsibility?: string;
  /** Whether this is a placeholder (not yet a confirmed employee). */
  placeholder?: boolean;
};

export const aboutTeamMembers: AboutTeamMember[] = [
  {
    name: "Dr. Nguhemen Doose Yuwa",
    role: "Head Veterinarian & Director",
    credential: "DVM",
    responsibility: "Leads all veterinary services and oversees clinical operations at Waggies.",
    image: "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?w=400&h=533&fit=crop&crop=face",
  },
  {
    name: "Aifuwa Bob Osaze",
    role: "Director",
    responsibility: "Oversees business strategy, partnerships, and overall operations at Waggies.",
    image: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=533&fit=crop&crop=face",
  },
  {
    name: "Oghomwen Oyuki Obaseki",
    role: "Secretary",
    responsibility: "Manages administrative operations, scheduling, and client communications.",
    image: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=533&fit=crop&crop=face",
  },
  {
    name: "Chidinma Eze",
    role: "Veterinary Support / Animal Health Technician",
    placeholder: true,
    image: "https://images.unsplash.com/photo-1594824476967-48c8b964ac31?w=400&h=533&fit=crop&crop=face",
  },
  {
    name: "Amina Bello",
    role: "Grooming Specialist",
    placeholder: true,
    image: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=533&fit=crop&crop=face",
  },
  {
    name: "Emeka Okonkwo",
    role: "Boarding & Care Attendant",
    placeholder: true,
    image: "https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=400&h=533&fit=crop&crop=face",
  },
  {
    name: "Fatima Abdullahi",
    role: "Operations & Customer Care",
    placeholder: true,
    image: "https://images.unsplash.com/photo-1560250097-0b93528c311a?w=400&h=533&fit=crop&crop=face",
  },
];

// ── Team section header ───────────────────────────────────────────────────

export const aboutTeamHeading = {
  eyebrow: "Our Team",
  title: "Meet the Waggies Team",
  intro:
    "The people behind Waggies who keep your pets healthy, safe, and happy.",
} as const;

// ── HQ contact card ───────────────────────────────────────────────────────
// NOTE: Address, phone, email, hours sourced from business-info.ts.

export type AboutHqTrustBadge = { label: string };

export type AboutHqContact = {
  title: string;
  trustBadges: AboutHqTrustBadge[];
  addressFormatted: string;
  hoursGrouped: { day: string; hours: string }[];
  phoneInternational: string;
  phoneHref: string;
  email: string;
  googleMapsUrl: string;
  whatsappUrl: string;
  mapIframeSrc: string;
};

export const aboutHqContact: AboutHqContact = {
  title: "Waggies HQ",
  trustBadges: [
    { label: "4.9 Rating" },
    { label: "Certified Care" },
    { label: "Open Today" },
  ],
  addressFormatted: businessInfo.addressFormatted,
  hoursGrouped: businessInfo.hoursGrouped,
  phoneInternational: businessInfo.phoneInternational,
  phoneHref: businessInfo.phoneHref,
  email: businessInfo.email,
  googleMapsUrl: `https://maps.google.com/?q=${encodeURIComponent(businessInfo.addressFormatted)}`,
  whatsappUrl: businessInfo.whatsappUrl,
  mapIframeSrc:
    `https://maps.google.com/maps?q=${encodeURIComponent(businessInfo.addressFormatted)}&output=embed`,
};

// ── Secondary CTA ─────────────────────────────────────────────────────────

export type AboutCtaSecondary = {
  heading: string;
  body: string;
  primaryLabel: string;
  primaryHref: string;
  primaryIcon: string;
};

export const aboutCtaSecondary: AboutCtaSecondary = {
  heading: "Explore Our Pet Care Services",
  body: "From grooming to veterinary care and boarding, discover everything we offer to keep your pet healthy and happy.",
  primaryLabel: "View Services",
  primaryHref: "/services",
  primaryIcon: "arrow_forward",
} as const;
