/**
 * /about page - Waggies about page with team, philosophy, story, and contact.
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { HeroGradient } from "@/components/waggies/hero-gradient";
import { FeatureBand } from "@/components/waggies/feature-band";
import { CtaSecondary } from "@/components/waggies/cta-secondary";
import { AboutTeamCard } from "@/components/waggies/about-team-card";
import { WaggiesImage } from "@/components/waggies/waggies-image";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, aboutPageSchema } from "@/components/waggies/json-ld";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";

import {
  aboutHero,
  aboutStats,
  aboutPhilosophy,
  aboutMosaicImages,
  aboutStory,
  aboutOperatingStandards,
  aboutTeamMembers,
  aboutTeamHeading,
  aboutHqContact,
  aboutCtaSecondary,
} from "@/data/about";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Waggies is a full-service pet care centre in Abuja offering boarding, grooming, vet care, training, and relocation under one roof.",
  alternates: { canonical: "/about" },
  openGraph: {
    title: "About Waggies - Pet Care in Abuja",
    description:
      "Waggies is a full-service pet care centre in Abuja offering boarding, grooming, vet care, training, and relocation under one roof.",
    url: "/about",
  },
};

export default function AboutPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "About" }]}
      />

      <HeroGradient
        title={aboutHero.title}
        subtitle={aboutHero.subtitle}
        primaryCta={aboutHero.primaryCta}
        secondaryCta={aboutHero.secondaryCta}
        imageSrc={aboutHero.imageSrc}
      />

      {/* Stats band */}
      <section className="relative z-30 -mt-8 mx-4 sm:mx-10 max-w-[1200px] lg:mx-auto bg-white rounded-2xl shadow-soft border border-surface-purple">
        <div className="px-6 py-8 sm:px-10 grid grid-cols-2 md:grid-cols-4 gap-8 md:divide-x md:divide-primary/10">
          {aboutStats.map((stat) => (
            <div key={stat.label} className="flex flex-col items-center text-center">
              <span className="font-serif text-4xl font-bold text-primary mb-1">
                {stat.value}
              </span>
              <span className="text-label text-primary-dark/50">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Philosophy section */}
      <section className="py-20 bg-surface">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="flex flex-col lg:flex-row gap-16 lg:gap-24 items-center">
            <div className="lg:w-1/2">
              <div className="flex items-center gap-3 mb-4">
                <span className="h-px w-8 bg-primary" aria-hidden="true" />
                <p className="text-label text-primary">
                  {aboutPhilosophy.eyebrow}
                </p>
              </div>
              <h2 className="text-h2 text-primary-dark leading-tight mb-6">
                {aboutPhilosophy.title}
              </h2>
              <div className="space-y-5 text-body">
                {aboutPhilosophy.body.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>

              <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-6">
                {aboutPhilosophy.features.map((feature) => (
                  <div key={feature.title} className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-surface-purple flex items-center justify-center text-primary shrink-0">
                      <MaterialSymbol name={feature.icon} className="text-lg" />
                    </div>
                    <div>
                      <h3 className="text-h4 text-primary-dark">
                        {feature.title}
                      </h3>
                      <p className="text-body-sm mt-0.5">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Image mosaic */}
            <div className="lg:w-1/2 w-full">
              <div className="grid grid-cols-2 gap-4">
                {aboutMosaicImages.map((img, i) => (
                  <div
                    key={i}
                    className={`rounded-2xl shadow-sm hover:shadow-soft transition ${i === 0 ? "mt-8" : ""}`}
                  >
                    <WaggiesImage
                      src={img.src}
                      alt={img.alt}
                      className="w-full h-64 rounded-2xl"
                      width={400}
                      height={256}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2
                className="text-h2 text-primary-dark mb-5 leading-tight"
                dangerouslySetInnerHTML={{ __html: aboutStory.title }}
              />
              {aboutStory.paragraphs.map((p, i) => (
                <p
                  key={i}
                  className={`text-body ${
                    i < aboutStory.paragraphs.length - 1 ? "mb-4" : ""
                  }`}
                >
                  {p}
                </p>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-4">
              {aboutStory.stats.map((stat) => (
                <div key={stat.label} className="bg-surface-purple rounded-2xl p-6 text-center">
                  <span className="font-serif text-4xl font-bold text-primary block mb-1">
                    {stat.value}
                  </span>
                  <span className="text-label text-primary-dark/50">
                    {stat.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Operating Standards */}
      <section>
        <FeatureBand
          eyebrow={aboutOperatingStandards.eyebrow}
          title={aboutOperatingStandards.title}
          subtitle={aboutOperatingStandards.subtitle}
          features={aboutOperatingStandards.features}
        />
      </section>

      {/* Meet the Waggies Team */}
      <section className="py-20 bg-surface">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="text-center mb-14">
            <p className="text-label text-primary mb-3">
              {aboutTeamHeading.eyebrow}
            </p>
            <h2 className="text-h2 text-primary-dark mb-4">
              {aboutTeamHeading.title}
            </h2>
            <p className="text-body-sm max-w-lg mx-auto">
              {aboutTeamHeading.intro}
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-5 sm:gap-6">
            {aboutTeamMembers.map((member, i) => (
              <AboutTeamCard
                key={member.name}
                name={member.name}
                role={member.role}
                image={member.image}
                credential={member.credential}
                responsibility={member.responsibility}
                placeholder={member.placeholder}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Visit Us - short location reference */}
      <section className="py-16 bg-white border-t border-surface-purple">
        <div className="max-w-3xl mx-auto px-4 md:px-10 text-center">
          <h2 className="text-h3 text-primary-dark mb-3">Visit Us</h2>
          <p className="text-primary-dark/70 mb-6">
            {aboutHqContact.addressFormatted}
          </p>
          <a
            href="/contact"
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full font-semibold text-sm transition-colors"
          >
            Get Directions & Contact Details
            <MaterialSymbol name="arrow_forward" className="text-base" />
          </a>
        </div>
      </section>

      {/* Secondary CTA */}
      <section className="py-16 bg-white border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <CtaSecondary
            heading={aboutCtaSecondary.heading}
            body={aboutCtaSecondary.body}
            primaryLabel={aboutCtaSecondary.primaryLabel}
            primaryHref={aboutCtaSecondary.primaryHref}
            primaryIcon={aboutCtaSecondary.primaryIcon}
          />
        </div>
      </section>

      <BreadcrumbSchema items={[{ name: "About Us", path: "/about" }]} />
      <JsonLd
        data={aboutPageSchema(
          "About Waggies - Pet Care in Abuja",
          "Waggies is a full-service pet care centre in Abuja offering boarding, grooming, vet care, training, and relocation under one roof.",
          "/about",
        )}
      />
    </>
  );
}