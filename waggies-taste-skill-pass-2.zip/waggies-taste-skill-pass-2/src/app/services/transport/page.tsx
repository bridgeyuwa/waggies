import { ServicePageEnhanced } from "@/components/waggies/sections/service-page-enhanced";
import { transportHero } from "@/data/services";
import { getFaqsForService } from "@/data/faqs";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import {
  JsonLd,
  serviceSchema,
  faqPageSchema,
} from "@/components/waggies/json-ld";
import { ShareThisPage } from "@/components/waggies/share-this-page";

export const metadata = {
  title: "Local Transport",
  description:
    "Air-conditioned, door-to-door pet transport and pickup across Abuja by trained handlers. Part of Waggies relocation services.",
  alternates: { canonical: "/services/transport" },
  openGraph: {
    title: "Local Transport Abuja - Waggies",
    description:
      "Air-conditioned, door-to-door pet transport and pickup across Abuja by trained handlers. Part of Waggies relocation services.",
    url: "/services/transport",
  },
};

export default function TransportPage() {
  const faqs = getFaqsForService("transport");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Relocation", href: "/relocation" },
          { label: "Local Transport" },
        ]}
      />

      <ServicePageEnhanced
        title="Local Transport"
        subtitle="Air-conditioned, purpose-fitted vehicles for pet pickup and drop-off anywhere across Abuja. Part of Waggies relocation services."
        description="Whether it is a trip to Waggies for boarding or grooming, a vet visit, or an airport transfer, our trained handlers and climate-controlled vehicles ensure your pet travels safely and comfortably — door to door."
        eyebrow="Local Transport · Relocation"
        imageSrc={transportHero.imageSrc}
        imageAlt="Pet transport service at Waggies Abuja"
        ctaText="Book Transport"
        ctaHref="/contact?intent=book&service=transport"
        features={[
          "Door-to-door collection and return for all Waggies appointments",
          "Air-conditioned, climate-controlled vehicles for comfort",
          "Approved travel crates and harnesses for secure transit",
          "Drivers trained in animal handling and pet first aid",
          "Coverage across all major Abuja districts",
          "Time slots booked in advance for reliable scheduling",
          "Airport pickup and drop-off for arriving/departing pets",
          "Same-day transport for urgent vet visits",
          "GPS-tracked vehicles for real-time location updates",
          "Pet travel health certificate assistance",
          "Multi-pet transport for households with several animals",
          "Emergency transport available 24/7",
        ]}
        benefits={[
          "Trained handlers - not just drivers. Our team knows how to keep pets calm and safe during transit.",
          "Climate-controlled vehicles keep your pet comfortable in any Abuja weather - hot or rainy.",
          "GPS tracking means you always know exactly where your pet is during the journey.",
          "Approved crates and harnesses ensure your pet is safe and secure - never loose in a vehicle.",
          "We cover all major districts - Maitama, Wuse, Asokoro, Garki, Gwarinpa, and beyond.",
          "Punctual, reliable scheduling so you can plan your day around the pickup time.",
        ]}
        packages={[
          {
            name: "City Ride",
            price: "₦3,500",
            duration: "Within Abuja",
            features: [
              "Door-to-door pickup & drop-off",
              "Air-conditioned vehicle",
              "Secure crate or harness",
              "GPS tracking included",
              "SMS notification on arrival",
            ],
          },
          {
            name: "Airport Transfer",
            price: "₦8,000",
            duration: "Nnamdi Azikiwe Airport",
            popular: true,
            features: [
              "Airport pickup or drop-off",
              "Travel crate provided",
              "Health certificate assistance",
              "Flight timing coordination",
              "Real-time GPS tracking",
              "Meet & greet service",
            ],
          },
          {
            name: "Vet Transport",
            price: "₦5,000",
            duration: "Same-day available",
            features: [
              "Transport to any Abuja vet clinic",
              "Same-day urgent booking",
              "Pet first aid kit on board",
              "Handler stays with your pet",
              "Wait time included (up to 1 hr)",
              "Return trip included",
            ],
          },
        ]}
        faqItems={faqs.map((f) => ({
          question: f.question,
          answer: f.answer,
        }))}
      />

      <BreadcrumbSchema
        items={[
          { name: "Services", path: "/services" },
          { name: "Relocation", path: "/relocation" },
          { name: "Local Transport", path: "/services/transport" },
        ]}
      />

      <ShareThisPage
        variant="row"
        title="Local Transport - Waggies"
        description="Air-conditioned, door-to-door pet transport and pickup across Abuja. Part of Waggies relocation services."
      />

      <JsonLd
        data={serviceSchema(
          "Local Transport Abuja - Waggies",
          "Air-conditioned, door-to-door pet transport and pickup across Abuja. Part of Waggies relocation services.",
          "/services/transport",
        )}
      />

      <JsonLd
        data={faqPageSchema(
          faqs.map((faq) => ({
            question: faq.question,
            answer: faq.answer,
          })),
        )}
      />
    </>
  );
}
