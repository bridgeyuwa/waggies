/**
 * OG image for /services/transport. Auto-picked up by Next.js metadata
 * system - overrides the default site OG image for this route.
 */

import {
  waggiesArticleOgImage,
  WAGGIES_OG_SIZE,
  WAGGIES_OG_CONTENT_TYPE,
} from "@/lib/og-image-helpers";

export const alt = "Local Transport - Waggies";
export const size = WAGGIES_OG_SIZE;
export const contentType = WAGGIES_OG_CONTENT_TYPE;

export default async function Image() {
  return waggiesArticleOgImage({
    title: "Local Transport",
    category: "Service",
  });
}
