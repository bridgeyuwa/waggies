import type { Metadata } from "next";
import Link from "next/link";
import { WaggiesImage } from "@/components/waggies/waggies-image";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { HeroSplit } from "@/components/waggies/hero-split";
import { JsonLd, websiteSchema } from "@/components/waggies/json-ld";
import { homeHero, homeServiceCards, homeTrustFeatures, homeTestimonials } from "@/data/home";

export const metadata: Metadata = {
  title: { absolute: "Pet Boarding, Grooming & Vet Care in Abuja" },
  description:
    "Waggies provides boarding, grooming, vet care, training, relocation and local transport for pets in Abuja, Nigeria.",
  alternates: { canonical: "/" },
  openGraph: {
    title: "Waggies - Pet Care in Abuja",
    description:
      "Waggies provides boarding, grooming, vet care, training, relocation and local transport for pets in Abuja, Nigeria.",
    url: "/",
  },
};

/* ── Trust features grid ─────────────────────────────────────────────────── */
function TrustSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <h2 className="text-h2 mb-12 max-w-lg">
          Why pet owners choose Waggies
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-x-10 gap-y-8">
          {homeTrustFeatures.map((f) => (
            <div key={f.title} className="flex items-start gap-4">
              <div className="size-10 rounded-lg bg-surface-purple flex items-center justify-center text-primary shrink-0">
                <MaterialSymbol name={f.icon} className="text-xl" />
              </div>
              <div>
                <h3 className="text-h4 mb-1">{f.title}</h3>
                <p className="text-body-sm">{f.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── Testimonials ────────────────────────────────────────────────────────── */
function TestimonialsSection() {
  return (
    <section className="py-20 bg-surface-purple">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <h2 className="text-h2 mb-12 max-w-lg">
          From our clients
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {homeTestimonials.map((t) => (
            <blockquote
              key={t.authorName}
              className="bg-white rounded-xl p-6 shadow-sm"
            >
              {/* Stars */}
              <div className="flex gap-0.5 mb-4" aria-label={`${t.stars} out of 5 stars`}>
                {Array.from({ length: t.stars }).map((_, i) => (
                  <MaterialSymbol
                    key={i}
                    name="star"
                    filled
                    className="text-primary text-base"
                  />
                ))}
              </div>
              <p className="text-body-sm mb-4">{t.quote}</p>
              <footer className="flex items-center gap-3">
                <div
                  className="size-9 rounded-full bg-primary text-white flex items-center justify-center text-sm font-bold"
                  aria-hidden="true"
                >
                  {t.authorInitial}
                </div>
                <div>
                  <p className="text-sm font-semibold text-primary-dark">
                    {t.authorName}
                  </p>
                  <p className="text-meta">{t.authorSubtitle}</p>
                </div>
              </footer>
            </blockquote>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ── CTA Band ────────────────────────────────────────────────────────────── */
function CtaBand() {
  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <div className="bg-primary-dark rounded-2xl px-8 py-14 md:px-16 md:py-16 text-center">
          <h2 className="font-serif text-2xl md:text-3xl font-bold text-white mb-3">
            Ready to book?
          </h2>
          <p className="text-white/65 max-w-md mx-auto mb-8">
            Get in touch to schedule a visit, ask questions, or make a booking for your pet.
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            <Link
              href="/contact"
              className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark px-8 py-3.5 rounded-full font-bold transition-colors focus:outline-none focus:ring-2 focus:ring-secondary/60 focus:ring-offset-2 focus:ring-offset-primary-dark"
            >
              Contact Us
              <MaterialSymbol name="arrow_forward" className="text-base" />
            </Link>
            <Link
              href="/services/pricing"
              className="inline-flex items-center gap-2 border border-white/30 text-white px-8 py-3.5 rounded-full font-semibold hover:bg-white/10 transition-colors focus:outline-none focus:ring-2 focus:ring-white/40 focus:ring-offset-2 focus:ring-offset-primary-dark"
            >
              See Pricing
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ── Homepage ────────────────────────────────────────────────────────────── */
export default function HomePage() {
  return (
    <>
      {/* ═══ HERO: Editorial asymmetric split ═══ */}
      <HeroSplit
        layout="editorial"
        title={homeHero.headline}
        subtitle={homeHero.subtitle}
        imageSrc={homeHero.imageSrc}
        imageAlt={homeHero.imageAlt}
        primaryLabel={homeHero.primaryCta.label}
        primaryHref={homeHero.primaryCta.href}
        secondaryLabel={homeHero.secondaryCta.label}
        secondaryHref={homeHero.secondaryCta.href}
      />

      {/* ═══ SERVICES ═══ */}
      <section className="py-20 bg-surface">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <h2 className="text-h2 mb-12 max-w-lg">
            What we offer
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {homeServiceCards.map((card) => (
              <Link
                key={card.title}
                href={card.href}
                className="group block bg-white rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow"
              >
                <div className="relative h-44 overflow-hidden">
                  <div className="absolute inset-0 transition-transform duration-500 group-hover:scale-105">
                    <WaggiesImage
                      src={card.imageSrc}
                      alt={card.title}
                      fill
                      sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                    />
                  </div>
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-2 mb-2">
                    <MaterialSymbol
                      name={card.icon}
                      filled
                      className="text-primary text-lg"
                    />
                    <h3 className="font-serif font-bold text-primary-dark">
                      {card.title}
                    </h3>
                  </div>
                  <p className="text-body-sm">{card.description}</p>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ═══ TRUST ═══ */}
      <TrustSection />

      {/* ═══ TESTIMONIALS ═══ */}
      <TestimonialsSection />

      {/* ═══ CTA ═══ */}
      <CtaBand />

      <JsonLd data={websiteSchema()} />
    </>
  );
}
