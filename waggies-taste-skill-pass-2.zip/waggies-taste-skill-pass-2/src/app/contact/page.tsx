/**
 * /contact page — Primary location & contact hub.
 *
 * Server component that renders:
 *  1. Breadcrumb + hero
 *  2. Contact info cards (address, phone, WhatsApp, email, hours)
 *  3. Google Maps embed with directions CTA
 *  4. Contact form (client component)
 *
 * Business data sourced from business-info.ts (canonical).
 * Pricing query-param logic preserved from original.
 */

import type { Metadata } from "next";
import Link from "next/link";
import {
  MapPin,
  Phone,
  EnvelopeSimple,
  Clock,
  WhatsappLogo,
  ArrowSquareOut,
  CalendarCheck,
} from "@phosphor-icons/react/dist/ssr";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { ContactForm } from "@/components/waggies/contact-form";
import { JsonLd, contactPageSchema } from "@/components/waggies/json-ld";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { businessInfo } from "@/lib/business-info";
import { resolveServiceContext, buildPrefillMessage, estimateUrl } from "@/data/pricing";

export const metadata: Metadata = {
  title: "Contact Us — Waggies Pet Care Abuja",
  description:
    "Get in touch with Waggies Pet Services in Abuja. Book boarding, grooming, vet care, training, or relocation. Call, WhatsApp, email, or visit us.",
  alternates: { canonical: "/contact" },
  openGraph: {
    title: "Contact Waggies — Abuja Pet Care",
    description:
      "Get in touch with Waggies Pet Services in Abuja. Call, WhatsApp, email, or visit us.",
    url: "/contact",
  },
};

type ContactSearchParams = {
  intent?: string;
  service?: string;
  variant?: string;
  tier?: string;
  quantity?: string;
  summary?: string;
  message?: string;
};

const GOOGLE_MAPS_EMBED_URL =
  "https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3964.729!2d7.4913!3d9.0578!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x104e0b8f2d8e4e41%3A0x5e9c3c7a8e8f8e8f!2sWaggies%20Pet%20Services!5e0!3m2!1sen!2sng!4v1234567890";

const GOOGLE_MAPS_DIRECTIONS_URL = `https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(businessInfo.addressFormatted)}`;

export default async function ContactPage({
  searchParams,
}: {
  searchParams: Promise<ContactSearchParams>;
}) {
  const sp = await searchParams;

  const resolved = resolveServiceContext(sp.service ?? null, sp.variant ?? null);

  const context = {
    service: resolved.service,
    variant: resolved.variant ?? "",
    tier: sp.tier ?? "",
    intent: sp.intent ?? "consult",
    quantity: sp.quantity ?? "",
    summary: sp.summary ?? "",
  };

  const prefillMessage =
    sp.message && sp.message.trim() !== ""
      ? sp.message
      : buildPrefillMessage({
          service: context.service,
          variant: context.variant,
          tier: context.tier,
          intent: context.intent,
          summary: context.summary,
        });

  const hasPricingContext = Boolean(context.service || context.summary);

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Contact Us", href: "/contact" }]}
      />

      <HeroPlain
        eyebrow="Get in Touch"
        eyebrowIcon="mail"
        title="Contact Waggies"
        subtitle="Have a question, want to make a booking, or need a quote? We'd love to hear from you."
      />

      {/* ── Contact Information Cards ─────────────────────────── */}
      <section className="py-12 md:py-16 bg-white" aria-labelledby="contact-info-heading">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <h2 id="contact-info-heading" className="sr-only">Contact Information</h2>

          {/* Business Name */}
          <div className="mb-8 md:mb-10">
            <h3 className="text-h3 text-primary-dark">{businessInfo.name} Pet Services</h3>
            <p className="text-body-sm mt-1">Abuja's comprehensive pet care centre</p>
          </div>

          {/* Info Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
            {/* Address Card */}
            <div className="bg-surface rounded-xl p-5 border border-primary/5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <MapPin className="text-xl text-primary" weight="fill" aria-hidden="true" />
                </div>
                <h4 className="text-label text-primary-dark">Our Address</h4>
              </div>
              <p className="text-sm text-primary-dark/70 leading-relaxed">
                {businessInfo.addressFormatted}
              </p>
              <a
                href={GOOGLE_MAPS_DIRECTIONS_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 mt-3 text-sm font-medium text-primary hover:text-primary-dark transition-colors"
              >
                Get Directions
                <ArrowSquareOut className="text-base" weight="bold" aria-hidden="true" />
              </a>
            </div>

            {/* Phone Card */}
            <div className="bg-surface rounded-xl p-5 border border-primary/5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Phone className="text-xl text-primary" weight="fill" aria-hidden="true" />
                </div>
                <h4 className="text-label text-primary-dark">Phone</h4>
              </div>
              <a
                href={businessInfo.phoneHref}
                className="block text-lg font-semibold text-primary-dark hover:text-primary transition-colors"
              >
                {businessInfo.phoneLocal}
              </a>
              <p className="text-xs text-primary-dark/50 mt-1">International: {businessInfo.phoneInternational}</p>
            </div>

            {/* WhatsApp Card */}
            <div className="bg-surface rounded-xl p-5 border border-primary/5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <WhatsappLogo className="text-xl text-primary" weight="fill" aria-hidden="true" />
                </div>
                <h4 className="text-label text-primary-dark">WhatsApp</h4>
              </div>
              <a
                href={businessInfo.whatsappUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary-dark transition-colors"
              >
                Chat with us on WhatsApp
                <ArrowSquareOut className="text-base" weight="bold" aria-hidden="true" />
              </a>
              <p className="text-xs text-primary-dark/50 mt-2">Quick replies during business hours</p>
            </div>

            {/* Email Card */}
            <div className="bg-surface rounded-xl p-5 border border-primary/5">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <EnvelopeSimple className="text-xl text-primary" weight="fill" aria-hidden="true" />
                </div>
                <h4 className="text-label text-primary-dark">Email</h4>
              </div>
              <a
                href={`mailto:${businessInfo.email}`}
                className="text-sm font-medium text-primary-dark hover:text-primary transition-colors"
              >
                {businessInfo.email}
              </a>
              <p className="text-xs text-primary-dark/50 mt-2">For bookings, quotes &amp; general enquiries</p>
            </div>

            {/* Operating Hours Card — spans 2 cols on desktop */}
            <div className="bg-surface rounded-xl p-5 border border-primary/5 sm:col-span-2 lg:col-span-2">
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Clock className="text-xl text-primary" weight="fill" aria-hidden="true" />
                </div>
                <h4 className="text-label text-primary-dark">Operating Hours</h4>
              </div>
              <ul className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {businessInfo.hoursGrouped.map((item) => (
                  <li key={item.day} className="flex flex-col gap-0.5">
                    <span className="text-sm font-medium text-primary-dark">{item.day}</span>
                    <span className="text-sm text-primary-dark/70">{item.hours}</span>
                  </li>
                ))}
              </ul>
              <p className="text-xs text-primary-dark/50 mt-3">
                Boarding guests receive 24/7 supervision regardless of office hours.
              </p>
            </div>

            {/* Book a Service CTA Card */}
            <div className="bg-primary/5 rounded-xl p-5 border border-primary/10 flex flex-col items-center justify-center text-center gap-3">
              <CalendarCheck className="text-3xl text-primary" weight="duotone" aria-hidden="true" />
              <div>
                <p className="text-sm font-semibold text-primary-dark">Ready to Book?</p>
                <p className="text-xs text-primary-dark/60 mt-1">Schedule a service or free consultation</p>
              </div>
              <Link
                href="/contact#contact-form"
                className="inline-flex items-center gap-1.5 text-btn text-white bg-primary hover:bg-primary-dark px-5 py-2.5 rounded-full transition-colors"
              >
                Book Now
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* ── Google Maps Embed ──────────────────────────────────── */}
      <section className="py-10 bg-surface" aria-label="Map">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="rounded-2xl overflow-hidden border border-primary/10 shadow-sm">
            <iframe
              src={GOOGLE_MAPS_EMBED_URL}
              width="100%"
              height="400"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="Waggies Pet Services location on Google Maps"
              className="w-full"
            />
          </div>
          <div className="mt-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <p className="text-sm text-primary-dark/60">
              {businessInfo.addressShort}
            </p>
            <a
              href={GOOGLE_MAPS_DIRECTIONS_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary-dark transition-colors"
            >
              Open in Google Maps
              <ArrowSquareOut className="text-base" weight="bold" aria-hidden="true" />
            </a>
          </div>
        </div>
      </section>

      {/* ── Contact Form ───────────────────────────────────────── */}
      <section id="contact-form" className="py-16 md:py-20 bg-white" aria-labelledby="contact-form-heading">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
            <div>
              <ContactForm
                service={context.service || undefined}
                variant={context.variant || undefined}
                tier={context.tier || undefined}
                intent={context.intent || undefined}
                estimateSummary={context.summary || undefined}
                defaultMessage={prefillMessage}
              />

              {hasPricingContext ? (
                <div className="mt-6 p-4 bg-surface-purple border border-primary/10 rounded-xl text-sm text-primary-dark/80">
                  <p className="font-semibold text-primary-dark mb-1">
                    Your estimate is attached to this message
                  </p>
                  {context.summary ? <p>{context.summary}</p> : null}
                  <p className="mt-2">
                    <a
                      href={estimateUrl(
                        context.service || null,
                        context.variant || null,
                        context.tier || null,
                      )}
                      className="text-primary font-medium hover:underline"
                    >
                      Adjust estimate
                    </a>
                  </p>
                </div>
              ) : null}
            </div>

            {/* Sidebar: Quick Contact Summary */}
            <div className="flex flex-col gap-6 lg:pt-14">
              <h3 className="text-h3 text-primary-dark">Prefer to Reach Out Directly?</h3>
              <p className="text-body-sm">
                Call, WhatsApp, or visit us in person. We're always happy to help with bookings, questions, or a free consultation.
              </p>

              <div className="flex flex-col gap-4">
                <a
                  href={businessInfo.phoneHref}
                  className="flex items-center gap-3 p-4 bg-surface rounded-xl border border-primary/5 hover:border-primary/20 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Phone className="text-lg text-primary" weight="fill" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-xs text-primary-dark/50">Call Us</p>
                    <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors">
                      {businessInfo.phoneLocal}
                    </p>
                  </div>
                </a>

                <a
                  href={businessInfo.whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 p-4 bg-surface rounded-xl border border-primary/5 hover:border-primary/20 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <WhatsappLogo className="text-lg text-primary" weight="fill" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-xs text-primary-dark/50">WhatsApp</p>
                    <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors">
                      Send a message
                    </p>
                  </div>
                </a>

                <a
                  href={`mailto:${businessInfo.email}`}
                  className="flex items-center gap-3 p-4 bg-surface rounded-xl border border-primary/5 hover:border-primary/20 transition-colors group"
                >
                  <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <EnvelopeSimple className="text-lg text-primary" weight="fill" aria-hidden="true" />
                  </div>
                  <div>
                    <p className="text-xs text-primary-dark/50">Email</p>
                    <p className="text-sm font-semibold text-primary-dark group-hover:text-primary transition-colors">
                      {businessInfo.email}
                    </p>
                  </div>
                </a>
              </div>

              <div className="flex items-start gap-3 p-4 bg-surface rounded-xl border border-primary/5">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <Clock className="text-lg text-primary" weight="fill" aria-hidden="true" />
                </div>
                <div>
                  <p className="text-xs text-primary-dark/50 mb-1">Operating Hours</p>
                  <div className="flex flex-col gap-1">
                    {businessInfo.hoursGrouped.map((item) => (
                      <p key={item.day} className="text-sm">
                        <span className="text-primary-dark/50">{item.day}:</span>{" "}
                        <span className="font-medium text-primary-dark">{item.hours}</span>
                      </p>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <BreadcrumbSchema items={[{ name: "Contact", path: "/contact" }]} />
      <JsonLd
        data={contactPageSchema(
          "Contact Waggies - Abuja Pet Care",
          "Get in touch with Waggies Pet Services in Abuja. Book boarding, grooming, vet care, training, or relocation.",
          "/contact",
        )}
      />
    </>
  );
}