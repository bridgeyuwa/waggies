/**
 * Shared Waggies OpenGraph image helpers.
 *
 * `next/og` (Satori) renders JSX → PNG at request time. Satori requires
 * `display: 'flex'` on every <div> and only supports a subset of CSS
 * (no box-shadow, no transform beyond basic scale, gradients via
 * `background` are supported). We use only inline styles + the default
 * sans-serif font that ImageResponse bundles, so no font fetching is
 * needed.
 *
 * Layout: 1200×630 branded OG image on a dark purple gradient with
 *   - top-left:  🐾 paw badge + "WAGGIES" wordmark (white, 700 weight)
 *   - top-right: optional category pill
 *   - middle:    large white title (48px, 700 weight) + author/readingTime
 *   - bottom:    thin white separator + "waggies.com.ng" + category badge
 *   - background: decorative paw watermark pattern at low opacity
 */

import { ImageResponse } from "next/og";

export const WAGGIES_OG_SIZE = { width: 1200, height: 630 } as const;
export const WAGGIES_OG_CONTENT_TYPE = "image/png";

/** Main gradient for article OG images (135° deep purple → purple). */
const ARTICLE_GRADIENT_BG =
  "linear-gradient(135deg, #2D0A4E 0%, #6B2C91 100%)";

/** Site-wide gradient (kept for the default site OG image). */
const SITE_GRADIENT_BG =
  "linear-gradient(135deg, #2A0F40 0%, #6B2C91 55%, #4A1F69 100%)";

/**
 * Paw-print watermark positions scattered across the background.
 * Each entry is [x, y, rotation, scale] - we render 🐾 at that spot.
 * Positioned to not overlap with the main content areas.
 */
const PAW_WATERMARKS: [number, number, number, number][] = [
  [900, 80, -15, 42],
  [1050, 200, 25, 36],
  [50, 350, -30, 38],
  [200, 480, 10, 30],
  [750, 440, -20, 34],
  [1000, 480, 35, 28],
  [400, 80, 5, 26],
  [600, 490, -10, 32],
  [950, 350, 15, 24],
  [300, 250, -25, 22],
];

/**
 * Render the paw watermark layer. Uses `position: absolute` so it sits
 * behind the main content without affecting flex layout.
 */
function PawWatermarkLayer() {
  return (
    <div
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        display: "flex",
        overflow: "hidden",
      }}
    >
      {PAW_WATERMARKS.map(([x, y, _rot, scale], i) => (
        <div
          key={i}
          style={{
            position: "absolute",
            left: x,
            top: y,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: scale,
            color: "rgba(255,255,255,0.06)",
            transform: `rotate(${_rot}deg)`,
          }}
        >
          🐾
        </div>
      ))}
    </div>
  );
}

/**
 * Build a subtitle line from author and reading time.
 * Returns "Author · X min read" or just one part if only one is provided.
 */
function buildSubtitle(author?: string, readingTime?: string): string | null {
  const parts: string[] = [];
  if (author) parts.push(author);
  if (readingTime) parts.push(readingTime);
  return parts.length > 0 ? parts.join(" · ") : null;
}

/**
 * Branded OG image used by blog posts (and any other route that wants
 * a category pill + dynamic title). Enhanced with author, readingTime,
 * paw watermarks, bottom separator line, and updated design specs.
 *
 * Backward-compatible: `author` and `readingTime` default to undefined
 * so existing callers (e.g. service page OG images) still work.
 */
export function waggiesArticleOgImage({
  title,
  category,
  author,
  readingTime,
}: {
  title?: string;
  category?: string;
  author?: string;
  readingTime?: string;
} = {}): ImageResponse {
  // Default to "Waggies Blog" if called without args - defensive.
  const safeTitle = title ?? "Waggies Blog";

  // Long titles wrap to more lines; drop the font-size so 3 lines fit.
  // Base is 48px per spec, scaling down for very long titles.
  const titleLength = safeTitle.length;
  const titleSize =
    titleLength > 90
      ? 36
      : titleLength > 70
        ? 40
        : titleLength > 50
          ? 44
          : 48;

  const subtitle = buildSubtitle(author, readingTime);

  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          background: ARTICLE_GRADIENT_BG,
          padding: "80px",
          fontFamily: "sans-serif",
          position: "relative",
        }}
      >
        {/* Paw watermark layer (behind content) */}
        <PawWatermarkLayer />

        {/* Content layer */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            justifyContent: "space-between",
            width: "100%",
            height: "100%",
            position: "relative",
          }}
        >
          {/* ── Top bar ── */}
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              width: "100%",
            }}
          >
            <div
              style={{ display: "flex", alignItems: "center", gap: "16px" }}
            >
              {/* Paw icon badge */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  width: "56px",
                  height: "56px",
                  background: "rgba(255,255,255,0.15)",
                  borderRadius: "14px",
                  fontSize: "30px",
                }}
              >
                🐾
              </div>
              {/* WAGGIES wordmark */}
              <div
                style={{
                  display: "flex",
                  color: "white",
                  fontSize: "32px",
                  fontWeight: 700,
                  letterSpacing: "1.5px",
                }}
              >
                WAGGIES
              </div>
            </div>

            {/* Category pill (top-right) */}
            {category ? (
              <div
                style={{
                  display: "flex",
                  padding: "8px 22px",
                  borderRadius: "999px",
                  background: "rgba(255,255,255,0.18)",
                  color: "white",
                  fontSize: "18px",
                  fontWeight: 700,
                  textTransform: "uppercase" as const,
                  letterSpacing: "1.2px",
                }}
              >
                {category}
              </div>
            ) : null}
          </div>

          {/* ── Center title + subtitle ── */}
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              maxWidth: "900px",
              marginTop: "16px",
              gap: "12px",
            }}
          >
            {/* Title */}
            <div
              style={{
                display: "flex",
                color: "white",
                fontSize: `${titleSize}px`,
                fontWeight: 700,
                lineHeight: 1.2,
                letterSpacing: "-0.5px",
                textWrap: "balance",
              }}
            >
              {safeTitle}
            </div>

            {/* Author + reading time */}
            {subtitle ? (
              <div
                style={{
                  display: "flex",
                  color: "rgba(255,255,255,0.6)",
                  fontSize: "20px",
                  fontWeight: 400,
                  letterSpacing: "0.3px",
                }}
              >
                {subtitle}
              </div>
            ) : null}
          </div>

          {/* ── Bottom bar ── */}
          <div
            style={{
              display: "flex",
              flexDirection: "column",
              width: "100%",
              gap: "16px",
            }}
          >
            {/* Thin white separator line */}
            <div
              style={{
                display: "flex",
                width: "100%",
                height: "1px",
                background: "rgba(255,255,255,0.2)",
              }}
            />

            {/* Bottom row: domain + category badge */}
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                width: "100%",
              }}
            >
              <div
                style={{
                  display: "flex",
                  color: "rgba(255,255,255,0.6)",
                  fontSize: "20px",
                  fontWeight: 600,
                }}
              >
                waggies.com.ng
              </div>

              {category ? (
                <div
                  style={{
                    display: "flex",
                    padding: "6px 16px",
                    borderRadius: "999px",
                    background: "rgba(255,255,255,0.12)",
                    color: "rgba(255,255,255,0.8)",
                    fontSize: "16px",
                    fontWeight: 600,
                    textTransform: "uppercase" as const,
                    letterSpacing: "0.8px",
                  }}
                >
                  {category}
                </div>
              ) : null}
            </div>
          </div>
        </div>
      </div>
    ),
    { ...WAGGIES_OG_SIZE }
  );
}

/**
 * Default site-wide OG image. Hero-style centered layout with a large
 * paw mark above the wordmark + tagline. Used as the fallback OG image
 * for any page without a per-route opengraph-image file.
 */
export function waggiesSiteOgImage({
  title = "Waggies",
  subtitle = "Luxury Pet Care in Abuja, Nigeria",
}: {
  title?: string;
  subtitle?: string;
} = {}): ImageResponse {
  return new ImageResponse(
    (
      <div
        style={{
          width: "100%",
          height: "100%",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          background: SITE_GRADIENT_BG,
          padding: "60px",
          fontFamily: "sans-serif",
        }}
      >
        {/* Big paw mark */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            width: "140px",
            height: "140px",
            background: "white",
            borderRadius: "36px",
            fontSize: "78px",
            marginBottom: "36px",
          }}
        >
          🐾
        </div>

        {/* Wordmark */}
        <div
          style={{
            display: "flex",
            color: "white",
            fontSize: "108px",
            fontWeight: 800,
            fontFamily: "serif",
            letterSpacing: "-2px",
            lineHeight: 1,
          }}
        >
          {title}
        </div>

        {/* Tagline */}
        <div
          style={{
            display: "flex",
            color: "rgba(255,255,255,0.88)",
            fontSize: "32px",
            marginTop: "20px",
            textAlign: "center",
          }}
        >
          {subtitle}
        </div>

        {/* Bottom strip */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            width: "100%",
            marginTop: "60px",
          }}
        >
          <div
            style={{
              display: "flex",
              color: "rgba(255,255,255,0.7)",
              fontSize: "22px",
            }}
          >
            Grooming · Training · Vet Care · Boarding · Transport
          </div>
          <div
            style={{
              display: "flex",
              color: "rgba(255,255,255,0.7)",
              fontSize: "22px",
              fontWeight: 600,
            }}
          >
            waggies.com.ng
          </div>
        </div>
      </div>
    ),
    { ...WAGGIES_OG_SIZE }
  );
}
