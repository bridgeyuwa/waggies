/**
 * About page content  -  extracted verbatim from the Laravel Blade source of
 * truth.
 *
 *   - Hero (gradient + image):  lines 4-7
 *   - Stats band (4):           lines 10-34
 *   - Philosophy section:       lines 38-136  (heading + 3 body paragraphs
 *                                              + 4 feature rows + image
 *                                              mosaic of 2)
 *   - Story section:            lines 139-183 (heading + 4 body paragraphs
 *                                              + 4 stat tiles)
 *   - Operating Standards band: lines 186-217 (feature-band with 4 features
 *                                              + multi-line subtitle)
 *   - Specialists (4 cards):    lines 221-264
 *   - HQ contact card + map:    lines 267-386
 *   - Secondary CTA:            lines 388-397
 *
 * Component defaults referenced:
 *   - components/hero/gradient.blade.php
 *   - components/feature-band.blade.php
 *   - components/about/team-card.blade.php  (badge, roles[], slot text)
 *   - components/cta/secondary.blade.php
 *
 * Route translations applied:
 *   route('contact')         → /contact
 *   route('services.index')  → /services
 *
 * NOTE  -  anomalies preserved verbatim from source:
 *   1. The "Meet the Specialists" grid (lines 235-262) contains FOUR
 *      identical team-card instances (Dr. Amara Okeke, Head Veterinarian,
 *      same image URL, same roles, same slot text). This is duplicate /
 *      placeholder content in the canonical source  -  preserved as-is.
 *   2. The "Our Story" body has 4 paragraphs in source (lines 148-169),
 *      not 3 as the brief stated. All 4 are preserved verbatim.
 *   3. Operating Standards `subtitle` in source spans multiple lines with
 *      embedded whitespace; visually collapsed whitespace is preserved here
 *      (HTML collapses multi-line attribute values to single spaces at
 *      render time anyway).
 *
 * DO NOT paraphrase, modernize, abbreviate, or "improve" this content.
 */

// ── Hero ──────────────────────────────────────────────────────────────────

export type AboutHero = {
  title: string;
  subtitle: string;
  primaryCta: { label: string; href: string };
  secondaryCta: { label: string; href: string };
  imageSrc: string;
};

export const aboutHero: AboutHero = {
  title: "Complete Veterinary & Pet Care in Abuja",
  subtitle:
    "Vet care, boarding, grooming, training, and relocation - all in one place.",
  primaryCta: { label: "Book a Free Consultation", href: "/contact" },
  secondaryCta: { label: "Explore Services", href: "/services" },
  /* TODO(client): Replace with authoritative Waggies facility photo */
  imageSrc: "" as string,
} as const;

// ── Stats band (4) ────────────────────────────────────────────────────────

export type AboutStat = { value: string; label: string };

export const aboutStats: AboutStat[] = [
  { value: "5k+", label: "Clients Served" },
  { value: "24/7", label: "Concierge Vet Care" },
  { value: "15+", label: "Global Specialists" },
  { value: "100%", label: "Protocol-Based Handling" },
];

// ── Philosophy section ────────────────────────────────────────────────────

export type AboutPhilosophyFeature = {
  icon: string;
  title: string;
  description: string;
};

export type AboutPhilosophy = {
  eyebrow: string;
  title: string;
  body: string[];
  features: AboutPhilosophyFeature[];
};

export const aboutPhilosophy: AboutPhilosophy = {
  eyebrow: "Our Philosophy",
  title: "Pet Care Standards in West Africa",
  body: [
    "Founded to bridge the gap in dedicated pet services, Waggies has grown into Abuja's most comprehensive pet care centre. We believe thorough, consistent care matters.",
    "Our facility combines proper medical equipment with comfortable, clean spaces. Whether it's a routine check-up, a grooming session, or international relocation, we handle every detail with care and precision.",
    "Pet Care Should Never Be Reactive: We believe animals benefit from the same structure and planning as human healthcare - not rushed decisions, not inconsistent handling, but deliberate care built around long-term wellbeing."
  ],
  features: [
    {
      icon: "diamond",
      title: "High Standards",
      description: "Climate-controlled suites & quality amenities.",
    },
    {
      icon: "public",
      title: "Global Mobility",
      description: "Experienced in straightforward international pet travel.",
    },
    {
      icon: "verified_user",
      title: "Expert Supervision",
      // TODO(client): verify specific qualification credentials
      description: "Veterinary staff on site during all operating hours.",
    },
    {
      icon: "schedule",
      title: "24/7 Concierge Care",
      description: "We never sleep so they can.",
    },
  ],
};

// ── Image mosaic (2 images) ───────────────────────────────────────────────

export type AboutMosaicImage = {
  src: string;
  alt: string;
  wrapperClass: string;
  imgClass: string;
};

export const aboutMosaicImages: AboutMosaicImage[] = [
  {
    /* TODO(client): Replace with authoritative Waggies clinic interior photo */
    src: "" as string,
    alt: "Waggies clinic interior [image required from client]",
    wrapperClass: "img-zoom-wrap rounded-2xl shadow-sm hover:shadow-soft transition mt-8",
    imgClass: "w-full h-64 object-cover rounded-2xl",
  },
  {
    /* TODO(client): Replace with authoritative Waggies grooming session photo */
    src: "" as string,
    alt: "Waggies grooming session [image required from client]",
    wrapperClass: "img-zoom-wrap rounded-2xl shadow-sm hover:shadow-soft transition",
    imgClass: "w-full h-64 object-cover rounded-2xl",
  },
];

// ── Our Story section ─────────────────────────────────────────────────────

export type AboutStoryStat = { value: string; label: string };

export type AboutStory = {
  eyebrow: string;
  /** Raw HTML  -  Blade renders via `{!! $title !!}`. Contains <br />. */
  title: string;
  paragraphs: string[];
  stats: AboutStoryStat[];
};

export const aboutStory: AboutStory = {
  eyebrow: "Our Story",
  title: "Built by Pet Lovers,<br />for Pet Owners",
  paragraphs: [
    "Waggies was born from a personal experience  -  a pet owner in Abuja struggling to find a boarding facility that matched the standard of care they gave their own dog at home. What started as a small dog hotel has grown into Abuja's most comprehensive pet care centre.",
    "Today, we offer boarding, grooming, vet care, training, transport, and international relocation  -  all under one roof, all to the same consistent standard.",
    "Every member of our team is an animal lover first. We believe the best pet care comes from genuine passion  -  not just process.",
    "Waggies began with a simple but frustrating reality - pet owners in Abuja had to choose between basic boarding facilities or expensive, fragmented services with no continuity of care. The idea was not to “start a pet business.” It was to remove the inconsistency between grooming, boarding, and veterinary handling by putting everything under one controlled system. What exists today is not a collection of separate services - but a unified care environment designed to reduce the risks created by fragmentation.",
  ],
  stats: [
    { value: "500+", label: "Happy Clients" },
    { value: "7", label: "Years in Business" },
    { value: "4.9", label: "Average Rating" },
    { value: "15+", label: "Team Members" },
  ],
};

// ── Operating Standards (feature-band) ────────────────────────────────────

export type AboutOperatingStandard = {
  icon: string;
  title: string;
  description: string;
};

export type AboutOperatingStandards = {
  eyebrow: string;
  /** Raw HTML  -  Blade renders via `{!! $title !!}`. Contains <br/> + <span>. */
  title: string;
  subtitle: string;
  features: AboutOperatingStandard[];
};

export const aboutOperatingStandards: AboutOperatingStandards = {
  eyebrow: "Operating Standards",
  title:
    'Our Standard of Handling<br/><span class="text-secondary italic">Across All Services</span>',
  subtitle:
    "Whether it is boarding, grooming, vet care, training, or relocation - our decisions follow one rule: what is best for the animal comes first.",
  features: [
    {
      icon: "volunteer_activism",
      title: "Supervised Pet-First Care",
      description:
        "Every service is designed around comfort, safety, and wellbeing  -  never convenience or speed.",
    },
    {
      icon: "sync",
      title: "Consistency Across Services",
      description:
        "Boarding, grooming, and medical care follow the same documented handling standards and staff procedures.",
    },
    {
      icon: "shield",
      title: "Controlled Safety Protocols",
      description:
        "Pets are separated by risk level, monitored during movement, and handled under strict safety procedures.",
    },
    {
      icon: "visibility",
      title: "Transparent Owner Communication",
      description:
        "Owners receive clear updates on condition, progress, and any incidents  -  with no hidden details.",
    },
  ],
};

// ── Meet the Specialists (team cards) ─────────────────────────────────────

export type AboutTeamMember = {
  name: string;
  role: string;
  image: string;
  badge: string;
  roles: string[];
  /** Slot text  -  the team-card component renders this as the body copy. */
  bio: string;
};

/**
 * NOTE: The Laravel source contained four identical placeholder team-card entries.
 * Team photos are TODO(client) - require real staff photographs from Waggies.
 * The single entry below preserves the data structure; the page component
 * should render a single card (or the section can be hidden until real
 * team data is supplied).
 */
export const aboutTeamMembers: AboutTeamMember[] = [
  {
    name: "Dr. Amara Okeke",
    role: "Head Veterinarian",
    /* TODO(client): Replace with real staff photo */
    image: "",
    badge: "Vet",
    roles: ["DVM"],
    // TODO(client): verify surgery credentials for accurate bio
    bio: "Experienced veterinarian with a focus on small animal surgery and over a decade of clinical experience."
  },
];

// ── Specialists section header ────────────────────────────────────────────

export const aboutSpecialistsHeading = {
  eyebrow: "Expertise",
  title: "Meet the Specialists",
  intro:
    "Our team is made up of experienced professionals trained to a high standard of animal care.",
} as const;

// ── HQ contact card ───────────────────────────────────────────────────────

export type AboutHqTrustBadge = { icon: string; label: string };

export type AboutHqContact = {
  title: string;
  trustBadges: AboutHqTrustBadge[];
  address: { label: string; /** Raw HTML  -  contains <br>. */ lines: string };
  hours: {
    label: string;
    lines: string[];
    openNowBadge: { label: string; className: string };
  };
  contact: {
    label: string;
    phone: { href: string; label: string; className: string };
    email: { href: string; label: string; className: string };
  };
  actions: {
    primary: {
      href: string;
      icon: string;
      label: string;
      className: string;
      /** Original `target="_blank"` on the Blade anchor. */
      targetBlank: boolean;
    };
    call: { href: string; ariaLabel: string; icon: string; className: string };
    whatsapp: { href: string; ariaLabel: string; className: string };
  };
  /** Google Maps embed iframe `src`. */
  mapIframeSrc: string;
};

export const aboutHqContact: AboutHqContact = {
  title: "Waggies HQ",
  trustBadges: [
    { icon: "star", label: "4.9 Rating" },
    { icon: "verified", label: "Certified Care" },
    { icon: "schedule", label: "Open Today" },
  ],
  address: {
    label: "Address",
    lines: "Life Camp, Efab City Estate,<br>65 1st Ave, Abuja 900108, FCT, Nigeria",
  },
  hours: {
    label: "Hours",
    lines: ["Mon-Fri: 9:00am - 5:00pm", "Saturday: 10:00am - 2:00pm", "Sunday: 10:00am - 2:00pm"],
    openNowBadge: {
      label: "Open Now",
      className: "inline-block mt-2 text-xs font-semibold px-2 py-1 rounded bg-success-light text-success",
    },
  },
  contact: {
    label: "Contact",
    phone: {
      href: "tel:+2349080811902",
      label: "+234 908 081 1902",
      className: "block font-semibold text-primary-dark",
    },
    email: {
      href: "mailto:hello@waggies.ng",
      label: "hello@waggies.ng",
      className: "text-sm text-primary underline",
    },
  },
  actions: {
    primary: {
      href: "https://maps.google.com/?q=Life+Camp+Efab+City+Estate+65+1st+Ave+Abuja+Nigeria",
      icon: "directions",
      label: "Get Directions",
      className:
        "flex-1 px-5 py-3 rounded-full bg-primary hover:bg-primary-dark text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors",
      targetBlank: true,
    },
    call: {
      href: "tel:+2349080811902",
      ariaLabel: "Call",
      icon: "call",
      className:
        "w-11 h-11 flex items-center justify-center rounded-full border border-primary/30 text-primary-dark hover:bg-surface-purple transition-colors",
    },
    whatsapp: {
      href: "https://wa.me/2349080811902",
      ariaLabel: "WhatsApp",
      className:
        "w-11 h-11 flex items-center justify-center rounded-full bg-whatsapp text-white hover:bg-whatsapp-hover transition-colors",
    },
  },
  mapIframeSrc:
    "https://maps.google.com/maps?q=Life+Camp+Efab+City+Estate+65+1st+Ave+Abuja+Nigeria&output=embed",
};

// ── Secondary CTA ─────────────────────────────────────────────────────────

export type AboutCtaSecondary = {
  heading: string;
  body: string;
  primaryLabel: string;
  primaryHref: string;
  primaryIcon: string;
};

export const aboutCtaSecondary: AboutCtaSecondary = {
  heading: "Explore Our Pet Care Services",
  body: "From grooming to veterinary care and boarding, discover everything we offer to keep your pet healthy and happy.",
  primaryLabel: "View Services",
  primaryHref: "/services",
  primaryIcon: "arrow_forward",
} as const;
