/**
 * Homepage content.
 *
 * Service descriptions are based on the original Laravel site content.
 * Testimonials are from the original source data.
 * Feature claims are from the Laravel source.
 *
 * Copy has been reviewed to remove AI-sounding language.
 * No statistics, credentials, or claims have been invented.
 */

export type HomeServiceCard = {
  title: string;
  description: string;
  href: string;
  imageSrc: string;
  icon: string;
};

export const homeServiceCards: HomeServiceCard[] = [
  {
    title: "Boarding",
    description: "Overnight stays in spacious, climate-controlled suites with 24/7 care.",
    href: "/services/boarding",
    imageSrc: "https://images.unsplash.com/photo-1544568100-847a948585b9?w=600&auto=format&fit=crop&q=60",
    icon: "apartment",
  },
  {
    title: "Grooming",
    description: "Breed-specific treatments, baths, and styling by experienced groomers.",
    href: "/services/grooming",
    imageSrc: "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=600&h=400&fit=crop&q=80",
    icon: "spa",
  },
  {
    title: "Vet Care",
    description: "On-site veterinary consultations, vaccinations, and wellness check-ups.",
    href: "/services/vet-care",
    imageSrc: "https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?w=600&h=400&fit=crop&q=80",
    icon: "medical_services",
  },
  {
    title: "Training",
    description: "Positive-reinforcement training programmes for puppies and adult dogs.",
    href: "/services/training",
    imageSrc: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=600&h=400&fit=crop&q=80",
    icon: "school",
  },
  {
    title: "Pet Relocation",
    description: "International pet moves with full documentation and logistics support.",
    href: "/relocation",
    imageSrc: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=600&h=400&fit=crop&q=80",
    icon: "flight_takeoff",
  },
  {
    title: "Transport",
    description: "Door-to-door pickup and drop-off across Abuja in air-conditioned vehicles.",
    href: "/services/transport",
    imageSrc: "https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=600&h=400&fit=crop&q=80",
    icon: "local_shipping",
  },
];

export type Feature = {
  icon: string;
  title: string;
  description: string;
};

export const homeTrustFeatures: Feature[] = [
  {
    icon: "verified",
    title: "PCSA Certified",
    description: "Licensed by the Pet Care Services Association of Nigeria.",
  },
  {
    icon: "medical_services",
    title: "On-site Vet",
    description: "A veterinarian on-site every day of the week.",
  },
  {
    icon: "lock_clock",
    title: "24/7 Supervision",
    description: "Your pets are monitored around the clock, never left alone.",
  },
  {
    icon: "hotel",
    title: "Climate-Controlled Suites",
    description: "Spacious suites with orthopedic bedding and temperature control.",
  },
  {
    icon: "photo_camera",
    title: "Daily Updates",
    description: "Receive photos and updates on your pet every day.",
  },
];

export type Testimonial = {
  stars: number;
  quote: string;
  authorInitial: string;
  authorName: string;
  authorSubtitle: string;
};

export const homeTestimonials: Testimonial[] = [
  {
    stars: 5,
    quote: "Waggies is the only place I would trust with my dog. The daily updates give me real peace of mind.",
    authorInitial: "A",
    authorName: "Adaeze O.",
    authorSubtitle: "Dog owner, Maitama",
  },
  {
    stars: 5,
    quote: "The grooming team transformed my Persian cat. She looked like she had come straight from a pet show.",
    authorInitial: "E",
    authorName: "Emeka N.",
    authorSubtitle: "Cat owner, Wuse II",
  },
  {
    stars: 5,
    quote: "Our relocation from London was well-organised. Every document was sorted, zero stress on our end.",
    authorInitial: "F",
    authorName: "Fatima M.",
    authorSubtitle: "Relocation client, Asokoro",
  },
];
