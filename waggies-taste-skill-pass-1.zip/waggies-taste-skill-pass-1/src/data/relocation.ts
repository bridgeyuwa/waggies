/**
 * Relocation page content  -  extracted verbatim from the Laravel Blade source.
 *
 * Sources:
 *   - resources/views/pages/relocation/index.blade.php
 *   - resources/views/pages/relocation/import.blade.php
 *   - resources/views/pages/relocation/export.blade.php
 *   - resources/views/pages/relocation/checklist.blade.php
 *
 * DO NOT paraphrase or "improve" this content.
 */

// ── Relocation index page ─────────────────────────────────────────────────

export const relocationIndexHero = {
  imageSrc: "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=1600&auto=format&fit=crop&q=80",
  eyebrow: "International Pet Relocation",
  title: "Move Your Pet Internationally",
  subtitle:
    "Import and export of pets - from health certificates and microchipping to airline bookings and customs clearance.",
  primaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=relocation",
    icon: "calculate",
  },
  secondaryCta: { label: "View Checklist", href: "/relocation/checklist" },
};

export const relocationIndexSectionHeading = {
  eyebrow: "Our Relocation Services",
  title: "Whether You're Moving In<br/>or Moving Out",
  subtitle:
    "We handle every stage of the relocation process so you can focus on your move, not the paperwork.",
};

export const relocationIndexCards = [
  {
    title: "Import to Nigeria",
    description:
      "Bringing your pet to Abuja? We manage all import permits, health checks, and airport collection.",
    href: "/relocation/import",
    imageSrc: "https://images.unsplash.com/photo-1606567595334-d39972c85dbe?w=600&h=400&fit=crop&q=80",
    icon: "flight_land",
  },
  {
    title: "Export from Nigeria",
    description:
      "Moving abroad? We handle export permits, airline-approved crates, and international documentation.",
    href: "/relocation/export",
    imageSrc: "https://images.unsplash.com/photo-1601758174114-e711c0cbaa56?w=600&h=400&fit=crop&q=80",
    icon: "flight_takeoff",
  },
  {
    title: "Relocation Checklist",
    description:
      "Use our checklist to stay on top of every requirement for a smooth relocation.",
    href: "/relocation/checklist",
    imageSrc: "https://images.unsplash.com/photo-1558618666-fcd25c85f82e?w=600&h=400&fit=crop&q=80",
    icon: "checklist",
  },
];

export const relocationIndexFeatureBand = {
  eyebrow: "Why Choose Waggies Relocation?",
  title: "Every Document,<br/><span class=\"text-secondary italic\">Every Step</span>",
  subtitle:
    "International pet moves are complex. We've done hundreds of them  -  let us handle the details.",
  cta: { label: "Get Estimate", href: "/services/pricing?service=relocation" },
  features: [
    { icon: "description", title: "Full Documentation", description: "Health certs, import/export permits, microchip records  -  all handled for you." },
    { icon: "flight", title: "Airline Coordination", description: "We liaise directly with airlines to book the right cargo or cabin option." },
    { icon: "verified", title: "Vet-Signed Health Certs", description: "Our on-site vet completes all required health examinations and paperwork." },
    { icon: "support_agent", title: "Dedicated Coordinator", description: "A single point of contact who manages your pet's move from start to finish." },
    { icon: "schedule", title: "Timeline Management", description: "We plan against your travel date to ensure all requirements are met on time." },
  ],
};

export const relocationTestimonials = [
  {
    stars: 5,
    quote:
      "Waggies handled every single document for our move to the UK. Completely seamless  -  zero stress on our part.",
    authorInitial: "F",
    authorName: "Fatima M.",
    authorSubtitle: "Relocation client · Asokoro",
  },
  {
    stars: 5,
    quote:
      "We imported two dogs from the US. The team knew exactly what was needed and kept us updated throughout.",
    authorInitial: "K",
    authorName: "Kunle A.",
    authorSubtitle: "Import client · Maitama",
  },
  {
    stars: 5,
    quote:
      "Professional, knowledgeable, and genuinely caring. Our cat arrived safely and we couldn't be happier.",
    authorInitial: "A",
    authorName: "Amaka O.",
    authorSubtitle: "Export client · Wuse II",
  },
] as const;

// ── Import page ───────────────────────────────────────────────────────────

export const relocationImportHero = {
  imageSrc: "https://images.unsplash.com/photo-1606567595334-d39972c85dbe?w=600&h=400&fit=crop&q=80",
  eyebrow: "Pet Import · Nigeria",
  title: "Bringing Your Pet<br/>to Nigeria?",
  subtitle:
    "We manage every import requirement  -  from advance permits and health certificates to airport collection and quarantine coordination.",
  primaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=relocation&tier=import",
    icon: "calculate",
  },
  secondaryCta: { label: "View Checklist", href: "/relocation/checklist" },
};

export const relocationImportSectionHeading = {
  eyebrow: "Import Process",
  title: "What We Handle<br/>for You",
  subtitle:
    "Importing a pet to Nigeria involves strict documentation and coordination. We take care of every step.",
};

export const relocationImportFeatures = [
  { icon: "description", title: "Import Permit", desc: "We obtain the required import permits from Nigerian veterinary and customs authorities on your behalf." },
  { icon: "vaccines", title: "Health & Vaccination Checks", desc: "Review of your pet's vaccination records to confirm compliance with Nigerian import requirements." },
  { icon: "qr_code_scanner", title: "Microchip Verification", desc: "Confirmation that your pet's microchip meets the ISO standard required for entry." },
  { icon: "flight_land", title: "Airport Collection", desc: "Our team collects your pet from the cargo terminal and handles all on-arrival documentation." },
  { icon: "home", title: "Post-Arrival Care", desc: "Optional post-arrival boarding and health check while your pet settles into their new home." },
  { icon: "support_agent", title: "Dedicated Coordinator", desc: "One point of contact throughout  -  keeping you informed every step of the way." },
];

export const relocationImportCtaBand = {
  heading: "Ready to start your import?",
  body: "Contact us as early as possible  -  import permits can take several weeks to process.",
  primary: { label: "Get Estimate", href: "/services/pricing?service=relocation&tier=import", icon: "calculate" },
  secondary: { label: "View Checklist", href: "/relocation/checklist" },
} as const;

// ── Export page ───────────────────────────────────────────────────────────

export const relocationExportHero = {
  imageSrc: "https://images.unsplash.com/photo-1552053831-71594a27632d?w=600&h=400&fit=crop&q=80",
  eyebrow: "Pet Export · Nigeria",
  title: "Moving Abroad<br/>with Your Pet?",
  subtitle:
    "We manage health certificates, export permits, IATA-approved crates, and airline coordination for a smooth international departure.",
  primaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=relocation&tier=export",
    icon: "calculate",
  },
  secondaryCta: { label: "View Checklist", href: "/relocation/checklist" },
};

export const relocationExportSectionHeading = {
  eyebrow: "Export Process",
  title: "Everything Covered<br/>Before Departure",
  subtitle:
    "Exporting a pet from Nigeria requires careful planning. We handle it all so your pet travels safely.",
};

export const relocationExportFeatures = [
  { icon: "description", title: "Export Health Certificate", desc: "Our vet issues an official government-endorsed health certificate valid for international travel." },
  { icon: "vaccines", title: "Vaccination Compliance", desc: "Review and update of vaccinations to meet the destination country's entry requirements." },
  { icon: "inventory_2", title: "IATA-Approved Crate", desc: "Supply and sizing of an IATA-compliant travel crate appropriate for your pet and the airline." },
  { icon: "flight_takeoff", title: "Airline Booking", desc: "We liaise with the airline to book your pet as cabin or cargo, and manage all airline paperwork." },
  { icon: "qr_code_scanner", title: "Microchip & Passport", desc: "Verification of microchip and preparation of a pet passport where required by the destination." },
  { icon: "support_agent", title: "Destination Guidance", desc: "Guidance on entry requirements at your destination country  -  so there are no surprises on arrival." },
];

export const relocationExportCtaBand = {
  heading: "Planning a move abroad?",
  body: "Contact us at least 6-8 weeks before your travel date to allow sufficient processing time.",
  primary: { label: "Get Estimate", href: "/services/pricing?service=relocation&tier=export", icon: "calculate" },
  secondary: { label: "View Checklist", href: "/relocation/checklist" },
} as const;

// ── Checklist page ────────────────────────────────────────────────────────
// Source: relocation/checklist.blade.php lines 7-69

export type ChecklistPhase = {
  heading: string;
  icon: string;
  items: string[];
};

export const relocationChecklistPhases: ChecklistPhase[] = [
  {
    heading: "3+ Months Before Travel",
    icon: "event_upcoming",
    items: [
      "Research the destination country's pet import requirements",
      "Confirm your pet is microchipped (ISO 11784/11785 standard)",
      "Check vaccination requirements  -  especially rabies",
      "Contact Waggies to begin the relocation process",
      "Book your travel and confirm airline pet policies",
    ],
  },
  {
    heading: "6-8 Weeks Before Travel",
    icon: "assignment",
    items: [
      "Apply for export permit from the Nigerian Federal Department of Livestock",
      "Book health examination with our on-site vet",
      "Order an IATA-approved travel crate (allow time for crate-training)",
      "Confirm destination country quarantine requirements",
      "Arrange travel insurance for your pet",
    ],
  },
  {
    heading: "2-4 Weeks Before Travel",
    icon: "checklist",
    items: [
      "Complete official veterinary health certificate (signed and endorsed)",
      "Confirm all vaccinations are within the required validity windows",
      "Confirm airline booking  -  cargo or cabin  -  with airline reference",
      "Prepare a comfort pack: familiar toy, blanket, and food for travel",
      "Check crate sizing meets airline and IATA requirements",
    ],
  },
  {
    heading: "Day of Travel",
    icon: "flight_takeoff",
    items: [
      "Arrive at the airport early  -  cargo check-in takes longer than passenger",
      "Carry all original documents in your hand luggage",
      "Do not feed your pet within 4 hours of the flight (unless advised otherwise)",
      "Attach a \"Live Animal\" label and your contact details to the crate",
      "Confirm collection arrangements at the destination",
    ],
  },
];

// ── Hero hub presets used by FAQ + checklist pages ────────────────────────
// Source: components/hero/hub.blade.php presets map

export const heroHubPresets = {
  faq: {
    eyebrow: "Help Centre",
    icon: "help",
    title: "Frequently Asked Questions",
    subtitle:
      "Quick answers to the questions we hear most often. Can't find what you need? Contact us directly.",
    image:
      "",
  },
  checklist: {
    eyebrow: "Relocation Checklist",
    icon: "checklist",
    title: "Your Pet Relocation Checklist",
    subtitle:
      "Stay on top of every requirement. Start early  -  some steps can take weeks to complete.",
    image:
      "https://images.unsplash.com/photo-1548199973-03d0b4fb1f8?w=1600&auto=format&fit=crop&q=80",
  },
} as const;
