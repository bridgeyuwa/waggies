export const careersHero = {
  imageSrc: "/images/careers-hero.jpg",
  eyebrow: "Careers",
  title: "Join the Waggies Pack",
  subtitle: "Build a career doing what you love — caring for pets in Abuja's premier pet care facility.",
  primaryCta: { label: "View Open Roles", href: "#open-roles" },
  secondaryCta: null,
};

export const careersPerksHeading = {
  eyebrow: "Why Waggies",
  title: "Perks & Benefits",
  subtitle: "We invest in our team because our people are the heart of everything we do.",
};

export const careersPerks = [
  { icon: "school", title: "Paid Training", desc: "Fully funded professional development and certification for all team members." },
  { icon: "favorite", title: "Do What You Love", desc: "Spend your working day doing something that genuinely matters to you." },
  { icon: "groups", title: "Great Team Culture", desc: "A tight-knit, supportive team that looks out for each other." },
  { icon: "trending_up", title: "Room to Grow", desc: "We promote from within and invest in the long-term careers of our staff." },
];

export const careersOpenRolesHeading = {
  eyebrow: "Open Roles",
  title: "Current Vacancies",
};

export const careersOpenRoles = [
  {
    role: "Pet Groomer",
    dept: "Grooming",
    type: "Full-time",
    applyHref: "/contact",
    applyLabel: "Apply Now",
  },
  {
    role: "Veterinary Technician",
    dept: "Veterinary",
    type: "Full-time",
    applyHref: "/contact",
    applyLabel: "Apply Now",
  },
  {
    role: "Kennel Attendant",
    dept: "Boarding",
    type: "Full-time",
    applyHref: "/contact",
    applyLabel: "Apply Now",
  },
  {
    role: "Dog Trainer",
    dept: "Training",
    type: "Part-time",
    applyHref: "/contact",
    applyLabel: "Apply Now",
  },
];

export const careersSpeculativeNote =
  "Don't see a role that fits? We're always open to hearing from passionate pet lovers. Send us your CV and we'll keep you in mind.";
