/**
 * Photo Gallery page content.
 *
 * The original Laravel site referenced 20 local image paths
 * (/images/gallery/boarding-*.jpg, grooming-*.jpg, guests-*.jpg)
 * that all 404'd on the live site.
 *
 * IMAGE STATUS: All gallery images are TODO(client).
 * These are documentary photographs of Waggies' actual facility,
 * team, and guests. They MUST come from the client.
 * No stock photography is acceptable for the gallery.
 *
 * The gallery section should render an empty-state message
 * when no valid images are available, rather than showing
 * broken images or misleading stock photos.
 */

// ── Page header ───────────────────────────────────────────────────────────

export type GalleryHero = {
  eyebrow: string;
  title: string;
  subtitle: string;
};

export const galleryHero: GalleryHero = {
  eyebrow: "Photo Gallery",
  title: "Take a Look Inside",
  subtitle:
    "Our facilities speak for themselves. Browse our boarding suites, grooming spa, play areas, and the happy faces of our guests.",
} as const;

// ── Gallery groups ────────────────────────────────────────────────────────

export type GalleryGroup = {
  eyebrow: string;
  title: string;
  headingClass: string;
  /**
   * Image paths - TODO(client): supply real facility/gallery photos.
   * Empty strings indicate pending client assets.
   */
  imagePaths: string[];
  altTemplate: string;
  cellClassName: string;
  imgClassName: string;
};

/**
 * All gallery images are pending client-supplied photographs.
 * Categories preserved from the original Laravel structure.
 */
export const galleryGroups: GalleryGroup[] = [
  {
    eyebrow: "Boarding",
    title: "Boarding Suites & Play Areas",
    headingClass: "mb-8",
    /* TODO(client): 8 boarding facility photos required */
    imagePaths: [],
    altTemplate: "Boarding facility photo {i}",
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },
  {
    eyebrow: "Grooming",
    title: "Grooming Spa",
    headingClass: "mb-8",
    /* TODO(client): 4 grooming spa photos required */
    imagePaths: [],
    altTemplate: "Grooming spa photo {i}",
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },
  {
    eyebrow: "Happy Guests",
    title: "Our Wonderful Guests",
    headingClass: "mb-8",
    /* TODO(client): 8 guest/pet photos required */
    imagePaths: [],
    altTemplate: "Happy guest photo {i}",
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },
];
