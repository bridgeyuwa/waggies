import Link from "next/link";
import { MaterialSymbol } from "./material-symbol";
import { BackToTopLink } from "./back-to-top-link";
import { NewsletterForm } from "./newsletter-form";
import { cn } from "@/lib/utils";
import {
  footerCopyright,
  footerLinkColumns,
  footerTagline,
  socialLinks,
} from "@/lib/site";
import { businessInfo } from "@/lib/business-info";

/**
 * Waggies Footer. Light mode only. Dark background variant.
 */

const OPERATING_HOURS = businessInfo.hoursGrouped;

const SOCIAL_ICONS: { label: string; href: string; icon: string }[] = [
  { label: "Instagram", href: businessInfo.socials.instagram, icon: "photo_camera" },
  { label: "Facebook", href: businessInfo.socials.facebook, icon: "public" },
  { label: "X / Twitter", href: businessInfo.socials.x, icon: "close" },
  { label: "LinkedIn", href: businessInfo.socials.linkedin, icon: "work" },
];

export function Footer() {
  return (
    <footer className="bg-primary-dark border-t border-white/10 mt-auto">

      <div className="mx-auto max-w-7xl px-4 sm:px-6 pt-12 pb-8 sm:pt-16 lg:px-8 lg:pt-20">
        {/* Newsletter strip */}
        <div className="mb-10 lg:mb-12 rounded-2xl p-6 sm:p-8 border bg-white/5 border-white/10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-10 items-center">
            <div>
              <h3 className="font-serif text-2xl sm:text-3xl font-bold mb-2 text-secondary">
                Newsletter
              </h3>
              <p className="text-sm sm:text-base max-w-md text-white/70">
                Pet care tips and updates from Waggies. No spam, unsubscribe anytime.
              </p>
            </div>
            <div>
              <NewsletterForm variant="inline" theme="dark" />
            </div>
          </div>
        </div>

        {/* Top section: Brand + Links + Hours */}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 lg:gap-6">
          {/* Brand column */}
          <div className="space-y-6 col-span-2">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center">
                <MaterialSymbol name="pets" filled />
              </div>
              <span className="font-serif font-bold text-white text-xl">Waggies</span>
            </Link>

            <p className="text-sm text-white/70 max-w-xs">{footerTagline}</p>

            {/* Social icons row */}
            <div className="flex gap-x-3">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className="w-9 h-9 rounded-full bg-white/10 border border-white/10 text-white/70 hover:bg-primary hover:text-white hover:border-primary transition-colors flex items-center justify-center"
                >
                  <span className="sr-only">{social.label}</span>
                  <svg
                    className="size-4"
                    fill="currentColor"
                    viewBox={social.label === "TikTok" ? "0 0 32 32" : "0 0 24 24"}
                    aria-hidden="true"
                  >
                    {social.svg}
                  </svg>
                </a>
              ))}
            </div>
          </div>

          {/* Services + Company + Support */}
          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Services
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[0].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                  >
                    <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Company
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[1].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                  >
                    <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Support
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[2].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                  >
                    <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Resources + Legal */}
          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Resources
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[4].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="flex items-center gap-1.5 text-sm text-white/60 hover:text-white transition-colors"
                  >
                    <span className="w-1.5 h-1.5 bg-primary-light/80 rounded-full flex-shrink-0" />
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Legal
            </h3>
            <ul className="space-y-3">
              {footerLinkColumns[3].links.map((link) => (
                <li key={link.href}>
                  <Link
                    href={link.href}
                    className="text-sm text-white/60 hover:text-white transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Operating Hours + Follow Us */}
          <div className="col-span-2">
            <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-4">
              Operating Hours
            </h3>
            <ul className="space-y-3">
              {OPERATING_HOURS.map((item) => (
                <li key={item.day} className="text-sm text-white/60">
                  <span className="font-medium">{item.day}</span>
                  <br />
                  <span className="text-white/50">{item.hours}</span>
                </li>
              ))}
            </ul>

            <div className="mt-6">
              <h3 className="font-bold text-secondary text-xs sm:text-sm uppercase tracking-widest mb-3">
                Follow Us
              </h3>
              <div className="flex gap-x-3">
                {SOCIAL_ICONS.map((social) => (
                  <a
                    key={social.label}
                    href={social.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="w-9 h-9 rounded-full bg-white/10 border border-white/10 text-white/70 hover:bg-primary hover:text-white hover:border-primary transition-colors flex items-center justify-center"
                    aria-label={social.label}
                  >
                    <MaterialSymbol name={social.icon} className="text-lg" />
                  </a>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-white/10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-xs sm:text-sm/6 text-white/50">{footerCopyright}</p>
          <BackToTopLink className="text-xs sm:text-sm text-white/60 hover:text-white" />
        </div>
      </div>
    </footer>
  );
}
