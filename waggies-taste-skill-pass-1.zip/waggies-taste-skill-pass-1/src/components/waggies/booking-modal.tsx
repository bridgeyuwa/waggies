"use client";

import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { MaterialSymbol } from "./material-symbol";

// ── Types ──────────────────────────────────────────────────────────────────

type BookingFormData = {
  ownerName: string;
  email: string;
  phone: string;
  petName: string;
  petType: string;
  service: string;
  preferredDate: string;
  notes: string;
};

const initialFormData: BookingFormData = {
  ownerName: "",
  email: "",
  phone: "",
  petName: "",
  petType: "",
  service: "",
  preferredDate: "",
  notes: "",
};

const petTypes = ["Dog", "Cat", "Bird", "Rabbit", "Other"] as const;
const services = [
  "Boarding",
  "Grooming",
  "Vet Care",
  "Training",
  "Transport",
  "Relocation",
] as const;

// ── Animation variants ─────────────────────────────────────────────────────

const contentVariants = {
  hidden: { opacity: 0, scale: 0.95, y: 10 },
  visible: {
    opacity: 1,
    scale: 1,
    y: 0,
    transition: { type: "spring" as const, damping: 25, stiffness: 300 },
  },
};

// ── BookingModal ───────────────────────────────────────────────────────────

export function BookingModal({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [formData, setFormData] = useState<BookingFormData>(initialFormData);
  const [submitted, setSubmitted] = useState(false);
  const shouldReduceMotion = useReducedMotion();

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    console.log("Booking form submitted:", formData);

    setSubmitted(true);
    toast.success("Booking request submitted!", {
      description:
        "We'll get back to you within 24 hours to confirm your appointment.",
      duration: 4000,
    });

    // Close dialog after 2 seconds
    setTimeout(() => {
      setSubmitted(false);
      setFormData(initialFormData);
      onOpenChange(false);
    }, 2000);
  }

  function updateField(field: keyof BookingFormData, value: string) {
    setFormData((prev) => ({ ...prev, [field]: value }));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent
        className="sm:max-w-2xl max-h-[90vh] overflow-y-auto bg-white border-surface-purple"
        showCloseButton
      >
        <motion.div
          variants={shouldReduceMotion ? undefined : contentVariants}
          initial={shouldReduceMotion ? false : "hidden"}
          animate={shouldReduceMotion ? false : "visible"}
        >
          <DialogHeader className="mb-2">
            <DialogTitle className="font-serif text-2xl text-primary-dark">
              Book a Consultation
            </DialogTitle>
            <DialogDescription className="text-primary-dark/60">
              Fill in the details below and we&apos;ll get back to you within 24
              hours.
            </DialogDescription>
          </DialogHeader>

          {submitted ? (
            <motion.div
              initial={shouldReduceMotion ? false : { opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="flex flex-col items-center justify-center py-12 text-center gap-4"
            >
              <div className="w-16 h-16 rounded-full bg-success/15 flex items-center justify-center">
                <MaterialSymbol
                  name="check_circle"
                  filled
                  className="text-3xl text-success"
                />
              </div>
              <h3 className="font-serif text-xl font-bold text-primary-dark">
                Booking Submitted!
              </h3>
              <p className="text-primary-dark/60 max-w-sm">
                Thank you! We&apos;ll contact you shortly to confirm your
                appointment.
              </p>
            </motion.div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5 pt-2">
              {/* Row: Owner Name + Email */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label
                    htmlFor="ownerName"
                    className="text-primary-dark font-semibold"
                  >
                    Pet Owner Name
                  </Label>
                  <Input
                    id="ownerName"
                    required
                    placeholder="Your full name"
                    value={formData.ownerName}
                    onChange={(e) => updateField("ownerName", e.target.value)}
                    className="border-surface-purple focus-visible:border-waggies-primary focus-visible:ring-waggies-primary/30"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label
                    htmlFor="email"
                    className="text-primary-dark font-semibold"
                  >
                    Email
                  </Label>
                  <Input
                    id="email"
                    type="email"
                    required
                    placeholder="you@example.com"
                    value={formData.email}
                    onChange={(e) => updateField("email", e.target.value)}
                    className="border-surface-purple focus-visible:border-waggies-primary focus-visible:ring-waggies-primary/30"
                  />
                </div>
              </div>

              {/* Row: Phone + Pet Name */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label
                    htmlFor="phone"
                    className="text-primary-dark font-semibold"
                  >
                    Phone
                  </Label>
                  <Input
                    id="phone"
                    type="tel"
                    required
                    placeholder="+234 800 000 0000"
                    value={formData.phone}
                    onChange={(e) => updateField("phone", e.target.value)}
                    className="border-surface-purple focus-visible:border-waggies-primary focus-visible:ring-waggies-primary/30"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label
                    htmlFor="petName"
                    className="text-primary-dark font-semibold"
                  >
                    Pet Name
                  </Label>
                  <Input
                    id="petName"
                    required
                    placeholder="Your pet's name"
                    value={formData.petName}
                    onChange={(e) => updateField("petName", e.target.value)}
                    className="border-surface-purple focus-visible:border-waggies-primary focus-visible:ring-waggies-primary/30"
                  />
                </div>
              </div>

              {/* Row: Pet Type + Service */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label className="text-primary-dark font-semibold">
                    Pet Type
                  </Label>
                  <Select
                    value={formData.petType}
                    onValueChange={(v) => updateField("petType", v)}
                    required
                  >
                    <SelectTrigger className="w-full border-surface-purple focus:ring-waggies-primary/30">
                      <SelectValue placeholder="Select pet type" />
                    </SelectTrigger>
                    <SelectContent>
                      {petTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-1.5">
                  <Label className="text-primary-dark font-semibold">
                    Service
                  </Label>
                  <Select
                    value={formData.service}
                    onValueChange={(v) => updateField("service", v)}
                    required
                  >
                    <SelectTrigger className="w-full border-surface-purple focus:ring-waggies-primary/30">
                      <SelectValue placeholder="Select a service" />
                    </SelectTrigger>
                    <SelectContent>
                      {services.map((svc) => (
                        <SelectItem key={svc} value={svc}>
                          {svc}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Preferred Date */}
              <div className="space-y-1.5">
                <Label
                  htmlFor="preferredDate"
                  className="text-primary-dark font-semibold"
                >
                  Preferred Date
                </Label>
                <Input
                  id="preferredDate"
                  type="date"
                  required
                  value={formData.preferredDate}
                  onChange={(e) =>
                    updateField("preferredDate", e.target.value)
                  }
                  className="border-surface-purple focus-visible:border-waggies-primary focus-visible:ring-waggies-primary/30"
                />
              </div>

              {/* Additional Notes */}
              <div className="space-y-1.5">
                <Label
                  htmlFor="notes"
                  className="text-primary-dark font-semibold"
                >
                  Additional Notes
                </Label>
                <Textarea
                  id="notes"
                  placeholder="Any special requirements, allergies, or preferences..."
                  rows={3}
                  value={formData.notes}
                  onChange={(e) => updateField("notes", e.target.value)}
                  className="border-surface-purple focus-visible:border-waggies-primary focus-visible:ring-waggies-primary/30"
                />
              </div>

              {/* Submit */}
              <Button
                type="submit"
                className="w-full bg-waggies-primary hover:bg-waggies-primary-dark text-white font-bold py-3 rounded-full shadow-sm transition-all"
                size="lg"
              >
                <MaterialSymbol
                  name="calendar_month"
                  className="text-lg mr-1"
                  ariaHidden={false}
                />
                Submit Booking Request
              </Button>
            </form>
          )}
        </motion.div>
      </DialogContent>
    </Dialog>
  );
}

// ── BookingModalTrigger ────────────────────────────────────────────────────

export function BookingModalTrigger({
  label = "Book Now",
  variant = "default",
  className = "",
}: {
  label?: string;
  variant?: "default" | "outline" | "secondary" | "ghost" | "link" | "destructive";
  className?: string;
}) {
  const [open, setOpen] = useState(false);

  return (
    <>
      <Button
        variant={variant}
        className={className}
        onClick={() => setOpen(true)}
        type="button"
      >
        <MaterialSymbol
          name="calendar_month"
          className="text-lg mr-1"
          ariaHidden={false}
        />
        {label}
      </Button>
      <BookingModal open={open} onOpenChange={setOpen} />
    </>
  );
}
