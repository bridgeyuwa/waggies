/**
 * Per-page JSON-LD structured data helpers.
 *
 * Reproduces the `@push('head')` schema blocks emitted by individual Laravel
 * Blade pages (services/pricing/relocation/etc). The Laravel site uses the
 * Spatie schema-org package; we hand-emit equivalent JSON-LD.
 *
 * Each helper returns a JSON-LD object that page components render inside a
 * <script type="application/ld+json"> tag.
 */

import { siteConfig } from "@/lib/site";

const BASE = siteConfig.siteUrl;

/** WebSite schema - emitted on the homepage. */
export function websiteSchema() {
  return {
    "@context": "https://schema.org",
    "@type": "WebSite",
    name: "Waggies",
    description:
      "Abuja's most trusted luxury pet boarding, grooming, vet care and relocation specialists.",
    url: BASE,
  };
}

/** WebPage schema - emitted on services index, pricing, checklist pages. */
export function webPageSchema(name: string, description: string, url: string) {
  return {
    "@context": "https://schema.org",
    "@type": "WebPage",
    name,
    description,
    url,
  };
}

/** Service schema - emitted on service & relocation pages. */
export function serviceSchema(
  name: string,
  description: string,
  url: string,
  areaServed = "Abuja, Nigeria",
) {
  return {
    "@context": "https://schema.org",
    "@type": "Service",
    name,
    description,
    url,
    provider: {
      "@type": "Organization",
      name: "Waggies",
      url: BASE,
    },
    areaServed,
  };
}

/** FAQPage schema - emitted on the FAQ page. */
export function faqPageSchema(
  faqs: ReadonlyArray<{ question: string; answer: string }>,
) {
  return {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((f) => ({
      "@type": "Question",
      name: f.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: f.answer,
      },
    })),
  };
}

/** Helper to render JSON-LD as a <script> tag. */
export function JsonLd({ data }: { data: object }) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

/** ContactPage schema - emitted on /contact. Mirrors Spatie's Schema::contactPage(). */
export function contactPageSchema(name: string, description: string, url: string) {
  return {
    "@context": "https://schema.org",
    "@type": "ContactPage",
    name,
    description,
    url,
  };
}

/** AboutPage schema - emitted on /about. Mirrors Spatie's Schema::aboutPage(). */
export function aboutPageSchema(name: string, description: string, url: string) {
  return {
    "@context": "https://schema.org",
    "@type": "AboutPage",
    name,
    description,
    url,
  };
}

/** Blog schema - emitted on /blog index. Mirrors Spatie's Schema::blog(). */
export function blogSchema(name: string, description: string, url: string) {
  return {
    "@context": "https://schema.org",
    "@type": "Blog",
    name,
    description,
    url,
    publisher: {
      "@type": "Organization",
      name: "Waggies",
      url: BASE,
    },
  };
}

/** CollectionPage schema - emitted on blog/category, guides, kb listing pages. */
export function collectionPageSchema(name: string, url: string, description?: string) {
  return {
    "@context": "https://schema.org",
    "@type": "CollectionPage",
    name,
    description,
    url,
  };
}

/** BlogPosting schema - emitted on /blog/{slug}. Mirrors Spatie's Schema::blogPosting(). */
export function blogPostingSchema(opts: {
  headline: string;
  description?: string;
  author?: string;
  datePublished?: string;
  url: string;
  image?: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "BlogPosting",
    headline: opts.headline,
    description: opts.description,
    author: opts.author
      ? { "@type": "Person", name: opts.author }
      : undefined,
    datePublished: opts.datePublished,
    url: opts.url,
    publisher: { "@type": "Organization", name: "Waggies", url: BASE },
    image: opts.image,
  };
}

/** Article schema - emitted on /guides/{slug} and /knowledge-base/{slug}. */
export function articleSchema(opts: {
  headline: string;
  description?: string;
  url: string;
  image?: string;
}) {
  return {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: opts.headline,
    description: opts.description,
    url: opts.url,
    publisher: { "@type": "Organization", name: "Waggies", url: BASE },
    image: opts.image,
  };
}

/** BreadcrumbList schema - emitted on every major page for SEO navigation. */
export function breadcrumbListSchema(
  items: ReadonlyArray<{ name: string; path: string }>,
) {
  return {
    "@context": "https://schema.org",
    "@type": "BreadcrumbList",
    itemListElement: items.map((item, i) => ({
      "@type": "ListItem",
      position: i + 1,
      name: item.name,
      item: `${BASE}${item.path}`,
    })),
  };
}
