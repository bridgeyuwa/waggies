/**
 * AboutTeamCard - React port of resources/views/components/about/team-card.blade.php
 *
 * Card with image + badge + name + role + bio + role badges + "View profile" link.
 * Used by the About index page.
 *
 */

import { type ReactNode } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type AboutTeamCardProps = {
  name: string;
  role: string;
  image: string;
  badge?: string | null;
  roles?: readonly string[];
  children?: ReactNode;
};

export function AboutTeamCard({
  name,
  role,
  image,
  badge,
  roles = [],
  children,
}: AboutTeamCardProps) {
  const hasImage = Boolean(image);

  return (
    <div className="group relative bg-white rounded-2xl overflow-hidden border border-surface-purple shadow-sm hover:shadow-soft transition">
      {/* IMAGE */}
      <div className="relative aspect-[4/5] overflow-hidden bg-surface-purple">
        {hasImage ? (
          <>
            <img
              src={image}
              alt={name}
              loading="lazy"
              className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-[1.03]"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-primary-dark/10 via-transparent to-transparent" />
          </>
        ) : (
          <div
            className="w-full h-full flex items-center justify-center"
            role="img"
            aria-label={`Photo of ${name}`}
          >
            <MaterialSymbol name="person" className="text-primary/15 text-6xl" />
          </div>
        )}

        {badge ? (
          <div className="absolute top-4 left-4 bg-white/90 backdrop-blur text-primary px-3 py-1.5 rounded-full text-xs font-semibold shadow-sm">
            {badge}
          </div>
        ) : null}
      </div>

      {/* CONTENT */}
      <div className="p-6 flex flex-col gap-4">
        <div className="space-y-1">
          <h3 className="text-primary-dark font-bold font-serif text-xl leading-tight">
            {name}
          </h3>
          <p className="text-primary text-sm font-medium tracking-wide">{role}</p>
        </div>

        {children ? (
          <p className="text-primary-dark/60 text-sm leading-relaxed line-clamp-2">
            {children}
          </p>
        ) : null}

        {roles && roles.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            {roles.map((r) => (
              <span
                key={r}
                className="text-[10px] uppercase tracking-wide text-primary-dark/60 border border-primary/20 px-2 py-1 rounded-lg"
              >
                {r}
              </span>
            ))}
          </div>
        ) : null}

        {/* CTA */}
        <div className="pt-4 border-t border-primary/10">
          <a
            href="#"
            className="inline-flex items-center gap-2 text-primary font-semibold text-sm uppercase tracking-wide hover:text-primary-dark transition-colors"
          >
            View profile
            <MaterialSymbol
              name="arrow_forward"
              className="text-sm transition-transform duration-200 group-hover:translate-x-0.5"
            />
          </a>
        </div>
      </div>
    </div>
  );
}
