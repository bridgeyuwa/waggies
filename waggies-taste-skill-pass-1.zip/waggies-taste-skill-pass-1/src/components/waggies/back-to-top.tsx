"use client";

import { useEffect, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { MaterialSymbol } from "./material-symbol";

/**
 * Back-to-Top Button - appears when the user scrolls down more than 400px.
 *
 * Position: fixed bottom-20 right-6 (above the WhatsApp FAB which is at
 * bottom-16 right-6).
 *
 * Uses framer-motion AnimatePresence for smooth entrance/exit animation.
 * Styled with Waggies purple (bg-waggies-primary) with a white icon.
 * Accessible: aria-label="Scroll to top".
 */
export function BackToTop() {
  const [visible, setVisible] = useState(false);
  const shouldReduceMotion = useReducedMotion();

  useEffect(() => {
    function handleScroll() {
      setVisible(window.scrollY > 400);
    }

    // Check initial scroll position
    handleScroll();

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  function scrollToTop() {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <AnimatePresence>
      {visible && (
        <motion.button
          initial={shouldReduceMotion ? false : { opacity: 0, scale: 0.8, y: 10 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={shouldReduceMotion ? undefined : { opacity: 0, scale: 0.8, y: 10 }}
          transition={{ type: "spring", damping: 20, stiffness: 300, duration: shouldReduceMotion ? 0 : undefined }}
          onClick={scrollToTop}
          aria-label="Scroll to top"
          className="fixed bottom-20 right-6 z-40 w-12 h-12 rounded-full bg-waggies-primary text-white shadow-sm flex items-center justify-center transition-shadow hover:shadow-lg hover:bg-waggies-primary-dark focus:outline-none focus:ring-2 focus:ring-waggies-primary/50 focus:ring-offset-2"
        >
          <MaterialSymbol name="keyboard_arrow_up" className="text-2xl" />
        </motion.button>
      )}
    </AnimatePresence>
  );
}
