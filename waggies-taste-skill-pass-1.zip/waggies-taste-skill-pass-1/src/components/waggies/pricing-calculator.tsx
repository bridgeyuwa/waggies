"use client";

/**
 * Pricing Calculator - React port of the Alpine `pricingCalculator` state
 * machine in resources/js/waggies.js.
 *
 * ════════════════════════════════════════════════════════════════════════
 *  STATE SHAPE (mirrors Alpine exactly)
 * ════════════════════════════════════════════════════════════════════════
 *
 *   services:        Record<string, PricingService>   (from config/waggies.php)
 *   service:         string                            (selected service key)
 *   variant:         string                            (selected variant key)
 *   tier:            string                            (selected tier key)
 *   quantity:        number                            (default 1)
 *   step:            'form' | 'result'
 *   result:          null | PricingResult
 *   contactBase:     string                            ('/contact')
 *   initialService:  string                            (locks service if preselected)
 *
 * ════════════════════════════════════════════════════════════════════════
 *  ENHANCEMENTS (polish pass)
 * ════════════════════════════════════════════════════════════════════════
 *
 *  • Animated price total - number counts up/down with framer-motion's
 *    `animate()` between the previous and new totals (fixed tiers) or
 *    low/high bounds (estimate tiers).
 *  • Price breakdown - the result panel now lists the tier's `features`
 *    (included / not included) in a left column.
 *  • Save indicator - when the selected tier is featured AND a more
 *    expensive tier exists in the same option group, we show a green
 *    "You saved ₦X" badge comparing the totals.
 *  • Smooth transitions - framer-motion AnimatePresence wraps the form
 *    and result panels; service selection cards animate with motion.div.
 *  • Sticky summary - on desktop (lg+), the result panel's right column
 *    (price + CTAs) is `lg:sticky lg:top-24` so it stays in view as the
 *    user scrolls through the features breakdown on the left.
 *
 *  The core calculation formula is UNCHANGED - see `doCalculate()` below.
 */

import { useEffect, useMemo, useRef, useState } from "react";
import { AnimatePresence, motion, useMotionValue, useTransform, animate as fmAnimate } from "framer-motion";
import {
  contactUrl as buildContactUrl,
  formatNaira,
  pricingConfig,
  resolveServiceContext,
  type PricingFeature,
  type PricingService,
  type PricingTier,
} from "@/data/pricing";
import { MaterialSymbol } from "./material-symbol";
import { SectionHeading } from "./section-heading";

// ── Types ──────────────────────────────────────────────────────────────────

type TierType = "fixed" | "estimate" | "quote";

type PricingResult = {
  display: string;
  /** May contain HTML (the `(qty × ₦X)` suffix uses a <span>). */
  summary: string;
  type: TierType;
  primaryCta: string;
  primaryIntent: "book" | "consult";
  serviceLabel: string;
  tierLabel: string;
  /** Numeric total (or low bound for estimates). Used by the animated counter. */
  numericTotal: number | null;
  /** Numeric high bound for estimates (same as numericTotal for fixed tiers). */
  numericHigh: number | null;
  /** Features included/excluded in this tier - rendered in the breakdown. */
  features: PricingFeature[];
  /** Savings vs the most expensive tier in the same option group (null = N/A). */
  savingsAmount: number | null;
  savingsComparisonLabel: string | null;
};

// ── Component ──────────────────────────────────────────────────────────────

export type PricingCalculatorProps = {
  /** Initial query params from the URL (server-side resolved). */
  service?: string | null;
  variant?: string | null;
  tier?: string | null;
};

export function PricingCalculator({
  service: initialServiceParam,
  variant: initialVariantParam,
  tier: initialTierParam,
}: PricingCalculatorProps = {}) {
  // Resolve alias context (e.g. "boarding-dogs" → service="boarding", variant="dogs")
  // exactly like PricingQuote::resolveServiceContext() in the Laravel controller.
  const resolved = useMemo(
    () => resolveServiceContext(initialServiceParam ?? null, initialVariantParam ?? null),
    [initialServiceParam, initialVariantParam],
  );

  // ── Alpine state ────────────────────────────────────────────────────────
  const services = pricingConfig.services;
  const initialService = resolved.service; // empty string = no preselect
  const initialTier = initialTierParam ?? null;

  const [service, setService] = useState<string>(initialService);
  const [variant, setVariant] = useState<string>(resolved.variant ?? "");
  const [tier, setTier] = useState<string>(initialTier ?? "");
  const [quantity, setQuantity] = useState<number>(1);
  const [step, setStep] = useState<"form" | "result">("form");
  const [result, setResult] = useState<PricingResult | null>(null);

  // ── init() - Alpine's init() runs on mount ──────────────────────────────
  const calcSectionRef = useRef<HTMLElement | null>(null);
  const decisionRef = useRef<HTMLDivElement | null>(null);

  // ── Computed getters ────────────────────────────────────────────────────
  const lockedService = Boolean(initialService);
  const currentService: PricingService | null = service ? services[service] : null;
  const hasVariants = Boolean(
    currentService?.variants && Object.keys(currentService.variants).length > 0,
  );

  const tierOptions: Record<string, PricingTier> = useMemo(() => {
    if (!currentService) return {};
    if (hasVariants) {
      return variant && currentService.variants?.[variant]
        ? currentService.variants[variant].tiers
        : {};
    }
    return currentService.tiers ?? {};
  }, [currentService, hasVariants, variant]);

  const hasTierOptions = Object.keys(tierOptions).length > 0;
  const currentTier: PricingTier | null = tier ? tierOptions[tier] : null;
  const showQuantity = Boolean(currentService?.quantity_label);
  const quantityMin = currentService?.quantity_min ?? 1;
  const quantityMax = currentService?.quantity_max ?? 99;

  const canCalc = canCalculate(currentService, service, variant, tier);

  const primaryActionLabel = (() => {
    const type = currentTier?.type;
    if (type === "quote") return "Request Consultation";
    if (type === "estimate") return "Get Estimate Range";
    return "Calculate Price";
  })();

  // ── Methods ─────────────────────────────────────────────────────────────
  function onServiceChange(next: string) {
    setService(next);
    setVariant("");
    setTier("");
  }

  function buildServiceLabel(): string {
    let label = currentService?.label ?? "";
    if (variant && currentService?.variants?.[variant]) {
      label += " - " + currentService.variants[variant].label;
    }
    return label;
  }

  function doCalculate() {
    const t = currentTier;
    if (!t) return;
    const svc = currentService;
    if (!svc) return;

    const qty = showQuantity ? Math.max(quantityMin, quantity) : 1;
    let display = "";
    let summary = "";
    let primaryCta = "Book Now";
    let primaryIntent: "book" | "consult" = "book";
    let numericTotal: number | null = null;
    let numericHigh: number | null = null;

    if (t.type === "fixed" && t.amount > 0) {
      const total = t.amount * qty;
      display = formatNaira(total);
      if (qty > 1) {
        display += ` <span class="text-base font-normal text-primary-dark/50">(${qty} × ${formatNaira(t.amount)})</span>`;
      }
      summary = `${t.label}: ${formatNaira(total)}${svc.unit || ""}`;
      primaryCta = "Book Now";
      primaryIntent = "book";
      numericTotal = total;
      numericHigh = total;
    } else if (t.type === "estimate") {
      const low = t.amount * (showQuantity ? qty : 1);
      // Match Alpine's `tier.amount_max || tier.amount` (waggies.js line 129):
      // `||` falls back on any falsy value (including 0), `??` would only
      // fall back on null/undefined. No current estimate tier has
      // amount_max=0, but we match Alpine exactly to preserve behavior
      // should the config change.
      const high = (t.amount_max || t.amount) * (showQuantity ? qty : 1);
      display = `${formatNaira(low)} - ${formatNaira(high)}`;
      summary = `${t.label}: ${formatNaira(low)} - ${formatNaira(high)}`;
      primaryCta = "Proceed";
      primaryIntent = "book";
      numericTotal = low;
      numericHigh = high;
    } else {
      // quote
      display = "Custom quote required";
      summary = `${t.label}: custom quote`;
      primaryCta = "Request Consultation";
      primaryIntent = "consult";
      numericTotal = null;
      numericHigh = null;
    }

    // ── Savings computation ──────────────────────────────────────────────
    // We compare the selected tier's effective price to the most expensive
    // tier in the same option group (i.e. among `tierOptions`). We only
    // surface savings when:
    //   1. The selected tier has a positive amount (so the comparison is meaningful)
    //   2. A more expensive sibling tier exists
    //   3. The selected tier is `featured` (the badge is the marketing hook
    //      that justifies the "Save ₦X vs Y" framing - without it the user
    //      would just be looking at a cheaper tier, which is not a "saving")
    //
    // The savings amount is multiplied by `qty` to mirror the per-tier total
    // math above.
    let savingsAmount: number | null = null;
    let savingsComparisonLabel: string | null = null;
    if (t.amount > 0 && Object.keys(tierOptions).length > 1) {
      const siblings = Object.values(tierOptions);
      const mostExpensive = siblings.reduce((acc, sib) =>
        sib.amount > acc.amount ? sib : acc,
      );
      if (mostExpensive.amount > t.amount && (t.featured || mostExpensive.featured)) {
        const perUnitDiff = mostExpensive.amount - t.amount;
        const unitQty = t.type === "estimate"
          ? (showQuantity ? qty : 1)
          : (showQuantity ? qty : 1);
        savingsAmount = perUnitDiff * unitQty;
        savingsComparisonLabel = mostExpensive.label;
      }
    }

    setResult({
      display,
      summary,
      type: t.type,
      primaryCta,
      primaryIntent,
      serviceLabel: buildServiceLabel(),
      tierLabel: t.label,
      numericTotal,
      numericHigh,
      features: t.features ?? [],
      savingsAmount,
      savingsComparisonLabel,
    });
    setStep("result");

    // $nextTick: scroll decision into view
    requestAnimationFrame(() => {
      decisionRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  // ── init() effect - runs once on mount ─────────────────────────────────
  // Mirrors Alpine's `init()` method (waggies.js lines 13-27):
  //   - if initialService set, scrollIntoView the calculator
  //   - if initialTier set AND canCalculate, calculate() on nextTick
  //
  // We intentionally pass `[]` as deps so this only runs once on mount.
  // The closure captures the initial render's state, which is exactly the
  // URL-resolved state we want to seed the calculation with.
  useEffect(() => {
    // Alpine init(): scroll to calculator if a service was preselected.
    if (initialService) {
      requestAnimationFrame(() => {
        calcSectionRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }

    // Alpine init(): if a tier was preselected AND we can calculate, do so.
    if (initialTier && tier) {
      const svc = services[service];
      if (svc && canCalculate(svc, service, variant, tier)) {
        requestAnimationFrame(() => {
          doCalculate();
        });
      }
    }
     
  }, []);

  function reset() {
    setStep("form");
    setResult(null);
  }

  function contactUrl(intent: "book" | "save" | "consult"): string {
    return buildContactUrl(intent, {
      service: service || null,
      variant: variant || null,
      tier: tier || null,
      quantity: showQuantity ? String(quantity) : null,
      summary: result?.summary ?? null,
    });
  }

  // ── Render ──────────────────────────────────────────────────────────────
  return (
    <section
      id="pricing-calculator"
      ref={calcSectionRef}
      className="py-16 bg-surface-purple scroll-mt-24"
    >
      <div className="max-w-5xl mx-auto px-4 md:px-10 lg:px-12">
        <SectionHeading
          eyebrow="Pricing Tool"
          title="Get Your Estimate"
          subtitle="Select your service and package - we'll show a clear price or quote range and next steps."
        />

        <AnimatePresence mode="wait" initial={false}>
          {/* ──────────────────────────────────────────────────────────────
              FORM STEP
              ──────────────────────────────────────────────────────────── */}
          {step === "form" ? (
            <motion.div
              key="form-step"
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3, ease: [0.25, 0.1, 0.25, 1] }}
              className="mt-10"
            >
              <div className="bg-white rounded-2xl border border-surface-purple shadow-soft p-6 md:p-8">
                <div className="flex flex-col gap-5">
                  {/* Service selector - hidden when locked */}
                  {!lockedService ? (
                    <div>
                      <label htmlFor="calc-service" className="block text-sm font-semibold text-primary-dark mb-2">
                        Service
                      </label>
                      <select
                        id="calc-service"
                        value={service}
                        onChange={(e) => onServiceChange(e.target.value)}
                        className="w-full rounded-xl border border-surface-purple px-4 py-3 text-primary-dark focus:ring-2 focus:ring-primary/40 focus:border-primary"
                      >
                        <option value="">Choose a service…</option>
                        {Object.entries(services).map(([key, svc]) => (
                          <option key={key} value={key}>
                            {svc.label}
                          </option>
                        ))}
                      </select>
                    </div>
                  ) : null}

                  {/* Locked service display */}
                  {lockedService && currentService ? (
                    <div>
                      <p className="text-sm font-semibold text-primary-dark/60 mb-1">Service</p>
                      <p className="text-lg font-bold text-primary-dark">{currentService.label}</p>
                    </div>
                  ) : null}

                  {/* Variant selector */}
                  {hasVariants ? (
                    <div>
                      <label htmlFor="calc-variant" className="block text-sm font-semibold text-primary-dark mb-2">
                        Pet type
                      </label>
                      <select
                        id="calc-variant"
                        value={variant}
                        onChange={(e) => {
                          setVariant(e.target.value);
                          setTier("");
                        }}
                        className="w-full rounded-xl border border-surface-purple px-4 py-3 text-primary-dark focus:ring-2 focus:ring-primary/40 focus:border-primary"
                      >
                        <option value="">Choose…</option>
                        {currentService?.variants
                          ? Object.entries(currentService.variants).map(([key, v]) => (
                              <option key={key} value={key}>
                                {v.label}
                              </option>
                            ))
                          : null}
                      </select>
                    </div>
                  ) : null}

                  {/* Tier selector - animated cards instead of a dropdown for polish */}
                  {hasTierOptions ? (
                    <div>
                      <label className="block text-sm font-semibold text-primary-dark mb-2">
                        Package
                      </label>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        {Object.entries(tierOptions).map(([key, t]) => {
                          const selected = tier === key;
                          return (
                            <motion.button
                              key={key}
                              type="button"
                              onClick={() => setTier(key)}
                              whileHover={{ y: -2 }}
                              whileTap={{ scale: 0.98 }}
                              transition={{ duration: 0.15 }}
                              className={`text-left p-4 rounded-xl border-2 transition relative overflow-hidden
                                ${selected
                                  ? "border-primary bg-primary/5 shadow-sm"
                                  : "border-surface-purple hover:border-primary/40 bg-white"}`}
                              aria-pressed={selected}
                            >
                              <div className="flex items-start justify-between gap-2">
                                <div>
                                  <p className="font-bold text-primary-dark text-sm">{t.label}</p>
                                  <p className="text-xs text-primary-dark/60 mt-0.5">
                                    {t.type === "fixed"
                                      ? formatNaira(t.amount)
                                      : t.type === "estimate"
                                        ? `${formatNaira(t.amount)} - ${formatNaira(t.amount_max || t.amount)}`
                                        : "Custom quote"}
                                  </p>
                                </div>
                                {t.badge ? (
                                  <span className="shrink-0 text-[10px] font-bold uppercase tracking-wider bg-primary/10 text-primary px-2 py-0.5 rounded-full">
                                    {t.badge}
                                  </span>
                                ) : null}
                              </div>
                              {selected ? (
                                <motion.span
                                  layoutId="tier-check"
                                  className="absolute top-3 right-3 w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center"
                                  initial={{ scale: 0 }}
                                  animate={{ scale: 1 }}
                                  transition={{ type: "spring", stiffness: 400, damping: 20 }}
                                >
                                  <MaterialSymbol name="check" className="text-sm" />
                                </motion.span>
                              ) : null}
                            </motion.button>
                          );
                        })}
                      </div>
                    </div>
                  ) : null}

                  {/* Quantity input */}
                  {showQuantity ? (
                    <div>
                      <label htmlFor="calc-qty" className="block text-sm font-semibold text-primary-dark mb-2">
                        {currentService?.quantity_label}
                      </label>
                      <input
                        id="calc-qty"
                        type="number"
                        value={quantity}
                        min={quantityMin}
                        max={quantityMax}
                        onChange={(e) => setQuantity(Number(e.target.value))}
                        className="w-full rounded-xl border border-surface-purple px-4 py-3 text-primary-dark focus:ring-2 focus:ring-primary/40 focus:border-primary"
                      />
                    </div>
                  ) : null}

                  <motion.button
                    type="button"
                    onClick={doCalculate}
                    disabled={!canCalc}
                    whileHover={canCalc ? { scale: 1.01 } : undefined}
                    whileTap={canCalc ? { scale: 0.99 } : undefined}
                    className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark disabled:opacity-50 disabled:pointer-events-none text-white px-8 py-4 rounded-full font-bold transition shadow-sm w-full sm:w-auto"
                  >
                    {primaryActionLabel}
                    <MaterialSymbol name="calculate" ariaHidden />
                  </motion.button>
                </div>
              </div>
            </motion.div>
          ) : null}

          {/* ──────────────────────────────────────────────────────────────
              RESULT STEP
              ──────────────────────────────────────────────────────────── */}
          {step === "result" && result ? (
            <motion.div
              key="result-step"
              ref={decisionRef}
              id="pricing-decision"
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.35, ease: [0.25, 0.1, 0.25, 1] }}
              className="mt-10"
            >
              <div className="bg-white rounded-2xl border-2 border-primary shadow-soft overflow-hidden">
                {/* ── Two-column layout on desktop ── */}
                <div className="grid grid-cols-1 lg:grid-cols-[1.4fr_1fr]">
                  {/* ── LEFT: Breakdown of what's included ── */}
                  <div className="p-6 md:p-8 border-b lg:border-b-0 lg:border-r border-surface-purple">
                    <p className="text-xs font-bold uppercase tracking-widest text-primary/60 mb-2">
                      Your estimate
                    </p>
                    <p className="text-sm text-primary-dark/60 mb-1">{result.serviceLabel}</p>
                    <p className="text-sm text-primary-dark/50 mb-6">{result.tierLabel}</p>

                    <h3 className="font-serif text-lg font-bold text-primary-dark mb-4 flex items-center gap-2">
                      <MaterialSymbol name="checklist" className="text-primary" />
                      What&apos;s included
                    </h3>
                    <AnimatePresence mode="popLayout">
                      <motion.ul
                        key={`${service}-${variant}-${tier}`}
                        initial="hidden"
                        animate="show"
                        variants={{
                          hidden: {},
                          show: { transition: { staggerChildren: 0.05 } },
                        }}
                        className="space-y-2.5"
                      >
                        {result.features.map((f, i) => (
                          <motion.li
                            key={i}
                            variants={{
                              hidden: { opacity: 0, x: -8 },
                              show: { opacity: 1, x: 0 },
                            }}
                            className={`flex items-start gap-2.5 text-sm ${f.included ? "text-primary-dark" : "text-primary-dark/40 line-through"}`}
                          >
                            <span
                              className={`shrink-0 w-5 h-5 rounded-full flex items-center justify-center mt-0.5
                                ${f.included ? "bg-success/15 text-success" : "bg-surface-purple text-primary-dark/40"}`}
                            >
                              <MaterialSymbol
                                name={f.included ? "check" : "close"}
                                className="text-sm"
                              />
                            </span>
                            <span className="leading-relaxed">{f.label}</span>
                          </motion.li>
                        ))}
                      </motion.ul>
                    </AnimatePresence>

                    <button
                      type="button"
                      onClick={reset}
                      className="mt-6 text-sm text-primary font-medium hover:underline inline-flex items-center gap-1"
                    >
                      <MaterialSymbol name="arrow_back" className="text-base" />
                      Start over
                    </button>
                  </div>

                  {/* ── RIGHT: Sticky price summary ── */}
                  <div className="p-6 md:p-8 bg-surface-purple/40 lg:sticky lg:top-24 lg:self-start">
                    <p className="text-xs font-bold uppercase tracking-widest text-primary/60 mb-3">
                      Price summary
                    </p>

                    {/* Animated price */}
                    <AnimatedPrice
                      type={result.type}
                      total={result.numericTotal}
                      high={result.numericHigh}
                      fallbackDisplay={result.display}
                    />

                    <p className="text-sm text-primary-dark/60 mt-2 mb-1">{result.tierLabel}</p>
                    <p className="text-xs text-primary-dark/40 mb-5">
                      {result.serviceLabel}
                    </p>

                    {/* Save indicator */}
                    <AnimatePresence>
                      {result.savingsAmount && result.savingsAmount > 0 && result.savingsComparisonLabel ? (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.9, y: -4 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0, scale: 0.9 }}
                          transition={{ type: "spring", stiffness: 300, damping: 22 }}
                          className="mb-5 inline-flex items-center gap-2 bg-success/15 text-success px-3 py-1.5 rounded-full text-xs font-bold"
                        >
                          <MaterialSymbol name="savings" className="text-sm" />
                          You saved {formatNaira(result.savingsAmount)}
                          <span className="font-normal text-success/70">
                            vs {result.savingsComparisonLabel}
                          </span>
                        </motion.div>
                      ) : null}
                    </AnimatePresence>

                    {/* CTAs */}
                    <div className="flex flex-col gap-3">
                      <a
                        href={contactUrl(result.primaryIntent || "book")}
                        className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3.5 rounded-full font-bold transition shadow-sm"
                      >
                        {result.primaryCta || "Book Now"}
                        <MaterialSymbol name="arrow_forward" className="text-base" />
                      </a>
                      <a
                        href={contactUrl("save")}
                        className="inline-flex items-center justify-center gap-2 border-2 border-primary text-primary hover:bg-primary hover:text-white px-6 py-3.5 rounded-full font-semibold transition"
                      >
                        Save Estimate
                      </a>
                      <a
                        href={contactUrl("consult")}
                        className="inline-flex items-center justify-center gap-2 bg-white text-primary-dark hover:bg-primary/10 px-6 py-3.5 rounded-full font-semibold transition"
                      >
                        Talk to Expert
                      </a>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          ) : null}
        </AnimatePresence>
      </div>
    </section>
  );
}

// ── AnimatedPrice - counts up/down between previous and new totals ─────────
//
// For "fixed" tiers we animate a single number; for "estimate" tiers we
// animate the low and high bounds in parallel; for "quote" tiers we just
// render the static "Custom quote required" text (no animation possible).

function AnimatedPrice({
  type,
  total,
  high,
  fallbackDisplay,
}: {
  type: TierType;
  total: number | null;
  high: number | null;
  fallbackDisplay: string;
}) {
  if (type === "quote" || total === null) {
    return (
      <p
        className="font-serif text-3xl md:text-4xl font-bold text-primary-dark mb-2"
        dangerouslySetInnerHTML={{ __html: fallbackDisplay }}
      />
    );
  }

  if (type === "estimate" && high !== null) {
    return (
      <p className="font-serif text-3xl md:text-4xl font-bold text-primary-dark mb-2 tabular-nums">
        <AnimatedNumber value={total} prefix="₦" />
        <span className="mx-1 text-primary-dark/40">-</span>
        <AnimatedNumber value={high} prefix="₦" />
      </p>
    );
  }

  // fixed
  return (
    <p className="font-serif text-3xl md:text-4xl font-bold text-primary-dark mb-2 tabular-nums">
      <AnimatedNumber value={total} prefix="₦" />
    </p>
  );
}

// ── AnimatedNumber - framer-motion driven counter from prev → next value ──
function AnimatedNumber({
  value,
  prefix = "",
  duration = 0.6,
}: {
  value: number;
  prefix?: string;
  duration?: number;
}) {
  const mv = useMotionValue(0);
  const text = useTransform(mv, (v) => `${prefix}${Math.round(v).toLocaleString("en-NG")}`);

  useEffect(() => {
    const controls = fmAnimate(mv, value, {
      duration,
      ease: [0.25, 0.1, 0.25, 1],
    });
    return () => controls.stop();
  }, [value, mv, duration]);

  return <motion.span>{text}</motion.span>;
}

// ── Pure helpers (mirrors Alpine getter logic, extracted for clarity) ──────

function canCalculate(
  currentService: PricingService | null,
  service: string,
  variant: string,
  tier: string,
): boolean {
  // Match Alpine's `canCalculate` getter exactly (waggies.js lines 74-82):
  //   if (!this.service || !this.tier) return false;
  //   if (this.hasVariants && !this.variant) return false;
  //   return true;
  // Alpine does NOT check `this.currentService` - an invalid service string
  // still satisfies `!!service`, so the button enables. calculate() then
  // returns early because currentTier is null. We mirror that behavior.
  if (!service || !tier) return false;
  const hasVariants = Boolean(
    currentService?.variants && Object.keys(currentService.variants).length > 0,
  );
  if (hasVariants && !variant) return false;
  return true;
}
