"use client";

import type { Pet } from "@/store/pet-store";
import { computeAge, speciesLabel, speciesIcon, sexLabel } from "@/store/pet-store";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type PetProfileCardProps = {
  pet: Pet;
  onEdit: (pet: Pet) => void;
  onDelete: (id: string) => void;
};

export function PetProfileCard({ pet, onEdit, onDelete }: PetProfileCardProps) {
  const age = computeAge(pet.dateOfBirth);

  return (
    <div className="bg-white rounded-xl border border-primary/10 shadow-sm p-5 flex flex-col gap-3 hover:shadow-md transition-shadow">
      {/* Top row: avatar + name + actions */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3 min-w-0">
          {/* Avatar circle */}
          <div className="w-12 h-12 rounded-full bg-surface-purple flex items-center justify-center shrink-0">
            <MaterialSymbol
              name={speciesIcon(pet.species)}
              className="text-xl text-primary"
            />
          </div>
          <div className="min-w-0">
            <h3 className="font-serif text-lg font-bold text-primary-dark truncate">
              {pet.name}
            </h3>
            <p className="text-sm text-primary-dark/60">
              {speciesLabel(pet.species)}{pet.breed ? ` - ${pet.breed}` : ""}
            </p>
          </div>
        </div>

        {/* Action buttons */}
        <div className="flex items-center gap-1 shrink-0">
          <button
            type="button"
            onClick={() => onEdit(pet)}
            aria-label={`Edit ${pet.name}`}
            className="p-1.5 rounded-lg hover:bg-surface-purple transition-colors"
          >
            <MaterialSymbol name="edit" className="text-base text-primary-dark/50" />
          </button>
          <button
            type="button"
            onClick={() => onDelete(pet.id)}
            aria-label={`Delete ${pet.name}`}
            className="p-1.5 rounded-lg hover:bg-red-50 transition-colors"
          >
            <MaterialSymbol name="delete" className="text-base text-red-400" />
          </button>
        </div>
      </div>

      {/* Info grid */}
      <div className="grid grid-cols-3 gap-3 text-sm">
        <div>
          <p className="text-primary-dark/40 text-xs font-medium uppercase tracking-wider mb-0.5">
            Age
          </p>
          <p className="text-primary-dark font-medium">{age}</p>
        </div>
        <div>
          <p className="text-primary-dark/40 text-xs font-medium uppercase tracking-wider mb-0.5">
            Sex
          </p>
          <p className="text-primary-dark font-medium">{sexLabel(pet.sex)}</p>
        </div>
        <div>
          <p className="text-primary-dark/40 text-xs font-medium uppercase tracking-wider mb-0.5">
            Weight
          </p>
          <p className="text-primary-dark font-medium">{pet.weight || "-"}</p>
        </div>
      </div>

      {/* Vaccination notes teaser */}
      {pet.vaccinationNotes && (
        <div className="pt-2 border-t border-primary/5">
          <p className="text-xs text-primary-dark/40 font-medium uppercase tracking-wider mb-1">
            Vaccinations
          </p>
          <p className="text-sm text-primary-dark/70 line-clamp-2">
            {pet.vaccinationNotes}
          </p>
        </div>
      )}

      {/* Notes teaser */}
      {pet.notes && (
        <div className="pt-2 border-t border-primary/5">
          <p className="text-xs text-primary-dark/40 font-medium uppercase tracking-wider mb-1">
            Notes
          </p>
          <p className="text-sm text-primary-dark/70 line-clamp-2">
            {pet.notes}
          </p>
        </div>
      )}
    </div>
  );
}
