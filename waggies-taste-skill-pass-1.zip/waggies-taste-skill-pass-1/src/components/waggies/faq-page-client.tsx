"use client";

/**
 * FAQ page client component - Alpine tabs reproduced in React.
 *
 * Faithful reproduction of the Alpine `x-data="{ active: '...' }"` tab
 * behaviour in resources/views/pages/faq.blade.php lines 11-67.
 *
 * The first category in insertion order is active by default. Clicking a
 * tab swaps the visible panel. Panel transition uses opacity (matching the
 * Alpine `x-transition.opacity` directive).
 *
 * ENHANCED with:
 *  - Real-time search bar (filters by question OR answer, case-insensitive)
 *  - When searching, tabs are hidden and all matches from all categories
 *    are shown
 *  - Clear (X) button to reset search
 *  - "No results found" empty state
 *  - framer-motion AnimatePresence + stagger for FAQ items
 *  - "Popular Questions" quick links that scroll to specific FAQs
 */

import { useMemo, useState } from "react";
import { AnimatePresence, motion, useReducedMotion } from "framer-motion";
import { FaqAccordion } from "./faq-accordion";
import { MaterialSymbol } from "./material-symbol";
import { getGroupedFaqs, type Faq } from "@/data/faqs";

// ── Popular questions (hardcoded quick links) ──────────────────────────────
// Each entry points to a specific FAQ id by its numeric id (matching the
// faqs.ts dataset). Clicking scrolls the corresponding FAQ into view and
// opens it.
const POPULAR_QUESTIONS: { faqId: number; label: string }[] = [
  { faqId: 19, label: "How do I make a booking?" },
  { faqId: 1, label: "What do I need to bring for check-in?" },
  { faqId: 10, label: "How early to plan a pet relocation?" },
];

export function FaqPageClient() {
  const { grouped, categories } = getGroupedFaqs();
  const [active, setActive] = useState<string>(
    categories.length > 0 ? categories[0].slug : "",
  );
  const [query, setQuery] = useState("");
  const shouldReduceMotion = useReducedMotion();

  // Flat list of every FAQ (for search). Memoized since the dataset is static.
  const allFaqs = useMemo(() => {
    return categories.flatMap((cat) => grouped[cat.slug] ?? []);
  }, [categories, grouped]);

  // Map faq.id → Faq for popular-question lookup.
  const faqById = useMemo(() => {
    const map = new Map<number, Faq>();
    for (const f of allFaqs) map.set(f.id, f);
    return map;
  }, [allFaqs]);

  // Normalised search query (lowercased, trimmed).
  const q = query.trim().toLowerCase();
  const isSearching = q.length > 0;

  // Search results: every FAQ whose question OR answer contains the query.
  const searchResults = useMemo(() => {
    if (!isSearching) return [] as Faq[];
    return allFaqs.filter(
      (f) =>
        f.question.toLowerCase().includes(q) ||
        f.answer.toLowerCase().includes(q),
    );
  }, [allFaqs, isSearching, q]);

  if (categories.length === 0) {
    return (
      <p className="text-primary-dark/50">No FAQs published yet - check back soon.</p>
    );
  }

  function handleClearSearch() {
    setQuery("");
  }

  function handleTabKeyDown(e: React.KeyboardEvent) {
    const tabs = Array.from(e.currentTarget.querySelectorAll<HTMLButtonElement>("[role=tab]"));
    const idx = tabs.indexOf(document.activeElement as HTMLButtonElement);
    if (idx < 0) return;
    let next = idx;
    if (e.key === "ArrowRight" || e.key === "ArrowDown") {
      e.preventDefault();
      next = (idx + 1) % tabs.length;
    } else if (e.key === "ArrowLeft" || e.key === "ArrowUp") {
      e.preventDefault();
      next = (idx - 1 + tabs.length) % tabs.length;
    } else if (e.key === "Home") {
      e.preventDefault();
      next = 0;
    } else if (e.key === "End") {
      e.preventDefault();
      next = tabs.length - 1;
    } else {
      return;
    }
    tabs[next]?.focus();
    tabs[next]?.click();
  }

  function handlePopularClick(faqId: number) {
    const target = faqById.get(faqId);
    if (!target) return;
    // If the FAQ lives in a tab that isn't currently active, switch to it
    // first so the target node is actually rendered in the DOM (otherwise
    // its parent panel is display:none and scrollIntoView would no-op).
    if (active !== target.category) {
      setActive(target.category);
    }
    // Defer the open + scroll until after the tab switch has rendered the
    // target FAQ (two RAFs ensure the new tab's panels have mounted and
    // the data-faq-id selector is queryable).
    requestAnimationFrame(() => {
      requestAnimationFrame(() => {
        const node = document.querySelector<HTMLDetailsElement>(
          `[data-faq-id="${faqId}"]`,
        );
        if (!node) return;
        if (!node.open) node.open = true;
        node.scrollIntoView({ behavior: "smooth", block: "center" });
        node.focus?.();
      });
    });
  }

  return (
    <>
      {/* ── Search bar ──────────────────────────────────────────────────── */}
      <div className="max-w-2xl mx-auto mb-10">
        <div className="relative">
          {/* Search icon */}
          <span className="absolute left-5 top-1/2 -translate-y-1/2 text-primary-dark/40 pointer-events-none">
            <MaterialSymbol name="search" className="text-xl" ariaHidden />
          </span>

          <input
            type="search"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search questions..."
            aria-label="Search FAQs"
            className={`w-full h-14 pl-14 pr-12 rounded-full border bg-white
                       font-medium text-primary-dark placeholder:text-primary-dark/40
                       shadow-soft focus:outline-none focus:ring-2 focus:ring-primary/40
                       focus:border-primary transition
                       ${isSearching ? "border-primary/60" : "border-primary/15"}`}
          />

          {/* Clear button */}
          <AnimatePresence initial={false}>
            {isSearching ? (
              <motion.button
                type="button"
                onClick={handleClearSearch}
                aria-label="Clear search"
                initial={shouldReduceMotion ? false : { opacity: 0, scale: 0.6 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={shouldReduceMotion ? undefined : { opacity: 0, scale: 0.6 }}
                transition={{ duration: shouldReduceMotion ? 0 : 0.15 }}
                className="absolute right-4 top-1/2 -translate-y-1/2 w-8 h-8 rounded-full
                           flex items-center justify-center text-primary-dark/50 hover:text-primary
                           hover:bg-primary/10 transition"
              >
                <MaterialSymbol name="close" className="text-lg" />
              </motion.button>
            ) : null}
          </AnimatePresence>
        </div>
      </div>

      {/* ── Popular questions (hidden while searching) ──────────────────── */}
      <AnimatePresence initial={false}>
        {!isSearching ? (
          <motion.div
            initial={shouldReduceMotion ? false : { opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={shouldReduceMotion ? undefined : { opacity: 0, height: 0 }}
            transition={{ duration: shouldReduceMotion ? 0 : 0.25 }}
            className="max-w-3xl mx-auto mb-10 overflow-hidden"
          >
            <div className="flex flex-wrap items-center gap-2">
              <span className="text-xs font-bold uppercase tracking-widest text-primary/60 mr-1">
                Popular:
              </span>
              {POPULAR_QUESTIONS.map((p) => (
                <button
                  key={p.faqId}
                  type="button"
                  onClick={() => handlePopularClick(p.faqId)}
                  className="inline-flex items-center gap-1.5 px-4 py-2.5 rounded-full
                             bg-surface-purple text-primary-dark text-xs font-semibold
                             hover:bg-primary hover:text-white transition shadow-sm
                             min-h-[44px]
                           "
                >
                  <MaterialSymbol name="trending_up" className="text-sm" />
                  {p.label}
                </button>
              ))}
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* ── Tabs (hidden while searching) ──────────────────────────────── */}
      <AnimatePresence initial={false}>
        {!isSearching ? (
          <motion.div
            initial={shouldReduceMotion ? false : { opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={shouldReduceMotion ? undefined : { opacity: 0, height: 0 }}
            transition={{ duration: shouldReduceMotion ? 0 : 0.2 }}
            className="overflow-hidden"
          >
            <div className="flex flex-wrap gap-2 mb-10" role="tablist" onKeyDown={handleTabKeyDown}>
              {categories.map((cat) => {
                const isActive = active === cat.slug;
                return (
                  <button
                    key={cat.slug}
                    type="button"
                    role="tab"
                    aria-selected={isActive}
                    onClick={() => setActive(cat.slug)}
                    className={`px-5 py-2.5 rounded-full text-sm font-semibold transition min-h-[44px] ${isActive ? "bg-primary text-white shadow-sm" : "bg-surface-purple text-primary-dark hover:bg-primary/10"}`}
                  >
                    {cat.label}
                  </button>
                );
              })}
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* ── Search results panel ────────────────────────────────────────── */}
      <AnimatePresence mode="wait">
        {isSearching ? (
          <motion.div
            key="search-results"
            initial={shouldReduceMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={shouldReduceMotion ? undefined : { opacity: 0 }}
            transition={{ duration: shouldReduceMotion ? 0 : 0.2 }}
            className="max-w-3xl mx-auto"
          >
            <p className="text-sm text-primary-dark/60 mb-4">
              {searchResults.length > 0 ? (
                <>
                  Showing{" "}
                  <span className="font-semibold text-primary">
                    {searchResults.length}
                  </span>{" "}
                  {searchResults.length === 1 ? "result" : "results"} for{" "}
                  <span className="font-semibold text-primary-dark">&ldquo;{query.trim()}&rdquo;</span>
                </>
              ) : null}
            </p>

            {searchResults.length === 0 ? (
              <div className="text-center py-16 px-6 bg-white border border-primary/10 rounded-2xl">
                <div className="inline-flex items-center justify-center w-14 h-14 rounded-full bg-surface-purple text-primary mb-4">
                  <MaterialSymbol name="search_off" className="text-2xl" />
                </div>
                <p className="font-serif text-xl font-bold text-primary-dark mb-1">
                  No results found
                </p>
                <p className="text-sm text-primary-dark/60 mb-6">
                  We couldn&apos;t find anything matching &ldquo;{query.trim()}&rdquo;.
                  Try a different search or browse the categories.
                </p>
                <button
                  type="button"
                  onClick={handleClearSearch}
                  className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-2.5 rounded-full font-semibold text-sm transition shadow-sm"
                >
                  <MaterialSymbol name="arrow_back" className="text-base" />
                  Browse all FAQs
                </button>
              </div>
            ) : (
              <div className="space-y-3">
                <AnimatePresence initial={false}>
                  {searchResults.map((faq, i) => (
                    <motion.div
                      key={faq.id}
                      layout
                      initial={shouldReduceMotion ? false : { opacity: 0, y: 12 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={shouldReduceMotion ? undefined : { opacity: 0, y: -8 }}
                      transition={{
                        duration: shouldReduceMotion ? 0 : 0.25,
                        delay: shouldReduceMotion ? 0 : Math.min(i * 0.04, 0.4),
                        ease: [0.25, 0.1, 0.25, 1],
                      }}
                    >
                      <FaqDetailsCard
                        faq={faq}
                        highlight={q}
                      />
                    </motion.div>
                  ))}
                </AnimatePresence>
              </div>
            )}
          </motion.div>
        ) : (
          <motion.div
            key="category-panels"
            initial={shouldReduceMotion ? false : { opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={shouldReduceMotion ? undefined : { opacity: 0 }}
            transition={{ duration: shouldReduceMotion ? 0 : 0.2 }}
          >
            {/* FAQ panels - only render the active one */}
          {categories
            .filter((cat) => cat.slug === active)
            .map((cat) => {
              const faqs = grouped[cat.slug] ?? [];
              return (
                <div
                  key={cat.slug}
                  role="tabpanel"
                  className="max-w-3xl mx-auto"
                >
                  <div className="space-y-3">
                    {faqs.map((faq, i) => (
                      <motion.div
                        key={faq.id}
                        initial={shouldReduceMotion ? false : { opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        transition={{
                          duration: shouldReduceMotion ? 0 : 0.25,
                          delay: shouldReduceMotion ? 0 : Math.min(i * 0.04, 0.4),
                          ease: [0.25, 0.1, 0.25, 1],
                        }}
                      >
                        <FaqDetailsCard
                          faq={faq}
                        />
                      </motion.div>
                    ))}
                  </div>
                </div>
              );
            })}
          </motion.div>
        )}
      </AnimatePresence>

      {/* CTA */}
      <div className="mt-14 text-center">
        <p className="text-sm text-primary-dark/60 mb-4">
          Still unsure? Talk to our care team before booking.
        </p>
        <a
          href="/contact"
          className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-7 py-3 rounded-full font-bold text-sm transition shadow-sm"
        >
          Contact Us
          <MaterialSymbol name="arrow_forward" className="text-base" />
        </a>
      </div>
    </>
  );
}

// ── Reusable FAQ details card (used by both browse & search modes) ────────

type FaqDetailsCardProps = {
  faq: Faq;
  /** Optional lowercased query to highlight in the question text. */
  highlight?: string;
};

function FaqDetailsCard({ faq, highlight }: FaqDetailsCardProps) {
  return (
    <details
      data-faq-id={faq.id}
      className="group bg-white border border-primary/10 rounded-2xl hover:border-primary/30 hover:shadow-sm transition scroll-mt-32"
    >
      <summary className="flex w-full cursor-pointer items-center justify-between gap-4 px-6 py-5 font-semibold text-primary-dark hover:text-primary transition-colors list-none [&::-webkit-details-marker]:hidden">
        {highlight ? highlightText(faq.question, highlight) : faq.question}
        <MaterialSymbol
          name="expand_more"
          className="text-primary shrink-0 transition-transform duration-200 group-open:rotate-180"
        />
      </summary>
      <div className="px-6 pb-5 pt-3 text-sm text-primary-dark/65 leading-relaxed">
        {highlight ? highlightText(faq.answer, highlight) : faq.answer}
      </div>
    </details>
  );
}

/**
 * Highlight occurrences of `query` (case-insensitive) inside `text` by
 * wrapping them in <mark> with a Waggies-tinted background.
 */
function highlightText(text: string, query: string): React.ReactNode {
  if (!query) return text;
  // Escape regex special chars in the query.
  const safe = query.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const re = new RegExp(`(${safe})`, "gi");
  const parts = text.split(re);
  if (parts.length === 1) return text;
  return parts.map((part, i) =>
    part.toLowerCase() === query.toLowerCase() ? (
      <mark
        key={i}
        className="bg-primary/15 text-primary-dark rounded px-0.5 py-0.5"
      >
        {part}
      </mark>
    ) : (
      <span key={i}>{part}</span>
    ),
  );
}

// Re-export FaqAccordion so the page can build FAQ schema from the same dataset.
export { FaqAccordion };
