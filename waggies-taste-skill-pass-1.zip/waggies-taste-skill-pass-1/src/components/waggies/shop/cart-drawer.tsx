"use client";

import Link from "next/link";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { useCartStore } from "@/store/cart-store";
import { formatPrice } from "./product-card";
import {
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
  SheetDescription,
} from "@/components/ui/sheet";

export function CartDrawer() {
  const items = useCartStore((s) => s.items);
  const isOpen = useCartStore((s) => s.isOpen);
  const close = useCartStore((s) => s.close);
  const updateQuantity = useCartStore((s) => s.updateQuantity);
  const removeItem = useCartStore((s) => s.removeItem);
  const subtotal = useCartStore((s) => s.subtotal);
  const clearCart = useCartStore((s) => s.clearCart);

  const total = subtotal();

  return (
    <Sheet open={isOpen} onOpenChange={(open) => { if (!open) close(); }}>
      <SheetContent side="right" className="w-full sm:max-w-md flex flex-col p-0 bg-white">
        <SheetHeader className="px-6 pt-6 pb-4 border-b border-primary/5">
          <SheetTitle className="font-serif text-xl font-bold text-primary-dark">
            Your Cart
          </SheetTitle>
          <SheetDescription className="text-sm text-primary-dark/50">
            {items.length === 0
              ? "Your cart is empty"
              : `${items.length} item${items.length === 1 ? "" : "s"} in your cart`}
          </SheetDescription>
        </SheetHeader>

        {items.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center gap-4 px-6">
            <span className="material-symbols-outlined text-5xl text-primary-dark/15">
              shopping_cart
            </span>
            <p className="text-primary-dark/40 text-sm text-center">
              No items in your cart yet. Browse our shop to find something for your pet.
            </p>
            <Link
              href="/shop"
              onClick={close}
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary-dark transition-colors mt-2"
            >
              <MaterialSymbol name="arrow_forward" className="text-base" />
              Browse Shop
            </Link>
          </div>
        ) : (
          <>
            {/* Cart items */}
            <div className="flex-1 overflow-y-auto px-6 py-4 flex flex-col gap-4">
              {items.map((item) => (
                <div
                  key={item.productId}
                  className="flex gap-4 p-3 bg-surface rounded-xl"
                >
                  <img
                    src={item.imageSrc}
                    alt={item.name}
                    className="w-16 h-16 rounded-lg object-cover shrink-0"
                  />
                  <div className="flex-1 min-w-0 flex flex-col gap-2">
                    <p className="text-sm font-semibold text-primary-dark leading-snug line-clamp-2">
                      {item.name}
                    </p>
                    <p className="text-sm font-bold text-primary-dark">
                      {formatPrice(item.price)}
                    </p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center border border-primary/10 rounded-full overflow-hidden">
                        <button
                          type="button"
                          onClick={() =>
                            updateQuantity(item.productId, item.quantity - 1)
                          }
                          aria-label="Decrease quantity"
                          className="w-8 h-8 flex items-center justify-center text-primary-dark hover:bg-surface-purple transition-colors focus:outline-none"
                        >
                          <MaterialSymbol name="remove" className="text-sm" ariaHidden={false} />
                        </button>
                        <span className="w-8 text-center text-sm font-semibold text-primary-dark select-none">
                          {item.quantity}
                        </span>
                        <button
                          type="button"
                          onClick={() =>
                            updateQuantity(item.productId, item.quantity + 1)
                          }
                          aria-label="Increase quantity"
                          className="w-8 h-8 flex items-center justify-center text-primary-dark hover:bg-surface-purple transition-colors focus:outline-none"
                        >
                          <MaterialSymbol name="add" className="text-sm" ariaHidden={false} />
                        </button>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeItem(item.productId)}
                        aria-label={`Remove ${item.name} from cart`}
                        className="p-1.5 text-primary-dark/40 hover:text-red-500 transition-colors focus:outline-none focus:ring-2 focus:ring-red-500/60 rounded-lg"
                      >
                        <MaterialSymbol name="delete" className="text-base" ariaHidden={false} />
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Footer with subtotal + checkout */}
            <div className="border-t border-primary/5 px-6 py-5 flex flex-col gap-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-primary-dark/60">
                  Subtotal
                </span>
                <span className="text-lg font-bold text-primary-dark">
                  {formatPrice(total)}
                </span>
              </div>
              <p className="text-xs text-primary-dark/40">
                Shipping and taxes calculated at checkout.
              </p>
              <button
                type="button"
                disabled
                className="w-full flex items-center justify-center gap-2 bg-primary/40 text-white/60 cursor-not-allowed px-6 py-3 rounded-full font-semibold text-sm"
              >
                <MaterialSymbol name="lock" className="text-base" ariaHidden={false} />
                Checkout (Coming Soon)
              </button>
              <button
                type="button"
                onClick={clearCart}
                className="w-full text-center text-xs font-medium text-primary-dark/40 hover:text-primary-dark/70 transition-colors py-1"
              >
                Clear cart
              </button>
            </div>
          </>
        )}
      </SheetContent>
    </Sheet>
  );
}
