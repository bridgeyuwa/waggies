/**
 * Pricing card (B13).
 *
 * Faithful React reproduction of
 * resources/views/components/card/pricing.blade.php.
 *
 * Two variants:
 *   - standard: white card, surface-purple border, hover shadow
 *   - featured: white card, 2px primary border + soft shadow, floating badge
 */

import { MaterialSymbol } from "./material-symbol";

export type PricingFeature = {
  label: string;
  included: boolean;
};

export type CardPricingProps = {
  variant?: "standard" | "featured";
  tierLabel?: string;
  badgeLabel?: string;
  price?: string;
  unit?: string;
  features?: PricingFeature[];
  ctaLabel?: string;
  ctaHref?: string;
};

export function CardPricing({
  variant = "standard",
  tierLabel = "",
  badgeLabel = "Most Popular",
  price = "",
  unit = "/night",
  features = [],
  ctaLabel = "Get Started",
  ctaHref = "#",
}: CardPricingProps) {
  const isFeatured = variant === "featured";
  const wrapperClasses = isFeatured
    ? "relative bg-white rounded-2xl border-2 border-primary shadow-soft p-8"
    : "relative bg-white rounded-2xl border border-surface-purple shadow-sm p-8 hover:shadow-soft transition-shadow";

  return (
    <div className={wrapperClasses}>
      {/* Featured badge */}
      {isFeatured ? (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2">
          <span className="bg-primary text-white text-xs font-bold px-4 py-1.5 rounded-full shadow-sm uppercase tracking-wider whitespace-nowrap">
            {badgeLabel}
          </span>
        </div>
      ) : null}

      {/* Tier label */}
      <p className="text-xs font-bold uppercase tracking-widest text-primary/60 mb-3">
        {tierLabel}
      </p>

      {/* Price */}
      <div className="flex items-baseline gap-1 mb-6">
        <span className="font-serif text-3xl font-bold text-primary-dark">
          {price}
        </span>
        <span className="text-base font-sans font-normal text-primary-dark/40">
          {unit}
        </span>
      </div>

      {/* Feature list */}
      <ul className="flex flex-col gap-3 mb-8">
        {features.map((feature, i) => (
          <li
            key={i}
            className={`flex items-center gap-3 text-sm ${feature.included ? "text-primary-dark" : "text-primary-dark/30"}`}
          >
            <MaterialSymbol
              name={feature.included ? "check_circle" : "remove"}
              filled
              className={`text-base shrink-0 ${feature.included ? "text-success" : "text-primary-dark/30"}`}
            />
            {feature.label}
          </li>
        ))}
      </ul>

      {/* CTA */}
      {isFeatured ? (
        <a
          href={ctaHref}
          className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-white py-3 rounded-full font-semibold transition shadow-sm focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
        >
          {ctaLabel}
          <MaterialSymbol name="arrow_forward" className="text-base" />
        </a>
      ) : (
        <a
          href={ctaHref}
          className="w-full flex items-center justify-center gap-2 border-2 border-primary text-primary hover:bg-primary hover:text-white py-3 rounded-full font-semibold transition focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
        >
          {ctaLabel}
        </a>
      )}
    </div>
  );
}
