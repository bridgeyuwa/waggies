"use client";

import { useState, useRef, useEffect } from "react";
import Link from "next/link";
import { businessInfo } from "@/lib/business-info";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

interface ChatMessage {
  id: string;
  role: "bot" | "user";
  text: string;
}

const WELCOME_MESSAGE: ChatMessage = {
  id: "welcome",
  role: "bot",
  text: "Hi! I\u2019m the Waggies assistant. I can help you with information about our services, booking, and pet care. How can I help?",
};

function getBotResponse(input: string): string {
  const lower = input.toLowerCase().trim();

  // Greetings
  if (/^(hi|hello|hey|good morning|good afternoon|good evening|howdy)\b/.test(lower)) {
    return "Hello! How can I help you today?";
  }

  // Boarding
  if (/\b(boarding|board|overnight|stay|kennel)\b/.test(lower)) {
    return "We offer comfortable boarding for dogs, cats, and exotic pets in Abuja. Our suites are climate-controlled with daily playtime and feeding. Learn more on our boarding page: ";
  }

  // Grooming
  if (/\b(groom|grooming|bath|haircut|nail|trim|wash)\b/.test(lower)) {
    return "Our professional groomers provide breed-specific treatments including baths, haircuts, nail trims, and more. We use pet-safe products. See our grooming services: ";
  }

  // Pricing
  if (/\b(pric|cost|how much|rate|fee|estimate|quote)\b/.test(lower)) {
    return "We have a pricing tool where you can get an estimate based on your needs. You can also request a quote on our pricing page: ";
  }

  // Contact / phone / whatsapp
  if (/\b(contact|phone|whatsapp|call|reach|number|telephone)\b/.test(lower)) {
    return `You can reach us at ${businessInfo.phoneInternational} or chat with us on WhatsApp. You can also visit our contact page for more ways to reach us: `;
  }

  // Hours
  if (/\b(hour|open|close|time|schedule|when|available)\b/.test(lower)) {
    return "We\u2019re open Mon-Fri 9am-5pm, Sat-Sun 10am-2pm. Boarding guests receive 24/7 supervision regardless of office hours.";
  }

  // Vet care
  if (/\b(vet|veterinary|doctor|health|medical|check.?up|vaccin)\b/.test(lower)) {
    return "We have on-site veterinary support for routine check-ups, vaccinations, and minor treatments. For more details, visit our vet care page: ";
  }

  // Training
  if (/\b(train|obedience|behavio?r|puppy|class)\b/.test(lower)) {
    return "We offer positive-reinforcement dog training for puppies and adult dogs. Check out our training page: ";
  }

  // Relocation
  if (/\b(relocat|move|travel|flight|import|export|international|nigeria|abroad)\b/.test(lower)) {
    return "We help with international pet relocation including import, export, and document preparation. Visit our relocation page for details: ";
  }

  // Transport
  if (/\b(transport|pickup|drop.?off|delivery|door.?to.?door|shuttle)\b/.test(lower)) {
    return "We offer door-to-door pet transport within Abuja. Learn more on our transport page: ";
  }

  // Default
  return "I\u2019d love to help with that! For detailed questions, please contact us directly at +234 908 081 1902 or visit our contact page.";
}

function responseNeedsLink(text: string): { linkText: string; href: string } | null {
  if (text.includes("boarding page")) {
    return { linkText: "View Boarding Services", href: "/services/boarding" };
  }
  if (text.includes("grooming services")) {
    return { linkText: "View Grooming Services", href: "/services/grooming" };
  }
  if (text.includes("pricing page")) {
    return { linkText: "View Pricing", href: "/services/pricing" };
  }
  if (text.includes("contact page")) {
    return { linkText: "Contact Us", href: "/contact" };
  }
  if (text.includes("vet care page")) {
    return { linkText: "View Vet Care", href: "/services/vet-care" };
  }
  if (text.includes("training page")) {
    return { linkText: "View Training", href: "/services/training" };
  }
  if (text.includes("relocation page")) {
    return { linkText: "View Relocation", href: "/relocation" };
  }
  if (text.includes("transport page")) {
    return { linkText: "View Transport", href: "/services/transport" };
  }
  return null;
}

let messageCounter = 0;
function nextId(): string {
  messageCounter += 1;
  return `msg_${messageCounter}`;
}

export function ChatbotWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME_MESSAGE]);
  const [input, setInput] = useState("");
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);

  // Scroll to bottom on new messages
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  // Focus input when chat opens
  useEffect(() => {
    if (isOpen) {
      // Slight delay to allow panel to render
      const t = setTimeout(() => inputRef.current?.focus(), 100);
      return () => clearTimeout(t);
    }
  }, [isOpen]);

  function handleSend() {
    const text = input.trim();
    if (!text) return;

    const userMsg: ChatMessage = { id: nextId(), role: "user", text };
    const botResponse = getBotResponse(text);
    const botMsg: ChatMessage = { id: nextId(), role: "bot", text: botResponse };

    setMessages((prev) => [...prev, userMsg, botMsg]);
    setInput("");
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  return (
    <div className="fixed bottom-32 right-6 z-40 flex flex-col items-end gap-3">
      {/* Chat panel */}
      {isOpen && (
        <div className="w-[360px] max-w-[calc(100vw-3rem)] bg-white rounded-2xl shadow-xl border border-primary/10 flex flex-col overflow-hidden" style={{ height: "480px" }}>
          {/* Header */}
          <div className="flex items-center justify-between px-5 py-4 bg-primary shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                <MaterialSymbol name="smart_toy" className="text-lg text-white" />
              </div>
              <div>
                <h3 className="text-sm font-semibold text-white">Waggies Assistant</h3>
                <p className="text-xs text-white/70">Typically replies instantly</p>
              </div>
            </div>
            <button
              type="button"
              onClick={() => setIsOpen(false)}
              aria-label="Close chat"
              className="p-1.5 rounded-lg hover:bg-white/10 transition-colors"
            >
              <MaterialSymbol name="close" className="text-white text-lg" />
            </button>
          </div>

          {/* Messages area */}
          <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
            {messages.map((msg) => {
              const linkInfo = msg.role === "bot" ? responseNeedsLink(msg.text) : null;
              return (
                <div
                  key={msg.id}
                  className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                      msg.role === "user"
                        ? "bg-primary text-white rounded-br-md"
                        : "bg-surface-purple text-primary-dark rounded-bl-md"
                    }`}
                  >
                    {msg.text}
                    {linkInfo && (
                      <Link
                        href={linkInfo.href}
                        className="inline-block mt-1.5 text-xs font-semibold underline underline-offset-2 text-primary"
                      >
                        {linkInfo.linkText} &rarr;
                      </Link>
                    )}
                  </div>
                </div>
              );
            })}
            <div ref={messagesEndRef} />
          </div>

          {/* Input area */}
          <div className="px-4 py-3 border-t border-primary/5 flex items-center gap-2 shrink-0">
            <input
              ref={inputRef}
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Type a message..."
              aria-label="Chat message"
              className="flex-1 bg-surface border border-primary/10 rounded-full px-4 py-2.5 text-sm text-primary-dark placeholder:text-primary-dark/40 focus:outline-none focus:ring-2 focus:ring-primary/30"
            />
            <button
              type="button"
              onClick={handleSend}
              disabled={!input.trim()}
              aria-label="Send message"
              className="w-10 h-10 rounded-full bg-primary hover:bg-primary-dark text-white flex items-center justify-center transition-colors disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
            >
              <MaterialSymbol name="send" className="text-lg" />
            </button>
          </div>
        </div>
      )}

      {/* FAB button */}
      <button
        type="button"
        onClick={() => setIsOpen((v) => !v)}
        aria-label={isOpen ? "Close chat assistant" : "Open chat assistant"}
        className="w-14 h-14 rounded-full bg-primary hover:bg-primary-dark text-white shadow-2xl flex items-center justify-center transition-colors"
      >
        <MaterialSymbol
          name={isOpen ? "close" : "chat"}
          className="text-2xl"
        />
      </button>
    </div>
  );
}
