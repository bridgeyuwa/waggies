"use client";

import dynamic from "next/dynamic";

export const LazyChatbotWidget = dynamic(
  () => import("./chatbot-widget").then((mod) => ({ default: mod.ChatbotWidget })),
  {
    ssr: false,
    loading: () => null,
  },
);
