/**
 * HeroSplit - React port of resources/views/components/hero/split.blade.php
 *
 * Two-column hero on a purple-gradient background. Left: text + rating badge
 * + CTAs. Right: image (or slotted content).
 *
 * Used by the Testimonials page.
 *
 */

import { type ReactNode } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { BadgeStat } from "@/components/waggies/badge-stat";

export type HeroSplitProps = {
  title: string;
  subtitle?: string | null;
  eyebrow?: string | null;
  eyebrowIcon?: string | null;
  imageSrc?: string | null;
  imageAlt?: string | null;
  rating?: string;
  reviewCount?: string;
  primaryLabel?: string | null;
  primaryHref?: string;
  primaryIcon?: string;
  secondaryLabel?: string | null;
  secondaryHref?: string;
  secondaryIcon?: string | null;
  children?: ReactNode;
};

export function HeroSplit({
  title,
  subtitle,
  eyebrow,
  eyebrowIcon,
  imageSrc,
  imageAlt,
  rating = "4.9",
  reviewCount = "500+",
  primaryLabel,
  primaryHref = "#",
  primaryIcon = "arrow_forward",
  secondaryLabel,
  secondaryHref = "#",
  secondaryIcon,
  children,
}: HeroSplitProps) {
  const alt = imageAlt ?? title.replace(/<[^>]*>/g, "");

  return (
    <section className="w-full relative bg-surface-purple overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16 py-16 md:py-24">
          {/* LEFT: text content */}
          <div className="flex flex-col gap-6 max-w-md flex-1">
            {eyebrow || eyebrowIcon ? (
              <span
                className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full w-fit
                           bg-white/20 border border-white/30 text-primary-dark
                           text-xs font-bold uppercase tracking-widest"
              >
                {eyebrowIcon ? (
                  <MaterialSymbol
                    name={eyebrowIcon}
                    filled
                    className="text-sm text-secondary"
                  />
                ) : null}
                {eyebrow}
              </span>
            ) : null}

            <BadgeStat rating={rating} reviewCount={reviewCount} />

            <h1
              className="font-serif text-4xl md:text-5xl font-bold text-primary-dark leading-tight"
              dangerouslySetInnerHTML={{ __html: title }}
            />

            {subtitle ? (
              <p className="text-primary-dark/60 text-base leading-relaxed">
                {subtitle}
              </p>
            ) : null}

            {primaryLabel || secondaryLabel ? (
              <div className="flex flex-col items-start gap-3 ml-1">
                {primaryLabel ? (
                  <a
                    href={primaryHref}
                    className="inline-flex items-center gap-2
                               bg-primary hover:bg-primary-dark text-white
                               px-8 py-4 rounded-full font-bold
                               transition shadow-sm
                               focus:outline-none focus:ring-2 focus:ring-primary/60"
                  >
                    {primaryLabel}
                    {primaryIcon ? (
                      <MaterialSymbol name={primaryIcon} className="text-base" />
                    ) : null}
                  </a>
                ) : null}

                {secondaryLabel && secondaryHref ? (
                  <a
                    href={secondaryHref}
                    className="inline-flex items-center gap-2
                               border border-primary/30 text-primary-dark
                               px-8 py-4 rounded-full font-semibold
                               hover:bg-white/50 transition
                               focus:outline-none focus:ring-2 focus:ring-primary/40"
                  >
                    {secondaryIcon ? (
                      <MaterialSymbol name={secondaryIcon} className="text-base" />
                    ) : null}
                    {secondaryLabel}
                  </a>
                ) : null}
              </div>
            ) : null}
          </div>

          {/* RIGHT: image */}
          <div className="flex-1 w-full max-w-lg lg:max-w-none">
            <div className="relative aspect-[4/3] lg:aspect-[5/4] rounded-2xl overflow-hidden shadow-lg">
              {imageSrc ? (
                <img
                  src={imageSrc}
                  alt={alt}
                  className="absolute inset-0 w-full h-full object-cover"
                  loading="lazy"
                />
              ) : (
                <div className="absolute inset-0 flex items-center justify-center">
                  {children}
                </div>
              )}

            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
