"use client";

import { useState, useCallback } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import {
  type PetType as SymptomPetType,
  PET_TYPES,
  BODY_AREAS,
  SYMPTOM_DATA,
  getGuidance,
  type SymptomGuidance,
} from "@/data/symptom-checker-data";
import { cn } from "@/lib/utils";

export function SymptomCheckerClient() {
  const [petType, setPetType] = useState<SymptomPetType | null>(null);
  const [selectedArea, setSelectedArea] = useState<string | null>(null);
  const [selectedSymptoms, setSelectedSymptoms] = useState<string[]>([]);
  const [guidance, setGuidance] = useState<SymptomGuidance | null>(null);

  const toggleSymptom = useCallback((symptomId: string) => {
    setSelectedSymptoms((prev) =>
      prev.includes(symptomId)
        ? prev.filter((id) => id !== symptomId)
        : [...prev, symptomId],
    );
    setGuidance(null);
  }, []);

  const handleCheck = useCallback(() => {
    if (!selectedArea || selectedSymptoms.length === 0) return;
    setGuidance(getGuidance(selectedArea, selectedSymptoms));
  }, [selectedArea, selectedSymptoms]);

  const handleReset = useCallback(() => {
    setPetType(null);
    setSelectedArea(null);
    setSelectedSymptoms([]);
    setGuidance(null);
  }, []);

  return (
    <div className="flex flex-col gap-8">
      {/* Step 1: Pet type */}
      <StepSection step={1} title="Select your pet type">
        <div className="grid grid-cols-3 gap-3">
          {PET_TYPES.map((pt) => (
            <button
              key={pt.id}
              type="button"
              onClick={() => {
                setPetType(pt.id);
                setSelectedArea(null);
                setSelectedSymptoms([]);
                setGuidance(null);
              }}
              className={cn(
                "flex flex-col items-center gap-2 p-4 rounded-xl border-2 transition-colors",
                petType === pt.id
                  ? "border-primary bg-surface-purple text-primary"
                  : "border-primary/10 bg-white text-primary-dark/70 hover:border-primary/30",
              )}
            >
              <MaterialSymbol
                name={pt.icon}
                className={cn(
                  "text-3xl",
                  petType === pt.id ? "text-primary" : "text-primary-dark/50",
                )}
              />
              <span className="text-sm font-semibold">{pt.label}</span>
            </button>
          ))}
        </div>
      </StepSection>

      {/* Step 2: Body area */}
      {petType && (
        <StepSection step={2} title="Select the body area">
          <div className="grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 lg:grid-cols-6 gap-2">
            {BODY_AREAS.map((area) => (
              <button
                key={area.id}
                type="button"
                onClick={() => {
                  setSelectedArea(area.id);
                  setSelectedSymptoms([]);
                  setGuidance(null);
                }}
                className={cn(
                  "flex flex-col items-center gap-1.5 p-3 rounded-xl border transition-colors",
                  selectedArea === area.id
                    ? "border-primary bg-surface-purple text-primary"
                    : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30",
                )}
              >
                <MaterialSymbol name={area.icon} className="text-xl" />
                <span className="text-xs font-medium text-center leading-tight">
                  {area.label}
                </span>
              </button>
            ))}
          </div>
        </StepSection>
      )}

      {/* Step 3: Symptoms */}
      {selectedArea && (
        <StepSection step={3} title="Select the symptoms you notice">
          <div className="flex flex-wrap gap-2">
            {(SYMPTOM_DATA[selectedArea] ?? []).map((symptom) => (
              <button
                key={symptom.id}
                type="button"
                onClick={() => toggleSymptom(symptom.id)}
                className={cn(
                  "px-4 py-2 rounded-full text-sm font-medium border transition-colors",
                  selectedSymptoms.includes(symptom.id)
                    ? "border-primary bg-primary text-white"
                    : "border-primary/10 bg-white text-primary-dark/70 hover:border-primary/30",
                )}
              >
                {symptom.label}
              </button>
            ))}
          </div>
          {selectedSymptoms.length > 0 && (
            <div className="mt-6 flex items-center gap-4">
              <button
                type="button"
                onClick={handleCheck}
                className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full text-sm font-semibold transition-colors"
              >
                <MaterialSymbol name="search" className="text-base" />
                Check Symptoms ({selectedSymptoms.length} selected)
              </button>
              <button
                type="button"
                onClick={() => setSelectedSymptoms([])}
                className="text-sm text-primary-dark/50 hover:text-primary transition-colors"
              >
                Clear selection
              </button>
            </div>
          )}
        </StepSection>
      )}

      {/* Results */}
      {guidance && <GuidanceCard guidance={guidance} onReset={handleReset} />}
    </div>
  );
}

function StepSection({
  step,
  title,
  children,
}: {
  step: number;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="bg-white border border-primary/10 rounded-2xl p-6">
      <div className="flex items-center gap-3 mb-5">
        <span className="w-8 h-8 rounded-full bg-primary text-white text-sm font-bold flex items-center justify-center">
          {step}
        </span>
        <h3 className="font-serif text-lg font-bold text-primary-dark">{title}</h3>
      </div>
      {children}
    </div>
  );
}

function GuidanceCard({
  guidance,
  onReset,
}: {
  guidance: SymptomGuidance;
  onReset: () => void;
}) {
  const severityConfig = {
    low: {
      icon: "check_circle",
      border: "border-green-200",
      bg: "bg-green-50",
      badge: "bg-green-100 text-green-800",
      label: "Low Concern",
    },
    moderate: {
      icon: "warning",
      border: "border-amber-200",
      bg: "bg-amber-50",
      badge: "bg-amber-100 text-amber-800",
      label: "Moderate Concern",
    },
    high: {
      icon: "emergency",
      border: "border-red-200",
      bg: "bg-red-50",
      badge: "bg-red-100 text-red-800",
      label: "High Concern",
    },
  };

  const config = severityConfig[guidance.severity];

  return (
    <div className={cn("border rounded-2xl p-6 md:p-8", config.border, config.bg)}>
      <div className="flex items-start gap-4 mb-6">
        <MaterialSymbol
          name={config.icon}
          className={cn("text-3xl", config.badge.split(" ")[1])}
        />
        <div>
          <span
            className={cn(
              "inline-block text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full mb-2",
              config.badge,
            )}
          >
            {config.label}
          </span>
          <h3 className="font-serif text-xl font-bold text-primary-dark">
            {guidance.title}
          </h3>
        </div>
      </div>

      <p className="text-primary-dark/70 leading-relaxed mb-6">
        {guidance.description}
      </p>

      <div className="mb-6">
        <h4 className="text-sm font-bold uppercase tracking-wider text-primary-dark/50 mb-3">
          Recommendations
        </h4>
        <ul className="space-y-2">
          {guidance.recommendations.map((rec, i) => (
            <li key={i} className="flex items-start gap-3">
              <MaterialSymbol
                name="check_small"
                className="text-primary text-lg mt-0.5 shrink-0"
              />
              <span className="text-sm text-primary-dark/70">{rec}</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="flex items-center gap-3 pt-4 border-t border-primary/10">
        <button
          type="button"
          onClick={onReset}
          className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:text-primary-dark transition-colors"
        >
          <MaterialSymbol name="refresh" className="text-base" />
          Start over
        </button>
      </div>

      <div className="mt-4 bg-white/80 rounded-xl p-4 flex items-start gap-2.5">
        <MaterialSymbol
          name="info"
          className="text-primary text-lg mt-0.5 shrink-0"
        />
        <p className="text-xs text-primary-dark/50 leading-relaxed">
          This is an informational aid only and does not constitute veterinary
          diagnosis. Please consult a veterinarian for medical advice.
        </p>
      </div>
    </div>
  );
}
