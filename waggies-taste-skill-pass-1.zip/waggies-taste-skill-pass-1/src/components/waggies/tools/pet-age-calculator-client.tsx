"use client";

import { useState, useMemo } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import {
  type DogSize,
  DOG_SIZES,
  calculateDogAge,
  calculateCatAge,
  getAgeFunFact,
  getLifeStage,
} from "@/data/pet-age-data";
import { cn } from "@/lib/utils";

type PetType = "dog" | "cat";

export function PetAgeCalculatorClient() {
  const [petType, setPetType] = useState<PetType>("dog");
  const [dogSize, setDogSize] = useState<DogSize>("medium");
  const [years, setYears] = useState(3);
  const [months, setMonths] = useState(0);

  const result = useMemo(() => {
    if (petType === "dog") {
      const humanAge = calculateDogAge(years, months, dogSize);
      return {
        humanAge,
        funFact: getAgeFunFact(humanAge, "dog"),
        lifeStage: getLifeStage(humanAge),
      };
    }
    const humanAge = calculateCatAge(years, months);
    return {
      humanAge,
      funFact: getAgeFunFact(humanAge, "cat"),
      lifeStage: getLifeStage(humanAge),
    };
  }, [petType, dogSize, years, months]);

  return (
    <div className="flex flex-col gap-8">
      {/* Pet type selection */}
      <div className="bg-white border border-primary/10 rounded-2xl p-6">
        <h3 className="font-serif text-lg font-bold text-primary-dark mb-5">
          Pet Type
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {(["dog", "cat"] as const).map((pt) => (
            <button
              key={pt}
              type="button"
              onClick={() => setPetType(pt)}
              className={cn(
                "flex items-center justify-center gap-2 p-4 rounded-xl border-2 font-semibold transition-colors",
                petType === pt
                  ? "border-primary bg-surface-purple text-primary"
                  : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30",
              )}
            >
              <MaterialSymbol
                name={pt === "dog" ? "pets" : "cat"}
                className="text-2xl"
              />
              {pt === "dog" ? "Dog" : "Cat"}
            </button>
          ))}
        </div>
      </div>

      {/* Dog size selection */}
      {petType === "dog" && (
        <div className="bg-white border border-primary/10 rounded-2xl p-6">
          <h3 className="font-serif text-lg font-bold text-primary-dark mb-5">
            Dog Size
          </h3>
          <div className="grid grid-cols-2 gap-3">
            {DOG_SIZES.map((size) => (
              <button
                key={size.id}
                type="button"
                onClick={() => setDogSize(size.id)}
                className={cn(
                  "flex flex-col items-start gap-0.5 p-4 rounded-xl border-2 transition-colors text-left",
                  dogSize === size.id
                    ? "border-primary bg-surface-purple"
                    : "border-primary/10 bg-white hover:border-primary/30",
                )}
              >
                <span
                  className={cn(
                    "font-semibold",
                    dogSize === size.id ? "text-primary" : "text-primary-dark/80",
                  )}
                >
                  {size.label}
                </span>
                <span className="text-xs text-primary-dark/50">
                  {size.description}
                </span>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Age input */}
      <div className="bg-white border border-primary/10 rounded-2xl p-6">
        <h3 className="font-serif text-lg font-bold text-primary-dark mb-5">
          Your Pet&rsquo;s Age
        </h3>
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-primary-dark/70 mb-2">
              Years
            </label>
            <input
              type="number"
              min={0}
              max={petType === "cat" ? 25 : 20}
              value={years}
              onChange={(e) => {
                const v = Math.max(0, Math.min(parseInt(e.target.value) || 0, petType === "cat" ? 25 : 20));
                setYears(v);
              }}
              className="w-full px-4 py-3 rounded-xl border border-primary/10 bg-surface text-primary-dark text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-dark/70 mb-2">
              Months <span className="text-primary-dark/40">(optional)</span>
            </label>
            <input
              type="number"
              min={0}
              max={11}
              value={months}
              onChange={(e) => {
                const v = Math.max(0, Math.min(parseInt(e.target.value) || 0, 11));
                setMonths(v);
              }}
              className="w-full px-4 py-3 rounded-xl border border-primary/10 bg-surface text-primary-dark text-lg font-semibold focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
            />
          </div>
        </div>
      </div>

      {/* Result */}
      <div className="bg-white border-2 border-primary/20 rounded-2xl p-8 text-center">
        <div className="mb-4">
          <MaterialSymbol name="celebration" className="text-4xl text-primary" />
        </div>
        <p className="text-primary-dark/50 text-sm uppercase tracking-wider font-bold mb-2">
          Human Equivalent
        </p>
        <p className="font-serif text-5xl md:text-6xl font-bold text-primary-dark mb-3">
          {result.humanAge}
          <span className="text-2xl md:text-3xl font-normal text-primary-dark/40 ml-1">
            years old
          </span>
        </p>
        <span
          className={cn(
            "inline-block text-xs font-bold uppercase tracking-wider px-3 py-1 rounded-full mb-4",
            result.lifeStage.color,
          )}
        >
          {result.lifeStage.stage}
        </span>
        <p className="text-primary-dark/60 text-sm leading-relaxed max-w-md mx-auto">
          {result.funFact}
        </p>
        <div className="mt-6 pt-4 border-t border-primary/10 text-xs text-primary-dark/40">
          {petType === "dog" && (
            <p>Size: {DOG_SIZES.find((s) => s.id === dogSize)?.label} &middot; Age: {years}y {months}m</p>
          )}
          {petType === "cat" && <p>Age: {years}y {months}m</p>}
        </div>
      </div>
    </div>
  );
}
