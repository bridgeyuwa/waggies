"use client";

import { useState, useMemo } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { cn } from "@/lib/utils";
import {
  type PetType,
  type PetSize,
  PET_TYPES,
  formatNaira,
} from "@/lib/cost-calculator-data";

export function CostCalculatorClient() {
  const [petType, setPetType] = useState<PetType>("dog");
  const [petSize, setPetSize] = useState<PetSize>("medium");
  const [service, setService] = useState<"boarding" | "grooming" | "vet" | "training">("boarding");
  const [duration, setDuration] = useState(7);

  const validSizes = PET_TYPES[petType].sizes;
  const effectiveSize = validSizes.includes(petSize) ? petSize : validSizes[0];

  const estimate = useMemo(() => {
    const perDayRates: Record<string, Record<PetSize, { min: number; max: number }>> = {
      boarding: {
        small: { min: 8000, max: 12000 },
        medium: { min: 12000, max: 18000 },
        large: { min: 18000, max: 28000 },
      },
      grooming: {
        small: { min: 5000, max: 8000 },
        medium: { min: 8000, max: 15000 },
        large: { min: 15000, max: 25000 },
      },
      vet: {
        small: { min: 3000, max: 8000 },
        medium: { min: 5000, max: 12000 },
        large: { min: 8000, max: 20000 },
      },
      training: {
        small: { min: 10000, max: 15000 },
        medium: { min: 15000, max: 25000 },
        large: { min: 20000, max: 35000 },
      },
    };

    const rates = perDayRates[service]?.[effectiveSize] ?? { min: 5000, max: 10000 };
    const multiplier = service === "grooming" || service === "vet" ? 1 : duration;
    return {
      min: rates.min * multiplier,
      max: rates.max * multiplier,
    };
  }, [service, effectiveSize, duration]);

  const serviceLabels: Record<string, { label: string; icon: string; description: string }> = {
    boarding: { label: "Boarding", icon: "apartment", description: "Per night" },
    grooming: { label: "Grooming", icon: "spa", description: "Per session" },
    vet: { label: "Vet Care", icon: "medical_services", description: "Per visit" },
    training: { label: "Training", icon: "school", description: "Per session" },
  };

  return (
    <div className="flex flex-col gap-8">
      {/* Pet type */}
      <div className="bg-white border border-primary/10 rounded-2xl p-6">
        <h3 className="font-serif text-lg font-bold text-primary-dark mb-5">Pet Type</h3>
        <div className="grid grid-cols-2 gap-3">
          {(["dog", "cat"] as const).map((pt) => (
            <button
              key={pt}
              type="button"
              onClick={() => setPetType(pt)}
              className={cn(
                "flex items-center justify-center gap-2 p-4 rounded-xl border-2 font-semibold transition-colors",
                petType === pt
                  ? "border-primary bg-surface-purple text-primary"
                  : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30",
              )}
            >
              <MaterialSymbol name={pt === "dog" ? "pets" : "cat"} className="text-2xl" />
              {pt === "dog" ? "Dog" : "Cat"}
            </button>
          ))}
        </div>
      </div>

      {/* Pet size */}
      <div className="bg-white border border-primary/10 rounded-2xl p-6">
        <h3 className="font-serif text-lg font-bold text-primary-dark mb-5">Pet Size</h3>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
          {validSizes.map((size) => {
            const cfg = PET_TYPES[petType];
            return (
              <button
                key={size}
                type="button"
                onClick={() => setPetSize(size)}
                className={cn(
                  "flex flex-col items-start gap-0.5 p-4 rounded-xl border-2 transition-colors text-left",
                  effectiveSize === size
                    ? "border-primary bg-surface-purple"
                    : "border-primary/10 bg-white hover:border-primary/30",
                )}
              >
                <span className={cn("font-semibold", effectiveSize === size ? "text-primary" : "text-primary-dark/80")}>
                  {size.charAt(0).toUpperCase() + size.slice(1)}
                </span>
                <span className="text-xs text-primary-dark/50">{cfg.sizeLabels[size]}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Service type */}
      <div className="bg-white border border-primary/10 rounded-2xl p-6">
        <h3 className="font-serif text-lg font-bold text-primary-dark mb-5">Service Type</h3>
        <div className="grid grid-cols-2 gap-3">
          {(["boarding", "grooming", "vet", "training"] as const).map((s) => {
            const info = serviceLabels[s];
            return (
              <button
                key={s}
                type="button"
                onClick={() => setService(s)}
                className={cn(
                  "flex items-center gap-3 p-4 rounded-xl border-2 transition-colors text-left",
                  service === s
                    ? "border-primary bg-surface-purple"
                    : "border-primary/10 bg-white hover:border-primary/30",
                )}
              >
                <MaterialSymbol
                  name={info.icon}
                  className={cn("text-xl", service === s ? "text-primary" : "text-primary-dark/40")}
                />
                <div>
                  <p className={cn("font-semibold text-sm", service === s ? "text-primary" : "text-primary-dark/80")}>
                    {info.label}
                  </p>
                  <p className="text-xs text-primary-dark/40">{info.description}</p>
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Duration (only for boarding) */}
      {service === "boarding" && (
        <div className="bg-white border border-primary/10 rounded-2xl p-6">
          <h3 className="font-serif text-lg font-bold text-primary-dark mb-2">Duration</h3>
          <p className="text-sm text-primary-dark/50 mb-5">Number of nights for boarding</p>
          <div className="flex items-center gap-4">
            <button
              type="button"
              onClick={() => setDuration((d) => Math.max(1, d - 1))}
              className="w-10 h-10 rounded-full border border-primary/20 flex items-center justify-center text-primary hover:bg-surface-purple transition-colors"
            >
              <MaterialSymbol name="remove" className="text-lg" />
            </button>
            <span className="font-serif text-3xl font-bold text-primary-dark w-24 text-center">
              {duration}
            </span>
            <button
              type="button"
              onClick={() => setDuration((d) => Math.min(30, d + 1))}
              className="w-10 h-10 rounded-full border border-primary/20 flex items-center justify-center text-primary hover:bg-surface-purple transition-colors"
            >
              <MaterialSymbol name="add" className="text-lg" />
            </button>
            <span className="text-sm text-primary-dark/50">
              {duration === 1 ? "night" : "nights"}
            </span>
          </div>
        </div>
      )}

      {/* Result */}
      <div className="bg-white border-2 border-primary/20 rounded-2xl p-8 text-center">
        <MaterialSymbol name="payments" className="text-4xl text-primary mb-3" />
        <p className="text-primary-dark/50 text-sm uppercase tracking-wider font-bold mb-2">
          Estimated Cost
        </p>
        <p className="font-serif text-3xl md:text-4xl font-bold text-primary-dark mb-1">
          {formatNaira(estimate.min)} &ndash; {formatNaira(estimate.max)}
        </p>
        <p className="text-sm text-primary-dark/50 mb-6">
          {serviceLabels[service].label}
          {service === "boarding" ? ` × ${duration} nights` : " (per session)"}
          {" · "}
          {PET_TYPES[petType].sizeLabels[effectiveSize]}
        </p>
        <div className="flex items-start gap-2.5 bg-secondary/30 rounded-xl p-4 text-left">
          <MaterialSymbol name="info" className="text-primary text-lg mt-0.5 shrink-0" />
          <p className="text-xs text-primary-dark/50 leading-relaxed">
            Estimates only. Contact us for an accurate quote. Prices vary based on
            your pet&rsquo;s specific needs and the services selected.
          </p>
        </div>
      </div>
    </div>
  );
}
