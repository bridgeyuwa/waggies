"use client";

import { useState } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { getVaccinationSchedule, type PetType } from "@/data/vaccination-data";
import { cn } from "@/lib/utils";

export function VaccinationScheduleClient() {
  const [petType, setPetType] = useState<PetType>("dog");
  const schedule = getVaccinationSchedule(petType);

  return (
    <div className="flex flex-col gap-8">
      {/* Pet type toggle */}
      <div className="bg-white border border-primary/10 rounded-2xl p-6">
        <h3 className="font-serif text-lg font-bold text-primary-dark mb-5">
          Select Pet Type
        </h3>
        <div className="grid grid-cols-2 gap-3">
          {(["dog", "cat"] as const).map((pt) => (
            <button
              key={pt}
              type="button"
              onClick={() => setPetType(pt)}
              className={cn(
                "flex items-center justify-center gap-2 p-4 rounded-xl border-2 font-semibold transition-colors",
                petType === pt
                  ? "border-primary bg-surface-purple text-primary"
                  : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30",
              )}
            >
              <MaterialSymbol
                name={pt === "dog" ? "pets" : "cat"}
                className="text-2xl"
              />
              {pt === "dog" ? "Dog" : "Cat"}
            </button>
          ))}
        </div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap gap-4 text-sm">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-primary" />
          <span className="text-primary-dark/60">Core (required)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-secondary border border-secondary" />
          <span className="text-primary-dark/60">Non-core (recommended)</span>
        </div>
      </div>

      {/* Timeline */}
      <div className="relative">
        {/* Vertical line */}
        <div className="absolute left-5 top-0 bottom-0 w-px bg-primary/15 hidden md:block" />

        <div className="flex flex-col gap-6">
          {schedule.map((entry, idx) => (
            <div key={idx} className="relative flex gap-5 md:gap-8">
              {/* Timeline dot */}
              <div className="hidden md:flex w-10 h-10 rounded-full bg-white border-2 border-primary items-center justify-center shrink-0 relative z-10">
                <MaterialSymbol name="vaccines" className="text-primary text-sm" />
              </div>

              {/* Card */}
              <div className="flex-1 bg-white border border-primary/10 rounded-2xl p-5 md:p-6">
                <div className="flex items-center gap-2 mb-4 md:mb-0">
                  <div className="md:hidden w-8 h-8 rounded-full bg-surface-purple flex items-center justify-center shrink-0">
                    <MaterialSymbol name="vaccines" className="text-primary text-sm" />
                  </div>
                  <h3 className="font-serif text-lg font-bold text-primary-dark">
                    {entry.age}
                  </h3>
                </div>
                <div className="flex flex-col gap-3 mt-3">
                  {entry.vaccines.map((vax, vIdx) => (
                    <div
                      key={vIdx}
                      className={cn(
                        "rounded-xl p-4",
                        vax.type === "core"
                          ? "bg-primary/5 border border-primary/15"
                          : "bg-secondary/30 border border-secondary",
                      )}
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1">
                          <p
                            className={cn(
                              "font-semibold text-sm",
                              vax.type === "core" ? "text-primary-dark" : "text-primary-dark/80",
                            )}
                          >
                            {vax.name}
                          </p>
                          <p className="text-xs text-primary-dark/50 mt-1 leading-relaxed">
                            {vax.description}
                          </p>
                        </div>
                        <span
                          className={cn(
                            "shrink-0 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-full",
                            vax.type === "core"
                              ? "bg-primary/10 text-primary"
                              : "bg-secondary text-primary-dark/60",
                          )}
                        >
                          {vax.type === "core" ? "Core" : "Non-core"}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
