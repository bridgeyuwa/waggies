import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { VaccinationScheduleClient } from "@/components/waggies/tools/vaccination-schedule-client";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export const metadata: Metadata = {
  title: "Vaccination Schedule",
  description:
    "Track recommended vaccinations for your dog or cat. Our vaccination schedule shows core and non-core vaccines by age.",
  alternates: { canonical: "/tools/vaccination-schedule" },
  openGraph: {
    title: "Vaccination Schedule - Waggies",
    description: "Track recommended vaccinations for your dog or cat.",
    url: "/tools/vaccination-schedule",
  },
};

export default function VaccinationSchedulePage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Vaccination Schedule" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon="vaccinations"
        title="Vaccination Schedule"
        subtitle="See the recommended vaccination timeline for your pet. Core vaccines are required; non-core vaccines depend on your pet's lifestyle."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-3xl mx-auto px-4 md:px-10">
          <VaccinationScheduleClient />

          <div className="mt-10 flex items-start gap-3 bg-white border border-primary/10 rounded-2xl p-5">
            <MaterialSymbol
              name="info"
              className="text-primary text-xl mt-0.5 shrink-0"
            />
            <p className="text-sm text-primary-dark/60 leading-relaxed">
              This schedule is based on general veterinary guidelines. Always
              consult your veterinarian for a personalised vaccination plan
              tailored to your pet&rsquo;s specific needs and local
              regulations.
            </p>
          </div>
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Vaccination Schedule", path: "/tools/vaccination-schedule" },
        ]}
      />
    </>
  );
}
