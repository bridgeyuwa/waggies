import type { Metadata } from "next";
import Link from "next/link";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { FadeIn, StaggerChildren } from "@/components/waggies/motion";

export const metadata: Metadata = {
  title: "Pet Care Tools",
  description:
    "Free pet care tools from Waggies: symptom checker, pet age calculator, vaccination schedule tracker, and cost estimator for pet services in Abuja.",
  alternates: { canonical: "/tools" },
  openGraph: {
    title: "Pet Care Tools - Waggies",
    description:
      "Free pet care tools: symptom checker, pet age calculator, vaccination schedule, and cost estimator.",
    url: "/tools",
  },
};

const TOOLS = [
  {
    href: "/tools/symptom-checker",
    icon: "medical_information",
    title: "Pet Symptom Checker",
    description: "Check your pet's symptoms and get guidance on next steps",
    featured: true,
  },
  {
    href: "/tools/pet-age-calculator",
    icon: "cake",
    title: "Pet Age Calculator",
    description: "Convert your pet's age to human years",
    featured: false,
  },
  {
    href: "/tools/vaccination-schedule",
    icon: "vaccinations",
    title: "Vaccination Schedule",
    description: "Track recommended vaccinations for your pet",
    featured: false,
  },
  {
    href: "/tools/cost-calculator",
    icon: "calculate",
    title: "Cost Calculator",
    description: "Estimate costs for Waggies services",
    featured: false,
  },
];

export default function ToolsPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Tools" }]}
      />

      <HeroPlain
        eyebrow="Pet Care Tools"
        title="Useful Tools for Pet Owners"
        subtitle="Free interactive tools to help you take better care of your pets."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-6xl mx-auto px-4 md:px-10 lg:px-12">
          <StaggerChildren className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {TOOLS.map((tool) => (
              <FadeIn
                key={tool.href}
                className={tool.featured ? "md:col-span-2" : ""}
              >
                <ToolCard tool={tool} />
              </FadeIn>
            ))}
          </StaggerChildren>

          <div className="mt-16 max-w-3xl mx-auto">
            <div className="bg-secondary/50 border border-secondary rounded-2xl px-6 py-5 flex items-start gap-3">
              <MaterialSymbol
                name="info"
                className="text-primary text-xl mt-0.5 shrink-0"
              />
              <p className="text-sm text-primary-dark/60 leading-relaxed">
                These tools provide general information only and do not replace
                professional veterinary advice. Always consult a qualified
                veterinarian for medical concerns about your pet.
              </p>
            </div>
          </div>
        </div>
      </section>

      <BreadcrumbSchema items={[{ name: "Tools", path: "/tools" }]} />
    </>
  );
}

function ToolCard({
  tool,
}: {
  tool: {
    href: string;
    icon: string;
    title: string;
    description: string;
    featured: boolean;
  };
}) {
  return (
    <Link
      href={tool.href}
      className={
        tool.featured
          ? "group block bg-white border border-primary/10 rounded-2xl p-8 md:p-10 shadow-sm hover:shadow-md transition-shadow"
          : "group block bg-white border border-primary/10 rounded-xl p-6 hover:shadow-sm transition-shadow"
      }
    >
      <div
        className={
          tool.featured
            ? "flex flex-col md:flex-row md:items-center gap-6"
            : "flex flex-col gap-4"
        }
      >
        <div
          className={
            tool.featured
              ? "w-16 h-16 rounded-2xl bg-surface-purple group-hover:bg-primary flex items-center justify-center text-primary group-hover:text-white transition-colors shrink-0"
              : "w-12 h-12 rounded-xl bg-surface-purple group-hover:bg-primary flex items-center justify-center text-primary group-hover:text-white transition-colors shrink-0"
          }
        >
          <MaterialSymbol
            name={tool.icon}
            className={tool.featured ? "text-3xl" : "text-2xl"}
          />
        </div>
        <div className="flex-1 min-w-0">
          <h3
            className={
              tool.featured
                ? "font-serif text-2xl font-bold text-primary-dark group-hover:text-primary transition-colors"
                : "font-serif text-lg font-bold text-primary-dark group-hover:text-primary transition-colors"
            }
          >
            {tool.title}
          </h3>
          <p
            className={
              tool.featured
                ? "text-primary-dark/50 text-base mt-2 leading-relaxed"
                : "text-primary-dark/50 text-sm mt-1 leading-relaxed"
            }
          >
            {tool.description}
          </p>
        </div>
        <div className="shrink-0 self-start md:self-center">
          <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary group-hover:gap-2.5 transition-all">
            {tool.featured ? "Try it out" : "Open tool"}
            <MaterialSymbol name="arrow_forward" className="text-base" />
          </span>
        </div>
      </div>
    </Link>
  );
}
