import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { SymptomCheckerClient } from "@/components/waggies/tools/symptom-checker-client";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export const metadata: Metadata = {
  title: "Pet Symptom Checker",
  description:
    "Check your pet's symptoms and get guidance on next steps. Our free symptom checker helps you understand what might be going on with your dog, cat, or other pet.",
  alternates: { canonical: "/tools/symptom-checker" },
  openGraph: {
    title: "Pet Symptom Checker - Waggies",
    description:
      "Check your pet's symptoms and get guidance on next steps.",
    url: "/tools/symptom-checker",
  },
};

export default function SymptomCheckerPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Symptom Checker" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon="medical_information"
        title="Pet Symptom Checker"
        subtitle="Select your pet type, choose the affected area, and pick the symptoms you notice to get general guidance."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-3xl mx-auto px-4 md:px-10">
          <SymptomCheckerClient />

          <div className="mt-10 flex items-start gap-3 bg-white border border-primary/10 rounded-2xl p-5">
            <MaterialSymbol
              name="info"
              className="text-primary text-xl mt-0.5 shrink-0"
            />
            <p className="text-sm text-primary-dark/60 leading-relaxed">
              This is an informational aid only and does not constitute
              veterinary diagnosis. Please consult a veterinarian for medical
              advice.
            </p>
          </div>
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Symptom Checker", path: "/tools/symptom-checker" },
        ]}
      />
    </>
  );
}
