import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { MyPetsClient } from "@/components/waggies/pets/my-pets-client";
import { siteConfig } from "@/lib/site";

export const metadata: Metadata = {
  title: "My Pets",
  description: "Manage your pet profiles on Waggies. Keep track of names, breeds, vaccination notes, and more.",
  alternates: { canonical: "/my-pets" },
  openGraph: {
    title: "My Pets - Waggies",
    description: "Manage your pet profiles on Waggies. Keep track of names, breeds, vaccination notes, and more.",
    url: "/my-pets",
  },
};

export default function MyPetsPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "My Pets", href: "/my-pets" }]}
      />

      <HeroPlain
        eyebrow="My Pets"
        eyebrowIcon="pets"
        title="Manage Your Pets"
        subtitle="Keep your pet profiles organised with important details like vaccinations, weight, and notes."
      />

      <MyPetsClient />

      <BreadcrumbSchema items={[{ name: "My Pets", path: "/my-pets" }]} />
      <JsonLd
        data={webPageSchema(
          "My Pets",
          "Manage your pet profiles on Waggies.",
          `${siteConfig.siteUrl}/my-pets`,
        )}
      />
    </>
  );
}
