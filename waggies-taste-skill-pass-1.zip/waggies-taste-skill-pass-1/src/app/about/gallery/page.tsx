/**
 * /about/gallery - Photo Gallery page.
 *
 * All gallery images are pending client-supplied photographs.
 * Until real photos arrive, each gallery group shows its heading
 * with a controlled empty-state message.
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { PageHeader } from "@/components/waggies/page-header";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { galleryHero, galleryGroups } from "@/data/gallery";

export const metadata: Metadata = {
  title: "Photo Gallery",
  description:
    "Browse Waggies' boarding suites, grooming spa, outdoor play areas, and happy guest photos.",
  alternates: { canonical: "/about/gallery" },
  openGraph: {
    title: "Photo Gallery - Waggies Pet Care Abuja",
    description:
      "Browse Waggies' boarding suites, grooming spa, outdoor play areas, and happy guest photos.",
    url: "/about/gallery",
  },
};

export default function GalleryPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "About", href: "/about" },
          { label: "Gallery", href: "/about/gallery" },
        ]}
      />

      <PageHeader
        eyebrow={galleryHero.eyebrow}
        title={galleryHero.title}
        subtitle={galleryHero.subtitle}
        variant="white"
        align="center"
      />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 space-y-20">
          {galleryGroups.map((group) => (
            <div key={group.eyebrow} className="text-center">
              <p className="text-label text-primary mb-2">{group.eyebrow}</p>
              <h2 className="text-h2 text-primary-dark mb-8">{group.title}</h2>
              <div className="max-w-md mx-auto bg-surface-purple rounded-2xl p-8 md:p-10">
                <MaterialSymbol
                  name="photo_camera"
                  className="text-primary/20 text-5xl block mx-auto mb-4"
                  aria-hidden="true"
                />
                <p className="text-h3 text-primary-dark mb-2">
                  Photos coming soon
                </p>
                <p className="text-body-sm">
                  We are updating our gallery with real facility photos. Check back soon.
                </p>
              </div>
            </div>
          ))}
        </div>
      </section>

      <JsonLd
        data={webPageSchema(
          "Photo Gallery - Waggies Pet Care Abuja",
          "Browse Waggies' boarding suites, grooming spa, outdoor play areas, and happy guest photos.",
          "/about/gallery",
        )}
      />
    </>
  );
}
