/**
 * /about page - React port of resources/views/pages/about/index.blade.php
 *
 * Static marketing page. All content from src/data/about.ts.
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { HeroGradient } from "@/components/waggies/hero-gradient";
import { FeatureBand } from "@/components/waggies/feature-band";
import { CtaSecondary } from "@/components/waggies/cta-secondary";
import { AboutTeamCard } from "@/components/waggies/about-team-card";
import { WaggiesImage } from "@/components/waggies/waggies-image";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, aboutPageSchema } from "@/components/waggies/json-ld";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";

import {
  aboutHero,
  aboutStats,
  aboutPhilosophy,
  aboutMosaicImages,
  aboutStory,
  aboutOperatingStandards,
  aboutTeamMembers,
  aboutSpecialistsHeading,
  aboutHqContact,
  aboutCtaSecondary,
} from "@/data/about";

export const metadata: Metadata = {
  title: "About Us",
  description:
    "Waggies is a full-service pet care centre in Abuja offering boarding, grooming, vet care, training, and relocation under one roof.",
  alternates: { canonical: "/about" },
  openGraph: {
    title: "About Waggies - Pet Care in Abuja",
    description:
      "Waggies is a full-service pet care centre in Abuja offering boarding, grooming, vet care, training, and relocation under one roof.",
    url: "/about",
  },
};

export default function AboutPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "About", href: "/about" }]}
      />

      <HeroGradient
        title={aboutHero.title}
        subtitle={aboutHero.subtitle}
        primaryCta={aboutHero.primaryCta}
        secondaryCta={aboutHero.secondaryCta}
        imageSrc={aboutHero.imageSrc}
      />

      {/* Stats band */}
      <section className="relative z-30 -mt-8 mx-4 sm:mx-10 max-w-[1200px] lg:mx-auto bg-white rounded-2xl shadow-soft border border-surface-purple">
        <div className="px-6 py-8 sm:px-10 grid grid-cols-2 md:grid-cols-4 gap-8 md:divide-x md:divide-primary/10">
          {aboutStats.map((stat) => (
            <div key={stat.label} className="flex flex-col items-center text-center">
              <span className="font-serif text-4xl font-bold text-primary mb-1">
                {stat.value}
              </span>
              <span className="text-label text-primary-dark/50">
                {stat.label}
              </span>
            </div>
          ))}
        </div>
      </section>

      {/* Philosophy section */}
      <section className="py-20 bg-surface">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="flex flex-col lg:flex-row gap-16 lg:gap-24 items-center">
            <div className="lg:w-1/2">
              <div className="flex items-center gap-3 mb-4">
                <span className="h-px w-8 bg-primary" aria-hidden="true" />
                <p className="text-label text-primary">
                  {aboutPhilosophy.eyebrow}
                </p>
              </div>
              <h2 className="text-h2 text-primary-dark leading-tight mb-6">
                {aboutPhilosophy.title}
              </h2>
              <div className="space-y-5 text-body">
                {aboutPhilosophy.body.map((p, i) => (
                  <p key={i}>{p}</p>
                ))}
              </div>

              <div className="mt-10 grid grid-cols-1 sm:grid-cols-2 gap-6">
                {aboutPhilosophy.features.map((feature) => (
                  <div key={feature.title} className="flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-surface-purple flex items-center justify-center text-primary shrink-0">
                      <MaterialSymbol name={feature.icon} className="text-lg" />
                    </div>
                    <div>
                      <h3 className="text-h4 text-primary-dark">
                        {feature.title}
                      </h3>
                      <p className="text-body-sm mt-0.5">
                        {feature.description}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Image mosaic */}
            <div className="lg:w-1/2 w-full">
              <div className="grid grid-cols-2 gap-4">
                {aboutMosaicImages.map((img, i) => (
                  <div
                    key={i}
                    className={`rounded-2xl shadow-sm hover:shadow-soft transition ${i === 0 ? "mt-8" : ""}`}
                  >
                    <WaggiesImage
                      src={img.src}
                      alt={img.alt}
                      className="w-full h-64 rounded-2xl"
                      width={400}
                      height={256}
                    />
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2
                className="text-h2 text-primary-dark mb-5 leading-tight"
                dangerouslySetInnerHTML={{ __html: aboutStory.title }}
              />
              {aboutStory.paragraphs.map((p, i) => (
                <p
                  key={i}
                  className={`text-body ${
                    i < aboutStory.paragraphs.length - 1 ? "mb-4" : ""
                  }`}
                >
                  {p}
                </p>
              ))}
            </div>
            <div className="grid grid-cols-2 gap-4">
              {aboutStory.stats.map((stat) => (
                <div key={stat.label} className="bg-surface-purple rounded-2xl p-6 text-center">
                  <span className="font-serif text-4xl font-bold text-primary block mb-1">
                    {stat.value}
                  </span>
                  <span className="text-label text-primary-dark/50">
                    {stat.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Operating Standards */}
      <section>
        <FeatureBand
          eyebrow={aboutOperatingStandards.eyebrow}
          title={aboutOperatingStandards.title}
          subtitle={aboutOperatingStandards.subtitle}
          features={aboutOperatingStandards.features}
        />
      </section>

      {/* Meet the Specialists */}
      <section className="py-20 bg-surface">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="flex flex-col md:flex-row justify-between items-end mb-16 gap-6">
            <div>
              <p className="text-label text-primary block mb-3">
                {aboutSpecialistsHeading.eyebrow}
              </p>
              <h2 className="text-h2 text-primary-dark">
                {aboutSpecialistsHeading.title}
              </h2>
            </div>
            <p className="text-body-sm max-w-md">
              {aboutSpecialistsHeading.intro}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {aboutTeamMembers.map((member, i) => (
              <AboutTeamCard
                key={i}
                name={member.name}
                role={member.role}
                image={member.image}
                badge={member.badge}
                roles={member.roles}
              >
                {member.bio}
              </AboutTeamCard>
            ))}
          </div>
        </div>
      </section>

      {/* HQ contact + map */}
      <section className="py-20 bg-white border-t border-surface-purple">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          {/* Trust badges */}
          <div className="flex flex-wrap justify-center gap-6 text-sm text-primary-dark/70 mb-10">
            {aboutHqContact.trustBadges.map((badge) => (
              <div key={badge.label} className="flex items-center gap-2">
                <MaterialSymbol name={badge.icon} className="text-base text-primary" />
                <span>{badge.label}</span>
              </div>
            ))}
          </div>

          {/* Main card */}
          <div className="grid lg:grid-cols-2 rounded-2xl overflow-hidden border border-primary/10 shadow-soft bg-white">
            {/* Info */}
            <div className="flex flex-col">
              <div className="px-8 md:px-10 py-6 bg-surface-purple border-b border-white/40">
                <h3 className="text-h3 text-primary-dark">
                  {aboutHqContact.title}
                </h3>
              </div>

              <div className="p-8 flex flex-col gap-6">
                {/* Address */}
                <div>
                  <p className="text-label text-primary/50 mb-1">
                    {aboutHqContact.address.label}
                  </p>
                  <p
                    className="text-primary-dark leading-relaxed"
                    dangerouslySetInnerHTML={{ __html: aboutHqContact.address.lines }}
                  />
                </div>

                {/* Hours */}
                <div>
                  <p className="text-label text-primary/50 mb-1">
                    {aboutHqContact.hours.label}
                  </p>
                  {aboutHqContact.hours.lines.map((line) => (
                    <p key={line} className="text-primary-dark/80 text-sm">
                      {line}
                    </p>
                  ))}
                  <span className={aboutHqContact.hours.openNowBadge.className}>
                    {aboutHqContact.hours.openNowBadge.label}
                  </span>
                </div>

                {/* Contact */}
                <div>
                  <p className="text-label text-primary/50 mb-1">
                    {aboutHqContact.contact.label}
                  </p>
                  <a
                    href={aboutHqContact.contact.phone.href}
                    className={aboutHqContact.contact.phone.className}
                  >
                    {aboutHqContact.contact.phone.label}
                  </a>
                  <a
                    href={aboutHqContact.contact.email.href}
                    className={aboutHqContact.contact.email.className}
                  >
                    {aboutHqContact.contact.email.label}
                  </a>
                </div>

                {/* Actions */}
                <div className="flex flex-wrap items-center gap-3 pt-6 border-t border-primary/10">
                  <a
                    href={aboutHqContact.actions.primary.href}
                    target={aboutHqContact.actions.primary.targetBlank ? "_blank" : undefined}
                    rel={aboutHqContact.actions.primary.targetBlank ? "noopener noreferrer" : undefined}
                    className={aboutHqContact.actions.primary.className}
                  >
                    <MaterialSymbol name={aboutHqContact.actions.primary.icon} className="text-base" />
                    {aboutHqContact.actions.primary.label}
                  </a>
                  <a
                    href={aboutHqContact.actions.call.href}
                    aria-label={aboutHqContact.actions.call.ariaLabel}
                    className={aboutHqContact.actions.call.className}
                  >
                    <MaterialSymbol name={aboutHqContact.actions.call.icon} className="text-lg" />
                  </a>
                  <a
                    href={aboutHqContact.actions.whatsapp.href}
                    aria-label={aboutHqContact.actions.whatsapp.ariaLabel}
                    className={aboutHqContact.actions.whatsapp.className}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      viewBox="0 0 32 32"
                      className="w-6 h-6 fill-current shrink-0 block"
                      aria-hidden="true"
                      focusable="false"
                    >
                      <path d="M26.576 5.363c-2.69-2.69-6.406-4.354-10.511-4.354-8.209 0-14.865 6.655-14.865 14.865 0 2.732 0.737 5.291 2.022 7.491l-0.038-0.070-2.109 7.702 7.879-2.067c2.051 1.139 4.498 1.809 7.102 1.809h0.006c8.209-0.003 14.862-6.659 14.862-14.868 0-4.103-1.662-7.817-4.349-10.507l0 0zM16.062 28.228h-0.005c-0 0-0.001 0-0.001 0-2.319 0-4.489-0.64-6.342-1.753l0.056 0.031-0.451-0.267-4.675 1.227 1.247-4.559-0.294-0.467c-1.185-1.862-1.889-4.131-1.889-6.565 0-6.822 5.531-12.353 12.353-12.353s12.353 5.531 12.353 12.353c0 6.822-5.53 12.353-12.353 12.353h-0zM22.838 18.977c-0.371-0.186-2.197-1.083-2.537-1.208-0.341-0.124-0.589-0.185-0.837 0.187-0.246 0.371-0.958 1.207-1.175 1.455-0.216 0.249-0.434 0.279-0.805 0.094-1.15-0.466-2.138-1.087-2.997-1.852l0.010 0.009c-0.799-0.74-1.484-1.587-2.037-2.521l-0.028-0.052c-0.216-0.371-0.023-0.572 0.162-0.757 0.167-0.166 0.372-0.434 0.557-0.65 0.146-0.179 0.271-0.384 0.366-0.604l0.006-0.017c0.043-0.087 0.068-0.188 0.068-0.296 0-0.131-0.037-0.253-0.101-0.357l0.002 0.003c-0.094-0.186-0.836-2.014-1.145-2.758-0.302-0.724-0.609-0.625-0.836-0.637-0.216-0.010-0.464-0.012-0.712-0.012-0.395 0.010-0.746 0.188-0.988 0.463l-0.001 0.002c-0.802 0.761-1.3 1.834-1.3 3.023 0 0.026 0 0.053 0.001 0.079l-0-0.004c0.131 1.467 0.681 2.784 1.527 3.857l-0.012-0.015c1.604 2.379 3.742 4.282 6.251 5.564l0.094 0.043c0.548 0.248 1.25 0.513 1.968 0.74l0.149 0.041c0.442 0.14 0.951 0.221 1.479 0.221 0.303 0 0.601-0.027 0.889-0.078l-0.031 0.004c1.069-0.223 1.956-0.868 2.497-1.749l0.009-0.017c0.165-0.366 0.261-0.793 0.261-1.242 0-0.185-0.016-0.366-0.047-0.542l0.003 0.019c-0.092-0.155-0.34-0.247-0.712-0.434z" />
                    </svg>
                  </a>
                </div>
              </div>
            </div>

            {/* Map */}
            <div className="relative min-h-[420px] bg-surface-purple">
              <iframe
                className="w-full h-full"
                loading="lazy"
                src={aboutHqContact.mapIframeSrc}
                title="Waggies HQ location map"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Secondary CTA */}
      <section className="py-16 bg-white border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-8">
          <CtaSecondary
            heading={aboutCtaSecondary.heading}
            body={aboutCtaSecondary.body}
            primaryLabel={aboutCtaSecondary.primaryLabel}
            primaryHref={aboutCtaSecondary.primaryHref}
            primaryIcon={aboutCtaSecondary.primaryIcon}
          />
        </div>
      </section>

      <BreadcrumbSchema items={[{ name: "About Us", path: "/about" }]} />
      <JsonLd
        data={aboutPageSchema(
          "About Waggies - Pet Care in Abuja",
          "Waggies is a full-service pet care centre in Abuja offering boarding, grooming, vet care, training, and relocation under one roof.",
          "/about",
        )}
      />
    </>
  );
}
