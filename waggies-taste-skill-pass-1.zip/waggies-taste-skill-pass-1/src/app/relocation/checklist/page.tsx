import type { Metadata } from "next";
import { HeroHub } from "@/components/waggies/hero-hub";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { relocationChecklistPhases } from "@/data/relocation";

export const metadata: Metadata = {
  title: "Pet Relocation Checklist",
  description:
    "Comprehensive step-by-step checklist for relocating your pet internationally - from 3 months out to the day of travel.",
  alternates: { canonical: "/relocation/checklist" },
  openGraph: {
    title: "Pet Relocation Checklist - Waggies",
    description:
      "Comprehensive step-by-step checklist for relocating your pet internationally - from 3 months out to the day of travel.",
    url: "/relocation/checklist",
  },
};

/**
 * Relocation checklist page.
 *
 * Uses the `utility` layout pattern from Laravel (hero slot + max-w-5xl
 * content slot). Reproduces resources/views/pages/relocation/checklist.blade.php.
 */
export default function RelocationChecklistPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Pet Relocation", href: "/relocation" },
          { label: "Relocation Checklist" },
        ]}
      />

      <HeroHub type="checklist" variant="bottom" />

      <div className="max-w-5xl mx-auto px-4 md:px-10 py-12 md:py-20">
        {relocationChecklistPhases.map((phase, i) => (
          <div key={i} className="mb-10">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                <MaterialSymbol name={phase.icon} filled className="text-primary" />
              </div>
              <h2 className="font-serif text-xl font-bold text-primary-dark">
                {phase.heading}
              </h2>
            </div>
            <ul className="flex flex-col gap-3 pl-12">
              {phase.items.map((item, j) => (
                <li
                  key={j}
                  className="flex items-start gap-3 text-sm text-primary-dark/70"
                >
                  <MaterialSymbol
                    name="check_box_outline_blank"
                    filled
                    className="text-base text-primary/40 mt-0.5 shrink-0"
                  />
                  {item}
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div className="mt-12 p-6 bg-surface-purple rounded-2xl">
          <h3 className="font-serif text-lg font-bold text-primary-dark mb-2">
            Need help working through this?
          </h3>
          <p className="text-sm text-primary-dark/60 mb-4">
            Our relocation team manages every item on this list for you. Get in touch to start the process.
          </p>
          <a
            href="/contact"
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full font-bold text-sm transition shadow-sm"
          >
            Contact Us <MaterialSymbol name="arrow_forward" className="text-base" />
          </a>
        </div>
      </div>

      <JsonLd
        data={webPageSchema(
          "Pet Relocation Checklist - Waggies",
          "Comprehensive step-by-step checklist for relocating your pet internationally - from 3 months out to the day of travel.",
          "/relocation/checklist",
        )}
      />
    </>
  );
}
