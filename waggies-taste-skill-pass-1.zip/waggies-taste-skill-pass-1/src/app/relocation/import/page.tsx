import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ServiceFeatureGrid } from "@/components/waggies/boarding-feature-grid";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import {
  relocationImportHero,
  relocationImportSectionHeading,
  relocationImportFeatures,
  relocationImportCtaBand,
} from "@/data/relocation";
import { getFaqsForService } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Import a Pet to Nigeria",
  description:
    "Full-service pet import to Nigeria - permits, health certificates, microchip verification, and airport collection in Abuja.",
  alternates: { canonical: "/relocation/import" },
  openGraph: {
    title: "Import Pets to Nigeria - Waggies Abuja",
    description:
      "Full-service pet import to Nigeria - permits, health certificates, microchip verification, and airport collection in Abuja.",
    url: "/relocation/import",
  },
};

export default function RelocationImportPage() {
  const faqs = getFaqsForService("relocation", "import");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Pet Relocation", href: "/relocation" },
          { label: "Import to Nigeria", href: "/relocation/import" },
        ]}
      />

      <HeroImage {...relocationImportHero} />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={relocationImportSectionHeading.eyebrow}
            title={relocationImportSectionHeading.title}
            subtitle={relocationImportSectionHeading.subtitle}
          />
          <ServiceFeatureGrid features={relocationImportFeatures} />
        </div>
      </section>

      {/* CTA band */}
      <section className="py-16 bg-white border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="font-serif text-2xl font-bold text-primary-dark mb-1">
              {relocationImportCtaBand.heading}
            </h2>
            <p className="text-primary-dark/60">{relocationImportCtaBand.body}</p>
          </div>
          <div className="flex gap-3 shrink-0">
            <a
              href={relocationImportCtaBand.secondary.href}
              className="inline-flex items-center gap-2 border-2 border-primary text-primary px-6 py-3 rounded-full font-semibold hover:bg-primary hover:text-white transition"
            >
              {relocationImportCtaBand.secondary.label}
            </a>
            <a
              href={relocationImportCtaBand.primary.href}
              className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full font-bold transition shadow-sm"
            >
              {relocationImportCtaBand.primary.label}{" "}
              <MaterialSymbol name={relocationImportCtaBand.primary.icon} className="text-base" />
            </a>
          </div>
        </div>
      </section>

      {faqs.length > 0 ? (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              spacing="mb-8"
            />
            <FaqAccordion
              faqs={faqs.map((f) => ({ question: f.question, answer: f.answer }))}
            />
            <p className="mt-6 text-sm text-primary-dark/50">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      ) : null}

      <JsonLd
        data={serviceSchema(
          "Import Pets to Nigeria - Waggies Abuja",
          "Full-service pet import to Nigeria - permits, health certificates, microchip verification, and airport collection in Abuja.",
          "/relocation/import",
          "Nigeria",
        )}
      />
    </>
  );
}
