import type { NextConfig } from "next";

/**
 * Waggies — Next.js configuration.
 * Adapted for Z.ai platform environment.
 */

const isDev = process.env.NODE_ENV === "development";

/**
 * Base security headers applied to ALL responses in ALL modes.
 */
const baseSecurityHeaders = [
  {
    key: "Strict-Transport-Security",
    value: "max-age=31536000; includeSubDomains; preload",
  },
  { key: "X-Content-Type-Options", value: "nosniff" },
  { key: "X-Frame-Options", value: "DENY" },
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  {
    key: "Permissions-Policy",
    value:
      "camera=(), microphone=(), geolocation=(), payment=(), usb=(), magnetometer=(), gyroscope=(), accelerometer=()",
  },
];

/**
 * Content-Security-Policy value, mode-dependent.
 * Dev mode adds 'unsafe-eval' for React/Turbopack dev tooling.
 * Production stays strict — no 'unsafe-eval'.
 */
const cspValue = [
  "default-src 'self'",
  `script-src 'self' 'unsafe-inline'${isDev ? " 'unsafe-eval'" : ""}`,
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com",
  "img-src 'self' data: https:",
  "connect-src 'self'",
  "frame-src https://maps.google.com https://www.google.com",
  "frame-ancestors 'none'",
  "form-action 'self'",
  "base-uri 'self'",
  "object-src 'none'",
].join("; ");

const securityHeaders = [
  ...baseSecurityHeaders,
  { key: "Content-Security-Policy", value: cspValue },
];

/**
 * Construct allowedDevOrigins from the platform-provided container ID.
 */
const containerId = process.env.FC_CONTAINER_ID;
const allowedDevOrigins: string[] = containerId
  ? [`preview-${containerId}.space-z.ai`]
  : [];

const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: false,
  poweredByHeader: false,
  typescript: {
    ignoreBuildErrors: true,
  },
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "images.unsplash.com",
      },
    ],
    qualities: [75, 85],
  },
  allowedDevOrigins,
  async headers() {
    return [
      {
        source: "/:path*",
        headers: securityHeaders,
      },
    ];
  },
};

export default nextConfig;
