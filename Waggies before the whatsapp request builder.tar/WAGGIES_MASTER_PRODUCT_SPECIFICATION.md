# Waggies — Master Product Specification

**Document type:** Authoritative product specification reflecting all confirmed user decisions.
**Status:** Living document — update when new decisions are made.

---

## 1. Brand Identity

- **Name:** Waggies
- **Location:** Abuja, FCT, Nigeria
- **Address:** Life Camp, Efab City Estate, 65 1st Ave, Abuja 900108, FCT, Nigeria
- **Tone:** Warm, premium, trust-first
- **Color mode:** Light mode only. No dark mode.
- **Brand palette:** Purple `#6B2C91` (primary), `#E8D5B5` (secondary), `#FDFBF7` (surface)
- **Fonts:** DM Sans (body), Cormorant Garamond (headings)

---

## 2. Navigation

### Primary Navigation Order

1. **Services** (flyout)
2. **About** (flyout)
3. **Tools** (flyout)
4. **Resources** (flyout)
5. **Shop** (plain link)
6. **Book Now** (CTA button)

### My Pets
- Route `/my-pets` is **fully removed from the product**.
- No route, no page, no components (`src/components/waggies/pets/` deleted), no store (`src/store/pet-store.ts` deleted).
- NOT in primary navigation.
- NOT in sitemap.
- NOT disallowed in `robots.txt` (no entry remains — the route does not exist).

### Mobile Navigation
- Hamburger drawer with accordion groups.
- Fixed bottom navigation bar.

---

## 3. Services

### Service Categories

| Category | Sub-pages |
|---|---|
| Boarding | Dogs, Cats, Exotic |
| Grooming | — |
| Veterinary Care | — |
| Training | — |
| Relocation | Pet Import, Pet Export, Local Transport |

### Wellness
- "Wellness" is a **grouping label only**. There is NO Wellness overview page.

### Service Pages
- `/services` — Services hub
- `/services/boarding` — Boarding overview
- `/services/boarding/dogs` — Dog boarding
- `/services/boarding/cats` — Cat boarding
- `/services/boarding/exotic` — Exotic pet boarding
- `/services/grooming` — Grooming services
- `/services/vet-care` — Veterinary care
- `/services/training` — Pet training
- `/services/pricing` — Pricing overview

---

## 4. Relocation

### Core Services
1. Pet Import
2. Pet Export
3. Local Transport

### Local Transport
- Lives under the **Relocation** section, NOT Services.
- Independently bookable service.
- Canonical URL: `/relocation/transport`
- Legacy URL `/services/transport` → **301 redirect** to `/relocation/transport`.

### Relocation Pages
- `/relocation` — Relocation hub
- `/relocation/import` — Pet import
- `/relocation/export` — Pet export
- `/relocation/transport` — Local transport (canonical)
- `/relocation/checklist` — Relocation checklist (see §4.4)

### Relocation Checklist
- **Hybrid capability** — serves as both a Relocation sub-page and a Tool.
- Canonical URL: `/relocation/checklist`
- Discoverable from both the Relocation section and Tools section.
- **One implementation only** — do not duplicate.

---

## 5. Tools

All 11 required tools are confirmed and remain in the product:

1. Symptom Checker
2. Pet Age Calculator
3. Vaccination Schedule
4. Cost Calculator
5. Medication Dosage Guide
6. Nutrition Calculator
7. Emergency Guide
8. New Pet Checklist
9. Parasite Schedule
10. Behavior Tips
11. Breed Finder

### Medical Tools
- Tools that provide medical/health information (Symptom Checker, Medication Dosage Guide, Emergency Guide, Vaccination Schedule, Parasite Schedule) **must** include a reusable `MedicalDisclaimer` component.
- Clinical content must be controlled and reviewed — not user-generated.

---

## 6. Booking Model

- **Booking Request**, NOT auto-confirmed appointment.
- User submits a request; no real-time availability or scheduling backend.
- **WhatsApp fallback:** If the in-app booking flow encounters issues, the user is directed to WhatsApp with prepopulated context.

### WhatsApp Request Structure
Prepopulated WhatsApp message must include:
1. Service context (which service the user is inquiring about)
2. Selected options (species, size, dates, etc.)
3. Cost estimate (if applicable)
4. Additional user message (free text)

---

## 7. Contact

- `/contact` is the **canonical location/contact hub**.
- Full embedded map on the Contact page.
- Contact form routes submissions to **WhatsApp** (not email/server endpoint).

---

## 8. Pricing Model

Three pricing modes across services:

| Mode | Meaning |
|---|---|
| `FIXED` | Exact price displayed |
| `ESTIMATED` | Price range displayed |
| `QUOTE_REQUIRED` | "Contact us for quote" — no price shown |

---

## 9. Homepage Hero

- **Image-led** and **visually distinctive**.
- Final composition is delegated to the Taste Skill for visual quality authority.
- Must make a strong first impression.

---

## 10. Images

- **Zero unintended empty image slots.** Every image position must have a valid image.
- **Temporary stock imagery is allowed** (e.g., Unsplash), but must NOT be visibly labeled as "stock" or "placeholder" in the UI.
- Long-term goal: replace with authentic Waggies photography.

---

## 11. Gallery

- `/about/gallery` must remain **populated** with images.
- Currently: 23 images across 5 groups.
- No empty gallery states.

---

## 12. Team

- Team is **not artificially limited to 7 members**.
- Three verified staff with confirmed credentials:
  - **Dr. Nguhemen Doose Yuwa** — DVM, Head Veterinarian & Director
  - **Aifuwa Bob Osaze** — Director
  - **Oghomwen Oyuki Obaseki** — Secretary
- Additional placeholder roles cover the service organization (Vet Support, Lead Groomer, Boarding Manager, Pet Trainer, Relocation & Transport).
- **Verified credentials only** — do not publish unverified claims.

---

## 13. Footer

Layout order (top to bottom):
1. **Brand / Follow Us** block (logo, tagline, social icons)
2. **Navigation columns** row (Services, About, Tools, Resources, etc.)
3. Legal / copyright row

---

## 14. Accessibility

- **WCAG 2.2 AA compliance is mandatory.**
- Release-blocking requirement.

---

## 15. Responsive Design

- **Cross-device support is release-blocking.**
- Must work on mobile, tablet, and desktop.

---

## 16. Icons

- **Phosphor Icons** (`@phosphor-icons/react`) is the **primary** icon set.
- Lucide React is **discouraged** — still in package.json but should be removed.
- Material Symbols are **legacy** — no new usage.

---

## 17. Database & Backend

- Database schema **may be prepared** (Prisma migrations) for future use.
- **Production backend is deferred.** No server-side booking, auth, or cart persistence in this version.
- Current state: client-side only (localStorage, WhatsApp).

---

## 18. Search

- Command palette search (`search-command-palette.tsx`).
- All public pages must be indexed and searchable.

---

## 19. Shop

- Cart with **localStorage persistence** (zustand).
- Server-side cart persistence is **deferred**.
- Product pages at `/shop/[id]`.

---

## 20. Loyalty

- Loyalty programme page exists at `/loyalty`.

---

## 21. Content Sections

### Blog
- `/blog` — listing page
- `/blog/[slug]` — individual posts

### Guides
- `/guides` — listing page
- `/guides/[slug]` — individual guides

### Knowledge Base
- `/knowledge-base` — listing page
- `/knowledge-base/[slug]` — individual articles

### FAQ
- `/faq` — FAQ page

---

## 22. Cookie Banner

- Cookie consent banner exists.
- `/cookies-policy` page exists.

---

## 23. Legal Pages

- `/privacy-policy`
- `/terms-of-service`
- `/cookies-policy`

---

## 24. SEO

- `sitemap.ts` — dynamic sitemap generation
- `robots.ts` — robots.txt generation (`User-agent: *`, `Allow: /`; no disallow rules)
- Canonical URLs on all pages
- Breadcrumb structured data (Schema.org)
- JSON-LD where applicable (Organization, LocalBusiness, FAQ, etc.)

---

## 25. Motion & Animation

- Framer Motion with restrained intensity (`MOTION_INTENSITY: 2`).
- `prefers-reduced-motion` is respected — animations disabled/reduced for users who prefer it.
