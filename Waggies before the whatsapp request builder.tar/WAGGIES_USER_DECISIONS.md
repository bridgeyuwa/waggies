# Waggies — User Decisions Log

This document records only **explicitly user-made decisions**. Each is categorized for traceability.

---

## Navigation

- **[Navigation]** Primary nav order is: Services → About → Tools → Resources → Shop → Book Now.
- **[Navigation]** Mobile uses hamburger drawer with accordion groups + fixed bottom nav.

## Information Architecture

- **[IA]** My Pets (`/my-pets`) is **fully removed from the product**. No route, no page, no components, no store exist. It is not in navigation, not in sitemap, and has no entry in robots.txt (the route does not exist).

## Services

- **[Services]** Service categories are: Boarding (Dogs, Cats, Exotic), Grooming, Veterinary Care, Training, Relocation.
- **[Services]** "Wellness" is a grouping label only. There is **no Wellness overview page**.

## Relocation

- **[Relocation]** Relocation is a **separate top-level section** from Services.
- **[Relocation]** Core relocation services are: Pet Import, Pet Export, Local Transport.
- **[Relocation]** Local Transport lives under Relocation. Canonical URL is `/relocation/transport`. Old `/services/transport` must **301 redirect** to `/relocation/transport`.
- **[Relocation]** Local Transport is **independently bookable**.
- **[Relocation]** Relocation Checklist is a **hybrid capability** — it serves as both a Relocation sub-page and a Tool. Canonical URL is `/relocation/checklist`. Discoverable from both Relocation and Tools sections. **One implementation only** — no duplication.

## Tools

- **[Tools]** All 11 required tools remain in the product: Symptom Checker, Pet Age Calculator, Vaccination Schedule, Cost Calculator, Medication Dosage Guide, Nutrition Calculator, Emergency Guide, New Pet Checklist, Parasite Schedule, Behavior Tips, Breed Finder.
- **[Tools]** Medical/health tools **must** include a reusable `MedicalDisclaimer` component. Clinical content must be controlled and reviewed.

## Booking & Conversion

- **[Booking]** The booking flow is a **Booking Request**, not an auto-confirmed appointment. No real-time scheduling.
- **[Booking]** WhatsApp is the **fallback** and primary conversion channel.
- **[WhatsApp]** The WhatsApp-first model uses **structured prepopulated context**: service name, selected options, cost estimate, and user's additional message.

## Contact

- **[Contact]** `/contact` is the **canonical location/contact hub**.
- **[Contact]** Full embedded map must appear on the Contact page.
- **[Contact]** Contact form submissions route to **WhatsApp** (not a server endpoint).

## Pricing

- **[Pricing]** Three pricing modes: `FIXED` (exact price), `ESTIMATED` (price range), `QUOTE_REQUIRED` (no price shown, contact for quote).

## Homepage Hero

- **[Design]** Homepage hero must be **image-led and visually distinctive**. Final composition delegated to Taste Skill.

## Images

- **[Content]** Temporary stock imagery (e.g., Unsplash) is **allowed**, but must **not be visibly labeled** as stock or placeholder in the UI.
- **[Content]** **Zero unintended empty image slots** — every image position must have a valid image.
- **[Content]** Gallery (`/about/gallery`) **must remain populated** with images.

## Team

- **[Content]** Team roster is **not artificially limited to 7 members**.
- **[Content]** Three verified staff: Dr. Nguhemen Doose Yuwa (DVM, Head Vet & Director), Aifuwa Bob Osaze (Director), Oghomwen Oyuki Obaseki (Secretary).
- **[Content]** Only **verified credentials** may be published. Unverified staff profiles must not make credential claims.

## Footer

- **[Design]** Footer layout: Brand/Follow Us block **above** the navigation-column row.

## Design System

- **[Design]** Light mode only. No dark mode.
- **[Design]** Phosphor Icons (`@phosphor-icons/react`) is the **primary** icon set.

## Accessibility & Responsive

- **[Accessibility]** WCAG 2.2 AA compliance is **mandatory**.
- **[Accessibility]** Cross-device responsive design is a **release-blocking requirement**.

## Backend & Infrastructure

- **[Backend]** Database schema **may be prepared** (Prisma) for future use.
- **[Backend]** Production backend is **deferred** — no server-side booking, auth, or cart in this version.
