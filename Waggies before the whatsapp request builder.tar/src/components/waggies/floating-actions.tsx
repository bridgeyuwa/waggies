"use client";

import { useState, useRef, useEffect, useCallback } from "react";
import Link from "next/link";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  Sparkle,
  WhatsappLogo,
  ArrowUp,
  X,
} from "@phosphor-icons/react/dist/ssr";
import { businessInfo } from "@/lib/business-info";
import { whatsappFab } from "@/lib/site";

// ── Chat types & data ─────────────────────────────────────────────────────

interface ChatMessage {
  id: string;
  role: "bot" | "user";
  text: string;
}

const WELCOME_MESSAGE: ChatMessage = {
  id: "welcome",
  role: "bot",
  text: "Hi! I\u2019m the Waggies AI assistant. I can help with information about our services, booking, and pet care. (This is a preview \u2014 for instant replies, chat with us on WhatsApp.)",
};

// ── Bot response logic (preserved from chatbot-widget.tsx) ─────────────────

function getBotResponse(input: string): string {
  const lower = input.toLowerCase().trim();

  if (/^(hi|hello|hey|good morning|good afternoon|good evening|howdy)\b/.test(lower)) {
    return "Hello! How can I help you today?";
  }
  if (/\b(boarding|board|overnight|stay|kennel)\b/.test(lower)) {
    return "We offer comfortable boarding for dogs, cats, and exotic pets in Abuja. Our suites are climate-controlled with daily playtime and feeding. Learn more on our boarding page: ";
  }
  if (/\b(groom|grooming|bath|haircut|nail|trim|wash)\b/.test(lower)) {
    return "Our professional groomers provide breed-specific treatments including baths, haircuts, nail trims, and more. We use pet-safe products. See our grooming services: ";
  }
  if (/\b(pric|cost|how much|rate|fee|estimate|quote)\b/.test(lower)) {
    return "We have a pricing tool where you can get an estimate based on your needs. You can also request a quote on our pricing page: ";
  }
  if (/\b(contact|phone|whatsapp|call|reach|number|telephone)\b/.test(lower)) {
    return `You can reach us at ${businessInfo.phoneInternational} or chat with us on WhatsApp. You can also visit our contact page for more ways to reach us: `;
  }
  if (/\b(hour|open|close|time|schedule|when|available)\b/.test(lower)) {
    return "We\u2019re open Mon-Fri 9am-5pm, Sat-Sun 10am-2pm. Boarding guests receive 24/7 supervision regardless of office hours.";
  }
  if (/\b(vet|veterinary|doctor|health|medical|check.?up|vaccin)\b/.test(lower)) {
    return "We have on-site veterinary support for routine check-ups, vaccinations, and minor treatments. For more details, visit our vet care page: ";
  }
  if (/\b(train|obedience|behavio?r|puppy|class)\b/.test(lower)) {
    return "We offer positive-reinforcement dog training for puppies and adult dogs. Check out our training page: ";
  }
  if (/\b(relocat|move|travel|flight|import|export|international|nigeria|abroad)\b/.test(lower)) {
    return "We help with international pet relocation including import, export, and document preparation. Visit our relocation page for details: ";
  }
  if (/\b(transport|pickup|drop.?off|delivery|door.?to.?door|shuttle)\b/.test(lower)) {
    return "We offer door-to-door pet transport within Abuja as part of our relocation services. Visit our transport page: ";
  }

  return "I\u2019d love to help with that! For detailed questions, please contact us directly at +234 908 081 1902 or visit our contact page.";
}

function responseNeedsLink(
  text: string
): { linkText: string; href: string } | null {
  if (text.includes("boarding page")) {
    return { linkText: "View Boarding Services", href: "/services/boarding" };
  }
  if (text.includes("grooming services")) {
    return { linkText: "View Grooming Services", href: "/services/grooming" };
  }
  if (text.includes("pricing page")) {
    return { linkText: "View Pricing", href: "/services/pricing" };
  }
  if (text.includes("contact page")) {
    return { linkText: "Contact Us", href: "/contact" };
  }
  if (text.includes("vet care page")) {
    return { linkText: "View Vet Care", href: "/services/vet-care" };
  }
  if (text.includes("training page")) {
    return { linkText: "View Training", href: "/services/training" };
  }
  if (text.includes("relocation page")) {
    return { linkText: "View Relocation", href: "/relocation" };
  }
  if (text.includes("transport page")) {
    return { linkText: "View Local Transport", href: "/relocation/transport" };
  }
  return null;
}

let messageCounter = 0;
function nextId(): string {
  messageCounter += 1;
  return `msg_${messageCounter}`;
}

// ── Animation variants ─────────────────────────────────────────────────────

const fabVariants = {
  hidden: { opacity: 0, scale: 0.8, y: 10 },
  visible: { opacity: 1, scale: 1, y: 0 },
  exit: { opacity: 0, scale: 0.8, y: 10 },
};

const chatPanelVariants = {
  hidden: { opacity: 0, scale: 0.95, y: 12 },
  visible: { opacity: 1, scale: 1, y: 0 },
  exit: { opacity: 0, scale: 0.95, y: 12 },
};

// ── Focus management helpers ───────────────────────────────────────────────

const FOCUSABLE_SELECTOR =
  'a[href], button:not([disabled]), textarea:not([disabled]), input:not([disabled]), select:not([disabled]), [tabindex]:not([tabindex="-1"])';

function getFocusable(container: HTMLElement): HTMLElement[] {
  return Array.from(
    container.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR),
  ).filter((el) => el.offsetParent !== null);
}

// ── Main component ─────────────────────────────────────────────────────────

export function FloatingActions() {
  const [chatOpen, setChatOpen] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([WELCOME_MESSAGE]);
  const [input, setInput] = useState("");
  const [showBackToTop, setShowBackToTop] = useState(false);

  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const chatPanelRef = useRef<HTMLDivElement | null>(null);
  const chatLauncherRef = useRef<HTMLButtonElement | null>(null);
  // Remembers the element that had focus before the chat opened, so we can
  // deterministically restore focus on close. This is set synchronously in
  // the open() callback — NOT in an effect — so it always captures the
  // launcher even if the effect runs a tick later.
  const previousFocusRef = useRef<HTMLElement | null>(null);

  const shouldReduceMotion = useReducedMotion();

  const motionTransition = shouldReduceMotion
    ? { duration: 0 }
    : { type: "spring" as const, damping: 20, stiffness: 300 };

  // Scroll listener for back-to-top
  useEffect(() => {
    if (typeof window === "undefined") return;

    function handleScroll() {
      setShowBackToTop(window.scrollY > 400);
    }

    handleScroll();
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Scroll to bottom on new messages
  useEffect(() => {
    if (shouldReduceMotion) {
      messagesEndRef.current?.scrollIntoView({ behavior: "auto" });
    } else {
      messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
    }
  }, [messages, shouldReduceMotion]);

  // ── Chatbot focus management ──────────────────────────────────────────
  //
  // Lifecycle (WCAG 2.2 AA):
  //   1. openChat() captures the currently-focused element (the launcher)
  //      into previousFocusRef BEFORE setting chatOpen=true.
  //   2. When chatOpen becomes true, an effect moves focus into the panel
  //      (close button first, so Escape is one keypress away).
  //   3. While open, a keydown listener on the panel traps Tab/Shift-Tab.
  //   4. When chatOpen becomes false, an effect EXPLICITLY restores focus
  //      to previousFocusRef.current (the launcher). This runs on the state
  //      transition — NOT on component unmount — so it is not affected by
  //      AnimatePresence exit-animation timing.
  //
  // The close handler (closeChat) is a no-op beyond setChatOpen(false);
  // focus restoration is handled by the effect below, guaranteeing it
  // happens regardless of how the chat was closed (Escape, Close button,
  // or clicking a link inside the chat).

  const openChat = useCallback(() => {
    // Capture the launcher (or whatever has focus) BEFORE opening.
    previousFocusRef.current =
      (document.activeElement as HTMLElement) ?? chatLauncherRef.current;
    setChatOpen(true);
  }, []);

  const closeChat = useCallback(() => {
    setChatOpen(false);
  }, []);

  // Move focus INTO the panel when it opens
  useEffect(() => {
    if (!chatOpen) return;
    const panel = chatPanelRef.current;
    if (!panel) return;
    // Defer one frame so the panel is painted and focusable children are
    // visible to querySelector.
    const raf = requestAnimationFrame(() => {
      const focusables = getFocusable(panel);
      // Focus the close button first — it's at the top, and Escape is
      // the expected next action for a keyboard user who opened by mistake.
      const closeBtn = focusables.find((el) =>
        el.getAttribute("aria-label") === "Close chat",
      );
      (closeBtn ?? focusables[0] ?? panel).focus();
    });
    return () => cancelAnimationFrame(raf);
  }, [chatOpen]);

  // Restore focus to the launcher when the chat CLOSES.
  //
  // Challenge: the launcher is wrapped in <AnimatePresence> and only renders
  // when chatOpen is false. When the chat closes, the launcher needs a frame
  // to remount before we can focus it. We use requestAnimationFrame to defer
  // the focus call until after React has reconciled the DOM.
  //
  // We track `previousFocusRef` (the element that had focus before opening)
  // but we actually focus `chatLauncherRef.current` (the freshly-mounted
  // launcher button) because the original element reference may be stale
  // (the launcher unmounts while the chat is open).
  useEffect(() => {
    if (chatOpen) return;
    if (!previousFocusRef.current) return;

    // The launcher was the element that opened the chat (in normal usage).
    // It has just remounted via AnimatePresence. Defer one frame so React
    // has finished DOM reconciliation, then focus it.
    const raf = requestAnimationFrame(() => {
      const launcher = chatLauncherRef.current;
      if (launcher) {
        launcher.focus();
      }
    });
    previousFocusRef.current = null;
    return () => cancelAnimationFrame(raf);
  }, [chatOpen]);

  // Tab trap + Escape while the chat is open
  useEffect(() => {
    if (!chatOpen) return;
    const panel = chatPanelRef.current;
    if (!panel) return;

    function handleKeydown(e: KeyboardEvent) {
      if (e.key === "Escape") {
        e.preventDefault();
        closeChat();
        return;
      }
      if (e.key !== "Tab") return;

      const currentPanel = chatPanelRef.current;
      if (!currentPanel) return;
      const focusables = getFocusable(currentPanel);
      if (focusables.length === 0) {
        e.preventDefault();
        return;
      }
      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      if (!first || !last) return;

      if (e.shiftKey) {
        if (document.activeElement === first) {
          e.preventDefault();
          last.focus();
        }
      } else {
        if (document.activeElement === last) {
          e.preventDefault();
          first.focus();
        }
      }
    }

    panel.addEventListener("keydown", handleKeydown);
    return () => panel.removeEventListener("keydown", handleKeydown);
  }, [chatOpen, closeChat]);

  const scrollToTop = useCallback(() => {
    if (typeof window === "undefined") return;
    window.scrollTo({ top: 0, behavior: shouldReduceMotion ? "auto" : "smooth" });
  }, [shouldReduceMotion]);

  function handleSend() {
    const text = input.trim();
    if (!text) return;

    const userMsg: ChatMessage = { id: nextId(), role: "user", text };
    const botResponse = getBotResponse(text);
    const botMsg: ChatMessage = { id: nextId(), role: "bot", text: botResponse };

    setMessages((prev) => [...prev, userMsg, botMsg]);
    setInput("");
  }

  function handleKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  }

  return (
    <>
      {/* ── Chat panel (z-[51], above FABs) ──
       * When chat is open, all lower-priority FABs (WhatsApp, Back-to-Top)
       * are hidden to prevent collision. The panel uses a focus trap and
       * restores focus to the launcher on close.
       *
       * Mobile sizing: uses dvh units for correct viewport-height behavior.
       * Position clears the mobile bottom nav (h-16 = 4rem) via bottom offset.
       */}
      <AnimatePresence>
        {chatOpen && (
          <motion.div
            ref={chatPanelRef}
            initial={shouldReduceMotion ? false : chatPanelVariants.hidden}
            animate={chatPanelVariants.visible}
            exit={shouldReduceMotion ? undefined : chatPanelVariants.exit}
            transition={motionTransition}
            className="fixed z-[51] flex flex-col overflow-hidden bg-white rounded-2xl shadow-xl border border-primary/10"
            style={{
              // Width: 380px on desktop, fluid on mobile (with 1rem margin each side)
              width: "clamp(280px, calc(100vw - 2rem), 380px)",
              // Right position: 1.5rem from right edge (respecting safe area)
              right: "max(1.5rem, env(safe-area-inset-right, 0px))",
              // Bottom position: clears mobile bottom nav (4rem) + 1rem gap
              bottom: "max(5rem, calc(env(safe-area-inset-bottom, 0px) + 5rem))",
              // Max height: never exceed viewport minus padding; uses dvh
              maxHeight: "calc(100dvh - 7rem)",
              // Min height: ensures usable chat area
              minHeight: "min(60dvh, 400px)",
            }}
            role="dialog"
            aria-label="Waggies AI Assistant chat"
            aria-modal="true"
          >
            {/* Header */}
            <div className="flex items-center justify-between px-5 py-4 bg-primary shrink-0">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                  <Sparkle size={18} weight="fill" className="text-white" />
                </div>
                <div>
                  <h3 className="text-sm font-semibold text-white">
                    Waggies AI Assistant
                  </h3>
                  <p className="flex items-center gap-1.5 text-xs text-white/70">
                    Typically replies instantly
                    <span className="text-[10px] font-medium text-white/60 bg-white/10 px-1.5 py-0.5 rounded-full">Preview</span>
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={closeChat}
                aria-label="Close chat"
                className="p-3 rounded-lg hover:bg-white/10 transition-colors min-w-[44px] min-h-[44px] flex items-center justify-center"
              >
                <X size={18} weight="bold" className="text-white" />
              </button>
            </div>

            {/* Messages area */}
            <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
              {messages.map((msg) => {
                const linkInfo =
                  msg.role === "bot" ? responseNeedsLink(msg.text) : null;
                return (
                  <div
                    key={msg.id}
                    className={`flex ${
                      msg.role === "user" ? "justify-end" : "justify-start"
                    }`}
                  >
                    <div
                      className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm leading-relaxed ${
                        msg.role === "user"
                          ? "bg-primary text-white rounded-br-md"
                          : "bg-surface-purple text-primary-dark rounded-bl-md"
                      }`}
                    >
                      {msg.text}
                      {linkInfo && (
                        <Link
                          href={linkInfo.href}
                          onClick={closeChat}
                          className="inline-block mt-1.5 text-xs font-semibold underline underline-offset-2 text-primary"
                        >
                          {linkInfo.linkText} &rarr;
                        </Link>
                      )}
                    </div>
                  </div>
                );
              })}
              <div ref={messagesEndRef} />
            </div>

            {/* Input area - respects safe area on iOS */}
            <div className="px-4 py-3 pb-[max(0.75rem,env(safe-area-inset-bottom))] border-t border-primary/5 flex items-center gap-2 shrink-0">
              <input
                ref={inputRef}
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                onKeyDown={handleKeyDown}
                placeholder="Type a message..."
                aria-label="Chat message"
                className="flex-1 bg-surface border border-primary/10 rounded-full px-4 py-2.5 text-sm text-primary-dark placeholder:text-primary-dark/60 focus:outline-none focus:ring-2 focus:ring-primary/30"
              />
              <button
                type="button"
                onClick={handleSend}
                disabled={!input.trim()}
                aria-label="Send message"
                className="w-11 h-11 rounded-full bg-primary hover:bg-primary-dark text-white flex items-center justify-center transition-colors disabled:opacity-40 disabled:cursor-not-allowed shrink-0"
              >
                <ArrowUp size={18} weight="bold" className="rotate-45" />
              </button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── WhatsApp FAB (primary, right-6) ──
       * Hidden when chat is open to prevent collision. */}
      <AnimatePresence>
        {!chatOpen && (
          <motion.div
            initial={shouldReduceMotion ? false : fabVariants.hidden}
            animate={fabVariants.visible}
            exit={shouldReduceMotion ? undefined : fabVariants.exit}
            transition={motionTransition}
            className="fixed z-50"
            style={{
              bottom: "max(1.5rem, calc(env(safe-area-inset-bottom, 0px) + 0.5rem))",
              right: "max(1.5rem, env(safe-area-inset-right, 0px))",
            }}
          >
            <div className="relative group">
              <a
                href={whatsappFab.href}
                target="_blank"
                rel="noopener noreferrer"
                aria-label={whatsappFab.tooltip}
                className="w-14 h-14 bg-[#25D366] hover:bg-[#20BD5A] rounded-full shadow-2xl flex items-center justify-center text-white transition duration-200 hover:scale-110 hover:ring-4 hover:ring-white block"
              >
                <WhatsappLogo size={28} weight="fill" />
              </a>
              {/* Tooltip */}
              <div className="absolute bottom-full right-0 mb-2 opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none">
                <div className="bg-primary-dark text-white text-xs font-semibold px-3 py-1.5 rounded-full whitespace-nowrap shadow-md">
                  {whatsappFab.tooltip}
                </div>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Chatbot launcher FAB (left of WhatsApp) ──
       * Hidden when chat is open (the panel replaces it). */}
      <AnimatePresence>
        {!chatOpen && (
          <motion.button
            ref={chatLauncherRef}
            initial={shouldReduceMotion ? false : fabVariants.hidden}
            animate={fabVariants.visible}
            exit={shouldReduceMotion ? undefined : fabVariants.exit}
            transition={motionTransition}
            onClick={openChat}
            aria-label="Open Waggies AI Assistant"
            className="fixed z-50 w-14 h-14 rounded-full bg-primary hover:bg-primary-dark text-primary-foreground shadow-2xl flex items-center justify-center transition-colors focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2"
            style={{
              bottom: "max(1.5rem, calc(env(safe-area-inset-bottom, 0px) + 0.5rem))",
              right: "max(4.5rem, calc(env(safe-area-inset-right, 0px) + 3rem))",
            }}
          >
            <Sparkle size={28} weight="fill" />
          </motion.button>
        )}
      </AnimatePresence>

      {/* ── Back-to-Top (above WhatsApp, hidden when chat is open) ── */}
      <AnimatePresence>
        {!chatOpen && showBackToTop && (
          <motion.button
            initial={shouldReduceMotion ? false : fabVariants.hidden}
            animate={fabVariants.visible}
            exit={shouldReduceMotion ? undefined : fabVariants.exit}
            transition={motionTransition}
            onClick={scrollToTop}
            aria-label="Scroll to top"
            className="fixed z-50 w-11 h-11 rounded-full bg-primary hover:bg-primary-dark text-primary-foreground shadow-lg hover:shadow-xl flex items-center justify-center transition-colors focus:outline-none focus:ring-2 focus:ring-primary/50 focus:ring-offset-2"
            style={{
              bottom: "max(5.5rem, calc(env(safe-area-inset-bottom, 0px) + 4.5rem))",
              right: "max(1.5rem, env(safe-area-inset-right, 0px))",
            }}
          >
            <ArrowUp size={24} weight="bold" />
          </motion.button>
        )}
      </AnimatePresence>
    </>
  );
}
