/**
 * ToolCta — shared CTA section for tool pages.
 *
 * Provides a consistent, wide CTA band at the bottom of every tool page.
 * Uses the Waggies WhatsApp-first conversion model.
 *
 * Two CTA types:
 *   - "medical": for health-related tools → "Book a Vet Appointment" (WhatsApp, vet-care context)
 *     Always shows WhatsApp + Call (medical tools need phone escalation)
 *   - "general": for utility/planning tools → "Contact Waggies" (WhatsApp, general context)
 *     Call button is optional (showCall prop) — some utility tools don't need phone escalation
 *
 * The section uses the full container width (not narrow), with intentional
 * spacing, stacked buttons on mobile, and horizontal on desktop.
 */

import { whatsappRequestUrl, serviceRequestPreset } from "@/lib/whatsapp-request";
import { businessInfo } from "@/lib/business-info";
import { ArrowRight, Phone } from "@phosphor-icons/react/dist/ssr";

export type ToolCtaProps = {
  /** Visual + contextual variant */
  variant?: "medical" | "general";
  /** Custom heading (overrides default) */
  heading?: string;
  /** Custom body text (overrides default) */
  body?: string;
  /** Custom primary CTA label (overrides default) */
  primaryLabel?: string;
  /** Whether to show the "Call" secondary button. Medical tools always show it. */
  showCall?: boolean;
};

const DEFAULTS = {
  medical: {
    heading: "Need Professional Help?",
    body: "Our veterinary team is available for consultations. Book an appointment or call us directly.",
    primaryLabel: "Book a Vet Appointment",
    service: "vet-care",
    source: "tool-medical-cta",
  },
  general: {
    heading: "Ready to Get Started?",
    body: "Speak with our care team about your pet\u2019s needs or book a service today.",
    primaryLabel: "Contact Waggies",
    service: "boarding",
    source: "tool-general-cta",
  },
} as const;

export function ToolCta({
  variant = "general",
  heading,
  body,
  primaryLabel,
  showCall,
}: ToolCtaProps) {
  const config = DEFAULTS[variant];
  // Medical tools always show the Call button (phone escalation is important
  // for health concerns). Utility tools only show it when explicitly requested.
  const shouldShowCall = showCall ?? (variant === "medical");

  const whatsappUrl = whatsappRequestUrl(
    serviceRequestPreset(config.service, {
      source: config.source,
    }),
  );

  return (
    <div className="mt-12 bg-primary-dark rounded-2xl p-8 sm:p-10">
      <h2 className="font-serif text-xl sm:text-2xl font-bold text-white text-center">
        {heading ?? config.heading}
      </h2>
      <p className="text-white/70 text-sm sm:text-base mt-2 max-w-lg mx-auto text-center leading-relaxed">
        {body ?? config.body}
      </p>
      <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-6">
        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white font-bold px-8 py-3.5 rounded-full transition text-sm min-h-[44px] w-full sm:w-auto justify-center"
        >
          {primaryLabel ?? config.primaryLabel}
          <ArrowRight size={16} weight="bold" />
        </a>
        {shouldShowCall && (
          <a
            href={businessInfo.phoneHref}
            className="inline-flex items-center gap-2 border border-white/30 text-white hover:bg-white/10 font-semibold px-8 py-3.5 rounded-full transition text-sm min-h-[44px] w-full sm:w-auto justify-center"
          >
            <Phone size={16} weight="regular" />
            Call {businessInfo.phoneLocal}
          </a>
        )}
      </div>
    </div>
  );
}
