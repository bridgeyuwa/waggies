"use client";

import Link from "next/link";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { useCartStore } from "@/store/cart-store";
import type { Product } from "@/data/shop-data";

export type ProductCardProps = {
  product: Product;
};

function formatPrice(amount: number): string {
  return new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function ProductCard({ product }: ProductCardProps) {
  const addItem = useCartStore((s) => s.addItem);

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault(); // prevent Link navigation
    e.stopPropagation();
    addItem({
      productId: product.id,
      name: product.name,
      price: product.price,
      imageSrc: product.imageSrc,
    });
  };

  return (
    <Link
      href={`/shop/${product.id}`}
      className="group block bg-white border border-primary/10 rounded-xl overflow-hidden shadow-sm hover:shadow-md transition-shadow h-full flex flex-col"
    >
      {/* Image */}
      <div className="relative aspect-square bg-surface overflow-hidden">
        <img
          src={product.imageSrc}
          alt={product.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          loading="lazy"
        />
        {product.badge ? (
          <span className="absolute top-3 left-3 bg-primary text-white text-xs font-bold uppercase tracking-wider px-2.5 py-1 rounded-full">
            {product.badge}
          </span>
        ) : null}
      </div>

      {/* Content */}
      <div className="p-4 flex flex-col gap-2">
        <p className="text-xs font-medium text-primary/60 uppercase tracking-wider">
          {product.category}
        </p>
        <h3 className="font-serif text-base font-bold text-primary-dark leading-snug line-clamp-2">
          {product.name}
        </h3>
        <p className="text-sm text-primary-dark/50 leading-relaxed line-clamp-2">
          {product.description}
        </p>
        <div className="flex items-center justify-between mt-1">
          <span className="text-lg font-bold text-primary-dark">
            {formatPrice(product.price)}
          </span>
          <button
            type="button"
            onClick={handleAdd}
            aria-label={`Add ${product.name} to cart`}
            className="flex items-center gap-1.5 bg-primary hover:bg-primary-dark text-white text-xs font-semibold px-4 py-2 rounded-full transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
          >
            <MaterialSymbol name="add_shopping_cart" className="text-sm" ariaHidden={false} />
            Add to Cart
          </button>
        </div>
      </div>
    </Link>
  );
}

export { formatPrice };
