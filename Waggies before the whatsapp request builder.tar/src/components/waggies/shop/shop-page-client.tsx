"use client";

import { Suspense, useCallback, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { cn } from "@/lib/utils";
import { PRODUCT_CATEGORIES, type Product, type ProductCategory } from "@/data/shop-data";
import { ProductCard } from "./product-card";

export type ShopPageClientProps = {
  products: readonly Product[];
};

/**
 * Shop page client with category filtering persisted to the URL via
 * `?category=`. The "All" filter is the default and removes the param.
 *
 * Wrapped in a `<Suspense>` boundary because `useSearchParams()` opts
 * the component into client-side rendering and Next.js requires the
 * boundary so the rest of the page can still be statically rendered.
 */
function ShopPageClientInner({ products }: ShopPageClientProps) {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const allTabs: Array<"All" | ProductCategory> = [
    "All",
    ...PRODUCT_CATEGORIES,
  ];

  // Initialise from `?category=` on mount. Discards values that don't
  // match a known category so a stale/hand-edited URL never leaves the
  // UI in a "no products" state.
  const [activeCategory, setActiveCategory] = useState<"All" | ProductCategory>(
    () => {
      const param = searchParams.get("category");
      if (param && (PRODUCT_CATEGORIES as readonly string[]).includes(param)) {
        return param as ProductCategory;
      }
      return "All";
    },
  );

  const updateUrl = useCallback(
    (category: "All" | ProductCategory) => {
      const params = new URLSearchParams(searchParams.toString());
      if (category === "All") {
        params.delete("category");
      } else {
        params.set("category", category);
      }
      const qs = params.toString();
      router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    },
    [searchParams, router, pathname],
  );

  const handleCategoryChange = useCallback(
    (category: "All" | ProductCategory) => {
      setActiveCategory(category);
      updateUrl(category);
    },
    [updateUrl],
  );

  const filtered = useMemo(() => {
    if (activeCategory === "All") return products;
    return products.filter((p) => p.category === activeCategory);
  }, [products, activeCategory]);

  return (
    <section className="bg-surface pb-20 md:pb-28">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        {/* Category filter pills */}
        <div className="flex flex-wrap gap-2 mb-10 justify-center">
          {allTabs.map((tab) => {
            const isActive = activeCategory === tab;
            return (
              <button
                key={tab}
                type="button"
                onClick={() => handleCategoryChange(tab)}
                aria-pressed={isActive}
                className={cn(
                  "px-5 py-2.5 rounded-full text-sm font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2",
                  isActive
                    ? "bg-primary text-white"
                    : "bg-white text-primary-dark/60 border border-primary/10 hover:bg-surface-purple hover:text-primary-dark",
                )}
              >
                {tab}
              </button>
            );
          })}
        </div>

        {/* Product grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
            {filtered.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        ) : (
          <div className="text-center py-20">
            <MaterialIcon name="search_off" />
            <p className="text-primary-dark/50 text-sm mt-3">
              No products found in this category.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

export function ShopPageClient(props: ShopPageClientProps) {
  return (
    <Suspense fallback={<div className="bg-surface pb-20 md:pb-28" />}>
      <ShopPageClientInner {...props} />
    </Suspense>
  );
}

function MaterialIcon({ name }: { name: string }) {
  return (
    <span className="material-symbols-outlined text-4xl text-primary-dark/20">
      {name}
    </span>
  );
}
