"use client";

import { useState, useMemo, useCallback } from "react";
import { useSearchParams, useRouter, usePathname } from "next/navigation";
import { Suspense } from "react";
import { TestimonialCard } from "@/components/waggies/card-testimonial";
import { testimonials, testimonialFilterOptions, type TestimonialService } from "@/data/testimonials";
import { cn } from "@/lib/utils";

/**
 * Testimonials grid with service filtering and URL state.
 *
 * Filters are preserved in the URL query string (?service=boarding-dogs)
 * so the filtered view can be shared, bookmarked, and restored on back/forward.
 */
function TestimonialsGridInner() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const [selectedService, setSelectedService] = useState<TestimonialService | "all">(
    () => (searchParams.get("service") as TestimonialService | "all") || "all",
  );

  const updateUrl = useCallback(
    (service: TestimonialService | "all") => {
      const params = new URLSearchParams(searchParams.toString());
      if (service === "all") {
        params.delete("service");
      } else {
        params.set("service", service);
      }
      const qs = params.toString();
      router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    },
    [searchParams, router, pathname],
  );

  const handleFilterChange = useCallback(
    (service: TestimonialService | "all") => {
      setSelectedService(service);
      updateUrl(service);
    },
    [updateUrl],
  );

  const filtered = useMemo(() => {
    if (selectedService === "all") return testimonials;
    return testimonials.filter((t) => t.service === selectedService);
  }, [selectedService]);

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        {/* Filter controls */}
        <div className="mb-10">
          <fieldset>
            <legend className="sr-only">Filter testimonials by service</legend>
            <div className="flex flex-wrap gap-2">
              {testimonialFilterOptions.map((opt) => (
                <button
                  key={opt.value}
                  type="button"
                  onClick={() => handleFilterChange(opt.value)}
                  aria-pressed={selectedService === opt.value}
                  className={cn(
                    "px-4 py-2.5 rounded-full text-sm font-medium transition-colors min-h-[44px]",
                    "focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 focus-visible:ring-offset-1",
                    selectedService === opt.value
                      ? "bg-primary text-white"
                      : "bg-surface-purple text-primary-dark/70 hover:bg-surface-purple/80 hover:text-primary",
                  )}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </fieldset>
        </div>

        {/* Result count */}
        <p className="text-sm text-primary-dark/50 mb-6" aria-live="polite">
          Showing {filtered.length} of {testimonials.length} testimonials
        </p>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((t) => (
            <TestimonialCard
              key={t.id}
              stars={t.stars}
              quote={t.quote}
              authorInitial={t.authorInitial}
              authorName={t.authorName}
              authorSubtitle={t.authorSubtitle}
            />
          ))}
        </div>

        {filtered.length === 0 && (
          <p className="text-center text-primary-dark/50 py-12">
            No testimonials for this service yet. Check back soon.
          </p>
        )}
      </div>
    </section>
  );
}

export function TestimonialsGrid() {
  return (
    <Suspense fallback={<div className="py-20 bg-white" />}>
      <TestimonialsGridInner />
    </Suspense>
  );
}
