"use client";

/**
 * ShareThisPage - reusable share row for blog posts & service pages.
 *
 * Two variants:
 *   - 'row'       → horizontal row with label + round icon buttons.
 *   - 'floating'  → vertical fixed-position sidebar on the left side of the
 *                   viewport, hidden on mobile, visible only on xl screens.
 *
 * Uses Phosphor icons (not Material Symbols) per Waggies icon policy.
 * The label is configurable via the `contextLabel` prop so service pages
 * can say "Share this service" while blog posts say "Share this article".
 *
 * Share targets: Copy Link · WhatsApp · Facebook · X/Twitter · LinkedIn · Email
 */

import { useCallback, useEffect, useState } from "react";
import { usePathname } from "next/navigation";
import { motion, AnimatePresence } from "framer-motion";
import {
  LinkSimple,
  WhatsappLogo,
  FacebookLogo,
  XLogo,
  LinkedinLogo,
  EnvelopeSimple,
  Check,
} from "@phosphor-icons/react/dist/ssr";
import { cn } from "@/lib/utils";

export type ShareThisPageProps = {
  /** Page URL (relative path, e.g. "/blog/my-post"); defaults to current pathname */
  url?: string;
  /** Page title for share text */
  title: string;
  /** Optional description for share text (used in email body + some share text) */
  description?: string;
  /** Layout: 'row' for inline, 'floating' for fixed sidebar */
  variant?: "row" | "floating";
  /** Accessible label for the share group and visible heading text */
  contextLabel?: string;
  className?: string;
};

type ShareTarget = {
  name: string;
  /** Phosphor icon component */
  Icon: typeof LinkSimple;
  /** Accessible label, e.g. "Share on WhatsApp" */
  ariaLabel: string;
  /** Returns the share URL for the target (or null for Copy Link, handled separately) */
  buildUrl: (absoluteUrl: string, title: string, description: string) => string | null;
  /** True if this target opens an external window (mailto, https://...) */
  external?: boolean;
};

const SHARE_TARGETS: ShareTarget[] = [
  {
    name: "Copy Link",
    Icon: LinkSimple,
    ariaLabel: "Copy link to clipboard",
    buildUrl: () => null,
  },
  {
    name: "WhatsApp",
    Icon: WhatsappLogo,
    ariaLabel: "Share on WhatsApp",
    buildUrl: (url, title) =>
      `https://wa.me/?text=${encodeURIComponent(`${title} ${url}`)}`,
    external: true,
  },
  {
    name: "Facebook",
    Icon: FacebookLogo,
    ariaLabel: "Share on Facebook",
    buildUrl: (url) =>
      `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(url)}`,
    external: true,
  },
  {
    name: "X",
    Icon: XLogo,
    ariaLabel: "Share on X / Twitter",
    buildUrl: (url, title) =>
      `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`,
    external: true,
  },
  {
    name: "LinkedIn",
    Icon: LinkedinLogo,
    ariaLabel: "Share on LinkedIn",
    buildUrl: (url) =>
      `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
    external: true,
  },
  {
    name: "Email",
    Icon: EnvelopeSimple,
    ariaLabel: "Share via email",
    buildUrl: (url, title, description) =>
      `mailto:?subject=${encodeURIComponent(title)}&body=${encodeURIComponent(
        description ? `${description}\n\n${url}` : url,
      )}`,
    external: true,
  },
];

function useAbsoluteUrl(relativeUrl: string | undefined): string {
  const pathname = usePathname();
  const [absolute, setAbsolute] = useState("");

  useEffect(() => {
    if (typeof window === "undefined") return;
    const path = relativeUrl ?? pathname ?? "";
    const normalizedPath = path.startsWith("http") ? path : path.startsWith("/") ? path : `/${path}`;
    const raf = requestAnimationFrame(() => {
      setAbsolute(`${window.location.origin}${normalizedPath}`);
    });
    return () => cancelAnimationFrame(raf);
  }, [relativeUrl, pathname]);

  return absolute;
}

export function ShareThisPage({
  url,
  title,
  description = "",
  variant = "row",
  contextLabel = "Share this page",
  className,
}: ShareThisPageProps) {
  const absoluteUrl = useAbsoluteUrl(url);
  const [copied, setCopied] = useState(false);

  const handleClick = useCallback(
    (target: ShareTarget) => {
      if (!absoluteUrl) return;
      if (target.name === "Copy Link") {
        navigator.clipboard
          .writeText(absoluteUrl)
          .then(() => {
            setCopied(true);
            window.setTimeout(() => setCopied(false), 2000);
          })
          .catch(() => {
            /* clipboard write failed silently */
          });
        return;
      }
      const shareUrl = target.buildUrl(absoluteUrl, title, description);
      if (shareUrl) {
        window.open(shareUrl, "_blank", "noopener,noreferrer");
      }
    },
    [absoluteUrl, title, description],
  );

  // ── Row variant ────────────────────────────────────────────────────────
  if (variant === "row") {
    return (
      <div
        role="group"
        aria-label={contextLabel}
        className={cn(
          "flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4",
          "py-6 px-4 md:px-6 rounded-2xl bg-surface-purple/60",
          className,
        )}
      >
        <span className="text-sm font-semibold text-primary-dark shrink-0">
          {contextLabel}:
        </span>
        <div className="flex flex-wrap items-center gap-2">
          {SHARE_TARGETS.map((target) => {
            const isCopy = target.name === "Copy Link";
            const isCopied = isCopy && copied;
            const { Icon } = target;
            return (
              <motion.button
                key={target.name}
                type="button"
                onClick={() => handleClick(target)}
                whileHover={{ scale: 1.1 }}
                whileTap={{ scale: 0.95 }}
                aria-label={isCopied ? "Link copied to clipboard" : target.ariaLabel}
                className={cn(
                  "relative w-11 h-11 rounded-full",
                  "bg-white border border-primary/40",
                  "flex items-center justify-center text-primary-dark/70",
                  "hover:bg-primary hover:text-white hover:border-primary",
                  "transition-colors duration-200",
                  "focus:outline-none focus:ring-2 focus:ring-primary/40 focus:ring-offset-1",
                  isCopied && "bg-primary text-white border-primary",
                )}
              >
                {isCopied ? (
                  <Check size={18} weight="bold" />
                ) : (
                  <Icon size={18} weight="regular" />
                )}
                {isCopy && (
                  <AnimatePresence>
                    {copied && (
                      <motion.span
                        initial={{ opacity: 0, y: 4, scale: 0.9 }}
                        animate={{ opacity: 1, y: 0, scale: 1 }}
                        exit={{ opacity: 0, y: 4, scale: 0.9 }}
                        transition={{ duration: 0.18, ease: "easeOut" }}
                        className="absolute -top-8 left-1/2 -translate-x-1/2"
                      >
                        <span className="block whitespace-nowrap px-2.5 py-1 rounded-md bg-primary-dark text-white text-[11px] font-semibold shadow-md">
                          Copied!
                        </span>
                      </motion.span>
                    )}
                  </AnimatePresence>
                )}
              </motion.button>
            );
          })}
        </div>
      </div>
    );
  }

  // ── Floating variant ──────────────────────────────────────────────────
  return (
    <motion.aside
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.35, ease: "easeOut" }}
      className={cn(
        "hidden xl:flex fixed left-6 top-1/2 -translate-y-1/2 z-40 flex-col gap-3",
        className,
      )}
      role="group"
      aria-label={contextLabel}
    >
      {SHARE_TARGETS.map((target) => {
        const isCopy = target.name === "Copy Link";
        const isCopied = isCopy && copied;
        const { Icon } = target;
        return (
          <div key={target.name} className="group relative">
            <motion.button
              type="button"
              onClick={() => handleClick(target)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.95 }}
              aria-label={isCopied ? "Link copied to clipboard" : target.ariaLabel}
              className={cn(
                "w-11 h-11 rounded-full",
                "bg-white border border-surface-purple",
                "flex items-center justify-center text-primary-dark/60",
                "hover:bg-primary hover:text-white hover:border-primary",
                "transition-colors duration-200",
                "focus:outline-none focus:ring-2 focus:ring-primary/40",
                isCopied && "bg-primary text-white border-primary",
              )}
            >
              {isCopied ? (
                <Check size={20} weight="bold" />
              ) : (
                <Icon size={20} weight="regular" />
              )}
            </motion.button>
            <span
              className={cn(
                "absolute left-full ml-3 top-1/2 -translate-y-1/2",
                "whitespace-nowrap px-2.5 py-1 rounded-lg",
                "bg-primary-dark text-white text-xs font-medium",
                "opacity-0 group-hover:opacity-100 transition-opacity duration-200",
                "pointer-events-none shadow-lg",
              )}
            >
              {isCopied ? "Copied!" : target.name}
            </span>
            {isCopy && (
              <AnimatePresence>
                {copied && (
                  <motion.span
                    initial={{ opacity: 0, y: 4 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 4 }}
                    transition={{ duration: 0.18, ease: "easeOut" }}
                    className="absolute -top-8 left-1/2 -translate-x-1/2"
                  >
                    <span className="block whitespace-nowrap px-2.5 py-1 rounded-md bg-primary-dark text-white text-[11px] font-semibold shadow-md">
                      Copied!
                    </span>
                  </motion.span>
                )}
              </AnimatePresence>
            )}
          </div>
        );
      })}
    </motion.aside>
  );
}
