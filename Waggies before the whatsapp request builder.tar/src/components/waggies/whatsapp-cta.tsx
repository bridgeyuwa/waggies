"use client";

import { whatsappRequestUrl, serviceRequestPreset, type WhatsAppServiceRequest } from "@/lib/whatsapp-request";
import { cn } from "@/lib/utils";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr";

/**
 * WhatsApp CTA Button — generates a structured WhatsApp service request
 * and opens WhatsApp with the pre-populated message.
 *
 * This is the primary conversion component for Waggies service pages.
 * It preserves service context (service identifier, category, pricing mode)
 * so the WhatsApp message is specific to the service the user was viewing.
 *
 * The message is always user-editable in WhatsApp before sending.
 */
export function WhatsAppCta({
  service,
  label = "Request via WhatsApp",
  variant = "primary",
  className,
  additionalContext,
  source,
}: {
  /** The service identifier (e.g. "boarding", "local-transport", "relocation-import") */
  service: string;
  /** Button label */
  label?: string;
  /** Visual variant */
  variant?: "primary" | "secondary";
  /** Additional CSS classes */
  className?: string;
  /** Additional fields to merge into the request (petName, dates, location, etc.) */
  additionalContext?: Partial<WhatsAppServiceRequest>;
  /** Analytics source (defaults to "service-page-cta") */
  source?: string;
}) {
  const request = serviceRequestPreset(service, {
    ...additionalContext,
    source: source ?? "service-page-cta",
  });
  const href = whatsappRequestUrl(request);

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={cn(
        "inline-flex items-center justify-center gap-2 rounded-full font-bold transition shadow-sm focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2 min-h-[44px] px-6 py-3 text-sm",
        variant === "primary"
          ? "bg-primary hover:bg-primary-dark text-white"
          : "border-2 border-primary text-primary hover:bg-primary hover:text-white",
        className,
      )}
      aria-label={`${label} — opens WhatsApp with a pre-filled service request`}
    >
      {label}
      <ArrowRight size={16} weight="bold" />
    </a>
  );
}
