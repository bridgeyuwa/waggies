"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import { motion, useScroll, useMotionValueEvent } from "framer-motion";
import { cn } from "@/lib/utils";
import { useFocusTrap } from "@/lib/use-focus-trap";
import { CaretDown, X, PawPrint, ArrowRight, CaretRight } from "@phosphor-icons/react/dist/ssr";
import { SearchTrigger } from "./search-trigger";
import { CartButton } from "./shop/cart-button";
import {
  aboutMenuLinks,
  aboutMobileLinks,
  resourcesMenuLinks,
  resourcesMobileLinks,
  servicesHubLink,
  servicesNav,
  toolsHubLink,
  toolsNav,
  servicesMenuColumns,
  toolsMenuColumns,
  type DesktopMenuKey,
  type NavSection,
} from "@/lib/site";
import { NavFlyout } from "./nav-flyout";
import { MegaMenuFlyout } from "./mega-menu-flyout";

/**
 * Derive the active Waggies nav-section from the current URL pathname.
 *
 * The Laravel layout passes a `nav-section` prop from each route's controller
 * (e.g. `nav-section="services"` for `/services/boarding`). In Next.js App
 * Router, the root layout cannot easily receive per-page props - so we infer
 * the section from `usePathname()`. This mirrors the Laravel site's behaviour
 * exactly: the section key controls which top-level nav item is highlighted.
 *
 * Mapping preserved verbatim from the original `nav-section=` props in
 * the Laravel blade page templates:
 *
 *   ""                       → no highlight (homepage)
 *   /services/*              → "services"
 *   /relocation/*            → "relocation"
 *   /about/*                 → "about"
 *   /blog/*                  → "blog"
 *   /guides/*                → "guides"
 *   /knowledge-base/*        → "kb"
 *   /tools/*                 → "tools"
 *   /shop/*                  → "shop"
 *   /contact                 → "contact"
 *   /privacy-policy          → "legal"
 *   /terms-of-service        → "legal"
 *   /cookies-policy          → "legal"
 */
function inferNavSection(pathname: string): NavSection {
  if (pathname === "/" || pathname === "") return "";
  if (pathname.startsWith("/services")) return "services";
  if (pathname.startsWith("/relocation")) return "relocation";
  if (pathname.startsWith("/about")) return "about";
  if (pathname.startsWith("/tools")) return "tools";
  if (pathname.startsWith("/blog")) return "resources";
  if (pathname.startsWith("/guides")) return "resources";
  if (pathname.startsWith("/knowledge-base")) return "resources";
  if (pathname === "/faq") return "resources";
  if (pathname.startsWith("/shop")) return "shop";
  if (pathname.startsWith("/contact")) return "contact";

  if (
    pathname.startsWith("/privacy-policy") ||
    pathname.startsWith("/terms-of-service") ||
    pathname.startsWith("/cookies-policy")
  )
    return "legal";
  return "";
}

/**
 * Waggies Navbar - faithful React reproduction of the Alpine-controlled navbar
 * in resources/views/components/navbar.blade.php.
 *
 * State machine (mirrors the Alpine `x-data` block):
 *
 *   mobileOpen:   boolean     - mobile drawer visibility
 *   servicesOpen: boolean     - mobile accordion: Services sub-section
 *   aboutOpen:    boolean     - mobile accordion: About sub-section
 *   resourcesOpen:boolean     - mobile accordion: Resources sub-section
 *   activeMenu:   key | null  - which desktop flyout panel is currently shown
 *   pinnedMenu:   key | null  - which desktop flyout is "pinned" open by click
 *
 * Hover timing:
 *   - scheduleOpen(menu)  waits 150ms before activating the menu, unless a
 *     different menu is pinned (in which case the hover is suppressed).
 *   - scheduleClose(menu) waits 150ms before deactivating, unless the menu is
 *     pinned.
 *   - Any new schedule cancels the previous timer.
 *
 * Click behavior (togglePin):
 *   - Clicking a trigger button toggles the pinned state of that menu.
 *   - If pinned == clicked, unpin and close.
 *   - Otherwise pin and activate the clicked menu.
 *
 * Keyboard:
 *   - Escape: closes mobile drawer first; if mobile is closed, closes desktop
 *     menus and restores focus to the trigger of the closed menu.
 *   - ArrowDown on a trigger: opens the menu and focuses the first menuitem.
 *   - ArrowUp/Down inside the Services panel: cycles focus among menuitems.
 *     (The Laravel source only wires this for the services panel - preserved.)
 *
 * Click-outside:
 *   - Clicks anywhere outside the desktop <ul> close desktop menus.
 *   - Clicks on the mobile overlay close the mobile drawer.
 *
 * Body scroll lock:
 *   - While the mobile drawer is open, body.overflow is set to hidden.
 *
 * Focus trap:
 *   - While the mobile drawer is open, Tab/Shift-Tab cycles within it; the
 *     previously-focused element is restored on close.
 */
export function Navbar({ navSection }: { navSection?: NavSection } = {}) {
  const pathname = usePathname();
  // Per-page prop wins; otherwise infer from the URL (matches Laravel's
  // `nav-section=` prop on each Blade page).
  const section = navSection ?? inferNavSection(pathname);
  const servicesActive = section === "services" || section === "relocation";
  const toolsActive = section === "tools";
  const resourcesActive = section === "resources";
  const aboutActive = section === "about";
  const shopActive = section === "shop";

  // --- Alpine state ------------------------------------------------------
  const [mobileOpen, setMobileOpen] = useState(false);
  const [servicesOpen, setServicesOpen] = useState(false);
  const [aboutOpen, setAboutOpen] = useState(false);
  const [resourcesOpen, setResourcesOpen] = useState(false);
  const [toolsOpen, setToolsOpen] = useState(false);

  // Mobile expandable sub-groups: tracks which parent (Boarding/Relocation)
  // and which Tools category (Pet Health/Pet Care/Planning) is expanded.
  const [expandedServiceParents, setExpandedServiceParents] = useState<
    Record<string, boolean>
  >({});
  const [expandedToolCategories, setExpandedToolCategories] = useState<
    Record<string, boolean>
  >({});

  const toggleServiceParent = useCallback((key: string) => {
    setExpandedServiceParents((prev) => ({ ...prev, [key]: !prev[key] }));
  }, []);
  const toggleToolCategory = useCallback((key: string) => {
    setExpandedToolCategories((prev) => ({ ...prev, [key]: !prev[key] }));
  }, []);
  const [activeMenu, setActiveMenu] = useState<DesktopMenuKey | null>(null);
  const [pinnedMenu, setPinnedMenu] = useState<DesktopMenuKey | null>(null);

  // --- Scroll-based navbar style ------------------------------------------
  const [scrolled, setScrolled] = useState(false);
  const { scrollY } = useScroll();
  useMotionValueEvent(scrollY, "change", (latest) => {
    setScrolled(latest > 40);
  });

  // --- Refs --------------------------------------------------------------
  const hoverTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const navRootRef = useRef<HTMLDivElement | null>(null);
  const desktopUlRef = useRef<HTMLUListElement | null>(null);
  const navElementRef = useRef<HTMLElement | null>(null);
  const servicesTriggerRef = useRef<HTMLButtonElement | null>(null);
  const aboutTriggerRef = useRef<HTMLButtonElement | null>(null);
  const resourcesTriggerRef = useRef<HTMLButtonElement | null>(null);
  const toolsTriggerRef = useRef<HTMLButtonElement | null>(null);
  const servicesPanelRef = useRef<HTMLDivElement | null>(null);
  const aboutPanelRef = useRef<HTMLDivElement | null>(null);
  const resourcesPanelRef = useRef<HTMLDivElement | null>(null);
  const toolsPanelRef = useRef<HTMLDivElement | null>(null);

  // Mobile drawer focus trap (matches Alpine x-trap="mobileOpen").
  const mobileDrawerRef = useFocusTrap<HTMLDivElement>(mobileOpen);

  // --- Alpine method equivalents ----------------------------------------

  const clearHoverTimer = useCallback(() => {
    if (hoverTimerRef.current !== null) {
      clearTimeout(hoverTimerRef.current);
      hoverTimerRef.current = null;
    }
  }, []);

  const scheduleOpen = useCallback(
    (menu: DesktopMenuKey) => {
      clearHoverTimer();
      hoverTimerRef.current = setTimeout(() => {
        setPinnedMenu((current) => {
          // Suppress hover activation when a different menu is pinned.
          if (current && current !== menu) return current;
          setActiveMenu(menu);
          return current;
        });
      }, 150);
    },
    [clearHoverTimer],
  );

  const scheduleClose = useCallback(
    (menu: DesktopMenuKey) => {
      clearHoverTimer();
      hoverTimerRef.current = setTimeout(() => {
        setPinnedMenu((pinned) => {
          if (pinned === menu) return pinned; // pinned menus stay open
          setActiveMenu((active) => (active === menu ? null : active));
          return pinned;
        });
      }, 150);
    },
    [clearHoverTimer],
  );

  const togglePin = useCallback(
    (menu: DesktopMenuKey) => {
      clearHoverTimer();
      setPinnedMenu((current) => {
        if (current === menu) {
          // Unpin and close.
          setActiveMenu(null);
          return null;
        }
        setActiveMenu(menu);
        return menu;
      });
    },
    [clearHoverTimer],
  );

  const closeDesktopMenus = useCallback(() => {
    clearHoverTimer();
    setPinnedMenu(null);
    setActiveMenu(null);
  }, [clearHoverTimer]);

  const focusFirstMenuItem = useCallback(
    (menu: DesktopMenuKey) => {
      setActiveMenu(menu);
      requestAnimationFrame(() => {
        const panelRef =
          menu === "services"
            ? servicesPanelRef.current
            : menu === "about"
              ? aboutPanelRef.current
              : menu === "tools"
                ? toolsPanelRef.current
                : resourcesPanelRef.current;
        panelRef?.querySelector<HTMLElement>("[role=menuitem]")?.focus();
      });
    },
    [],
  );

  // --- Body scroll lock + Escape handling (x-effect + @keydown.escape) --

  useEffect(() => {
    if (typeof document === "undefined") return;
    // x-effect="document.body.classList.toggle('overflow-hidden', mobileOpen)"
    document.body.classList.toggle("overflow-hidden", mobileOpen);
    return () => {
      document.body.classList.remove("overflow-hidden");
    };
  }, [mobileOpen]);

  useEffect(() => {
    const handleKeydown = (event: KeyboardEvent) => {
      if (event.key !== "Escape") return;
      if (mobileOpen) {
        setMobileOpen(false);
      } else if (activeMenu !== null) {
        closeDesktopMenus();
        // Restore focus to the trigger of the closed menu (matches Alpine
        // @keydown.escape.prevent on the panel: closeDesktopMenus();
        // $refs.servicesTrigger?.focus()).
        const triggerRef =
          activeMenu === "services"
            ? servicesTriggerRef.current
            : activeMenu === "about"
              ? aboutTriggerRef.current
              : activeMenu === "tools"
                ? toolsTriggerRef.current
                : resourcesTriggerRef.current;
        triggerRef?.focus();
      }
    };
    window.addEventListener("keydown", handleKeydown);
    return () => window.removeEventListener("keydown", handleKeydown);
  }, [mobileOpen, activeMenu, closeDesktopMenus]);

  // --- Click-outside for desktop menus (@click.outside on <ul>) ---------

  useEffect(() => {
    if (activeMenu === null && pinnedMenu === null) return;
    const handleClick = (event: MouseEvent) => {
      const ul = desktopUlRef.current;
      if (!ul) return;
      if (ul.contains(event.target as Node)) return;
      closeDesktopMenus();
    };
    // Defer one tick so the click that opened the menu doesn't immediately
    // close it.
    const id = setTimeout(() => {
      document.addEventListener("click", handleClick);
    }, 0);
    return () => {
      clearTimeout(id);
      document.removeEventListener("click", handleClick);
    };
  }, [activeMenu, pinnedMenu, closeDesktopMenus]);

  // --- Helpers for trigger button classes (preserve Blade ternaries) ---

  const triggerClass = (isActive: boolean) =>
    cn(
      "flex items-center gap-1 px-4 py-2 text-sm font-medium uppercase tracking-wide rounded-lg transition-colors",
      isActive
        ? "text-primary font-semibold bg-surface-purple"
        : "text-primary-dark/60 hover:text-primary hover:bg-surface-purple",
    );

  return (
    <div className="contents" ref={navRootRef}>
      {/* ── Desktop header (sticky) ──────────────────────────────────────── */}
      <motion.header
        className={cn(
          "sticky top-0 z-50 w-full overflow-visible transition-all duration-300",
          scrolled
            ? "bg-white/90 backdrop-blur-lg border-b border-surface-purple/60 shadow-[0_2px_20px_rgba(107,44,145,0.06)] supports-[backdrop-filter]:bg-white/85"
            : "bg-white/60 backdrop-blur-sm border-b border-transparent shadow-none supports-[backdrop-filter]:bg-white/50",
        )}
        initial={false}
        animate={{ opacity: 1 }}
      >
        <nav
          ref={navElementRef}
          className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 h-16 flex items-center justify-between overflow-visible"
          aria-label="Main navigation"
        >
          {/* Logo */}
          <Link
            href="/"
            className="flex items-center gap-2 shrink-0"
            aria-label="Waggies - home"
          >
            <div className="w-8 h-8 rounded-xl bg-primary flex items-center justify-center shadow-sm">
              <PawPrint size={18} weight="fill" className="text-white" />
            </div>
            <span className="font-serif text-xl font-bold text-primary-dark tracking-tight">
              Waggies
            </span>
          </Link>

          {/* Desktop nav — canonical order: Services, About, Tools, Resources, Shop */}
          <ul
            ref={desktopUlRef}
            className="hidden lg:flex items-center gap-1 overflow-visible"
            role="list"
          >
            {/* Services mega-menu */}
            <li
              className="relative overflow-visible"
              onMouseEnter={() => scheduleOpen("services")}
              onMouseLeave={() => scheduleClose("services")}
            >
              <button
                ref={servicesTriggerRef}
                type="button"
                aria-haspopup="true"
                aria-expanded={activeMenu === "services"}
                onClick={(e) => {
                  e.preventDefault();
                  togglePin("services");
                }}
                onKeyDown={(e) => {
                  if (e.key === "ArrowDown") {
                    e.preventDefault();
                    focusFirstMenuItem("services");
                  }
                }}
                className={triggerClass(servicesActive)}
                {...(servicesActive ? { "aria-current": "page" as const } : {})}
              >
                Services
                <CaretDown
                  size={14}
                  weight="bold"
                  className={cn(
                    "transition-transform duration-200",
                    activeMenu === "services" && "rotate-180",
                  )}
                />
              </button>
              <MegaMenuFlyout
                columns={servicesMenuColumns}
                isOpen={activeMenu === "services"}
                onClose={closeDesktopMenus}
                triggerRef={servicesTriggerRef}
                panelRef={servicesPanelRef}
                navRef={navElementRef}
                label="Our Services"
                ariaLabel="Services menu"
                columnsCount={3}
                hubLink={servicesHubLink}
                parentGroupLabels={["Boarding", "Relocation"]}
              />
            </li>

            {/* About */}
            <li
              className="relative overflow-visible"
              onMouseEnter={() => scheduleOpen("about")}
              onMouseLeave={() => scheduleClose("about")}
            >
              <button
                ref={aboutTriggerRef}
                type="button"
                aria-haspopup="true"
                aria-expanded={activeMenu === "about"}
                onClick={(e) => {
                  e.preventDefault();
                  togglePin("about");
                }}
                className={triggerClass(aboutActive)}
                {...(aboutActive ? { "aria-current": "page" as const } : {})}
              >
                About
                <CaretDown
                  size={14}
                  weight="bold"
                  className={cn(
                    "transition-transform duration-200",
                    activeMenu === "about" && "rotate-180",
                  )}
                />
              </button>
              <NavFlyout
                links={aboutMenuLinks}
                isOpen={activeMenu === "about"}
                onClose={closeDesktopMenus}
                triggerRef={aboutTriggerRef}
                panelRef={aboutPanelRef}
                align="right"
                label="About Waggies"
              />
            </li>

            {/* Tools */}
            <li
              className="relative overflow-visible"
              onMouseEnter={() => scheduleOpen("tools")}
              onMouseLeave={() => scheduleClose("tools")}
            >
              <button
                ref={toolsTriggerRef}
                type="button"
                aria-haspopup="true"
                aria-expanded={activeMenu === "tools"}
                onClick={(e) => {
                  e.preventDefault();
                  togglePin("tools");
                }}
                className={triggerClass(toolsActive)}
                {...(toolsActive ? { "aria-current": "page" as const } : {})}
              >
                Tools
                <CaretDown
                  size={14}
                  weight="bold"
                  className={cn(
                    "transition-transform duration-200",
                    activeMenu === "tools" && "rotate-180",
                  )}
                />
              </button>
              <MegaMenuFlyout
                columns={toolsMenuColumns}
                isOpen={activeMenu === "tools"}
                onClose={closeDesktopMenus}
                triggerRef={toolsTriggerRef}
                panelRef={toolsPanelRef}
                navRef={navElementRef}
                label="Pet Care Tools"
                ariaLabel="Tools menu"
                columnsCount={3}
                hubLink={toolsHubLink}
              />
            </li>

            {/* Resources */}
            <li
              className="relative overflow-visible"
              onMouseEnter={() => scheduleOpen("resources")}
              onMouseLeave={() => scheduleClose("resources")}
            >
              <button
                ref={resourcesTriggerRef}
                type="button"
                aria-haspopup="true"
                aria-expanded={activeMenu === "resources"}
                onClick={(e) => {
                  e.preventDefault();
                  togglePin("resources");
                }}
                className={triggerClass(resourcesActive)}
                {...(resourcesActive ? { "aria-current": "page" as const } : {})}
              >
                Resources
                <CaretDown
                  size={14}
                  weight="bold"
                  className={cn(
                    "transition-transform duration-200",
                    activeMenu === "resources" && "rotate-180",
                  )}
                />
              </button>
              <NavFlyout
                links={resourcesMenuLinks}
                isOpen={activeMenu === "resources"}
                onClose={closeDesktopMenus}
                triggerRef={resourcesTriggerRef}
                panelRef={resourcesPanelRef}
                align="right"
                label="Resources"
              />
            </li>

            {/* Shop - plain link, no flyout */}
            <li>
              <Link
                href="/shop"
                className={cn(
                  "flex items-center gap-1 px-4 py-2 text-sm font-medium uppercase tracking-wide rounded-lg transition-colors",
                  shopActive
                    ? "text-primary font-semibold bg-surface-purple"
                    : "text-primary-dark/60 hover:text-primary hover:bg-surface-purple",
                )}
                {...(shopActive ? { "aria-current": "page" as const } : {})}
              >
                Shop
              </Link>
            </li>
          </ul>

          {/* Desktop CTA + Hamburger */}
          <div className="flex items-center gap-3">
            <div className="hidden lg:flex items-center gap-2">
              <CartButton />
              <SearchTrigger />
            </div>
            <Link
              href="/contact"
              className="hidden lg:flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-2.5 rounded-full text-sm font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
            >
              Book Now
              <ArrowRight size={16} weight="bold" className="text-white" />
            </Link>

            <button
              type="button"
              onClick={() => setMobileOpen((v) => !v)}
              aria-expanded={mobileOpen}
              aria-label={mobileOpen ? "Close navigation menu" : "Open navigation menu"}
              aria-controls="mobile-menu"
              className="lg:hidden flex flex-col gap-[5px] p-3 rounded-lg hover:bg-surface-purple transition-colors"
            >
              <span
                className={cn(
                  "block w-5 h-0.5 bg-primary-dark rounded-full transition-all duration-300 origin-center",
                  mobileOpen && "translate-y-[7px] rotate-45",
                )}
                aria-hidden="true"
              />
              <span
                className={cn(
                  "block w-5 h-0.5 bg-primary-dark rounded-full transition-all duration-300",
                  mobileOpen && "opacity-0",
                )}
                aria-hidden="true"
              />
              <span
                className={cn(
                  "block w-5 h-0.5 bg-primary-dark rounded-full transition-all duration-300 origin-center",
                  mobileOpen && "-translate-y-[7px] -rotate-45",
                )}
                aria-hidden="true"
              />
            </button>
          </div>
        </nav>
      </motion.header>

      {/* ── Mobile overlay ─────────────────────────────────────── */}
      <div
        className={cn(
          "fixed inset-0 bg-primary-dark/40 backdrop-blur-sm z-40 lg:hidden transition duration-300",
          mobileOpen ? "opacity-100" : "opacity-0 pointer-events-none",
        )}
        onClick={() => setMobileOpen(false)}
        aria-hidden="true"
      />

      {/* ── Mobile menu ──────────────────────────────────────── */}
      <aside
        id="mobile-menu"
        ref={mobileDrawerRef}
        role="navigation"
        aria-label="Main navigation"
        tabIndex={-1}
        className={cn(
          "fixed top-0 right-0 h-full w-80 max-w-[90vw] bg-white z-50 shadow-2xl flex flex-col lg:hidden transition-transform duration-300 ease-out",
          mobileOpen ? "translate-x-0" : "translate-x-full",
        )}
        aria-hidden={!mobileOpen}
      >
        <div className="flex items-center justify-between px-5 py-4 border-b border-surface-purple">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
              <PawPrint size={16} weight="fill" className="text-white" />
            </div>
            <span className="font-serif text-lg font-bold text-primary-dark">Waggies</span>
          </div>
          <button
            type="button"
            onClick={() => setMobileOpen(false)}
            aria-label="Close navigation menu"
            className="p-3 rounded-lg hover:bg-surface-purple transition-colors"
          >
            <X size={20} weight="bold" className="text-primary-dark" />
          </button>
        </div>

        <nav
          className="flex-1 overflow-y-auto px-4 py-4 flex flex-col gap-1"
          aria-label="Mobile navigation links"
        >
          {/* Search trigger (top row) - opens the global command palette */}
          <div className="mb-2">
            <SearchTrigger
              variant="row"
              onOpen={() => setMobileOpen(false)}
            />
          </div>

          {/* ── Services section ──────────────────────────────────────────
           * Derived from the unified `servicesNav` data model.
           * - "All Services" hub link is a direct Services-level destination.
           * - "parent" groups (Boarding, Relocation) are Level-1 expandable
           *   groups. Their overview link is Level 2 (visually stronger),
           *   and their specialized services are Level 3 (indented children).
           * - "desktopOnly" groups (Wellness) are flattened: their children
           *   become direct Services-level items with no extra nesting.
           */}
          <div>
            <button
              type="button"
              onClick={() => setServicesOpen((v) => !v)}
              aria-expanded={servicesOpen}
              aria-controls="mobile-services-submenu"
              className="w-full flex items-center justify-between px-3 py-3 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-xl transition-colors min-h-[44px]"
            >
              Services
              <CaretDown
                size={16}
                weight="bold"
                className={cn(
                  "transition-transform duration-200",
                  servicesOpen && "rotate-180",
                )}
              />
            </button>
            <div
              id="mobile-services-submenu"
              className={cn(
                "pl-2 transition duration-200 ease-out overflow-hidden",
                servicesOpen ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
              )}
              aria-hidden={!servicesOpen}
            >
              <div className="flex flex-col gap-0.5 py-1">
                {/* All Services hub link — Level 1 destination */}
                <MobileLinkRow
                  href={servicesHubLink.href}
                  label={servicesHubLink.label}
                  onNavigate={() => setMobileOpen(false)}
                  variant="hub"
                />
                {servicesNav.map((group) => {
                  if (group.kind === "parent") {
                    const overviewLink = group.links[0];
                    const childLinks = group.links.slice(1);
                    const expanded = !!expandedServiceParents[group.groupLabel];
                    const submenuId = `mobile-services-${group.groupLabel.toLowerCase()}`;
                    return (
                      <MobileParentRow
                        key={group.groupLabel}
                        parentLabel={group.groupLabel}
                        overviewHref={overviewLink.href}
                        overviewLabel={overviewLink.title}
                        expanded={expanded}
                        submenuId={submenuId}
                        onToggle={() => toggleServiceParent(group.groupLabel)}
                        onNavigate={() => setMobileOpen(false)}
                      >
                        {childLinks.map((link) => (
                          <MobileLinkRow
                            key={link.href}
                            href={link.href}
                            label={link.title}
                            onNavigate={() => setMobileOpen(false)}
                            variant="child"
                          />
                        ))}
                      </MobileParentRow>
                    );
                  }
                  // desktopOnly group (Wellness): flatten into direct items
                  return group.links.map((link) => (
                    <MobileLinkRow
                      key={link.href}
                      href={link.href}
                      label={link.title}
                      onNavigate={() => setMobileOpen(false)}
                    />
                  ));
                })}
              </div>
            </div>
          </div>

          {/* ── About section ────────────────────────────────────────────
           * Flat list — no parent/child hierarchy exists. Rendered from the
           * unified `aboutMobileLinks` derived from `aboutMenuLinks`.
           */}
          <div>
            <button
              type="button"
              onClick={() => setAboutOpen((v) => !v)}
              aria-expanded={aboutOpen}
              aria-controls="mobile-about-submenu"
              className="w-full flex items-center justify-between px-3 py-3 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-xl transition-colors min-h-[44px]"
            >
              About
              <CaretDown
                size={16}
                weight="bold"
                className={cn(
                  "transition-transform duration-200",
                  aboutOpen && "rotate-180",
                )}
              />
            </button>
            <div
              id="mobile-about-submenu"
              className={cn(
                "pl-2 transition duration-200 ease-out overflow-hidden",
                aboutOpen ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
              )}
              aria-hidden={!aboutOpen}
            >
              <div className="flex flex-col gap-0.5 py-1">
                {aboutMobileLinks.map((link) => (
                  <MobileLinkRow
                    key={link.href}
                    href={link.href}
                    label={link.label}
                    onNavigate={() => setMobileOpen(false)}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* ── Tools section ────────────────────────────────────────────
           * "All Tools" overview link + 3 expandable category rows (Pet
           * Health, Pet Care, Planning). Categories are pure grouping labels
           * with no overview page — they expand/collapse only.
           */}
          <div>
            <button
              type="button"
              onClick={() => setToolsOpen((v) => !v)}
              aria-expanded={toolsOpen}
              aria-controls="mobile-tools-submenu"
              className="w-full flex items-center justify-between px-3 py-3 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-xl transition-colors min-h-[44px]"
            >
              Tools
              <CaretDown
                size={16}
                weight="bold"
                className={cn(
                  "transition-transform duration-200",
                  toolsOpen && "rotate-180",
                )}
              />
            </button>
            <div
              id="mobile-tools-submenu"
              className={cn(
                "pl-2 transition duration-200 ease-out overflow-hidden",
                toolsOpen ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
              )}
              aria-hidden={!toolsOpen}
            >
              <div className="flex flex-col gap-0.5 py-1">
                {/* Tools hub overview link */}
                <MobileLinkRow
                  href={toolsHubLink.href}
                  label={toolsHubLink.label}
                  onNavigate={() => setMobileOpen(false)}
                  variant="hub"
                />
                {/* Expandable category groups */}
                {toolsNav.map((category) => {
                  const expanded = !!expandedToolCategories[category.groupLabel];
                  const submenuId = `mobile-tools-${category.groupLabel.toLowerCase().replace(/\s+/g, "-")}`;
                  return (
                    <MobileCategoryRow
                      key={category.groupLabel}
                      label={category.groupLabel}
                      expanded={expanded}
                      submenuId={submenuId}
                      onToggle={() => toggleToolCategory(category.groupLabel)}
                    >
                      {category.links.map((link) => (
                        <MobileLinkRow
                          key={link.href}
                          href={link.href}
                          label={link.title}
                          onNavigate={() => setMobileOpen(false)}
                        />
                      ))}
                    </MobileCategoryRow>
                  );
                })}
              </div>
            </div>
          </div>

          {/* ── Resources section ────────────────────────────────────────
           * Flat list — no parent/child hierarchy exists.
           */}
          <div>
            <button
              type="button"
              onClick={() => setResourcesOpen((v) => !v)}
              aria-expanded={resourcesOpen}
              aria-controls="mobile-resources-submenu"
              className="w-full flex items-center justify-between px-3 py-3 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-xl transition-colors min-h-[44px]"
            >
              Resources
              <CaretDown
                size={16}
                weight="bold"
                className={cn(
                  "transition-transform duration-200",
                  resourcesOpen && "rotate-180",
                )}
              />
            </button>
            <div
              id="mobile-resources-submenu"
              className={cn(
                "pl-2 transition duration-200 ease-out overflow-hidden",
                resourcesOpen ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
              )}
              aria-hidden={!resourcesOpen}
            >
              <div className="flex flex-col gap-0.5 py-1">
                {resourcesMobileLinks.map((link) => (
                  <MobileLinkRow
                    key={link.href}
                    href={link.href}
                    label={link.label}
                    onNavigate={() => setMobileOpen(false)}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Shop - plain link */}
          <MobileLinkRow
            href="/shop"
            label="Shop"
            onNavigate={() => setMobileOpen(false)}
          />

          {/* Contact - plain link */}
          <MobileLinkRow
            href="/contact"
            label="Contact"
            onNavigate={() => setMobileOpen(false)}
          />
        </nav>

        <div className="px-4 py-4 border-t border-surface-purple space-y-3">
          <Link
            href="/contact"
            onClick={() => setMobileOpen(false)}
            className="w-full flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-white py-3 rounded-full font-semibold transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
          >
            Book Now
            <ArrowRight size={16} weight="bold" className="text-white" />
          </Link>
        </div>
      </aside>
    </div>
  );
}

/**
 * Mobile parent row — a Level-1 expandable group for Services.
 *
 * Structure (3-level hierarchy):
 *   Level 1: the group label (e.g. "Boarding") with a separate expand button
 *   Level 2: the overview link (e.g. "Boarding" → /services/boarding) — visually stronger
 *   Level 3: child links (e.g. "Dog Boarding") — indented, lighter
 *
 * The group label row provides BOTH a link to the overview page AND a separate
 * expand/collapse button. This avoids the ambiguity of a single tap target
 * that must perform two conflicting functions (navigate vs. expand).
 *
 * When expanded, the overview link appears as the first child (Level 2),
 * followed by the specialized service children (Level 3).
 */
function MobileParentRow({
  parentLabel,
  overviewHref,
  overviewLabel,
  expanded,
  submenuId,
  onToggle,
  onNavigate,
  children,
}: {
  parentLabel: string;
  overviewHref: string;
  overviewLabel: string;
  expanded: boolean;
  submenuId: string;
  onToggle: () => void;
  onNavigate: () => void;
  children: React.ReactNode;
}) {
  return (
    <div role="group" aria-label={parentLabel}>
      {/* Level 1: group label row with separate expand control */}
      <div className="flex items-stretch rounded-xl overflow-hidden hover:bg-surface-purple transition-colors">
        <Link
          href={overviewHref}
          onClick={onNavigate}
          className="flex-1 flex items-center gap-2 px-3 py-3 text-sm font-semibold text-primary-dark min-h-[44px]"
        >
          {parentLabel}
        </Link>
        <button
          type="button"
          onClick={onToggle}
          aria-expanded={expanded}
          aria-controls={submenuId}
          aria-label={expanded ? `Collapse ${parentLabel}` : `Expand ${parentLabel}`}
          className="flex items-center justify-center w-11 min-h-[44px] shrink-0 text-primary-dark hover:bg-primary/10 transition-colors"
        >
          <CaretDown
            size={18}
            weight="bold"
            className={cn(
              "transition-transform duration-200",
              expanded && "rotate-180",
            )}
          />
        </button>
      </div>
      {/* Level 2 + Level 3: overview link + indented children */}
      <div
        id={submenuId}
        className={cn(
          "transition duration-200 ease-out overflow-hidden",
          expanded ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
        )}
        aria-hidden={!expanded}
      >
        <div className="flex flex-col gap-0.5 pl-3 py-0.5 border-l-2 border-surface-purple ml-4">
          {/* Level 2: overview link — visually stronger */}
          <Link
            href={overviewHref}
            onClick={onNavigate}
            className="flex items-center gap-2 px-3 py-2.5 text-sm font-semibold text-primary-dark hover:bg-surface-purple rounded-lg transition-colors min-h-[44px]"
          >
            <span className="w-1.5 h-1.5 rounded-full bg-primary shrink-0" aria-hidden="true" />
            {overviewLabel}
          </Link>
          {/* Level 3: children — indented, lighter */}
          <div className="pl-3">
            {children}
          </div>
        </div>
      </div>
    </div>
  );
}

/**
 * Mobile category row — an expandable grouping label with NO overview page.
 *
 * Used for Tools categories (Pet Health, Pet Care, Planning). The entire row
 * is an expand/collapse control; there is no parent link because the category
 * is a pure organizational label, not a destination.
 */
function MobileCategoryRow({
  label,
  expanded,
  submenuId,
  onToggle,
  children,
}: {
  label: string;
  expanded: boolean;
  submenuId: string;
  onToggle: () => void;
  children: React.ReactNode;
}) {
  return (
    <div role="group" aria-label={label}>
      <button
        type="button"
        onClick={onToggle}
        aria-expanded={expanded}
        aria-controls={submenuId}
        className="w-full flex items-center justify-between px-3 py-2.5 text-sm font-medium text-primary-dark/80 hover:bg-surface-purple rounded-xl transition-colors min-h-[44px]"
      >
        {label}
        <CaretRight
          size={16}
          weight="bold"
          className={cn(
            "transition-transform duration-200 text-primary/60",
            expanded && "rotate-90",
          )}
        />
      </button>
      <div
        id={submenuId}
        className={cn(
          "transition duration-200 ease-out overflow-hidden",
          expanded ? "opacity-100 max-h-none" : "opacity-0 max-h-0 pointer-events-none",
        )}
        aria-hidden={!expanded}
      >
        <div className="flex flex-col gap-0.5 pl-4 py-0.5 border-l-2 border-surface-purple ml-3">
          {children}
        </div>
      </div>
    </div>
  );
}

/**
 * Mobile link row. A simple navigable row.
 *
 * Variants:
 *   - "hub": overview/hub destination (e.g. "All Services", "View All Tools") — stronger
 *   - "child": a child destination under a parent group — indented, lighter
 *   - "default": standard peer link
 */
function MobileLinkRow({
  href,
  label,
  onNavigate,
  variant = "default",
}: {
  href: string;
  label: string;
  onNavigate: () => void;
  variant?: "default" | "hub" | "child";
}) {
  return (
    <Link
      href={href}
      onClick={onNavigate}
      className={cn(
        "flex items-center gap-2 px-3 py-2.5 text-sm rounded-lg transition-colors min-h-[44px]",
        variant === "hub"
          ? "font-semibold text-primary-dark hover:bg-surface-purple"
          : variant === "child"
            ? "text-primary-dark/65 hover:text-primary hover:bg-surface-purple pl-5"
            : "text-primary-dark/70 hover:text-primary hover:bg-surface-purple",
      )}
    >
      <span
        className={cn(
          "rounded-full bg-primary/40 shrink-0",
          variant === "hub" ? "w-1.5 h-1.5 bg-primary" : "w-1 h-1",
        )}
        aria-hidden="true"
      />
      {label}
    </Link>
  );
}
