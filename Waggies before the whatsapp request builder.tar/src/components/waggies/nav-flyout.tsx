"use client";

import Link from "next/link";
import { type RefObject, useEffect } from "react";
import { cn } from "@/lib/utils";
import { type MegaLink } from "@/lib/site";
import { PhosphorIcon } from "@/lib/phosphor-icons";

/**
 * NavFlyout — reusable single-column stacked flyout panel.
 *
 * Used for About, Tools, and Resources desktop flyouts which share
 * an identical structure (gradient header + stacked MegaLink rows).
 */
export function NavFlyout({
  links,
  isOpen,
  onClose,
  triggerRef,
  panelRef,
  align = "left",
  label,
}: {
  links: MegaLink[];
  isOpen: boolean;
  onClose: () => void;
  triggerRef: RefObject<HTMLElement | null>;
  panelRef: RefObject<HTMLDivElement | null>;
  align?: "left" | "right";
  /** Header label shown in the gradient bar. */
  label: string;
}) {
  const ref = panelRef;

  // Escape key + ArrowUp/ArrowDown keyboard handling.
  useEffect(() => {
    if (!isOpen) return;
    const el = ref.current;
    if (!el) return;

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        triggerRef.current?.focus();
        return;
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        const items = Array.from(el.querySelectorAll<HTMLElement>("[role=\"menuitem\"]"));
        if (items.length === 0) return;
        const idx = items.indexOf(document.activeElement as HTMLElement);
        const dir = e.key === "ArrowDown" ? 1 : -1;
        let next = idx + dir;
        if (next < 0) next = items.length - 1;
        if (next >= items.length) next = 0;
        items[next]?.focus();
      }
    };

    el.addEventListener("keydown", handleKey);
    return () => el.removeEventListener("keydown", handleKey);
  }, [isOpen, onClose, triggerRef, ref]);

  return (
    <div
      ref={ref}
      role="menu"
      aria-label={`${label} menu`}
      className={cn(
        "nav-dropdown nav-dropdown--stacked absolute top-full mt-1 transition ease-out duration-150",
        align === "left" ? "left-1/2 -translate-x-1/2" : "right-0",
        isOpen
          ? "opacity-100 translate-y-0"
          : "opacity-0 -translate-y-1 pointer-events-none",
      )}
      style={{ display: isOpen ? "block" : "none" }}
    >
      <div className="nav-dropdown__eyebrow">
        <span className="nav-dropdown__eyebrow-text">{label}</span>
      </div>
      <div className="nav-dropdown__stacked-links">
        {links.map((link) => (
          <NavFlyoutLink
            key={link.href}
            href={link.href}
            icon={link.icon}
            title={link.title}
            subtitle={link.subtitle}
            onClose={onClose}
          />
        ))}
      </div>
    </div>
  );
}

/**
 * Single link row inside a NavFlyout panel.
 * Shares the same `nav-mega-link` visual grammar as the mega-menu for
 * coherent styling across all navigation surfaces.
 */
function NavFlyoutLink({
  href,
  icon,
  title,
  subtitle,
  onClose,
}: {
  href: string;
  icon: string;
  title: string;
  subtitle: string;
  onClose?: () => void;
}) {
  return (
    <Link
      href={href}
      role="menuitem"
      tabIndex={-1}
      onClick={onClose}
      className="nav-mega-link group"
    >
      <span className="nav-mega-link__icon">
        <PhosphorIcon name={icon} size={18} />
      </span>
      <span className="min-w-0">
        <span className="nav-mega-link__title">{title}</span>
        {subtitle ? (
          <span className="nav-mega-link__subtitle">{subtitle}</span>
        ) : null}
      </span>
    </Link>
  );
}
