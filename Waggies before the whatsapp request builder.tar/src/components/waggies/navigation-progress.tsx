"use client";

import { useEffect, useState, useRef } from "react";
import { usePathname } from "next/navigation";
import { motion, useReducedMotion } from "framer-motion";

/**
 * NavigationProgress — global top progress bar.
 *
 * Shows a thin Waggies-styled progress line at the top of the viewport
 * during internal route navigation. Does NOT depend on loading.tsx —
 * it listens to pathname changes directly.
 *
 * Behavior:
 *   - When pathname changes, the bar appears at the top (h-0.5, bg-primary)
 *   - It animates from 0% to 90% width over ~400ms (indeterminate progress)
 *   - When the new page renders, it completes to 100% and fades out
 *   - Respects reduced motion (instant show/hide, no animation)
 *   - Sits above sticky navbar (z-[60])
 *   - Does not interfere with FABs, mobile bottom nav, or chatbot
 *
 * The bar is a fixed element that does NOT cause layout shift.
 */
export function NavigationProgress() {
  const pathname = usePathname();
  const [isLoading, setIsLoading] = useState(false);
  const prevPathRef = useRef(pathname);
  const shouldReduceMotion = useReducedMotion();

  useEffect(() => {
    if (prevPathRef.current !== pathname) {
      // Navigation started — defer setState to avoid cascading renders
      prevPathRef.current = pathname;
      const startRaf = requestAnimationFrame(() => {
        setIsLoading(true);
      });

      // Complete after a short delay (simulating route completion)
      const completeTimer = setTimeout(() => {
        setIsLoading(false);
      }, 600);

      return () => {
        cancelAnimationFrame(startRaf);
        clearTimeout(completeTimer);
      };
    }
  }, [pathname]);

  if (shouldReduceMotion) {
    // For reduced motion: show a static bar without animation
    return isLoading ? (
      <div
        className="fixed top-0 left-0 right-0 z-[60] h-0.5 bg-primary"
        role="status"
        aria-label="Loading page"
        aria-live="polite"
      />
    ) : null;
  }

  return (
    <motion.div
      className="fixed top-0 left-0 z-[60] h-0.5 bg-primary origin-left"
      style={{ width: "100%", transformOrigin: "left", opacity: isLoading ? 1 : 0 }}
      initial={false}
      animate={
        isLoading
          ? { scaleX: [0, 0.4, 0.7, 0.9], opacity: 1 }
          : { scaleX: 1, opacity: 0 }
      }
      transition={
        isLoading
          ? { duration: 0.6, ease: "easeInOut", times: [0, 0.3, 0.6, 1] }
          : { duration: 0.2, ease: "easeOut" }
      }
      role="status"
      aria-label={isLoading ? "Loading page" : "Page loaded"}
      aria-live="polite"
    />
  );
}
