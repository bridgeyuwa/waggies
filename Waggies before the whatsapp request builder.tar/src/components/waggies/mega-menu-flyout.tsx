"use client";

import Link from "next/link";
import { type RefObject, useCallback, useLayoutEffect, useEffect } from "react";
import { cn } from "@/lib/utils";
import { type MegaLink } from "@/lib/site";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr";

/**
 * MegaMenuFlyout — shared multi-column mega-menu panel.
 *
 * Used for Services and Tools desktop flyouts. Renders a wide panel
 * (≈72 rem) with an editorial eyebrow, an optional "View All" hub link,
 * grouped columns, and Phosphor icons.
 *
 * Positioning strategy:
 *   The panel is `position: absolute` inside the trigger `<li>`. CSS
 *   places it at `left: 50%` of the <li> then shifts it via
 *   `transform: translateX(calc(-50% + var(--mega-offset)))`.
 *
 *   `--mega-offset` is a CSS custom property set by this component
 *   (via JS) so the panel's centre aligns with the <nav> container's
 *   centre rather than the trigger button's centre.
 *
 * Visual hierarchy:
 *   - The hub link ("View All Services" / "View All Tools") is rendered
 *     as a prominent overview action at the top of the panel body.
 *   - For parent groups (Boarding, Relocation), the overview link is
 *     visually stronger than its children, and children are indented.
 *   - For desktopOnly groups (Wellness) and Tools categories, all links
 *     are peers at the same visual level.
 */
export function MegaMenuFlyout({
  columns,
  isOpen,
  onClose,
  triggerRef,
  panelRef,
  navRef,
  label,
  ariaLabel,
  columnsCount = 3,
  hubLink,
  parentGroupLabels = [],
}: {
  columns: ReadonlyArray<{
    groupLabel: string;
    links: MegaLink[];
  }>;
  isOpen: boolean;
  onClose: () => void;
  triggerRef: RefObject<HTMLElement | null>;
  panelRef: RefObject<HTMLDivElement | null>;
  navRef: RefObject<HTMLElement | null>;
  label: string;
  ariaLabel: string;
  columnsCount?: number;
  /** Optional hub overview link (e.g. "View All Services" → /services). */
  hubLink?: { href: string; label: string };
  /**
   * Labels of groups that have parent/child structure. For these groups,
   * links[0] is rendered as a visually stronger overview link and
   * links[1..] are rendered as indented children.
   */
  parentGroupLabels?: ReadonlyArray<string>;
}) {
  const ref = panelRef;

  // ── Calculate --mega-offset so the panel centres in the <nav> ──
  const updateOffset = useCallback(() => {
    const el = ref.current;
    const trigger = triggerRef.current;
    const nav = navRef.current;
    if (!el || !trigger || !nav) return;

    const triggerRect = trigger.getBoundingClientRect();
    const navRect = nav.getBoundingClientRect();
    const triggerCenter = triggerRect.left + triggerRect.width / 2;
    const navCenter = navRect.left + navRect.width / 2;
    const offset = navCenter - triggerCenter;
    el.style.setProperty("--mega-offset", `${offset}px`);
  }, [ref, triggerRef, navRef]);

  useLayoutEffect(() => {
    if (!isOpen) return;
    updateOffset();
    window.addEventListener("resize", updateOffset);
    return () => window.removeEventListener("resize", updateOffset);
  }, [isOpen, updateOffset]);

  // ── Keyboard: Escape + ArrowUp/Down ─────────────────────────────
  useEffect(() => {
    if (!isOpen) return;
    const el = ref.current;
    if (!el) return;

    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        e.preventDefault();
        onClose();
        triggerRef.current?.focus();
        return;
      }
      if (e.key === "ArrowDown" || e.key === "ArrowUp") {
        e.preventDefault();
        const items = Array.from(
          el.querySelectorAll<HTMLElement>("[role=\"menuitem\"]"),
        );
        if (items.length === 0) return;
        const idx = items.indexOf(document.activeElement as HTMLElement);
        const dir = e.key === "ArrowDown" ? 1 : -1;
        let next = idx + dir;
        if (next < 0) next = items.length - 1;
        if (next >= items.length) next = 0;
        items[next]?.focus();
      }
    };

    el.addEventListener("keydown", handleKey);
    return () => el.removeEventListener("keydown", handleKey);
  }, [isOpen, onClose, triggerRef, ref]);

  return (
    <div
      ref={ref}
      role="menu"
      aria-label={ariaLabel}
      className={cn(
        "nav-dropdown nav-dropdown--mega absolute top-full mt-1 transition ease-out duration-150",
        isOpen
          ? "opacity-100 translate-y-0"
          : "opacity-0 -translate-y-1 pointer-events-none",
      )}
      style={{ display: isOpen ? "block" : "none" }}
    >
      <div className="nav-dropdown__eyebrow">
        <span className="nav-dropdown__eyebrow-text">{label}</span>
      </div>

      {/* Hub overview link — prominent "View All" action */}
      {hubLink && (
        <div className="nav-dropdown__hub">
          <Link
            href={hubLink.href}
            role="menuitem"
            tabIndex={-1}
            className="nav-dropdown__hub-link group"
            onClick={onClose}
          >
            <span className="nav-dropdown__hub-label">{hubLink.label}</span>
            <ArrowRight
              size={16}
              weight="bold"
              className="nav-dropdown__hub-arrow"
            />
          </Link>
        </div>
      )}

      <div
        className={cn(
          "nav-dropdown__columns",
          columnsCount === 3 && "nav-dropdown__columns--mega-3col",
        )}
      >
        {columns.map((column) => {
          const isParentGroup = parentGroupLabels.includes(column.groupLabel);
          const overviewLink = isParentGroup ? column.links[0] : null;
          const childLinks = isParentGroup ? column.links.slice(1) : column.links;

          return (
            <div key={column.groupLabel} role="group" aria-label={column.groupLabel}>
              <p className="nav-dropdown__group-heading">{column.groupLabel}</p>
              <div className="flex flex-col gap-0.5">
                {overviewLink && (
                  <MegaMenuLink
                    href={overviewLink.href}
                    icon={overviewLink.icon}
                    title={overviewLink.title}
                    subtitle={overviewLink.subtitle}
                    variant="overview"
                    onClose={onClose}
                  />
                )}
                {childLinks.map((link) => (
                  <MegaMenuLink
                    key={link.href}
                    href={link.href}
                    icon={link.icon}
                    title={link.title}
                    subtitle={link.subtitle}
                    variant={isParentGroup ? "child" : "default"}
                    onClose={onClose}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/**
 * Single link row inside a mega-menu column.
 *
 * Three variants for visual hierarchy:
 *   - "overview": parent/overview destination — stronger weight, no indent
 *   - "child": child destination — indented, slightly lighter
 *   - "default": peer link (Wellness items, Tools) — standard treatment
 */
function MegaMenuLink({
  href,
  icon,
  title,
  subtitle,
  variant = "default",
  onClose,
}: {
  href: string;
  icon: string;
  title: string;
  subtitle: string;
  variant?: "default" | "overview" | "child";
  onClose?: () => void;
}) {
  return (
    <Link
      href={href}
      role="menuitem"
      tabIndex={-1}
      onClick={onClose}
      className={cn(
        "nav-mega-link group",
        variant === "child" && "nav-mega-link--child",
        variant === "overview" && "nav-mega-link--overview",
      )}
    >
      <span className="nav-mega-link__icon">
        <PhosphorIcon name={icon} size={18} />
      </span>
      <span className="min-w-0">
        <span className="nav-mega-link__title">{title}</span>
        {subtitle ? (
          <span className="nav-mega-link__subtitle">{subtitle}</span>
        ) : null}
      </span>
    </Link>
  );
}
