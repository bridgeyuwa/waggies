"use client";

import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { PhosphorIcon } from "@/lib/phosphor-icons-client";
import { MedicalDisclaimer } from "@/components/waggies/medical-disclaimer";
import { cn } from "@/lib/utils";
import {
  breedFilterOptions,
  filterBreeds,
  getBreedsBySpecies,
  type BreedEntry,
  type Species,
} from "@/data/breeds-data";

/* ------------------------------------------------------------------ */
/* Display-label maps — translate the lowercase enum values used in    */
/* the reference dataset into human-readable labels for the UI.        */
/* ------------------------------------------------------------------ */

const SIZE_LABELS: Record<BreedEntry["size"], string> = {
  small: "Small",
  medium: "Medium",
  large: "Large",
  giant: "Giant",
};

const EXERCISE_LABELS: Record<BreedEntry["exerciseNeeds"], string> = {
  low: "Low",
  moderate: "Moderate",
  high: "High",
  "very-high": "Very high",
};

const GROOMING_LABELS: Record<BreedEntry["groomingNeeds"], string> = {
  low: "Low",
  moderate: "Moderate",
  high: "High",
};

/**
 * Preferred display order for filter dropdowns. `breedFilterOptions`
 * is derived from the live dataset (insertion order), so we re-sort
 * here to give users a predictable Low → High listing rather than the
 * order breeds happen to appear in the data file.
 */
const PREFERRED_SIZES: BreedEntry["size"][] = [
  "small",
  "medium",
  "large",
  "giant",
];
const PREFERRED_EXERCISE: BreedEntry["exerciseNeeds"][] = [
  "low",
  "moderate",
  "high",
  "very-high",
];
const PREFERRED_GROOMING: BreedEntry["groomingNeeds"][] = [
  "low",
  "moderate",
  "high",
];

/* ------------------------------------------------------------------ */
/* URL state — filters are readable from and written to URL query      */
/* params so that a Breed Finder view is shareable & bookmarkable.     */
/* ------------------------------------------------------------------ */

type BreedFilterState = {
  species: Species;
  size: string;
  exerciseNeeds: string;
  groomingNeeds: string;
  search: string;
};

const DEFAULT_STATE: BreedFilterState = {
  species: "dog",
  size: "",
  exerciseNeeds: "",
  groomingNeeds: "",
  search: "",
};

/** Read the filter state from the URL on first render. */
function readStateFromParams(
  searchParams: ReturnType<typeof useSearchParams>,
): BreedFilterState {
  const sp = searchParams ?? new URLSearchParams("");
  const speciesParam = sp.get("species");
  const species: Species =
    speciesParam === "cat" || speciesParam === "dog" ? speciesParam : "dog";

  const size = sp.get("size") ?? "";
  const exerciseNeeds = sp.get("exerciseNeeds") ?? "";
  const groomingNeeds = sp.get("groomingNeeds") ?? "";
  const search = sp.get("search") ?? "";

  // Discard filter values that aren't present in the reference dataset
  // so the UI never shows a "filtered to zero" state caused by a stale
  // or hand-edited URL.
  return {
    species,
    size: breedFilterOptions.sizes.includes(size as BreedEntry["size"])
      ? size
      : "",
    exerciseNeeds: breedFilterOptions.exerciseNeeds.includes(
      exerciseNeeds as BreedEntry["exerciseNeeds"],
    )
      ? exerciseNeeds
      : "",
    groomingNeeds: breedFilterOptions.groomingNeeds.includes(
      groomingNeeds as BreedEntry["groomingNeeds"],
    )
      ? groomingNeeds
      : "",
    search,
  };
}

/** Serialise the filter state into a `?query=string` for the URL. */
function buildSearchString(state: BreedFilterState): string {
  const sp = new URLSearchParams();
  sp.set("species", state.species);
  if (state.size) sp.set("size", state.size);
  if (state.exerciseNeeds) sp.set("exerciseNeeds", state.exerciseNeeds);
  if (state.groomingNeeds) sp.set("groomingNeeds", state.groomingNeeds);
  const trimmedSearch = state.search.trim();
  if (trimmedSearch) sp.set("search", trimmedSearch);
  const str = sp.toString();
  return str ? `?${str}` : "";
}

/* ------------------------------------------------------------------ */
/* Component                                                           */
/* ------------------------------------------------------------------ */

function BreedFinderClientInner() {
  const router = useRouter();
  const pathname = usePathname();
  const searchParams = useSearchParams();

  // Read initial filter state from the URL exactly once on mount.
  // After that, local state is the source of truth and we push updates
  // to the URL via a debounced `router.replace()` (no history spam).
  const [state, setState] = useState<BreedFilterState>(() =>
    readStateFromParams(searchParams),
  );

  // Debounced URL sync — fires 350ms after the last filter change so
  // rapid keystrokes in the search box don't flood browser history.
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      const target = `${pathname}${buildSearchString(state)}`;
      router.replace(target, { scroll: false });
    }, 350);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [state, pathname, router]);

  // Run the filter helper from breeds-data.ts. Memoised on `state`
  // so we only re-compute when something actually changes.
  const filtered = useMemo(
    () =>
      filterBreeds({
        species: state.species,
        size: state.size,
        exerciseNeeds: state.exerciseNeeds,
        groomingNeeds: state.groomingNeeds,
        search: state.search,
      }),
    [state],
  );

  // Total count for the currently-selected species — used in the
  // "Showing X of Y breeds" result-count line.
  const speciesTotal = useMemo(
    () => getBreedsBySpecies(state.species).length,
    [state.species],
  );

  const updateField = useCallback(
    <K extends keyof BreedFilterState>(key: K, value: BreedFilterState[K]) => {
      setState((prev) => ({ ...prev, [key]: value }));
    },
    [],
  );

  // Switching species clears size/exercise/grooming filters (the new
  // species may not offer the same options), but preserves the search
  // term so the user can keep looking for "friendly" across both
  // species. This mirrors the behaviour of the previous client.
  const handleSpeciesChange = (species: Species) => {
    setState((prev) => ({
      ...DEFAULT_STATE,
      species,
      search: prev.search,
    }));
  };

  const handleClear = () => {
    setState((prev) => ({
      ...DEFAULT_STATE,
      species: prev.species,
    }));
  };

  const hasActiveFilters =
    !!state.size ||
    !!state.exerciseNeeds ||
    !!state.groomingNeeds ||
    !!state.search.trim();

  // Filter dropdown options, re-sorted into a predictable Low→High
  // order rather than the dataset's insertion order.
  const sizeOptions = PREFERRED_SIZES.filter((s) =>
    breedFilterOptions.sizes.includes(s),
  );
  const exerciseOptions = PREFERRED_EXERCISE.filter((e) =>
    breedFilterOptions.exerciseNeeds.includes(e),
  );
  const groomingOptions = PREFERRED_GROOMING.filter((g) =>
    breedFilterOptions.groomingNeeds.includes(g),
  );

  return (
    <div className="space-y-6">
      {/* ---- Filter panel ------------------------------------------ */}
      <div className="bg-white border border-primary/10 rounded-2xl p-5 sm:p-6 space-y-5">
        {/* Species toggle */}
        <fieldset>
          <legend className="block text-sm font-semibold text-primary-dark mb-2">
            Species
          </legend>
          <div className="grid grid-cols-2 gap-3" role="radiogroup" aria-label="Species">
            {(["dog", "cat"] as const).map((s) => {
              const selected = state.species === s;
              return (
                <button
                  key={s}
                  type="button"
                  role="radio"
                  aria-checked={selected}
                  onClick={() => handleSpeciesChange(s)}
                  className={cn(
                    "flex items-center justify-center gap-2 min-h-[44px] rounded-xl border px-3 py-2.5 text-sm font-semibold transition focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/40",
                    selected
                      ? "border-primary bg-surface-purple text-primary"
                      : "border-primary/10 bg-white text-primary-dark/60 hover:border-primary/30",
                  )}
                >
                  <PhosphorIcon
                    name={s === "dog" ? "paw-print" : "cat"}
                    size={18}
                    weight="fill"
                    aria-hidden="true"
                  />
                  <span>{s === "dog" ? "Dogs" : "Cats"}</span>
                </button>
              );
            })}
          </div>
        </fieldset>

        {/* Search */}
        <div>
          <label
            htmlFor="breed-search"
            className="block text-sm font-semibold text-primary-dark mb-2"
          >
            Search Breeds
          </label>
          <div className="relative">
            <PhosphorIcon
              name="magnifying-glass"
              size={18}
              className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-primary-dark/40"
              aria-hidden="true"
            />
            <input
              id="breed-search"
              type="text"
              autoComplete="off"
              value={state.search}
              onChange={(e) => updateField("search", e.target.value)}
              placeholder="e.g. Labrador, Friendly, Active…"
              className="w-full min-h-[44px] rounded-xl border border-primary/10 bg-white pl-10 pr-4 py-2.5 text-sm text-primary-dark placeholder:text-primary-dark/30 focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>
        </div>

        {/* Filter dropdowns */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <FilterSelect
            id="filter-size"
            label="Size"
            value={state.size}
            onChange={(v) => updateField("size", v)}
            allLabel="All sizes"
            options={sizeOptions.map((s) => ({
              value: s,
              label: SIZE_LABELS[s],
            }))}
          />
          <FilterSelect
            id="filter-exercise"
            label="Exercise Needs"
            value={state.exerciseNeeds}
            onChange={(v) => updateField("exerciseNeeds", v)}
            allLabel="All levels"
            options={exerciseOptions.map((e) => ({
              value: e,
              label: EXERCISE_LABELS[e],
            }))}
          />
          <FilterSelect
            id="filter-grooming"
            label="Grooming Needs"
            value={state.groomingNeeds}
            onChange={(v) => updateField("groomingNeeds", v)}
            allLabel="All levels"
            options={groomingOptions.map((g) => ({
              value: g,
              label: GROOMING_LABELS[g],
            }))}
          />
        </div>

        {hasActiveFilters && (
          <button
            type="button"
            onClick={handleClear}
            className="inline-flex items-center gap-1.5 min-h-[44px] px-1 -mx-1 text-xs font-semibold text-primary hover:underline focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/40 rounded-md"
          >
            <PhosphorIcon
              name="arrow-counter-clockwise"
              size={14}
              aria-hidden="true"
            />
            Clear filters
          </button>
        )}
      </div>

      {/* ---- Result count ----------------------------------------- */}
      <p className="text-xs text-primary-dark/50" aria-live="polite">
        Showing{" "}
        <span className="font-semibold text-primary-dark/70">
          {filtered.length}
        </span>{" "}
        of{" "}
        <span className="font-semibold text-primary-dark/70">
          {speciesTotal}
        </span>{" "}
        {state.species === "dog" ? "dog" : "cat"} breed
        {speciesTotal !== 1 ? "s" : ""}
      </p>

      {/* ---- Breed cards ------------------------------------------ */}
      {filtered.length === 0 ? (
        <div className="text-center py-12 bg-white border border-primary/10 rounded-2xl">
          <PhosphorIcon
            name="paw-print"
            size={32}
            weight="fill"
            className="text-primary-dark/20 mx-auto mb-3"
            aria-hidden="true"
          />
          <p className="text-sm text-primary-dark/60">
            No breeds match your filters. Try adjusting your search criteria.
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((breed) => (
            <BreedCard key={breed.id} breed={breed} />
          ))}
        </div>
      )}

      {/* ---- Medical disclaimer ----------------------------------- */}
      <MedicalDisclaimer />
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Sub-components                                                      */
/* ------------------------------------------------------------------ */

function FilterSelect({
  id,
  label,
  value,
  onChange,
  options,
  allLabel,
}: {
  id: string;
  label: string;
  value: string;
  onChange: (value: string) => void;
  options: { value: string; label: string }[];
  allLabel: string;
}) {
  return (
    <div>
      <label
        htmlFor={id}
        className="block text-xs font-semibold text-primary-dark/60 mb-1.5"
      >
        {label}
      </label>
      <select
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full min-h-[44px] rounded-xl border border-primary/10 bg-white px-3 py-2.5 text-sm text-primary-dark focus:outline-none focus:ring-2 focus:ring-primary/40"
      >
        <option value="">{allLabel}</option>
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </div>
  );
}

function BreedCard({ breed }: { breed: BreedEntry }) {
  return (
    <article className="bg-white border border-primary/10 rounded-2xl p-5 flex flex-col gap-3">
      <header>
        <h3 className="font-serif text-base sm:text-lg font-bold text-primary-dark">
          {breed.name}
        </h3>
        {/* Badges */}
        <div className="flex flex-wrap gap-1.5 mt-2">
          <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-primary/10 text-primary border border-primary/20">
            {SIZE_LABELS[breed.size]}
          </span>
          <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-700 border border-emerald-200/60">
            Exercise: {EXERCISE_LABELS[breed.exerciseNeeds]}
          </span>
          <span className="text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full bg-amber-50 text-amber-700 border border-amber-200/60">
            Grooming: {GROOMING_LABELS[breed.groomingNeeds]}
          </span>
        </div>
      </header>

      {/* Overview */}
      <p className="text-sm text-primary-dark/60 leading-relaxed">
        {breed.overview}
      </p>

      {/* Temperament tags */}
      <div>
        <h4 className="text-[10px] font-bold uppercase tracking-wider text-primary/50 mb-1.5">
          Temperament
        </h4>
        <div className="flex flex-wrap gap-1.5">
          {breed.temperament.map((t) => (
            <span
              key={t}
              className="text-[11px] font-medium px-2 py-0.5 rounded-md bg-surface-purple/60 text-primary-dark/70 border border-primary/10"
            >
              {t}
            </span>
          ))}
        </div>
      </div>

      {/* Key stats */}
      <div className="grid grid-cols-2 gap-2">
        <div className="rounded-lg bg-surface px-3 py-2 border border-primary/5">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-primary/50">
            Weight
          </div>
          <div className="text-sm font-semibold text-primary-dark mt-0.5">
            {breed.weightRange}
          </div>
        </div>
        <div className="rounded-lg bg-surface px-3 py-2 border border-primary/5">
          <div className="text-[10px] font-semibold uppercase tracking-wider text-primary/50">
            Lifespan
          </div>
          <div className="text-sm font-semibold text-primary-dark mt-0.5">
            {breed.lifespan}
          </div>
        </div>
      </div>

      {/* Expandable health considerations */}
      <details className="group mt-1">
        <summary className="flex items-center justify-between gap-2 cursor-pointer list-none min-h-[44px] -mx-1 px-1 py-1 rounded-md hover:bg-surface-purple/40 transition select-none focus:outline-none focus-visible:ring-2 focus-visible:ring-primary/40">
          <span className="text-xs font-bold uppercase tracking-wider text-primary/60 flex items-center gap-1.5">
            <PhosphorIcon
              name="heartbeat"
              size={14}
              weight="fill"
              className="text-primary/60"
              aria-hidden="true"
            />
            Health Considerations
          </span>
          <PhosphorIcon
            name="caret-down"
            size={16}
            className="text-primary/50 transition-transform group-open:rotate-180"
            aria-hidden="true"
          />
        </summary>
        <p className="text-sm text-primary-dark/60 leading-relaxed mt-2 pl-1">
          {breed.generalHealthConsiderations}
        </p>
      </details>
    </article>
  );
}

/* ------------------------------------------------------------------ */
/* Skeleton fallback shown while the Suspense boundary is resolving    */
/* (useSearchParams must be wrapped in Suspense per Next.js docs).     */
/* ------------------------------------------------------------------ */

function BreedFinderSkeleton() {
  return (
    <div className="space-y-6">
      <div className="bg-white border border-primary/10 rounded-2xl p-5 sm:p-6 space-y-5 animate-pulse">
        <div className="grid grid-cols-2 gap-3">
          <div className="h-11 rounded-xl bg-surface-purple/40" />
          <div className="h-11 rounded-xl bg-surface-purple/40" />
        </div>
        <div className="h-11 rounded-xl bg-surface-purple/40" />
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <div className="h-11 rounded-xl bg-surface-purple/40" />
          <div className="h-11 rounded-xl bg-surface-purple/40" />
          <div className="h-11 rounded-xl bg-surface-purple/40" />
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {Array.from({ length: 6 }).map((_, i) => (
          <div
            key={i}
            className="h-64 rounded-2xl bg-white border border-primary/10 animate-pulse"
          />
        ))}
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* Exported component — wraps the inner client in <Suspense> so that   */
/* `useSearchParams()` does not deopt the entire page to CSR.          */
/* ------------------------------------------------------------------ */

export function BreedFinderClient() {
  return (
    <Suspense fallback={<BreedFinderSkeleton />}>
      <BreedFinderClientInner />
    </Suspense>
  );
}
