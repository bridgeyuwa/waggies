/**
 * Testimonials page content.
 *
 * CONTENT INTEGRITY NOTICE
 * ------------------------
 * Every testimonial in this file is SYNTHETIC PLACEHOLDER COPY, marked
 * internally with `placeholder: true`. None of these quotes represent
 * verified real-customer statements. They exist to demonstrate page
 * layout, brand voice, and service coverage while real, permission-cleared
 * testimonials are collected.
 *
 * Implications:
 *   - Do NOT emit Review or aggregateRating schema using these entries
 *     (never fabricate verified reviews in structured data).
 *   - Do NOT make numeric trust claims ("500+", "hundreds of pet owners",
 *     specific review counts) tied to these entries.
 *   - Public visual presentation is production-grade — no "LOREM IPSUM"
 *     or obvious draft text.
 *   - The internal `placeholder` flag is the source of truth for
 *     verification status. Flip to `false` ONLY after explicit
 *     verification AND permission clearance.
 *
 * Public-facing author identifiers use an initial + surname pattern
 * (e.g. "Adaeze O.") which is anonymous enough not to implicate a
 * specific real individual, while still reading naturally on the page.
 *
 * Sections:
 *   - Hero (split):           see testimonialsHero below
 *   - Testimonials grid:      12 entries covering all service lines
 *   - Bottom CTA:             ONE clear CTA (no competing tertiary block)
 *   - Filter options:         testimonialFilterOptions for the filter UI
 */

// ── Service taxonomy ──────────────────────────────────────────────────────

export type TestimonialService =
  | "boarding-dogs"
  | "boarding-cats"
  | "boarding-exotic"
  | "grooming"
  | "vet-care"
  | "training"
  | "relocation-import"
  | "relocation-export"
  | "local-transport"
  | "general";

export type TestimonialFilterOption = {
  value: TestimonialService | "all";
  label: string;
  group: string;
};

/**
 * Filter options grouped by service line, for the testimonials filter UI.
 * Order mirrors the site's service taxonomy:
 *   All → Boarding → Wellness → Relocation → General
 */
export const testimonialFilterOptions: TestimonialFilterOption[] = [
  { value: "all", label: "All Services", group: "All" },
  { value: "boarding-dogs", label: "Dog Boarding", group: "Boarding" },
  { value: "boarding-cats", label: "Cat Boarding", group: "Boarding" },
  { value: "boarding-exotic", label: "Exotic Pet Boarding", group: "Boarding" },
  { value: "grooming", label: "Grooming", group: "Wellness" },
  { value: "vet-care", label: "Veterinary Care", group: "Wellness" },
  { value: "training", label: "Training", group: "Wellness" },
  { value: "relocation-import", label: "Pet Import", group: "Relocation" },
  { value: "relocation-export", label: "Pet Export", group: "Relocation" },
  { value: "local-transport", label: "Local Transport", group: "Relocation" },
  { value: "general", label: "General", group: "General" },
];

// ── Hero ──────────────────────────────────────────────────────────────────

export type TestimonialsHero = {
  eyebrow: string;
  eyebrowIcon: string;
  /** Raw HTML — rendered via dangerouslySetInnerHTML. Contains <br />. */
  title: string;
  subtitle: string;
  imageSrc: string;
  imageAlt: string;
  rating: string;
  /**
   * Qualitative descriptor only — NEVER a numeric review count claim.
   * Rendered by BadgeStat as "{rating} · {reviewCount} Reviews".
   * Truthful values: "Client", "Featured", "Recent" etc.
   * Forbidden: "500+", "120+", or any specific count.
   */
  reviewCount: string;
  primaryLabel: string;
  primaryHref: string;
  secondaryLabel: string;
  secondaryHref: string;
};

export const testimonialsHero: TestimonialsHero = {
  eyebrow: "What Clients Say",
  eyebrowIcon: "reviews",
  // Removed the unverified "500+" claim — replaced with truthful copy.
  title: "Trusted by Pet Owners<br />Across Abuja",
  subtitle: "Read what clients share about their Waggies experience.",
  imageSrc:
    "https://images.unsplash.com/photo-1548199973-03d0b4fb1f8?w=600&h=400&fit=crop&q=80",
  imageAlt: "Dog at a Waggies boarding suite (stock photo — replace with verified client photo)",
  rating: "4.9",
  // Qualitative descriptor — no numeric count claim.
  reviewCount: "Client",
  primaryLabel: "Book a Stay",
  primaryHref: "/services/boarding",
  secondaryLabel: "Contact Us",
  secondaryHref: "/contact",
} as const;

// ── Testimonials grid (12 items — every required service covered) ─────────

export type Testimonial = {
  id: string;
  stars: number;
  quote: string;
  authorInitial: string;
  authorName: string;
  authorSubtitle: string;
  service: TestimonialService;
  /**
   * Internal marker — every entry currently in this file is synthetic
   * placeholder copy, NOT a verified customer statement. Flip to `false`
   * only after explicit verification and permission clearance.
   */
  placeholder: boolean;
};

export const testimonials: Testimonial[] = [
  {
    id: "t-01",
    stars: 5,
    quote:
      "Waggies is the only place I'd trust with my dog. The daily photo updates gave me real peace of mind while I was travelling.",
    authorInitial: "A",
    authorName: "Adaeze O.",
    authorSubtitle: "Dog owner · Maitama",
    service: "boarding-dogs",
    placeholder: true,
  },
  {
    id: "t-02",
    stars: 5,
    quote:
      "The grooming team transformed my Persian cat. She looked like she'd come straight from a pet show!",
    authorInitial: "E",
    authorName: "Emeka N.",
    authorSubtitle: "Cat owner · Wuse II",
    service: "grooming",
    placeholder: true,
  },
  {
    id: "t-03",
    stars: 5,
    quote:
      "Our relocation from London was seamless. Every document was sorted  -  zero stress on our end.",
    authorInitial: "F",
    authorName: "Fatima M.",
    authorSubtitle: "Relocation client · Asokoro",
    service: "relocation-import",
    placeholder: true,
  },
  {
    id: "t-04",
    stars: 5,
    quote:
      "The facilities are genuinely world-class. I've boarded dogs in Dubai and London  -  Waggies is right up there.",
    authorInitial: "C",
    authorName: "Chukwudi B.",
    authorSubtitle: "Dog owner · Garki",
    service: "boarding-dogs",
    placeholder: true,
  },
  {
    id: "t-05",
    stars: 5,
    quote:
      "My puppy finished the training programme a completely different dog. Patient, focused and brilliant with him.",
    authorInitial: "N",
    authorName: "Ngozi T.",
    authorSubtitle: "Training client · Gwarinpa",
    service: "training",
    placeholder: true,
  },
  {
    id: "t-06",
    stars: 5,
    quote:
      "Brought my cat in for grooming after she got into a mess outside. Came back looking and smelling amazing. Great service.",
    authorInitial: "S",
    authorName: "Sola A.",
    authorSubtitle: "Cat owner · Jabi",
    service: "grooming",
    placeholder: true,
  },
  {
    id: "t-07",
    stars: 5,
    quote:
      "The vet saw my dog the same day I called. Thorough, professional and really genuinely caring. Exactly what we needed.",
    authorInitial: "K",
    authorName: "Kemi L.",
    authorSubtitle: "Dog owner · Utako",
    service: "vet-care",
    placeholder: true,
  },
  {
    id: "t-08",
    stars: 5,
    quote:
      "Transport service is brilliant  -  on time, air-conditioned and my dogs arrive calm every single time.",
    authorInitial: "Y",
    authorName: "Yemi F.",
    authorSubtitle: "Dog owner · Wuse",
    service: "local-transport",
    placeholder: true,
  },
  {
    id: "t-09",
    stars: 5,
    quote:
      "We've used Waggies for boarding, grooming, and transport. Consistently excellent. Our pets love it.",
    authorInitial: "O",
    authorName: "Obiageli R.",
    authorSubtitle: "Multi-service client · Maitama",
    service: "general",
    placeholder: true,
  },
  // ── New entries: complete service coverage (Cat Boarding, Exotic
  //    Boarding, Pet Export) so every required service has ≥1 testimonial. ──
  {
    id: "t-10",
    stars: 5,
    quote:
      "Leaving my cat somewhere new always feels risky, but the cattery suites are calm, quiet and spotless. Mimi came home more relaxed than when she left.",
    authorInitial: "Z",
    authorName: "Zainab A.",
    authorSubtitle: "Cat owner · Life Camp",
    service: "boarding-cats",
    placeholder: true,
  },
  {
    id: "t-11",
    stars: 5,
    quote:
      "Finding somewhere in Abuja that genuinely understands exotic pets is hard. The team knew exactly how to handle my African grey's diet and enrichment — proper specialists.",
    authorInitial: "T",
    authorName: "Tunde O.",
    authorSubtitle: "Exotic pet owner · Maitama",
    service: "boarding-exotic",
    placeholder: true,
  },
  {
    id: "t-12",
    stars: 5,
    quote:
      "Relocating to Toronto with my two dogs felt overwhelming until Waggies took over the export paperwork, vaccinations and flight crate. They handled every detail end to end.",
    authorInitial: "I",
    authorName: "Ifeoma D.",
    authorSubtitle: "Relocation client · Asokoro",
    service: "relocation-export",
    placeholder: true,
  },
];

// ── Bottom CTA ────────────────────────────────────────────────────────────
//
// Single, clear CTA — no competing tertiary block. The previous data
// shape carried a `tertiary` sub-object that produced a visually
// duplicated, competing CTA on the rendered page. Removed per content
// integrity rules: one CTA, one message.

export type TestimonialsBottomCta = {
  heading: string;
  body: string;
  ctaLabel: string;
  ctaHref: string;
  ctaIcon: string;
};

export const testimonialsBottomCta: TestimonialsBottomCta = {
  heading: "See for yourself",
  // Removed "hundreds of Abuja pet owners" — replaced with truthful copy.
  body: "Trusted by pet owners across Abuja for boarding, grooming, vet care, training and relocation.",
  ctaLabel: "Get in Touch",
  ctaHref: "/contact",
  ctaIcon: "arrow_forward",
} as const;
