/**
 * WhatsApp Service Request Composer
 *
 * Implements the Waggies WhatsApp-first conversion model documented in
 * WAGGIES_WHATSAPP_REQUEST_SCHEMA.md.
 *
 * Converts a structured WhatsAppServiceRequest object into a human-readable,
 * pre-populated WhatsApp message URL. The customer can edit the message
 * before sending.
 *
 * The message is NEVER sent as JSON — it is converted to structured plain
 * text that a human can read and a Waggies staff member can parse at a glance.
 */

import { businessInfo } from "@/lib/business-info";

// ── Types ──────────────────────────────────────────────────────────────────

export type PricingMode = "FIXED" | "ESTIMATED" | "QUOTE_REQUIRED";

export type WhatsAppServiceRequest = {
  // Service Identification
  service: string;
  serviceCategory: string;

  // Pet Information
  petName?: string;
  petType?: string;
  breed?: string;

  // Service Specifics
  package?: string;
  options?: string[];

  // Scheduling
  dates?: {
    checkIn?: string;
    checkOut?: string;
    preferredDate?: string;
    preferredTime?: string;
  };
  duration?: string;

  // Location (Transport / Relocation)
  location?: {
    pickup?: string;
    dropoff?: string;
    route?: string;
    destination?: string;
  };

  // Pricing
  estimate?: string;
  pricingMode: PricingMode;

  // Customer Information
  customerName?: string;
  phone?: string;
  email?: string;

  // Additional Context
  additionalMessage?: string;
  source: string;
};

// ── Message Construction ───────────────────────────────────────────────────

/**
 * Convert a WhatsAppServiceRequest into a human-readable plain-text message.
 *
 * Follows the template from WAGGIES_WHATSAPP_REQUEST_SCHEMA.md:
 *
 *   🐾 Waggies Pet Care - Service Request
 *
 *   Service: {category} - {service}
 *   Package: {package} (if applicable)
 *   Options: {options} (if any)
 *
 *   Pet: {name} ({type}, {breed})
 *
 *   Dates: {checkIn} to {checkOut} ({duration})
 *   Time: {preferredTime}
 *
 *   Location: {route or pickup/dropoff}
 *   Pricing: {estimate or quote description}
 *
 *   Name: {customerName}
 *   Phone: {phone}
 *   Email: {email}
 *
 *   {additionalMessage}
 *
 *   ---
 *   Sent from: {source}
 */
export function buildWhatsAppMessage(req: WhatsAppServiceRequest): string {
  const lines: string[] = [];

  lines.push("🐾 Waggies Pet Care - Service Request");
  lines.push("");

  // Service identification
  lines.push(`Service: ${req.serviceCategory} - ${formatServiceName(req.service)}`);
  if (req.package) {
    lines.push(`Package: ${req.package}`);
  }
  if (req.options && req.options.length > 0) {
    lines.push(`Options: ${req.options.join(", ")}`);
  }
  lines.push("");

  // Pet information
  if (req.petName || req.petType || req.breed) {
    const petParts: string[] = [];
    if (req.petName) petParts.push(req.petName);
    const petDetails: string[] = [];
    if (req.petType) petDetails.push(req.petType);
    if (req.breed) petDetails.push(req.breed);
    if (petDetails.length > 0) {
      petParts.push(`(${petDetails.join(", ")})`);
    }
    lines.push(`Pet: ${petParts.join(" ")}`);
    lines.push("");
  }

  // Scheduling
  if (req.dates) {
    const dateParts: string[] = [];
    if (req.dates.checkIn && req.dates.checkOut) {
      dateParts.push(`${req.dates.checkIn} to ${req.dates.checkOut}`);
    } else if (req.dates.preferredDate) {
      dateParts.push(req.dates.preferredDate);
    }
    if (req.duration) {
      dateParts.push(`(${req.duration})`);
    }
    if (dateParts.length > 0) {
      lines.push(`Dates: ${dateParts.join(" ")}`);
    }
    if (req.dates.preferredTime) {
      lines.push(`Time: ${req.dates.preferredTime}`);
    }
    if (dateParts.length > 0 || req.dates.preferredTime) {
      lines.push("");
    }
  }

  // Location
  if (req.location) {
    const locParts: string[] = [];
    if (req.location.route) {
      locParts.push(req.location.route);
    } else if (req.location.pickup && req.location.dropoff) {
      locParts.push(`${req.location.pickup} → ${req.location.dropoff}`);
    } else if (req.location.pickup) {
      locParts.push(`Pickup: ${req.location.pickup}`);
    } else if (req.location.destination) {
      locParts.push(`Destination: ${req.location.destination}`);
    }
    if (locParts.length > 0) {
      lines.push(`Location: ${locParts.join(" | ")}`);
      if (req.location.pickup && req.location.dropoff && !req.location.route) {
        lines.push(`Pickup: ${req.location.pickup}`);
        lines.push(`Dropoff: ${req.location.dropoff}`);
      }
      lines.push("");
    }
  }

  // Pricing
  const pricingLabel = formatPricing(req.pricingMode, req.estimate);
  if (pricingLabel) {
    lines.push(`Pricing: ${pricingLabel}`);
    lines.push("");
  }

  // Customer information
  if (req.customerName) {
    lines.push(`Name: ${req.customerName}`);
  }
  if (req.phone) {
    lines.push(`Phone: ${req.phone}`);
  }
  if (req.email) {
    lines.push(`Email: ${req.email}`);
  }
  if (req.customerName || req.phone || req.email) {
    lines.push("");
  }

  // Additional message
  if (req.additionalMessage) {
    lines.push(req.additionalMessage);
    lines.push("");
  }

  // Footer
  lines.push("---");
  lines.push(`Sent from: ${req.source}`);

  return lines.join("\n");
}

/**
 * Build a complete WhatsApp URL with the pre-populated message.
 *
 * Uses the canonical Waggies WhatsApp number (2349080811902) and
 * URL-encodes the message text.
 */
export function whatsappRequestUrl(req: WhatsAppServiceRequest): string {
  const message = buildWhatsAppMessage(req);
  return `${businessInfo.whatsappUrl}?text=${encodeURIComponent(message)}`;
}

// ── Helpers ────────────────────────────────────────────────────────────────

/**
 * Format a service identifier into a human-readable name.
 * e.g. "boarding-dogs" → "Boarding (Dogs)", "local-transport" → "Local Transport"
 */
function formatServiceName(service: string): string {
  const labelMap: Record<string, string> = {
    "boarding": "Boarding",
    "boarding-dogs": "Boarding (Dogs)",
    "boarding-cats": "Boarding (Cats)",
    "boarding-exotic": "Boarding (Exotic Pets)",
    "grooming": "Grooming",
    "vet-care": "Veterinary Care",
    "training": "Training",
    "relocation": "Relocation",
    "relocation-import": "Pet Import",
    "relocation-export": "Pet Export",
    "local-transport": "Local Transport",
    "transport": "Local Transport",
  };
  return labelMap[service] ?? service
    .split("-")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

/**
 * Format the pricing mode into a human-readable label.
 */
function formatPricing(mode: PricingMode, estimate?: string): string | null {
  if (estimate) {
    return `${estimate} (${mode === "FIXED" ? "fixed" : mode === "ESTIMATED" ? "estimated" : "quote required"})`;
  }
  switch (mode) {
    case "FIXED":
      return "Fixed price (see pricing page)";
    case "ESTIMATED":
      return "Estimate (use pricing calculator)";
    case "QUOTE_REQUIRED":
      return "Quote required - please provide details";
    default:
      return null;
  }
}

// ── Preset builders for common service requests ───────────────────────────

/**
 * Create a minimal service-request preset for a given service.
 * The user can add additional context via the `additionalMessage` field.
 */
export function serviceRequestPreset(
  service: string,
  options?: Partial<WhatsAppServiceRequest>,
): WhatsAppServiceRequest {
  const defaults = getServiceDefaults(service);
  return {
    ...defaults,
    ...options,
    service,
    source: options?.source ?? `service-page-cta`,
  };
}

function getServiceDefaults(
  service: string,
): Pick<WhatsAppServiceRequest, "serviceCategory" | "pricingMode"> {
  const boardingServices = ["boarding", "boarding-dogs", "boarding-cats", "boarding-exotic"];
  const relocationServices = ["relocation", "relocation-import", "relocation-export", "local-transport", "transport"];

  if (boardingServices.includes(service)) {
    return { serviceCategory: "Boarding", pricingMode: "ESTIMATED" };
  }
  if (relocationServices.includes(service)) {
    if (service === "local-transport" || service === "transport") {
      return { serviceCategory: "Relocation", pricingMode: "ESTIMATED" };
    }
    return { serviceCategory: "Relocation", pricingMode: "QUOTE_REQUIRED" };
  }
  if (service === "grooming") {
    return { serviceCategory: "Wellness", pricingMode: "ESTIMATED" };
  }
  if (service === "vet-care") {
    return { serviceCategory: "Wellness", pricingMode: "QUOTE_REQUIRED" };
  }
  if (service === "training") {
    return { serviceCategory: "Wellness", pricingMode: "ESTIMATED" };
  }
  return { serviceCategory: "General", pricingMode: "QUOTE_REQUIRED" };
}
