"use client";

import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { kbArticles, kbCategories, type KbCategory } from "@/data/content-data";
import { ArticleCard } from "@/components/waggies/content/article-card";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { FadeIn } from "@/components/waggies/motion";
import { cn } from "@/lib/utils";

/**
 * Knowledge Base index page client with category filtering (`?category=`)
 * and full-text search (`?q=`) persisted to the URL.
 *
 * - Category changes update the URL immediately (single click action).
 * - Search text updates are debounced 350ms so rapid keystrokes don't
 *   flood the browser history with intermediate states.
 *
 * Wrapped in a `<Suspense>` boundary because `useSearchParams()`
 * requires it per Next.js docs to avoid deopting the whole page to CSR.
 */
function KnowledgeBasePageClientInner() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const [activeCategory, setActiveCategory] = useState<KbCategory | "All">(
    () => {
      const param = searchParams.get("category");
      if (param && (kbCategories as readonly string[]).includes(param)) {
        return param as KbCategory;
      }
      return "All";
    },
  );
  const [search, setSearch] = useState<string>(() => searchParams.get("q") ?? "");

  // Debounced URL sync — fires 350ms after the last filter/search change
  // so rapid keystrokes in the search box don't flood browser history.
  const debounceRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => {
      const params = new URLSearchParams(searchParams.toString());
      if (activeCategory === "All") {
        params.delete("category");
      } else {
        params.set("category", activeCategory);
      }
      const trimmedSearch = search.trim();
      if (trimmedSearch) {
        params.set("q", trimmedSearch);
      } else {
        params.delete("q");
      }
      const qs = params.toString();
      router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    }, 350);
    return () => {
      if (debounceRef.current) clearTimeout(debounceRef.current);
    };
  }, [activeCategory, search, searchParams, pathname, router]);

  const handleCategoryChange = useCallback((category: KbCategory | "All") => {
    setActiveCategory(category);
  }, []);

  const handleSearchChange = useCallback((value: string) => {
    setSearch(value);
  }, []);

  const filtered = useMemo(() => {
    let items =
      activeCategory === "All"
        ? kbArticles
        : kbArticles.filter((a) => a.category === activeCategory);

    if (search.trim()) {
      const q = search.toLowerCase();
      items = items.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.excerpt.toLowerCase().includes(q),
      );
    }

    return items;
  }, [activeCategory, search]);

  return (
    <section className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-20">
      {/* Search + filters */}
      <FadeIn duration={0.3}>
        <div className="flex flex-col sm:flex-row gap-4 mb-10">
          {/* Search input */}
          <div className="relative flex-1 max-w-md">
            <MaterialSymbol
              name="search"
              className="absolute left-3 top-1/2 -translate-y-1/2 text-text-muted text-lg"
            />
            <input
              type="text"
              placeholder="Search articles..."
              value={search}
              onChange={(e) => handleSearchChange(e.target.value)}
              className="w-full pl-10 pr-4 py-2.5 rounded-full border border-border-subtle bg-white text-sm text-primary-dark placeholder:text-text-muted focus:outline-none focus:ring-2 focus:ring-primary/40"
            />
          </div>

          {/* Category pills */}
          <div className="flex flex-wrap gap-2">
            {(["All", ...kbCategories] as const).map((cat) => (
              <button
                key={cat}
                type="button"
                onClick={() => handleCategoryChange(cat)}
                className={cn(
                  "rounded-full px-4 py-2 text-label transition-colors",
                  activeCategory === cat
                    ? "bg-primary text-white"
                    : "bg-surface-purple text-primary hover:bg-primary/10",
                )}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
      </FadeIn>

      {/* Articles grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((article, i) => (
            <FadeIn key={article.id} duration={0.3} delay={i * 0.05}>
              <ArticleCard
                href={`/knowledge-base/${article.slug}`}
                title={article.title}
                excerpt={article.excerpt}
                imageSrc={article.imageSrc}
                category={article.category}
              />
            </FadeIn>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <MaterialSymbol name="search_off" className="text-5xl text-text-muted/40 mb-4" />
          <p className="text-text-muted text-body">
            No articles found. Try a different search term or category.
          </p>
        </div>
      )}
    </section>
  );
}

export function KnowledgeBasePageClient() {
  return (
    <Suspense fallback={<div />}>
      <KnowledgeBasePageClientInner />
    </Suspense>
  );
}
