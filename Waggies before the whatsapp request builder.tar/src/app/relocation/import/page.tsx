import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ServiceFeatureGrid } from "@/components/waggies/boarding-feature-grid";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { ShareThisPage } from "@/components/waggies/share-this-page";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import { whatsappRequestUrl, serviceRequestPreset } from "@/lib/whatsapp-request";
import {
  relocationImportHero,
  relocationImportSectionHeading,
  relocationImportFeatures,
} from "@/data/relocation";
import { getFaqsForService } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Import a Pet to Nigeria",
  description:
    "Full-service pet import to Nigeria - permits, health certificates, microchip verification, and airport collection in Abuja.",
  alternates: { canonical: "/relocation/import" },
  openGraph: {
    title: "Import Pets to Nigeria - Waggies Abuja",
    description:
      "Full-service pet import to Nigeria - permits, health certificates, microchip verification, and airport collection in Abuja.",
    url: "/relocation/import",
  },
};

export default function RelocationImportPage() {
  const faqs = getFaqsForService("relocation", "import");

  // Pet import is QUOTE_REQUIRED — route directly to a structured WhatsApp
  // request rather than a pricing estimator that doesn't have relocation data.
  const importWhatsappUrl = whatsappRequestUrl(
    serviceRequestPreset("relocation-import", {
      source: "relocation-import-page-cta",
    }),
  );

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Relocation", href: "/relocation" },
          { label: "Pet Import" },
        ]}
      />

      <HeroImage {...relocationImportHero} />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={relocationImportSectionHeading.eyebrow}
            title={relocationImportSectionHeading.title}
            subtitle={relocationImportSectionHeading.subtitle}
          />
          <ServiceFeatureGrid features={relocationImportFeatures} />
        </div>
      </section>

      {/* CTA band — quote-required service, routes to WhatsApp */}
      <section className="py-16 bg-white border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="font-serif text-2xl font-bold text-primary-dark mb-1">
              Ready to start your import?
            </h2>
            <p className="text-primary-dark/60">
              Contact us as early as possible — import permits can take several weeks to process.
            </p>
          </div>
          <div className="flex gap-3 shrink-0">
            <a
              href="/relocation/checklist"
              className="inline-flex items-center gap-2 border-2 border-primary text-primary px-6 py-3 rounded-full font-semibold hover:bg-primary hover:text-white transition min-h-[44px]"
            >
              View Checklist
            </a>
            <a
              href={importWhatsappUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full font-bold transition shadow-sm min-h-[44px]"
            >
              Request Quote
            </a>
          </div>
        </div>
      </section>

      {faqs.length > 0 ? (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              spacing="mb-8"
            />
            <FaqAccordion
              faqs={faqs.map((f) => ({ question: f.question, answer: f.answer }))}
            />
            <p className="mt-6 text-sm text-primary-dark/50">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      ) : null}

      <ShareThisPage
        variant="row"
        contextLabel="Share this service"
        title="Pet Import - Waggies"
        description="Full-service pet import to Nigeria - permits, health certificates, microchip verification, and airport collection in Abuja."
      />

      <BreadcrumbSchema
        items={[
          { name: "Services", path: "/services" },
          { name: "Relocation", path: "/relocation" },
          { name: "Pet Import", path: "/relocation/import" },
        ]}
      />
      <JsonLd
        data={serviceSchema(
          "Import Pets to Nigeria - Waggies Abuja",
          "Full-service pet import to Nigeria - permits, health certificates, microchip verification, and airport collection in Abuja.",
          "/relocation/import",
          "Nigeria",
        )}
      />
    </>
  );
}
