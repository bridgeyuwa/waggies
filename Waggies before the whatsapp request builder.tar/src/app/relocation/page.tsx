import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ServiceCard } from "@/components/waggies/card-service";
import { TestimonialCard } from "@/components/waggies/card-testimonial";
import { FeatureBand } from "@/components/waggies/feature-band";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr";
import {
  relocationIndexHero,
  relocationIndexSectionHeading,
  relocationIndexCards,
  relocationIndexFeatureBand,
  relocationTestimonials,
} from "@/data/relocation";
import { getFaqsForService } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Pet Relocation",
  description:
    "Full-service pet import and export from Abuja - health certificates, import permits, airline coordination, and customs clearance.",
  alternates: { canonical: "/relocation" },
  openGraph: {
    title: "International Pet Relocation Abuja - Waggies",
    description:
      "Full-service pet import and export from Abuja - health certificates, import permits, airline coordination, and customs clearance.",
    url: "/relocation",
  },
};

export default function RelocationIndexPage() {
  const faqs = getFaqsForService("relocation");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Services", href: "/services" }, { label: "Relocation" }]}
      />

      <HeroImage {...relocationIndexHero} />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={relocationIndexSectionHeading.eyebrow}
            title={relocationIndexSectionHeading.title}
            subtitle={relocationIndexSectionHeading.subtitle}
          />

          {/* Core Relocation Services: Import, Export, Local Transport.
              These are the three independently requestable relocation services.
              3-column grid at sm+ gives a clean 3+0 composition. */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {relocationIndexCards.slice(0, 3).map((card, i) => (
              <ServiceCard key={i} {...card} />
            ))}
          </div>

          {/* Planning Utility: Relocation Checklist — SPLIT FEATURE composition.
              Semantically distinct from the core services above. Uses an
              editorial split layout (image + content) to clearly communicate
              this is a planning tool, not a fourth service. */}
          <div className="mt-12 rounded-2xl overflow-hidden border border-surface-purple bg-surface-purple/30">
            <div className="grid grid-cols-1 md:grid-cols-2">
              {/* Visual side */}
              <div className="relative h-48 md:h-auto min-h-[200px] overflow-hidden">
                <img
                  src={relocationIndexCards[3].imageSrc}
                  alt="Relocation planning checklist"
                  className="absolute inset-0 w-full h-full object-cover"
                  loading="lazy"
                />
                <div className="absolute inset-0 bg-primary-dark/20" aria-hidden="true" />
              </div>
              {/* Content side */}
              <div className="p-8 md:p-10 flex flex-col justify-center">
                <p className="text-xs font-bold uppercase tracking-widest text-primary/50 mb-3">
                  Planning Tool
                </p>
                <h3 className="font-serif text-2xl font-bold text-primary-dark mb-3">
                  Relocation Checklist
                </h3>
                <p className="text-primary-dark/60 text-sm leading-relaxed mb-4">
                  {relocationIndexCards[3].description}
                </p>
                <ul className="text-sm text-primary-dark/60 space-y-2 mb-6">
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" aria-hidden="true" />
                    Timeline-based preparation guide
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" aria-hidden="true" />
                    Document and permit tracking
                  </li>
                  <li className="flex items-start gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-primary mt-1.5 shrink-0" aria-hidden="true" />
                    Pre-travel and post-arrival steps
                  </li>
                </ul>
                <a
                  href={relocationIndexCards[3].href}
                  className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full font-bold text-sm transition shadow-sm min-h-[44px] w-fit focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
                >
                  Open Relocation Checklist
                  <ArrowRight size={16} weight="bold" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <FeatureBand {...relocationIndexFeatureBand} />

      {/* Testimonials */}
      <section className="py-20 bg-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow="Client Experiences"
            title="Smooth Moves, Happy Pets"
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relocationTestimonials.map((t, i) => (
              <TestimonialCard
                key={i}
                stars={t.stars}
                quote={t.quote}
                authorInitial={t.authorInitial}
                authorName={t.authorName}
                authorSubtitle={t.authorSubtitle}
              />
            ))}
          </div>
        </div>
      </section>

      {/* FAQ accordion (relocation category - all subcategories) */}
      {faqs.length > 0 ? (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              spacing="mb-8"
            />
            <FaqAccordion
              faqs={faqs.map((f) => ({ question: f.question, answer: f.answer }))}
            />
            <p className="mt-6 text-sm text-primary-dark/50">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      ) : null}

      <BreadcrumbSchema items={[{ name: "Services", path: "/services" }, { name: "Relocation", path: "/relocation" }]} />
      <JsonLd
        data={serviceSchema(
          "International Pet Relocation Abuja - Waggies",
          "Full-service pet import and export from Abuja - health certificates, import permits, airline coordination, and customs clearance.",
          "/relocation",
        )}
      />
    </>
  );
}
