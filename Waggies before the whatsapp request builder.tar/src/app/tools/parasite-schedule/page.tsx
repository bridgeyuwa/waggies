import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { MedicalDisclaimer } from "@/components/waggies/medical-disclaimer";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { ParasiteScheduleClient } from "@/components/waggies/tools/parasite-schedule-client";
import { ToolCta } from "@/components/waggies/tool-cta";

export const metadata: Metadata = {
  title: "Parasite & Deworming Schedule - Waggies",
  description:
    "Deworming schedule reference for puppies, kittens, and adult pets. Educational timeline with general parasite prevention guidance.",
  alternates: { canonical: "/tools/parasite-schedule" },
  openGraph: {
    title: "Parasite & Deworming Schedule - Waggies",
    description: "Pet deworming and parasite prevention schedule reference.",
    url: "/tools/parasite-schedule",
  },
};

export default function ParasiteSchedulePage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Parasite & Deworming Schedule" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon={
          <PhosphorIcon
            name="bug-beetle"
            size={14}
            className="text-secondary"
          />
        }
        title="Parasite & Deworming Schedule"
        subtitle="A general educational timeline for deworming puppies, kittens, and adult pets."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-2xl mx-auto px-4 md:px-10">
          <MedicalDisclaimer />
          <div className="mt-6">
            <ParasiteScheduleClient />
          </div>
          <ToolCta variant="medical" />
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Parasite & Deworming Schedule", path: "/tools/parasite-schedule" },
        ]}
      />
    </>
  );
}
