import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { MedicalDisclaimer } from "@/components/waggies/medical-disclaimer";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { businessInfo } from "@/lib/business-info";
import {
  Warning,
  Prohibit,
  CheckCircle,
  Phone,
} from "@phosphor-icons/react/dist/ssr";
import { ToolCta } from "@/components/waggies/tool-cta";

export const metadata: Metadata = {
  title: "Emergency & Poison Guide - Waggies",
  description:
    "Pet emergency and poison reference guide: poisonous foods, household dangers, heatstroke, choking, seizures, and bleeding. Know what to do in a crisis.",
  alternates: { canonical: "/tools/emergency-guide" },
  openGraph: {
    title: "Emergency & Poison Guide - Waggies",
    description:
      "Quick-reference guide for common pet emergencies and poisons.",
    url: "/tools/emergency-guide",
  },
};

type EmergencyCategory = {
  title: string;
  icon: string;
  warningSigns: string[];
  immediateActions: string[];
  whatNotToDo: string[];
};

const EMERGENCIES: EmergencyCategory[] = [
  {
    title: "Poisonous Foods",
    icon: "warning-circle",
    warningSigns: [
      "Vomiting or diarrhoea",
      "Excessive drooling",
      "Lethargy or weakness",
      "Tremors or seizures",
      "Difficulty breathing",
    ],
    immediateActions: [
      "Call your vet or an emergency clinic immediately",
      "Tell the vet what your pet ate and how much",
      "Bring the packaging or a sample of the substance",
      "Follow the vet's instructions - do not wait for symptoms",
    ],
    whatNotToDo: [
      "Do not induce vomiting unless your vet tells you to",
      "Do not give your pet milk, salt water, or home remedies",
      "Do not try to treat the poisoning yourself",
    ],
  },
  {
    title: "Common Household Dangers",
    icon: "warning-circle",
    warningSigns: [
      "Excessive pawing at the mouth",
      "Burns or redness on skin or in mouth",
      "Drooling, gagging, or coughing",
      "Swelling around the face or paws",
      "Unusual drowsiness or agitation",
    ],
    immediateActions: [
      "Move your pet away from the dangerous substance",
      "Check product labels for first-aid instructions",
      "Rinse the area with water if skin contact occurred (unless contraindicated on label)",
      "Call your vet or an emergency clinic",
    ],
    whatNotToDo: [
      "Do not apply human ointments or treatments",
      "Do not try to neutralise chemicals yourself",
      "Do not delay seeking veterinary help",
    ],
  },
  {
    title: "Heatstroke",
    icon: "warning-circle",
    warningSigns: [
      "Excessive panting or difficulty breathing",
      "Drooling more than usual",
      "Bright red or pale gums",
      "Rapid heart rate",
      "Weakness, staggering, or collapse",
    ],
    immediateActions: [
      "Move your pet to a cool, shaded area immediately",
      "Offer small amounts of cool (not ice-cold) water",
      "Place cool, damp towels on the neck, armpits, and groin",
      "Call your vet or go to an emergency clinic right away",
    ],
    whatNotToDo: [
      "Do not use ice or very cold water - this can make things worse",
      "Do not force your pet to drink large amounts of water",
      "Do not leave your pet in a hot car, even for a few minutes",
    ],
  },
  {
    title: "Choking",
    icon: "warning-circle",
    warningSigns: [
      "Pawing at the mouth or throat",
      "Difficulty breathing or noisy breathing",
      "Blue or pale gums or tongue",
      "Coughing or gagging",
      "Distress or panic",
    ],
    immediateActions: [
      "Stay calm - your pet can sense your panic",
      "Look inside the mouth if you can do so safely",
      "If you can see the object and it is reachable, carefully remove it with pliers (not your fingers)",
      "If you cannot remove it, get to a vet immediately",
    ],
    whatNotToDo: [
      "Do not attempt the Heimlich manoeuvre on a pet without veterinary guidance",
      "Do not push blindly into the throat",
      "Do not give your pet anything to eat or drink while choking",
    ],
  },
  {
    title: "Seizures",
    icon: "warning-circle",
    warningSigns: [
      "Sudden collapse or stiffening",
      "Uncontrolled shaking or paddling of legs",
      "Loss of consciousness",
      "Drooling or foaming at the mouth",
      "Involuntary urination or defecation",
    ],
    immediateActions: [
      "Move objects away from your pet to prevent injury",
      "Time the seizure if possible",
      "Do not restrain your pet - let the seizure run its course",
      "Call your vet as soon as the seizure ends (or during if safe to do so)",
    ],
    whatNotToDo: [
      "Do not put anything in your pet's mouth",
      "Do not try to hold your pet down",
      "Do not give food or water until fully recovered and alert",
    ],
  },
  {
    title: "Bleeding",
    icon: "warning-circle",
    warningSigns: [
      "Visible wound with blood flow",
      "Pale gums (sign of significant blood loss)",
      "Weakness or collapse",
      "Rapid breathing",
      "Swelling or bruising",
    ],
    immediateActions: [
      "Apply firm, steady pressure with a clean cloth or gauze",
      "Do not remove the first cloth if it soaks through - add more on top",
      "Keep your pet as still and calm as possible",
      "Get to a vet - severe bleeding needs professional treatment",
    ],
    whatNotToDo: [
      "Do not use a tourniquet unless directed by a vet",
      "Do not apply human antiseptics, hydrogen peroxide, or alcohol to open wounds",
      "Do not remove embedded objects",
    ],
  },
];

export default function EmergencyGuidePage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Emergency & Poison Guide" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon={
          <PhosphorIcon
            name="warning-circle"
            size={14}
            className="text-secondary"
          />
        }
        title="Emergency & Poison Guide"
        subtitle="Quick-reference for common pet emergencies. Know the warning signs, immediate actions, and what not to do."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-3xl mx-auto px-4 md:px-10">
          <MedicalDisclaimer />

          {/* Emergency contact banner */}
          <div className="mt-6 bg-red-50 border border-red-200/60 rounded-2xl p-5 sm:p-6">
            <h2 className="font-serif text-lg font-bold text-red-900 flex items-center gap-2">
              <Phone size={20} weight="fill" className="text-red-600" />
              Emergency Contact
            </h2>
            <div className="mt-3 flex flex-col sm:flex-row gap-3">
              <a
                href={businessInfo.phoneHref}
                className="inline-flex items-center gap-2 bg-red-600 hover:bg-red-700 text-white font-bold px-6 py-3 rounded-full transition text-sm"
              >
                <Phone size={16} weight="bold" />
                Call Waggies: {businessInfo.phoneInternational}
              </a>
              <a
                href={`${businessInfo.whatsappUrl}?text=Emergency%20-%20My%20pet%20needs%20help`}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 bg-white border border-red-200 text-red-800 hover:bg-red-50 font-semibold px-6 py-3 rounded-full transition text-sm"
              >
                WhatsApp Emergency
              </a>
            </div>
          </div>

          {/* Emergency categories */}
          <div className="mt-8 space-y-6">
            {EMERGENCIES.map((emergency) => (
              <div
                key={emergency.title}
                className="bg-white border border-primary/10 rounded-2xl p-5 sm:p-6"
              >
                <h3 className="font-serif text-base sm:text-lg font-bold text-primary-dark flex items-center gap-2">
                  <Warning
                    size={20}
                    weight="fill"
                    className="text-red-500 shrink-0"
                  />
                  {emergency.title}
                </h3>

                <div className="mt-4 grid grid-cols-1 md:grid-cols-3 gap-4">
                  {/* Warning Signs */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-primary/50 mb-2 flex items-center gap-1.5">
                      <Warning size={14} className="text-amber-500" />
                      Warning Signs
                    </h4>
                    <ul className="space-y-1.5">
                      {emergency.warningSigns.map((sign) => (
                        <li
                          key={sign}
                          className="text-sm text-primary-dark/60 flex items-start gap-2"
                        >
                          <span className="text-amber-400 mt-1 shrink-0">
                            &bull;
                          </span>
                          {sign}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Immediate Actions */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-primary/50 mb-2 flex items-center gap-1.5">
                      <CheckCircle
                        size={14}
                        className="text-emerald-500"
                      />
                      Immediate Actions
                    </h4>
                    <ul className="space-y-1.5">
                      {emergency.immediateActions.map((action) => (
                        <li
                          key={action}
                          className="text-sm text-primary-dark/60 flex items-start gap-2"
                        >
                          <span className="text-emerald-400 mt-1 shrink-0">
                            &bull;
                          </span>
                          {action}
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* What NOT to do */}
                  <div>
                    <h4 className="text-xs font-bold uppercase tracking-wider text-primary/50 mb-2 flex items-center gap-1.5">
                      <Prohibit
                        size={14}
                        className="text-red-500"
                      />
                      What NOT to Do
                    </h4>
                    <ul className="space-y-1.5">
                      {emergency.whatNotToDo.map((item) => (
                        <li
                          key={item}
                          className="text-sm text-primary-dark/60 flex items-start gap-2"
                        >
                          <span className="text-red-400 mt-1 shrink-0">
                            &bull;
                          </span>
                          {item}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Book Appointment CTA */}
          <ToolCta variant="medical" />
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Emergency & Poison Guide", path: "/tools/emergency-guide" },
        ]}
      />
    </>
  );
}
