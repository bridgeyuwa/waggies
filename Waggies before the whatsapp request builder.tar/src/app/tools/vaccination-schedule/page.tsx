import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { MedicalDisclaimer } from "@/components/waggies/medical-disclaimer";
import { VaccinationScheduleClient } from "@/components/waggies/tools/vaccination-schedule-client";
import { ToolCta } from "@/components/waggies/tool-cta";

export const metadata: Metadata = {
  title: "Vaccination Schedule",
  description:
    "Track recommended vaccinations for your dog or cat. Our vaccination schedule shows core and non-core vaccines by age.",
  alternates: { canonical: "/tools/vaccination-schedule" },
  openGraph: {
    title: "Vaccination Schedule - Waggies",
    description: "Track recommended vaccinations for your dog or cat.",
    url: "/tools/vaccination-schedule",
  },
};

export default function VaccinationSchedulePage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Vaccination Schedule" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        title="Vaccination Schedule"
        subtitle="See the recommended vaccination timeline for your pet. Core vaccines are required; non-core vaccines depend on your pet's lifestyle."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-3xl mx-auto px-4 md:px-10">
          <VaccinationScheduleClient />

          <ToolCta variant="medical" />

          <div className="mt-10">
            <MedicalDisclaimer />
          </div>
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Vaccination Schedule", path: "/tools/vaccination-schedule" },
        ]}
      />
    </>
  );
}
