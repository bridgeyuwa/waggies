import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { MedicalDisclaimer } from "@/components/waggies/medical-disclaimer";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { NutritionCalculatorClient } from "@/components/waggies/tools/nutrition-calculator-client";
import { ToolCta } from "@/components/waggies/tool-cta";

export const metadata: Metadata = {
  title: "Diet & Nutrition Calculator - Waggies",
  description:
    "Calculate your pet's daily calorie needs using the RER formula. Free nutrition calculator for dogs and cats by weight, life stage, and activity level.",
  alternates: { canonical: "/tools/nutrition-calculator" },
  openGraph: {
    title: "Diet & Nutrition Calculator - Waggies",
    description:
      "Estimate your pet's daily calorie needs with our RER-based nutrition calculator.",
    url: "/tools/nutrition-calculator",
  },
};

export default function NutritionCalculatorPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Nutrition Calculator" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon={
          <PhosphorIcon
            name="fork-knife"
            size={14}
            className="text-secondary"
          />
        }
        title="Diet & Nutrition Calculator"
        subtitle="Estimate your pet's daily calorie needs based on weight, species, life stage, and activity level."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-lg mx-auto px-4 md:px-10">
          <MedicalDisclaimer variant="compact" />
          <div className="mt-6">
            <NutritionCalculatorClient />
          </div>
          <ToolCta variant="general" />
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Nutrition Calculator", path: "/tools/nutrition-calculator" },
        ]}
      />
    </>
  );
}
