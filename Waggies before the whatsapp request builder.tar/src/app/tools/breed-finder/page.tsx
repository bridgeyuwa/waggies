import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { BreedFinderClient } from "@/components/waggies/tools/breed-finder-client";
import { ToolCta } from "@/components/waggies/tool-cta";

export const metadata: Metadata = {
  title: "Breed Info Finder - Waggies",
  description:
    "Browse popular dog and cat breeds. Filter by size, energy, and grooming needs. General breed information and health considerations.",
  alternates: { canonical: "/tools/breed-finder" },
  openGraph: {
    title: "Breed Info Finder - Waggies",
    description: "Search and filter popular dog and cat breeds with general breed information.",
    url: "/tools/breed-finder",
  },
};

export default function BreedFinderPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Breed Info Finder" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon={
          <PhosphorIcon
            name="magnifying-glass"
            size={14}
            className="text-secondary"
          />
        }
        title="Breed Info Finder"
        subtitle="Browse popular dog and cat breeds with general information on size, energy, grooming, and temperament."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-6xl mx-auto px-4 md:px-10">
          <BreedFinderClient />
          <ToolCta variant="general" showCall={false} />
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Breed Info Finder", path: "/tools/breed-finder" },
        ]}
      />
    </>
  );
}
