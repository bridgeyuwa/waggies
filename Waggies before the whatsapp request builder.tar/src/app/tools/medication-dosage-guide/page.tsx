import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { MedicalDisclaimer } from "@/components/waggies/medical-disclaimer";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { Pill, BookOpen, ShieldCheck, Stethoscope } from "@phosphor-icons/react/dist/ssr";
import { ToolCta } from "@/components/waggies/tool-cta";

export const metadata: Metadata = {
  title: "Medication Dosage Guide - Waggies",
  description:
    "Veterinary-reviewed medication reference guide for common pet medications, dosage guidelines, and safety notes. Coming soon from Waggies.",
  alternates: { canonical: "/tools/medication-dosage-guide" },
  openGraph: {
    title: "Medication Dosage Guide - Waggies",
    description:
      "Veterinary-reviewed pet medication reference. Dosage guidelines and safety notes.",
    url: "/tools/medication-dosage-guide",
  },
};

const SECTIONS = [
  {
    title: "Common Medications",
    icon: "pill",
    phosphorIcon: <Pill size={28} weight="duotone" className="text-primary/40" />,
    description: "Verified reference information on frequently prescribed medications for dogs and cats.",
  },
  {
    title: "Dosage Guidelines",
    icon: "book-open",
    phosphorIcon: <BookOpen size={28} weight="duotone" className="text-primary/40" />,
    description: "General dosage principles and weight-based calculation references.",
  },
  {
    title: "Safety Notes",
    icon: "shield-check",
    phosphorIcon: <ShieldCheck size={28} weight="duotone" className="text-primary/40" />,
    description: "Drug interactions, toxic substances, and what to avoid.",
  },
] as const;

export default function MedicationDosageGuidePage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Medication Dosage Guide" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon={<PhosphorIcon name="pill" size={14} className="text-secondary" />}
        title="Medication Dosage Guide"
        subtitle="A veterinary-reviewed reference for common pet medications, dosage guidelines, and safety notes."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-3xl mx-auto px-4 md:px-10">
          <MedicalDisclaimer />

          {/* Coming soon message */}
          <div className="mt-8 bg-white border border-primary/10 rounded-2xl p-6 sm:p-8 text-center">
            <div className="w-14 h-14 rounded-2xl bg-surface-purple flex items-center justify-center mx-auto mb-4">
              <Stethoscope size={28} weight="duotone" className="text-primary" />
            </div>
            <h2 className="font-serif text-lg sm:text-xl font-bold text-primary-dark">
              This guide is being prepared by our veterinary team
            </h2>
            <p className="text-primary-dark/50 text-sm mt-2 leading-relaxed max-w-md mx-auto">
              Check back soon for verified medication reference information.
              In the meantime, always consult your veterinarian for medication questions.
            </p>
          </div>

          {/* Section placeholders */}
          <div className="mt-8 space-y-4">
            {SECTIONS.map((section) => (
              <div
                key={section.title}
                className="bg-white border border-primary/10 rounded-xl p-5 sm:p-6 flex items-start gap-4 opacity-60"
              >
                <div className="w-12 h-12 rounded-xl bg-surface-purple flex items-center justify-center shrink-0">
                  {section.phosphorIcon}
                </div>
                <div>
                  <h3 className="font-serif text-base font-bold text-primary-dark">
                    {section.title}
                  </h3>
                  <p className="text-primary-dark/50 text-sm mt-1 leading-relaxed">
                    {section.description}
                  </p>
                  <span className="inline-block mt-2 text-xs font-medium text-primary/50">
                    Content coming soon
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Book Appointment CTA */}
          <ToolCta variant="medical" />
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Medication Dosage Guide", path: "/tools/medication-dosage-guide" },
        ]}
      />
    </>
  );
}
