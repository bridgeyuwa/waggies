import type { Metadata } from "next";
import Link from "next/link";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { MedicalDisclaimer } from "@/components/waggies/medical-disclaimer";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import { FadeIn, StaggerChildren } from "@/components/waggies/motion";
import {
  allTools,
  categoryLabels,
  categoryOrder,
  getToolsByCategory,
  type ToolEntry,
} from "@/data/tools-data";
import { businessInfo } from "@/lib/business-info";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr";

export const metadata: Metadata = {
  title: "Pet Care Tools",
  description:
    "Free pet care tools from Waggies: symptom checker, pet age calculator, nutrition calculator, emergency guide, breed finder, and more for pet owners in Abuja.",
  alternates: { canonical: "/tools" },
  openGraph: {
    title: "Pet Care Tools - Waggies",
    description:
      "Free pet care tools: symptom checker, age calculator, nutrition calculator, emergency guide, and breed info finder.",
    url: "/tools",
  },
};

const FEATURED_TOOL = allTools.find(
  (t) => t.route === "/tools/symptom-checker",
) as ToolEntry;

export default function ToolsPage() {
  const grouped = getToolsByCategory();
  const hasHealthTools = grouped.health.length > 0;

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Tools" }]}
      />

      <HeroPlain
        eyebrow="Pet Care Tools"
        title="Useful Tools for Pet Owners"
        subtitle="Free interactive tools and reference guides to help you take better care of your pets."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-6xl mx-auto px-4 md:px-10 lg:px-12">
          {/* Featured tool */}
          <FadeIn>
            <Link
              href={FEATURED_TOOL.route}
              className="group block bg-white border border-primary/10 rounded-2xl p-6 sm:p-8 md:p-10 shadow-sm hover:shadow-md transition-shadow mb-10"
            >
              <div className="flex flex-col sm:flex-row sm:items-center gap-5">
                <div className="w-14 h-14 sm:w-16 sm:h-16 rounded-2xl bg-surface-purple group-hover:bg-primary flex items-center justify-center text-primary group-hover:text-white transition-colors shrink-0">
                  <PhosphorIcon
                    name={FEATURED_TOOL.icon}
                    size={28}
                    className="sm:text-[32px]"
                  />
                </div>
                <div className="flex-1 min-w-0">
                  <span className="inline-block text-[10px] font-bold uppercase tracking-widest text-primary/50 mb-1">
                    Featured Tool
                  </span>
                  <h2 className="font-serif text-xl sm:text-2xl font-bold text-primary-dark group-hover:text-primary transition-colors">
                    {FEATURED_TOOL.name}
                  </h2>
                  <p className="text-primary-dark/50 text-sm sm:text-base mt-1 leading-relaxed">
                    {FEATURED_TOOL.longDescription}
                  </p>
                </div>
                <div className="shrink-0 self-start sm:self-center">
                  <span className="inline-flex items-center gap-1.5 text-sm font-semibold text-primary group-hover:gap-2.5 transition-all">
                    Try it out
                    <ArrowRight
                      size={16}
                      className="transition-transform group-hover:translate-x-0.5"
                      weight="bold"
                    />
                  </span>
                </div>
              </div>
            </Link>
          </FadeIn>

          {/* Grouped tool categories.
              Categories with ≤2 tools use a 2-column grid to avoid a stranded
              single card in a 3-column grid. Categories with 3+ tools use 3 columns. */}
          {categoryOrder.map((cat) => {
            const tools = grouped[cat];
            if (tools.length === 0) return null;
            // Filter out the featured tool (shown above) from the Health grid
            const displayTools = tools.filter(
              (t) => t.route !== "/tools/symptom-checker",
            );
            if (displayTools.length === 0) return null;
            const gridCols =
              displayTools.length <= 2
                ? "grid grid-cols-1 sm:grid-cols-2 gap-4"
                : "grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4";
            return (
              <div key={cat} className="mb-12 last:mb-0">
                <h3 className="text-xs font-bold uppercase tracking-widest text-primary/40 mb-5">
                  {categoryLabels[cat]}
                </h3>
                <StaggerChildren className={gridCols}>
                  {displayTools.map((tool) => (
                    <FadeIn key={tool.route}>
                      <ToolCard tool={tool} />
                    </FadeIn>
                  ))}
                </StaggerChildren>
              </div>
            );
          })}

          {/* Medical disclaimer for health tools */}
          {hasHealthTools && (
            <div className="mt-12">
              <MedicalDisclaimer />
            </div>
          )}

          {/* Book an Appointment CTA */}
          <div className="mt-16 text-center">
            <div className="bg-primary-dark rounded-2xl p-8 sm:p-10">
              <h2 className="font-serif text-xl sm:text-2xl font-bold text-white">
                Need Professional Advice?
              </h2>
              <p className="text-white/70 text-sm sm:text-base mt-2 max-w-lg mx-auto">
                Our veterinary team is available for consultations. Book an
                appointment or call us directly.
              </p>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3 mt-6">
                <a
                  href="/contact"
                  className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark font-bold px-8 py-3.5 rounded-full transition text-sm"
                >
                  Book an Appointment
                </a>
                <a
                  href={businessInfo.phoneHref}
                  className="inline-flex items-center gap-2 border border-white/30 text-white hover:bg-white/10 font-semibold px-8 py-3.5 rounded-full transition text-sm"
                >
                  Call {businessInfo.phoneLocal}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <BreadcrumbSchema items={[{ name: "Tools", path: "/tools" }]} />
    </>
  );
}

function ToolCard({ tool }: { tool: ToolEntry }) {
  const categoryBadgeColors: Record<
    ToolEntry["category"],
    string
  > = {
    health: "bg-red-50 text-red-700 border-red-200/60",
    calculator: "bg-blue-50 text-blue-700 border-blue-200/60",
    reference: "bg-emerald-50 text-emerald-700 border-emerald-200/60",
    utility: "bg-amber-50 text-amber-700 border-amber-200/60",
  };

  return (
    <Link
      href={tool.route}
      className="group block bg-white border border-primary/10 rounded-xl p-5 hover:shadow-sm transition-shadow h-full"
    >
      <div className="flex items-start gap-4">
        <div className="w-11 h-11 rounded-xl bg-surface-purple group-hover:bg-primary flex items-center justify-center text-primary group-hover:text-white transition-colors shrink-0">
          <PhosphorIcon name={tool.icon} size={20} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="font-serif text-base font-bold text-primary-dark group-hover:text-primary transition-colors truncate">
              {tool.name}
            </h4>
          </div>
          <p className="text-primary-dark/50 text-sm leading-relaxed line-clamp-2">
            {tool.description}
          </p>
          <span
            className={`inline-block mt-3 text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full border ${categoryBadgeColors[tool.category]}`}
          >
            {categoryLabels[tool.category]}
          </span>
        </div>
      </div>
    </Link>
  );
}
