import type { Metadata } from "next";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { PhosphorIcon } from "@/lib/phosphor-icons";
import {
  ChatCircle,
  HandPointing,
  WarningOctagon,
} from "@phosphor-icons/react/dist/ssr";
import { ToolCta } from "@/components/waggies/tool-cta";

export const metadata: Metadata = {
  title: "Behavior & Training Tips - Waggies",
  description:
    "Practical pet behavior and training tips. Advice for barking, anxiety, house training, aggression, and more.",
  alternates: { canonical: "/tools/behavior-tips" },
  openGraph: {
    title: "Behavior & Training Tips - Waggies",
    description:
      "General, non-diagnostic advice for common pet behavior issues.",
    url: "/tools/behavior-tips",
  },
};

type BehaviorTip = {
  title: string;
  description: string;
  practicalAdvice: string[];
  whenToSeekHelp: string;
  escalate: boolean;
};

const BEHAVIOR_TIPS: BehaviorTip[] = [
  {
    title: "Excessive Barking",
    description:
      "Barking is natural communication, but excessive barking can indicate boredom, anxiety, territorial behaviour, or a need for more exercise.",
    practicalAdvice: [
      "Identify the trigger (passers-by, other dogs, sounds, loneliness)",
      "Ensure adequate daily exercise and mental stimulation",
      "Teach a \"quiet\" command using positive reinforcement",
      "Use puzzle feeders and toys to reduce boredom when alone",
      "Avoid shouting at your dog to stop barking - they may interpret this as you barking along",
    ],
    whenToSeekHelp:
      "If the barking persists despite consistent training over several weeks, or if it is causing complaints from neighbours.",
    escalate: true,
  },
  {
    title: "Jumping Up",
    description:
      "Dogs jump to greet people because it gets attention. It is a common and manageable behaviour.",
    practicalAdvice: [
      "Ignore the jumping completely - turn away, cross your arms, do not make eye contact",
      "Only give attention (petting, greeting) when all four paws are on the floor",
      "Ask visitors to do the same",
      "Teach an alternative behaviour like \"sit\" for greetings",
      "Reward calm behaviour consistently",
    ],
    whenToSeekHelp:
      "If your dog is jumping on children, elderly people, or anyone who could be injured.",
    escalate: false,
  },
  {
    title: "Anxiety & Separation",
    description:
      "Separation anxiety is distress when a dog is left alone or separated from their owner. It can manifest as barking, destructive behaviour, or toileting indoors.",
    practicalAdvice: [
      "Start with very short absences and gradually increase the duration",
      "Leave a worn item of clothing with your scent",
      "Use puzzle feeders and long-lasting chews when you leave",
      "Keep departures and arrivals calm and low-key",
      "Establish a predictable routine for leaving and returning",
    ],
    whenToSeekHelp:
      "If your dog shows severe distress (self-injury, persistent destruction, excessive vocalisation) when left alone, consult your vet and a qualified behaviourist.",
    escalate: true,
  },
  {
    title: "Aggression",
    description:
      "Aggression can be directed at people, other dogs, or other animals. It is often rooted in fear, resource guarding, or lack of socialisation.",
    practicalAdvice: [
      "Do not punish aggressive behaviour - it often makes it worse",
      "Identify triggers and avoid them while seeking professional help",
      "Manage the environment to prevent incidents",
      "Use a muzzle if recommended by a professional for safety during training",
      "Work with a qualified behaviourist - aggression is not a DIY project",
    ],
    whenToSeekHelp:
      "Always seek professional help for aggression. This is not something to manage on your own. Contact your vet and a qualified animal behaviourist.",
    escalate: true,
  },
  {
    title: "House Training",
    description:
      "House training takes patience and consistency. Most dogs can learn with a structured routine.",
    practicalAdvice: [
      "Take your puppy outside frequently - after waking, eating, drinking, and playing",
      "Praise and reward immediately when they toilet in the correct spot",
      "Establish a regular feeding schedule to predict toilet times",
      "Clean accidents with an enzymatic cleaner to remove the scent marker",
      "Do not punish accidents - just clean up and move on",
    ],
    whenToSeekHelp:
      "If an adult dog that was previously house-trained starts having accidents, consult your vet to rule out medical issues.",
    escalate: false,
  },
  {
    title: "Destructive Chewing",
    description:
      "Chewing is natural, especially in puppies. Destructive chewing usually indicates boredom, excess energy, or stress.",
    practicalAdvice: [
      "Provide plenty of appropriate chew toys",
      "Rotate toys to keep them interesting",
      "Ensure adequate exercise for your dog's breed and age",
      "Use baby gates or close doors to limit access to valuable items",
      "When you catch them chewing something inappropriate, redirect to a chew toy",
    ],
    whenToSeekHelp:
      "If the chewing is severe, sudden, or accompanied by other behaviour changes, consult your vet to rule out dental pain or anxiety.",
    escalate: true,
  },
];

export default function BehaviorTipsPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Tools", href: "/tools" },
          { label: "Behavior & Training Tips" },
        ]}
      />

      <HeroPlain
        eyebrow="Pet Care Tool"
        eyebrowIcon={
          <PhosphorIcon
            name="brain"
            size={14}
            className="text-secondary"
          />
        }
        title="Behavior & Training Tips"
        subtitle="General, non-diagnostic advice for common pet behaviour issues."
      />

      <section className="bg-surface pb-20 md:pb-28">
        <div className="max-w-3xl mx-auto px-4 md:px-10">
          <div className="space-y-6">
            {BEHAVIOR_TIPS.map((tip) => (
              <div
                key={tip.title}
                className="bg-white border border-primary/10 rounded-2xl p-5 sm:p-6"
              >
                <h3 className="font-serif text-base sm:text-lg font-bold text-primary-dark">
                  {tip.title}
                </h3>
                <p className="text-sm text-primary-dark/60 mt-2 leading-relaxed">
                  {tip.description}
                </p>

                {/* Practical advice */}
                <div className="mt-4">
                  <h4 className="text-xs font-bold uppercase tracking-wider text-primary/50 mb-2 flex items-center gap-1.5">
                    <ChatCircle size={14} className="text-primary" />
                    Practical Advice
                  </h4>
                  <ul className="space-y-2">
                    {tip.practicalAdvice.map((advice, idx) => (
                      <li
                        key={idx}
                        className="text-sm text-primary-dark/60 flex items-start gap-2"
                      >
                        <HandPointing
                          size={12}
                          className="text-primary/40 mt-1 shrink-0"
                        />
                        {advice}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* When to seek help */}
                <div
                  className={`mt-4 rounded-xl p-3 ${
                    tip.escalate
                      ? "bg-amber-50 border border-amber-200/60"
                      : "bg-surface-purple border border-primary/10"
                  }`}
                >
                  <h4
                    className={`text-xs font-bold uppercase tracking-wider mb-1 flex items-center gap-1.5 ${
                      tip.escalate ? "text-amber-700" : "text-primary/60"
                    }`}
                  >
                    <WarningOctagon
                      size={14}
                      className={tip.escalate ? "text-amber-600" : "text-primary/40"}
                    />
                    {tip.escalate ? "When to Seek Professional Help" : "Good to Know"}
                  </h4>
                  <p
                    className={`text-sm leading-relaxed ${
                      tip.escalate ? "text-amber-900" : "text-primary-dark/60"
                    }`}
                  >
                    {tip.whenToSeekHelp}
                  </p>
                  {tip.escalate && (
                    <a
                      href="/services/training"
                      className="inline-flex items-center gap-1 text-xs font-semibold text-primary hover:underline mt-2"
                    >
                      View our Training services
                    </a>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Book Appointment CTA */}
          <ToolCta variant="general" />
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "Tools", path: "/tools" },
          { name: "Behavior & Training Tips", path: "/tools/behavior-tips" },
        ]}
      />
    </>
  );
}
