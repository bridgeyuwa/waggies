"use client";

import { Suspense, useCallback, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { blogArticles, blogCategories, type BlogCategory } from "@/data/content-data";
import { ArticleCard } from "@/components/waggies/content/article-card";
import { FadeIn } from "@/components/waggies/motion";
import { cn } from "@/lib/utils";

/**
 * Blog index page client with category filtering persisted to the URL
 * via `?category=`. The "All" filter is the default and removes the
 * param so the URL stays clean when no filter is active.
 *
 * Wrapped in a `<Suspense>` boundary because `useSearchParams()`
 * requires it per Next.js docs to avoid deopting the whole page to CSR.
 */
function BlogPageClientInner() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const [activeCategory, setActiveCategory] = useState<BlogCategory | "All">(
    () => {
      const param = searchParams.get("category");
      if (param && (blogCategories as readonly string[]).includes(param)) {
        return param as BlogCategory;
      }
      return "All";
    },
  );

  const updateUrl = useCallback(
    (category: BlogCategory | "All") => {
      const params = new URLSearchParams(searchParams.toString());
      if (category === "All") {
        params.delete("category");
      } else {
        params.set("category", category);
      }
      const qs = params.toString();
      router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    },
    [searchParams, router, pathname],
  );

  const handleCategoryChange = useCallback(
    (category: BlogCategory | "All") => {
      setActiveCategory(category);
      updateUrl(category);
    },
    [updateUrl],
  );

  const filtered = useMemo(
    () =>
      activeCategory === "All"
        ? blogArticles
        : blogArticles.filter((a) => a.category === activeCategory),
    [activeCategory],
  );

  return (
    <section className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-20">
      {/* Category filter pills */}
      <FadeIn duration={0.3}>
        <div className="flex flex-wrap gap-2 mb-10">
          {(["All", ...blogCategories] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => handleCategoryChange(cat)}
              className={cn(
                "rounded-full px-4 py-2 text-label transition-colors",
                activeCategory === cat
                  ? "bg-primary text-white"
                  : "bg-surface-purple text-primary hover:bg-primary/10",
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </FadeIn>

      {/* Articles grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((article, i) => (
            <FadeIn key={article.id} duration={0.3} delay={i * 0.05}>
              <ArticleCard
                href={`/blog/${article.slug}`}
                title={article.title}
                excerpt={article.excerpt}
                imageSrc={article.imageSrc}
                category={article.category}
                author={article.author}
                date={article.date}
                readTime={article.readTime}
              />
            </FadeIn>
          ))}
        </div>
      ) : (
        <div className="text-center py-16">
          <p className="text-text-muted text-body">
            No articles found in this category.
          </p>
        </div>
      )}
    </section>
  );
}

export function BlogPageClient() {
  return (
    <Suspense fallback={<div />}>
      <BlogPageClientInner />
    </Suspense>
  );
}
