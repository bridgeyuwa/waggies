/**
 * Route-level loading state.
 *
 * Shows a subtle top progress bar during route transitions. Preserves the
 * page shell (navbar, footer, etc.) — only the main content area shows
 * a lightweight loading indication.
 *
 * Design principles:
 *   - No full-screen spinner (avoids visual jank)
 *   - No layout shift (the bar is fixed at the top, doesn't push content)
 *   - Respects reduced motion (static bar instead of animated)
 *   - Does not interfere with sticky navbar (z-50) — uses z-[60]
 *   - Does not compete with WhatsApp/chatbot controls (z-50/51)
 */

export default function Loading() {
  return (
    <div
      className="fixed top-0 left-0 right-0 z-[60] h-0.5 bg-primary/80"
      role="status"
      aria-label="Loading"
      aria-live="polite"
    >
      <div className="h-full w-full bg-primary animate-pulse" />
    </div>
  );
}
