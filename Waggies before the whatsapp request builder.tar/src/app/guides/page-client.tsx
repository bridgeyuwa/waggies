"use client";

import { Suspense, useCallback, useMemo, useState } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { guides, guideCategories, type GuideCategory } from "@/data/content-data";
import { ArticleCard } from "@/components/waggies/content/article-card";
import { FadeIn } from "@/components/waggies/motion";
import { cn } from "@/lib/utils";

/**
 * Guides index page client with category filtering persisted to the URL
 * via `?category=`. The "All" filter is the default and removes the
 * param so the URL stays clean when no filter is active.
 *
 * Wrapped in a `<Suspense>` boundary because `useSearchParams()`
 * requires it per Next.js docs to avoid deopting the whole page to CSR.
 */
function GuidesPageClientInner() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const pathname = usePathname();

  const [activeCategory, setActiveCategory] = useState<GuideCategory | "All">(
    () => {
      const param = searchParams.get("category");
      if (param && (guideCategories as readonly string[]).includes(param)) {
        return param as GuideCategory;
      }
      return "All";
    },
  );

  const updateUrl = useCallback(
    (category: GuideCategory | "All") => {
      const params = new URLSearchParams(searchParams.toString());
      if (category === "All") {
        params.delete("category");
      } else {
        params.set("category", category);
      }
      const qs = params.toString();
      router.replace(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
    },
    [searchParams, router, pathname],
  );

  const handleCategoryChange = useCallback(
    (category: GuideCategory | "All") => {
      setActiveCategory(category);
      updateUrl(category);
    },
    [updateUrl],
  );

  const filtered = useMemo(
    () =>
      activeCategory === "All"
        ? guides
        : guides.filter((g) => g.category === activeCategory),
    [activeCategory],
  );

  const featured = filtered[0];
  const rest = filtered.slice(1);

  return (
    <section className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-20">
      {/* Category filter pills */}
      <FadeIn duration={0.3}>
        <div className="flex flex-wrap gap-2 mb-10">
          {(["All", ...guideCategories] as const).map((cat) => (
            <button
              key={cat}
              type="button"
              onClick={() => handleCategoryChange(cat)}
              className={cn(
                "rounded-full px-4 py-2 text-label transition-colors",
                activeCategory === cat
                  ? "bg-primary text-white"
                  : "bg-surface-purple text-primary hover:bg-primary/10",
              )}
            >
              {cat}
            </button>
          ))}
        </div>
      </FadeIn>

      {filtered.length > 0 ? (
        <>
          {/* Featured guide - full width */}
          <FadeIn duration={0.35}>
            <ArticleCard
              href={`/guides/${featured.slug}`}
              title={featured.title}
              excerpt={featured.excerpt}
              imageSrc={featured.imageSrc}
              category={featured.category}
              readTime={featured.readTime}
              featured
              className="mb-8"
            />
          </FadeIn>

          {/* Remaining guides in a grid */}
          {rest.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {rest.map((guide, i) => (
                <FadeIn key={guide.id} duration={0.3} delay={i * 0.05}>
                  <ArticleCard
                    href={`/guides/${guide.slug}`}
                    title={guide.title}
                    excerpt={guide.excerpt}
                    imageSrc={guide.imageSrc}
                    category={guide.category}
                    readTime={guide.readTime}
                  />
                </FadeIn>
              ))}
            </div>
          )}
        </>
      ) : (
        <div className="text-center py-16">
          <p className="text-text-muted text-body">No guides found in this category.</p>
        </div>
      )}
    </section>
  );
}

export function GuidesPageClient() {
  return (
    <Suspense fallback={<div />}>
      <GuidesPageClientInner />
    </Suspense>
  );
}
