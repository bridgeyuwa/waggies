/**
 * /about/testimonials - Client testimonials page with service filtering.
 *
 * Uses the TestimonialsGrid client component for filterable, URL-stateful
 * testimonials display. All testimonial data from src/data/testimonials.ts.
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { HeroSplit } from "@/components/waggies/hero-split";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { testimonialsHero, testimonialsBottomCta } from "@/data/testimonials";
import { TestimonialForm } from "@/components/waggies/sections/testimonial-form";
import { TestimonialsGrid } from "@/components/waggies/sections/testimonials-grid";
import { FadeIn } from "@/components/waggies/motion/fade-in";
import { ArrowRight } from "@phosphor-icons/react/dist/ssr";

export const metadata: Metadata = {
  title: "Client Testimonials",
  description:
    "Read what pet owners across Abuja share about their Waggies boarding, grooming, vet care, training and relocation experience.",
  alternates: { canonical: "/about/testimonials" },
  openGraph: {
    title: "Client Testimonials - Waggies Pet Care Abuja",
    description:
      "Read what pet owners across Abuja share about their Waggies boarding, grooming, vet care, training and relocation experience.",
    url: "/about/testimonials",
  },
};

export default function TestimonialsPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "About", href: "/about" },
          { label: "Testimonials" },
        ]}
      />

      <HeroSplit
        eyebrow={testimonialsHero.eyebrow}
        eyebrowIcon={testimonialsHero.eyebrowIcon}
        title={testimonialsHero.title}
        subtitle={testimonialsHero.subtitle}
        imageSrc={testimonialsHero.imageSrc}
        imageAlt={testimonialsHero.imageAlt}
        // Rating badge suppressed — all testimonials are placeholder/synthetic.
        // No unverified rating or review count is displayed.
        primaryLabel={testimonialsHero.primaryLabel}
        primaryHref={testimonialsHero.primaryHref}
        secondaryLabel={testimonialsHero.secondaryLabel}
        secondaryHref={testimonialsHero.secondaryHref}
      />

      {/* Filterable testimonials grid */}
      <TestimonialsGrid />

      {/* Share Your Experience - testimonial submission form */}
      <section className="py-20 bg-surface-purple">
        <div className="max-w-3xl mx-auto px-4 md:px-10 lg:px-12">
          <FadeIn direction="up" className="text-center mb-10">
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark mb-3">
              Share Your Experience
            </h2>
            <p className="text-primary-dark/60 max-w-xl mx-auto">
              Help other pet owners discover Waggies.
            </p>
          </FadeIn>

          <FadeIn direction="up" delay={0.1}>
            <TestimonialForm />
          </FadeIn>
        </div>
      </section>

      {/* Single clear CTA — no competing duplicate */}
      <section className="py-20 bg-primary-dark">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="font-serif text-3xl font-bold text-white mb-3">
            {testimonialsBottomCta.heading}
          </h2>
          <p className="text-white/70 mb-6">
            {testimonialsBottomCta.body}
          </p>
          <a
            href={testimonialsBottomCta.ctaHref}
            className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark px-8 py-4 rounded-full font-bold transition shadow-sm min-h-[44px]"
          >
            {testimonialsBottomCta.ctaLabel}
            <ArrowRight size={18} weight="bold" />
          </a>
        </div>
      </section>

      <BreadcrumbSchema
        items={[
          { name: "About", path: "/about" },
          { name: "Testimonials", path: "/about/testimonials" },
        ]}
      />
      <JsonLd
        data={webPageSchema(
          "Client Testimonials - Waggies Pet Care Abuja",
          "Read what pet owners across Abuja share about their Waggies boarding, grooming, vet care, training and relocation experience.",
          "/about/testimonials",
        )}
      />
    </>
  );
}
