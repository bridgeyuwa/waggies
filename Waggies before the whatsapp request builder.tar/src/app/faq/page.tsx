import type { Metadata } from "next";
import { HeroHub } from "@/components/waggies/hero-hub";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { FaqPageClient } from "@/components/waggies/faq-page-client";
import { JsonLd, faqPageSchema } from "@/components/waggies/json-ld";
import { BreadcrumbSchema } from "@/components/waggies/breadcrumb-schema";
import { getActiveFaqs, getGroupedFaqs } from "@/data/faqs";

// ── SEO metadata for FAQ category filter states ───────────────────────────
//
// Only meaningful categories with sufficient content are given unique
// metadata. The canonical for a category URL points to that category URL
// (NOT the base /faq), so search engines can index the category page.
//
// Unknown/arbitrary category values fall through to the base /faq metadata
// with canonical /faq (no indexable category page).

type CategoryMeta = {
  title: string;
  description: string;
};

const CATEGORY_METADATA: Record<string, CategoryMeta> = {
  boarding: {
    title: "Boarding FAQs",
    description:
      "Frequently asked questions about pet boarding at Waggies Abuja — check-in requirements, daily updates, stay durations, shared boarding, and what happens if your pet becomes unwell.",
  },
  grooming: {
    title: "Grooming FAQs",
    description:
      "Frequently asked questions about pet grooming at Waggies Abuja — cat and dog grooming, appointment booking, grooming duration, and available services.",
  },
  "vet-care": {
    title: "Veterinary Care FAQs",
    description:
      "Frequently asked questions about veterinary care at Waggies Abuja — appointments, vaccinations, microchipping, and emergency care.",
  },
  training: {
    title: "Training FAQs",
    description:
      "Frequently asked questions about dog training at Waggies Abuja — training methods, programme structure, and behaviour modification.",
  },
  relocation: {
    title: "Pet Relocation FAQs",
    description:
      "Frequently asked questions about pet relocation at Waggies Abuja — import and export permits, documentation, timelines, and airport pickup.",
  },
  transport: {
    title: "Local Transport FAQs",
    description:
      "Frequently asked questions about local pet transport at Waggies Abuja — door-to-door pickup, vehicle standards, and booking.",
  },
  general: {
    title: "General FAQs",
    description:
      "General frequently asked questions about Waggies Abuja — location, opening hours, booking process, and breed policies.",
  },
};

// Validate that a category slug is a real FAQ category with content.
function isValidCategory(slug: string | null): slug is string {
  if (!slug) return false;
  const { categories } = getGroupedFaqs();
  return categories.some((c) => c.slug === slug);
}

export async function generateMetadata({
  searchParams,
}: {
  searchParams: Promise<{ category?: string }>;
}): Promise<Metadata> {
  const sp = await searchParams;
  const category = sp.category;

  // Unknown or missing category → base /faq metadata
  if (!category || !isValidCategory(category)) {
    return {
      title: "Frequently Asked Questions",
      description:
        "Quick answers to the questions we hear most often about Waggies pet boarding, grooming, vet care, training, relocation and local transport services in Abuja.",
      alternates: { canonical: "/faq" },
      openGraph: {
        title: "Frequently Asked Questions - Waggies",
        description:
          "Quick answers to the questions we hear most often about Waggies pet boarding, grooming, vet care, training, relocation and local transport services in Abuja.",
        url: "/faq",
      },
    };
  }

  // Known category → unique metadata with category-specific canonical
  const catMeta = CATEGORY_METADATA[category];
  if (!catMeta) {
    // Valid category but no metadata mapping — fall back to base
    return {
      title: "Frequently Asked Questions",
      description:
        "Quick answers to the questions we hear most often about Waggies pet boarding, grooming, vet care, training, relocation and local transport services in Abuja.",
      alternates: { canonical: "/faq" },
      openGraph: {
        title: "Frequently Asked Questions - Waggies",
        description:
          "Quick answers to the questions we hear most often about Waggies pet boarding, grooming, vet care, training, relocation and local transport services in Abuja.",
        url: "/faq",
      },
    };
  }

  const categoryUrl = `/faq?category=${category}`;
  return {
    title: catMeta.title,
    description: catMeta.description,
    alternates: { canonical: categoryUrl },
    openGraph: {
      title: `${catMeta.title} - Waggies`,
      description: catMeta.description,
      url: categoryUrl,
    },
  };
}

/**
 * FAQ page - uses the `utility` layout pattern from Laravel (hero slot +
 * max-w-5xl content slot). We reproduce that here with a hero hub + a
 * max-w-5xl wrapper around the FAQ tabbed accordion.
 */
export default function FaqPage() {
  // Build FAQPage schema from the full active FAQ dataset (all categories).
  const faqs = getActiveFaqs();

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "FAQ" }]}
      />

      <HeroHub type="faq" />

      <div className="max-w-5xl mx-auto px-4 md:px-10 py-12 md:py-20">
        <FaqPageClient />
      </div>

      <BreadcrumbSchema items={[{ name: "FAQ", path: "/faq" }]} />
      <JsonLd
        data={faqPageSchema(
          faqs.map((f) => ({ question: f.question, answer: f.answer })),
        )}
      />
    </>
  );
}
