import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ServiceCard } from "@/components/waggies/card-service";
import { TestimonialCard } from "@/components/waggies/card-testimonial";
import { CtaPrimary } from "@/components/waggies/cta-primary";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import { whatsappRequestUrl, serviceRequestPreset } from "@/lib/whatsapp-request";
import {
  boardingIndexHero,
  boardingIndexCards,
  boardingIncludedFeatures,
  boardingSafeSpaceCard,
  boardingTestimonials,
} from "@/data/services";
import { servicesIndexInlineFaqs } from "@/data/services";

export const metadata: Metadata = {
  title: "Pet Boarding",
  description:
    "Pet boarding in Abuja with 24/7 supervision, private suites, on-site vet, and daily photo updates.",
  alternates: { canonical: "/services/boarding" },
  openGraph: {
    title: "Pet Boarding Abuja - Waggies",
    description:
      "Pet boarding in Abuja with 24/7 supervision, private suites, on-site vet, and daily photo updates.",
    url: "/services/boarding",
  },
};

export default function BoardingIndexPage() {
  const boardingWhatsappUrl = whatsappRequestUrl(
    serviceRequestPreset("boarding", {
      source: "boarding-hub-cta",
    }),
  );

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Boarding", href: "/services/boarding" },
        ]}
      />

      <HeroImage {...boardingIndexHero} />

      {/* Boarding options grid */}
      <section className="py-20 bg-surface">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow="Boarding Options"
            title="Choose the Right Stay<br/>for Your Pet"
            subtitle="We offer tailored boarding for dogs, cats, and exotic animals - each in a dedicated, species-appropriate environment."
          />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {boardingIndexCards.map((card, i) => (
              <ServiceCard key={i} {...card} />
            ))}
          </div>
        </div>
      </section>

      {/* "What's Included" - dark feature section */}
      <section className="py-20 bg-primary-dark">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            {/* Text content */}
            <div className="space-y-6">
              <div className="flex flex-col gap-2">
                <p className="text-label text-secondary">
                  What&apos;s Included
                </p>
                <h2 className="text-h2 text-white leading-tight mb-4">
                  Everything Covered, <br />
                  <span className="text-secondary italic">Every Day</span>
                </h2>
                <p className="text-white/70 text-base max-w-xl">
                  Every boarding stay includes premium amenities and attentive care as standard - no hidden extras.
                </p>
              </div>

              {/* Feature grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {boardingIncludedFeatures.map((feature, i) => (
                  <div key={i} className="flex gap-4">
                    <div className="size-10 shrink-0 rounded-lg bg-white/10 flex items-center justify-center text-secondary">
                      <MaterialSymbol name={feature.icon} />
                    </div>
                    <div>
                      <h3 className="text-h4 text-white mb-1">
                        {feature.title}
                      </h3>
                      <p className="text-sm text-white/60">{feature.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Image with floating card */}
            <div className="relative h-[500px] w-full rounded-2xl overflow-hidden shadow-sm bg-surface-purple">
              {boardingSafeSpaceCard.imageSrc ? (
                <img
                  loading="lazy"
                  alt={boardingSafeSpaceCard.imageAlt}
                  className="absolute inset-0 w-full h-full object-cover"
                  src={boardingSafeSpaceCard.imageSrc}
                  decoding="async"
                />
              ) : null}
              <div className="absolute inset-0 bg-gradient-to-t from-primary-dark/80 via-primary-dark/20 to-transparent" />
              <div className="absolute bottom-6 left-6 right-6 bg-primary-dark/60 backdrop-blur p-6 rounded-2xl border border-white/10 shadow-soft">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-bold text-white">
                      {boardingSafeSpaceCard.title}
                    </p>
                    <div className="flex text-gold text-sm mt-1">
                      {Array.from({ length: 5 }).map((_, i) => (
                        <MaterialSymbol key={i} name="star" className="text-base" />
                      ))}
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-2xl font-bold text-secondary">
                      {boardingSafeSpaceCard.happyGuests}
                    </p>
                    <p className="text-xs text-white/60 uppercase font-semibold">
                      Happy Guests
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow="What Clients Say"
            title="Trusted by Abuja's Pet Owners"
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {boardingTestimonials.map((t, i) => (
              <TestimonialCard
                key={i}
                stars={t.stars}
                quote={t.quote}
                authorInitial={t.authorInitial}
                authorName={t.authorName}
                authorSubtitle={t.authorSubtitle}
              />
            ))}
          </div>
        </div>
      </section>

      {/* Inline FAQ section (hardcoded in the Blade source - preserved verbatim) */}
      <section className="py-20 bg-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="text-center mb-14">
            <span className="text-label text-primary block mb-3">
              Need Clarity?
            </span>
            <h2 className="text-h2 text-primary-dark leading-tight mb-4">
              Before You Book, Here&rsquo;s What You Should Know
            </h2>
            <p className="text-primary-dark/60 max-w-2xl mx-auto">
              Quick answers to help you choose the right service for your pet with confidence.
            </p>
          </div>

          <div className="max-w-3xl mx-auto space-y-3">
            {servicesIndexInlineFaqs.map((faq, i) => (
              <details
                key={i}
                className="group bg-white border border-primary/10 rounded-2xl hover:border-primary/30 hover:shadow-sm transition"
              >
                <summary className="flex w-full cursor-pointer items-center justify-between gap-4 px-6 py-5 font-semibold text-primary-dark hover:text-primary transition-colors list-none [&::-webkit-details-marker]:hidden">
                  {faq.question}
                  <MaterialSymbol
                    name="expand_more"
                    className="text-primary shrink-0 transition-transform duration-200 group-open:rotate-180"
                  />
                </summary>
                <p className="px-6 pb-5 pt-3 text-sm text-primary-dark/60 leading-relaxed">
                  {faq.answer}
                </p>
              </details>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="w-full py-20">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <CtaPrimary
            heading="Secure Your Pet’s Stay"
            headingAccent="While You're Away"
            body="Reserve your pet’s suite today and enjoy complete peace of mind with daily updates, expert care, and 24/7 supervision."
            primaryLabel="Request Boarding"
            primaryHref={boardingWhatsappUrl}
            primaryIcon="arrow_forward"
            secondaryLabel="Get Estimate"
            secondaryHref="/services/pricing?service=boarding"
            secondaryIcon="calculate"
          />
        </div>
      </section>

      <JsonLd
        data={serviceSchema(
          "Pet Boarding Abuja - Waggies",
          "Pet boarding in Abuja with 24/7 supervision, private suites, on-site vet, and daily photo updates.",
          "/services/boarding",
        )}
      />
    </>
  );
}
