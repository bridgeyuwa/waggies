# Waggies — Production Deployment Guide

**Status:** Platform-agnostic. The application can be deployed to any
Node-compatible host (Vercel, VPS, Docker, dedicated server, etc.)
without source code changes. Only the deployment environment differs.

---

## Architecture

```text
Development:
  http://localhost:3000  (built-in fallback when NEXT_PUBLIC_SITE_URL is unset)

Production:
  NEXT_PUBLIC_SITE_URL supplied by the deployment environment
  (Vercel project env, VPS .env.production, Docker -e flag, K8s secret, etc.)
```

The application source contains **no hardcoded production domain**. The
canonical base URL is read from `NEXT_PUBLIC_SITE_URL` at build time by
`src/lib/site.tsx`, and flows through to:

- `<link rel="canonical">` (via `metadataBase` in `src/app/layout.tsx`)
- `<meta property="og:url">` (via `openGraph.url`)
- JSON-LD `url` fields (Organization, LocalBusiness, WebSite)
- All absolute internal URLs

To change the production domain in the future, update the env var and
rebuild — no source code changes required.

`.env.example` is the authoritative documentation for all environment
variables. See that file for the full variable list and semantics.

---

## Prerequisites (all paths)

Regardless of deployment target, you need:

1. **The repository** — cloned to the deployment environment.
2. **Node.js 20+ or bun 1.3+** — to run `bun install` and `bun run build`.
3. **`NEXT_PUBLIC_SITE_URL`** — set to your production URL **before**
   running `bun run build` (it is inlined into the build at build time).
4. **Resend credentials** (optional) — required only if you want contact
   form emails and newsletter persistence to actually work. The
   application runs without them (submissions are logged to stdout).

The four optional Resend variables:
- `RESEND_API_KEY`
- `ADMIN_EMAIL`
- `RESEND_FROM_ADDRESS`
- `RESEND_AUDIENCE_ID`

Never commit secrets to git. `.gitignore` already protects `.env*`
(with `.env.example` as the tracked exception).

---

## Local build (common to all deployment paths)

```bash
# 1. Install dependencies
bun install --production

# 2. Set NEXT_PUBLIC_SITE_URL in the build environment.
#    Replace with your actual production URL.
export NEXT_PUBLIC_SITE_URL="https://your-production-domain.example"

# 3. (Optional) Set Resend credentials if you want email/newsletter
#    functionality in this build.
# export RESEND_API_KEY="..."
# export ADMIN_EMAIL="..."
# export RESEND_FROM_ADDRESS="..."
# export RESEND_AUDIENCE_ID="..."

# 4. Build. Next.js inlines NEXT_PUBLIC_* vars into the static HTML.
bun run build
# Output: .next/standalone/server.js + .next/static/ + public/

# 5. (Optional) Verify the build locally before deploying.
NODE_ENV=production bun .next/standalone/server.js
# Visit http://localhost:3000/ and verify canonical URLs use your
# production domain (not localhost).
```

**Critical:** `NEXT_PUBLIC_SITE_URL` MUST be set before `bun run build`.
Building without it produces a build with `http://localhost:3000` canonical
URLs — a visible misconfiguration, not a silent substitution.

---

## Deployment path A — Vercel

Vercel is the simplest path if you already use it.

### Steps

1. **Push the repository to GitHub/GitLab/Bitbucket** and import it into
   Vercel, OR use the Vercel CLI: `npx vercel link` (links to an existing
   project) / `npx vercel` (creates a new project — only if authorized).

2. **Configure environment variables** in the Vercel project dashboard
   (Settings → Environment Variables → Production):
   - `NEXT_PUBLIC_SITE_URL` = `https://your-project.vercel.app` (or your
     custom domain attached to the Vercel project)
   - `RESEND_API_KEY` (optional, for contact/newsletter)
   - `ADMIN_EMAIL` (optional, for contact)
   - `RESEND_FROM_ADDRESS` (optional, for contact)
   - `RESEND_AUDIENCE_ID` (optional, for newsletter)

   Mark `RESEND_*` variables as "Production" only (not Preview/Development)
   unless you want them in those environments too. `NEXT_PUBLIC_SITE_URL`
   should match whichever environment you are building for.

3. **Deploy:** `npx vercel --prod` (CLI), or push to your production
   branch (Git integration). Vercel runs `bun run build` (or `npm run
   build`) automatically with the env vars set.

4. **Verify:** after the deployment is ready, run the smoke test against
   your Vercel URL (see "Post-deployment smoke test" below).

### Notes

- Vercel sets its own HSTS `max-age=63072000` at the platform layer. The
  application's `max-age=31536000` (from `next.config.ts`) is also
  emitted and the more restrictive value applies in practice.
- Vercel's `output: "standalone"` build is supported natively.
- No `.vercel/` directory needs to be committed; `.gitignore` already
  excludes it.

---

## Deployment path B — VPS with Caddy + systemd

Use this path for a self-hosted VPS or dedicated server.

### Files in this repository (deployment adapters)

- `Caddyfile` — dev config (listens on `:81`, forwards to `localhost:3000`)
- `Caddyfile.prod` — production template (replace the domain placeholder
  with your production domain, then deploy to `/etc/caddy/Caddyfile`)

These are templates. Edit the production Caddyfile to use your domain
before deploying — do not assume the placeholder domain is correct.

### Steps (Ubuntu/Debian example)

1. **Provision the server:**
   ```bash
   # Install bun
   curl -fsSL https://bun.sh/install | bash
   source ~/.bashrc

   # Install Caddy (per https://caddyserver.com/docs/install)
   sudo apt install -y debian-keyring debian-archive-keyring apt-transport-https
   curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
     | sudo gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg
   curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' \
     | sudo tee /etc/apt/sources.list.d/caddy-stable.list
   sudo apt update && sudo apt install -y caddy
   ```

2. **Clone and build:**
   ```bash
   git clone <repo-url> /opt/waggies
   cd /opt/waggies
   bun install --production

   # Create the production environment file (DO NOT COMMIT)
   sudo tee /opt/waggies/.env.production > /dev/null <<'EOF'
   NEXT_PUBLIC_SITE_URL=https://your-production-domain.example
   RESEND_API_KEY=re_xxxxxxxxxxxxxxxxxxxx
   ADMIN_EMAIL=hello@your-production-domain.example
   RESEND_FROM_ADDRESS=Waggies Contact <noreply@your-production-domain.example>
   RESEND_AUDIENCE_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
   EOF
   sudo chown waggies:waggies /opt/waggies/.env.production
   sudo chmod 600 /opt/waggies/.env.production

   # Build WITH the env var set (NEXT_PUBLIC_* is inlined at build time)
   set -a; source /opt/waggies/.env.production; set +a
   bun run build
   ```

3. **Configure systemd** to keep the Next.js server running:
   ```bash
   sudo tee /etc/systemd/system/waggies.service > /dev/null <<'EOF'
   [Unit]
   Description=Waggies Next.js standalone server
   After=network.target

   [Service]
   Type=simple
   User=waggies
   WorkingDirectory=/opt/waggies
   EnvironmentFile=/opt/waggies/.env.production
   ExecStart=/usr/local/bin/bun /opt/waggies/.next/standalone/server.js
   Restart=on-failure
   RestartSec=5
   NoNewPrivileges=yes
   ProtectSystem=strict
   ProtectHome=yes
   ReadWritePaths=/opt/waggies
   PrivateTmp=yes

   [Install]
   WantedBy=multi-user.target
   EOF

   sudo systemctl daemon-reload
   sudo systemctl enable --now waggies
   sudo systemctl status waggies --no-pager
   ```

4. **Configure Caddy** (edit `Caddyfile.prod` to use your domain first):
   ```bash
   # Edit Caddyfile.prod: replace the domain placeholder with your domain
   sudo cp /opt/waggies/Caddyfile.prod /etc/caddy/Caddyfile
   sudo systemctl reload caddy
   # Caddy auto-provisions TLS via Let's Encrypt on ports 80/443.
   ```

5. **Configure DNS** at your DNS provider:
   - A record: `your-production-domain.example` → server IPv4
   - AAAA record (if applicable): `your-production-domain.example` → server IPv6

6. **Wait for TLS** and verify:
   ```bash
   sudo journalctl -u caddy -f
   # Expect: "certificate obtained successfully" within ~30 seconds
   curl -sI https://your-production-domain.example/ | head -5
   ```

---

## Deployment path C — Docker

The application's `output: "standalone"` build is Docker-friendly.

### Example Dockerfile (not committed — create your own)

```dockerfile
FROM oven/bun:1 AS build
WORKDIR /app
COPY package.json bun.lock* ./
RUN bun install --frozen-lockfile
COPY . .
ARG NEXT_PUBLIC_SITE_URL
ENV NEXT_PUBLIC_SITE_URL=$NEXT_PUBLIC_SITE_URL
RUN bun run build

FROM oven/bun:1 AS runtime
WORKDIR /app
COPY --from=build /app/.next/standalone ./
COPY --from=build /app/.next/static ./.next/static
COPY --from=build /app/public ./public
ENV NODE_ENV=production
ENV PORT=3000
EXPOSE 3000
CMD ["bun", "server.js"]
```

### Build and run

```bash
# Build with NEXT_PUBLIC_SITE_URL as a build arg (inlined at build time)
docker build \
  --build-arg NEXT_PUBLIC_SITE_URL=https://your-production-domain.example \
  -t waggies:latest .

# Run with runtime secrets (Resend credentials) as env vars
docker run -d \
  --name waggies \
  -p 3000:3000 \
  -e RESEND_API_KEY=re_xxx \
  -e ADMIN_EMAIL=hello@your-production-domain.example \
  -e RESEND_FROM_ADDRESS=noreply@your-production-domain.example \
  -e RESEND_AUDIENCE_ID=xxx \
  waggies:latest
```

Place a reverse proxy (Caddy, nginx, Traefik, Cloudflare Tunnel, etc.) in
front for TLS termination. Reuse the security headers from
`next.config.ts` at the proxy layer for defense in depth.

---

## Deployment path D — other Node-compatible hosts

The standalone server at `.next/standalone/server.js` runs anywhere Node
20+ or bun 1.3+ is available. Generic steps:

1. Build with `NEXT_PUBLIC_SITE_URL` set (see "Local build" above).
2. Copy `.next/standalone/`, `.next/static/`, and `public/` to the host.
3. Set runtime env vars (`RESEND_*`) through the host's env mechanism.
4. Run `node .next/standalone/server.js` (or `bun .next/standalone/server.js`).
5. Put a TLS-terminating reverse proxy in front (Caddy, nginx, Cloudflare,
   the host's built-in load balancer, etc.).

---

## Post-deployment smoke test (all paths)

After deployment, run the smoke test against your production URL. The
included `scripts/phase6-deploy-smoke-test.sh` is hardcoded to one
specific domain — edit it to point at your deployment, or run the
checks manually:

```bash
# Set BASE to your production URL
BASE="https://your-production-domain.example"

# 38 canonical routes (expect 200)
for path in "/" "/about" "/about/careers" "/about/gallery" "/about/partnerships" \
            "/about/testimonials" "/blog" "/contact" "/cookies-policy" "/faq" \
            "/guides" "/knowledge-base" "/loyalty" "/privacy-policy" \
            "/relocation" "/relocation/checklist" "/relocation/export" "/relocation/import" \
            "/services" "/services/boarding" "/services/boarding/cats" \
            "/services/boarding/dogs" "/services/boarding/exotic" "/services/grooming" \
            "/services/pricing" "/services/training" "/services/transport" \
            "/services/vet-care" "/shop" "/terms-of-service"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "${BASE}${path}")
  [ "$code" = "200" ] && echo "OK   $path" || echo "FAIL $code $path"
done

# Negative routes (expect 404)
for path in "/blog/nonexistent-slug-xyz" "/guides/nonexistent-slug-xyz" \
            "/knowledge-base/nonexistent-slug-xyz" "/blog/category/nonexistent-xyz" \
            "/guides/category/nonexistent-xyz" "/knowledge-base/category/nonexistent-xyz" \
            "/nonexistent-page"; do
  code=$(curl -s -o /dev/null -w "%{http_code}" "${BASE}${path}")
  [ "$code" = "404" ] && echo "OK   $path" || echo "FAIL $code $path"
done

# Canonical URL must use your production domain
curl -s "${BASE}/" | grep -oE '<link rel="canonical" href="[^"]*"'
# Expect: <link rel="canonical" href="https://your-production-domain.example"/>

# OG URL
curl -s "${BASE}/" | grep -oE '<meta property="og:url" content="[^"]*"'

# JSON-LD (expect at least 3 scripts: Organization, LocalBusiness, WebSite)
curl -s "${BASE}/" | grep -oE 'application/ld\+json' | wc -l

# Security headers (expect 6)
curl -sI "${BASE}/" | grep -iE "strict-transport|x-frame|x-content-type|referrer-policy|permissions-policy|content-security"

# X-Powered-By must be absent
curl -sI "${BASE}/" | grep -i "x-powered-by"
# Expect: no output

# Contact API (valid)
curl -s -w "\n%{http_code}\n" -X POST "${BASE}/api/contact" \
  -H "Content-Type: application/json" \
  -d '{"name":"Smoke","email":"smoke@example.com","message":"test"}'
# Expect: 200 + body containing "success":true

# Newsletter API (valid)
curl -s -w "\n%{http_code}\n" -X POST "${BASE}/api/newsletter" \
  -H "Content-Type: application/json" \
  -d '{"email":"smoke@example.com"}'
# Expect: 200 + body containing "success":true

# Pricing prefill
curl -s "${BASE}/contact?intent=book&service=boarding&variant=dogs&tier=deluxe&quantity=2&summary=Test" \
  | grep -oE 'name="(service|variant|tier|intent|estimate_summary)" value="[^"]*"'
# Expect 5 hidden inputs

# Robots
curl -s "${BASE}/robots.txt"
# Expect: User-agent: * / Disallow: / Sitemap: /sitemap.xml

# Logo
curl -sI "${BASE}/logo.svg" | head -1
# Expect: HTTP/2 200 (or HTTP/1.1 200)
```

---

## Rollback procedure

If deployment fails or causes issues:

```bash
# Vercel: roll back to the previous deployment in the Vercel dashboard
# (Deployments → ... → Promote to Production on the previous deployment)

# VPS: stop the new server and start the previous build
sudo systemctl stop waggies
cd /opt/waggies
git checkout <previous-commit>
bun install --production
set -a; source /opt/waggies/.env.production; set +a
bun run build
sudo systemctl start waggies

# Docker: run the previous image tag
docker stop waggies && docker rm waggies
docker run -d --name waggies -p 3000:3000 ... waggies:<previous-tag>
```

---

## Important notes

- **No hardcoded production domain in source code.** The domain comes from
  `NEXT_PUBLIC_SITE_URL`. See `src/lib/site.tsx` and `.env.example`.
- **Localhost-first.** The application runs locally with zero environment
  variables set. No production secrets are required for development.
- **Resend is optional.** The contact and newsletter APIs degrade to
  console logging when Resend credentials are absent. Do NOT remove this
  fallback or require the credentials to boot.
- **No database.** The marketing site is intentionally database-free.
  Contact persistence = admin email. Subscriber persistence = Resend
  Audiences. Do NOT add Prisma or any other DB to this repository.
- **Provider-specific files** (`Caddyfile`, `Caddyfile.prod`, any future
  `Dockerfile`, etc.) are deployment adapters/templates. Edit them to
  match your deployment target. Application runtime code does not depend
  on any specific provider.
