#!/bin/bash
# Starts the Waggies production server in background, validates it's responding,
# then keeps it alive in the foreground so the bash tool's process tree stays up.
set -e
cd /home/z/my-project

# Kill any stale server
pkill -f "standalone/server.js" 2>/dev/null || true
sleep 1

# Start the server in background so we can validate it
nohup bun .next/standalone/server.js > /home/z/my-project/server.log 2>&1 &
SERVER_PID=$!
echo "Started server with PID $SERVER_PID"

# Wait for it to be ready
for i in $(seq 1 30); do
  if curl -sS -o /dev/null http://localhost:3000/ 2>/dev/null; then
    echo "Server is ready (after ${i} attempts)"
    break
  fi
  sleep 0.5
done

# Probe representative routes
echo ""
echo "=== Route smoke test ==="
for path in / /about /services /blog /contact /faq /pricing; do
  code=$(curl -sS -o /dev/null -w "%{http_code}" "http://localhost:3000${path}")
  echo "  ${path} -> HTTP ${code}"
done

echo ""
echo "=== Canonical URL on homepage ==="
curl -sS http://localhost:3000/ | grep -oE '<link rel="canonical"[^>]*>' | head -1

echo ""
echo "=== Sample blog article links ==="
curl -sS http://localhost:3000/blog | grep -oE 'href="/blog/[^"]+"' | head -3

echo ""
echo "=== Security headers ==="
curl -sS -I http://localhost:3000/ | grep -iE "strict-transport|x-content-type|x-frame|referrer-policy|permissions-policy|content-security"

echo ""
echo "=== Server is live at http://localhost:3000 ==="
echo "Server PID: $SERVER_PID"
echo "Server log: /home/z/my-project/server.log"

# Keep the foreground alive so the server stays running
echo ""
echo "Holding process tree open. Server will stay alive while this script runs."
echo "Press Ctrl+C to stop the server."
wait $SERVER_PID
