import type { NextConfig } from "next";

/**
 * Waggies — Next.js configuration.
 *
 * ── Distinguishing four concepts (see also src/lib/site.tsx & .env.example) ──
 *
 *   1. SERVER LISTEN ADDRESS — where the Next.js process listens.
 *      Default: 0.0.0.0:3000 (overridable via PORT / HOSTNAME env vars on the
 *      standalone server). This is NOT the public origin.
 *
 *   2. BROWSER ORIGIN — whatever origin the browser used to reach the server.
 *      In local dev: http://localhost:3000. Behind a preview proxy:
 *      https://preview-<container-id>.space-z.ai. In production: the
 *      deployment's public URL. The application does NOT control this; the
 *      deployment infrastructure does.
 *
 *   3. CANONICAL / OG / JSON-LD ORIGIN — the absolute URL emitted in
 *      <link rel="canonical">, Open Graph tags, and JSON-LD structured data.
 *      Controlled by NEXT_PUBLIC_SITE_URL (see src/lib/site.tsx).
 *
 *   4. DEPLOYMENT CONFIG — NEXT_PUBLIC_SITE_URL + the runtime env (PORT,
 *      HOSTNAME, FC_CONTAINER_ID for the preview platform, etc.).
 *
 * ── Development vs. production CSP ─────────────────────────────────────────
 *
 * Next.js 16.3.0 + React 19 + Turbopack dev tooling requires `eval()` for
 * stack-trace reconstruction (server-component error stacks rendered in the
 * browser). The Next.js docs state explicitly:
 *
 *   "In development, 'unsafe-eval' is required because React uses eval to
 *    provide enhanced debugging information, such as reconstructing
 *    server-side error stacks in the browser. `unsafe-eval` is not required
 *    for production. Neither React nor Next.js use `eval` in production by
 *    default."
 *   — node_modules/next/dist/docs/01-app/02-guides/content-security-policy.md
 *
 * Confirmed by direct inspection of the dev-mode JS bundles:
 *   - react-server-dom-turbopack chunk: 1 eval() call (the React error message
 *     itself, embedded verbatim)
 *   - turbopack/browser/runtime chunk: 2 eval() calls
 *   - All production chunks: 0 eval() calls
 *
 * The previous single-CSP configuration applied the same strict production
 * CSP to dev mode, blocking React's eval() calls and producing the browser
 * console error:
 *
 *   "eval() is not supported in this environment.
 *    If this page was served with a Content-Security-Policy header, make
 *    sure that 'unsafe-eval' is included. React requires eval() in
 *    development mode for various debugging features like reconstructing
 *    callstacks from a different environment. React will never use eval()
 *    in production mode."
 *
 * Fix: emit a DEVELOPMENT-ONLY CSP that adds `'unsafe-eval'` to `script-src`.
 * The production CSP is UNCHANGED — strict, no `unsafe-eval`.
 *
 *   Development:  script-src 'self' 'unsafe-inline' 'unsafe-eval'
 *   Production:   script-src 'self' 'unsafe-inline'
 *
 * This is the official Next.js 16 documented pattern.
 *
 * ── allowedDevOrigins (preview-platform-aware, no hardcoded IPs) ───────────
 *
 * When the dev server is reached through an external preview proxy (e.g.
 * https://preview-<container-id>.space-z.ai), Next.js dev mode blocks the
 * cross-origin request by default and emits:
 *
 *   ⚠ Blocked cross-origin request to Next.js dev resource ...
 *     from "preview-<container-id>.space-z.ai".
 *     To allow this host in development, add it to "allowedDevOrigins" ...
 *
 * We construct the allowed origin from the platform-provided `FC_CONTAINER_ID`
 * env var (Alibaba Cloud Function Compute). This is:
 *   - Environment-driven (no hardcoded container ID)
 *   - Hostname-based (no transient container IP like 10.x.x.x)
 *   - Local-dev-safe (when FC_CONTAINER_ID is unset, allowedDevOrigins is
 *     empty and Next.js uses its default behavior)
 *
 * If a different preview platform is used in the future, set FC_CONTAINER_ID
 * (or extend this logic) to that platform's container-ID env var.
 */

const isDev = process.env.NODE_ENV === "development";

/**
 * Base security headers applied to ALL responses in ALL modes.
 *
 * Headers chosen to NOT break any feature actually used by the application:
 *   - script-src 'unsafe-inline'  → Next.js inline hydration + JSON-LD scripts
 *   - style-src 'unsafe-inline'   → Tailwind v4 inlined critical CSS
 *   - font-src fonts.gstatic.com  → Material Symbols Outlined woff2 files
 *   - img-src https:              → Unsplash / lh3.googleusercontent.com /
 *                                    media.istockphoto.com hero images
 *   - connect-src 'self'          → same-origin /api/* calls only
 *   - frame-ancestors 'none'      → no iframing (clickjacking protection)
 *
 * Verified against the rendered output of all 38 routes + 2 API endpoints.
 */
const baseSecurityHeaders = [
  // HTTPS enforcement (1 year, incl. subdomains, ready for preload list)
  {
    key: "Strict-Transport-Security",
    value: "max-age=31536000; includeSubDomains; preload",
  },
  // MIME-type sniffing protection
  { key: "X-Content-Type-Options", value: "nosniff" },
  // Clickjacking protection (frame-ancestors in CSP also enforces this)
  { key: "X-Frame-Options", value: "DENY" },
  // Referrer policy — only send origin to cross-origin destinations
  { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
  // Disable unnecessary browser features
  {
    key: "Permissions-Policy",
    value:
      "camera=(), microphone=(), geolocation=(), payment=(), usb=(), magnetometer=(), gyroscope=(), accelerometer=()",
  },
];

/**
 * Content-Security-Policy value, mode-dependent.
 *
 * Production CSP (strict, no 'unsafe-eval'):
 *   default-src 'self'
 *   script-src 'self' 'unsafe-inline'              ← Next.js hydration + JSON-LD
 *   style-src  'self' 'unsafe-inline' https://fonts.googleapis.com
 *   font-src   'self' https://fonts.gstatic.com
 *   img-src    'self' data: https:                  ← Unsplash, etc.
 *   connect-src 'self'                              ← same-origin API only
 *   frame-src   https://maps.google.com https://www.google.com
 *   frame-ancestors 'none'                          ← no one can frame US
 *   form-action 'self'                              ← form posts to same origin
 *   base-uri 'self'                                 ← <base> can only point to self
 *   object-src 'none'                               ← no Flash/Java/plugins
 *
 * Development CSP (adds 'unsafe-eval' to script-src):
 *   Identical to production, EXCEPT script-src gains 'unsafe-eval'.
 *   This is required by React/Turbopack dev tooling for stack-trace
 *   reconstruction (see module-level docs above for the Next.js 16 quote).
 *   Production React/Next.js do NOT use eval().
 */
const cspValue = [
  "default-src 'self'",
  // Dev mode adds 'unsafe-eval' for React/Turbopack dev tooling. Prod stays strict.
  `script-src 'self' 'unsafe-inline'${isDev ? " 'unsafe-eval'" : ""}`,
  "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
  "font-src 'self' https://fonts.gstatic.com",
  "img-src 'self' data: https:",
  "connect-src 'self'",
  "frame-src https://maps.google.com https://www.google.com",
  "frame-ancestors 'none'",
  "form-action 'self'",
  "base-uri 'self'",
  "object-src 'none'",
].join("; ");

const securityHeaders = [
  ...baseSecurityHeaders,
  { key: "Content-Security-Policy", value: cspValue },
];

/**
 * Construct allowedDevOrigins from the platform-provided container ID.
 *
 * Pattern: preview-<container-id>.space-z.ai
 *
 * - When FC_CONTAINER_ID is set (Space-Z preview platform), the exact preview
 *   hostname for this session is allowed.
 * - When FC_CONTAINER_ID is unset (local dev, other platforms), the array is
 *   empty and Next.js uses its default behavior (only localhost is allowed).
 *
 * This deliberately does NOT hardcode:
 *   - Any specific container ID (changes between sessions)
 *   - Any specific IP address (e.g. 10.x.x.x — container IPs are transient)
 *   - Any wildcard domain (would over-permit)
 *
 * If you change preview platforms, either:
 *   (a) Set FC_CONTAINER_ID to the new platform's container/session ID env
 *       var, or
 *   (b) Extend this logic to read the new platform's hostname-pattern env var.
 */
const containerId = process.env.FC_CONTAINER_ID;
const allowedDevOrigins: string[] = containerId
  ? [`preview-${containerId}.space-z.ai`]
  : [];

const nextConfig: NextConfig = {
  output: "standalone",
  reactStrictMode: false,
  // Suppress X-Powered-By: Next.js header (information disclosure)
  poweredByHeader: false,
  // Cross-origin dev-server access — only set when running on the Space-Z
  // preview platform (FC_CONTAINER_ID env var present). Empty array in local
  // dev → Next.js uses default behavior (localhost only).
  allowedDevOrigins,
  async headers() {
    return [
      {
        // Apply security headers to ALL routes (HTML, API, static assets)
        source: "/:path*",
        headers: securityHeaders,
      },
    ];
  },
};

export default nextConfig;
