/**
 * ArticleCard — React port of the blog/guides listing card markup.
 *
 * The Laravel Blade renders these inline (no dedicated component). They appear
 * in blog/index, blog/category, guides/index, guides/category as a 2-col grid.
 *
 * Two footer styles:
 *   - blog:  shows `{publishedAtText} · {readingTime}` (muted gray)
 *   - guide: shows "Read guide" + arrow (primary color, bold)
 *
 * Source:
 *   - resources/views/pages/blog/index.blade.php lines 42–68 (blog variant)
 *   - resources/views/pages/guides/index.blade.php (guide variant — same shape
 *     but with `Read guide` link instead of date footer)
 */

import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type ArticleCardProps = {
  href: string;
  imageUrl?: string | null;
  category: string;
  title: string;
  excerpt?: string | null;
  /** For `type="blog"`: date string shown in footer (e.g. "April 27, 2026"). */
  publishedAtText?: string;
  /** For `type="blog"`: reading-time label (e.g. "1 min read"). */
  readingTime?: string;
  /** Card variant. "blog" shows date footer; "guide" shows "Read guide" link. */
  type?: "blog" | "guide";
};

export function ArticleCard({
  href,
  imageUrl,
  category,
  title,
  excerpt,
  publishedAtText,
  readingTime,
  type = "blog",
}: ArticleCardProps) {
  const categoryDisplay = category.replace(/-/g, " ");

  return (
    <a
      href={href}
      className="group bg-white rounded-2xl shadow-sm hover:shadow-soft transition-shadow overflow-hidden flex flex-col"
    >
      <div className="h-44 bg-surface-purple group-hover:bg-primary/10 transition-colors overflow-hidden">
        {imageUrl ? (
          <img
            src={imageUrl}
            alt={title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
        ) : null}
      </div>
      <div className="p-5 flex flex-col gap-2 flex-1">
        <span className="text-xs font-bold uppercase tracking-widest text-primary/60 capitalize">
          {categoryDisplay}
        </span>
        <h2 className="font-serif text-lg font-bold text-primary-dark leading-snug group-hover:text-primary transition-colors">
          {title}
        </h2>
        {excerpt ? (
          <p className="text-sm text-primary-dark/60 line-clamp-2">{excerpt}</p>
        ) : null}

        {type === "guide" ? (
          <span className="text-xs text-primary font-semibold mt-auto inline-flex items-center gap-1">
            Read guide
            <MaterialSymbol name="arrow_forward" className="text-sm" />
          </span>
        ) : (
          <span className="text-xs text-primary-dark/40 mt-auto">
            {publishedAtText}
            {readingTime ? ` · ${readingTime}` : null}
          </span>
        )}
      </div>
    </a>
  );
}
