/**
 * Blog card.
 *
 * Faithful React reproduction of resources/views/components/card/blog.blade.php.
 *
 * Used on the homepage blog section and (in later phases) the blog index.
 * First card in a list can be marked `featured` to render the "Featured"
 * badge and slightly larger typography.
 */

import { MaterialSymbol } from "./material-symbol";

export type BlogPost = {
  image: string;
  category: string;
  categoryStyle?: "primary" | "secondary";
  readTime: string;
  title: string;
  excerpt: string;
  authorInitial: string;
  authorName: string;
  authorDate: string;
  url: string;
};

export type CardBlogProps = {
  post: BlogPost;
  featured?: boolean;
  className?: string;
};

export function CardBlog({ post, featured = false, className = "" }: CardBlogProps) {
  const categoryStyle = post.categoryStyle ?? "primary";
  const badgeClass =
    categoryStyle === "secondary"
      ? "bg-secondary/60 text-primary-dark"
      : "bg-surface-purple text-primary";

  return (
    <div
      className={`group bg-white border border-surface-purple rounded-2xl overflow-hidden card-lift cursor-pointer flex flex-col ${className}`}
    >
      {/* Image */}
      <div className="img-zoom h-52 w-full relative">
        <div
          className="bg-img h-full w-full bg-cover bg-center"
          style={{ backgroundImage: `url('${post.image}')` }}
        />
        <div className="absolute inset-0 bg-primary-dark/10 group-hover:bg-primary-dark/0 transition-colors" />

        {featured ? (
          <span className="absolute top-4 left-4 bg-primary text-white text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider shadow-glow">
            Featured
          </span>
        ) : null}
      </div>

      {/* Body */}
      <div className="p-6 flex flex-col flex-1">
        {/* Meta */}
        <div className="flex items-center gap-2 mb-3">
          <span className={`${badgeClass} text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider`}>
            {post.category}
          </span>
          <span className="text-primary-dark/40 text-xs">{post.readTime}</span>
        </div>

        {/* Title */}
        <h3
          className={`font-serif font-bold text-primary-dark ${featured ? "text-xl" : "text-lg"} leading-snug mb-2 line-clamp-2`}
        >
          {post.title}
        </h3>

        {/* Excerpt */}
        <p
          className={`text-primary-dark/55 text-sm leading-relaxed ${featured ? "line-clamp-3" : "line-clamp-2"} flex-1`}
        >
          {post.excerpt}
        </p>

        {/* Footer */}
        <div className="flex items-center justify-between mt-5 pt-4 border-t border-surface-purple">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-full bg-surface-purple flex items-center justify-center text-primary font-bold font-serif text-xs">
              {post.authorInitial}
            </div>
            <span className="text-xs font-medium text-primary-dark/60">
              {post.authorName} · {post.authorDate}
            </span>
          </div>
          <a
            href={post.url}
            className="inline-flex items-center gap-1 text-primary text-xs font-semibold uppercase tracking-wide group-hover:text-primary-light transition-colors"
          >
            Read <MaterialSymbol name="arrow_forward" className="text-sm" />
          </a>
        </div>
      </div>
    </div>
  );
}
