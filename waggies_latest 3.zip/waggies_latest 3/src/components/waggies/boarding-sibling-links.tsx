/**
 * Cross-links to other boarding service pages.
 *
 * Faithful React reproduction of
 * resources/views/components/boarding/sibling-links.blade.php.
 *
 * Renders the two siblings other than `current`.
 */

import { SectionHeading } from "./section-heading";
import { MaterialSymbol } from "./material-symbol";
import { boardingSiblings, type BoardingSibling } from "@/data/boarding";

export function BoardingSiblingLinks({ current }: { current: "dogs" | "cats" | "exotic" }) {
  const others: BoardingSibling[] = boardingSiblings.filter((s) => s.key !== current);

  return (
    <section
      className="py-16 bg-white border-t border-surface-purple"
      aria-label="Other boarding options"
    >
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <SectionHeading
          eyebrow="More Boarding"
          title="Explore Our Other Boarding Options"
          subtitle="Every species gets a dedicated environment — find the right stay for your pet."
          spacing="mb-10"
        />
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {others.map((sibling) => (
            <a
              key={sibling.key}
              href={sibling.href}
              className="group flex gap-5 p-5 rounded-2xl border border-surface-purple bg-surface-purple/30 hover:bg-surface-purple hover:shadow-soft transition-all focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
            >
              { }
              <img
                src={sibling.image}
                alt=""
                className="w-24 h-24 rounded-xl object-cover shrink-0 group-hover:scale-[1.02] transition-transform"
                loading="lazy"
                decoding="async"
                aria-hidden="true"
              />
              <div className="min-w-0">
                <div className="flex items-center gap-2 mb-1">
                  <MaterialSymbol
                    name={sibling.icon}
                    filled
                    className="text-primary text-lg"
                  />
                  <h3 className="font-serif font-bold text-primary-dark group-hover:text-primary transition-colors">
                    {sibling.title}
                  </h3>
                </div>
                <p className="text-sm text-primary-dark/60 leading-relaxed">
                  {sibling.desc}
                </p>
                <span className="mt-3 inline-flex items-center gap-1 text-sm font-semibold text-primary group-hover:underline">
                  Learn more
                  <MaterialSymbol name="arrow_forward" className="text-sm" />
                </span>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
}
