/**
 * Newsletter subscribe widget — React port of
 * resources/views/components/newsletter.blade.php.
 *
 * Reproduces the Alpine.js component behaviour:
 *   - Email input with client-side regex validation
 *   - On submit, POSTs to /api/newsletter
 *   - On success, replaces form with "You're subscribed — welcome to the pack!" panel
 *   - On validation error (422), displays red error text under the input
 *   - On throttle error (429), displays red error text
 *
 */

"use client";

import { useState, type FormEvent } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type NewsletterFormProps = {
  title?: string;
  subtitle?: string;
  placeholder?: string;
  buttonLabel?: string;
};

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function NewsletterForm({
  title = "Join the Waggies Pack",
  subtitle = "Get pet care tips, exclusive offers and Waggies news delivered weekly.",
  placeholder = "your@email.com",
  buttonLabel = "Subscribe",
}: NewsletterFormProps) {
  const [email, setEmail] = useState("");
  const [clientError, setClientError] = useState("");
  const [serverError, setServerError] = useState("");
  const [subscribed, setSubscribed] = useState(false);
  const [submitting, setSubmitting] = useState(false);

  function validate(value: string): boolean {
    if (!value) {
      setClientError("Please enter your email address.");
      return false;
    }
    if (!EMAIL_RE.test(value)) {
      setClientError("Please enter a valid email address.");
      return false;
    }
    setClientError("");
    return true;
  }

  async function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setServerError("");
    if (!validate(email)) return;
    setSubmitting(true);

    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      if (res.ok) {
        setSubscribed(true);
        return;
      }

      if (res.status === 422) {
        const data = (await res.json().catch(() => ({}))) as {
          errors?: Record<string, string | string[]>;
        };
        const msg = data.errors?.email
          ? Array.isArray(data.errors.email)
            ? data.errors.email[0]
            : data.errors.email
          : "Please enter a valid email address.";
        setServerError(msg);
        return;
      }

      if (res.status === 429) {
        setServerError("Too many subscriptions. Please wait a minute and try again.");
        return;
      }

      setServerError("Something went wrong. Please try again.");
    } catch {
      setServerError("Network error. Please check your connection and try again.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="flex flex-col gap-3">
      {title ? (
        <p className="font-serif text-lg font-bold text-primary-dark">{title}</p>
      ) : null}
      {subtitle ? (
        <p className="text-sm text-primary-dark/50">{subtitle}</p>
      ) : null}

      {!subscribed ? (
        <form onSubmit={handleSubmit} noValidate>
          <div className="flex flex-col gap-3">
            <input
              type="email"
              name="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={`w-full h-12 px-5 rounded-2xl border border-primary/30 bg-white/50
                          font-medium text-primary-dark placeholder:text-primary-dark/50
                          focus:outline-none focus:ring-2 focus:ring-primary/60 focus:border-primary transition
                          ${clientError || serverError ? "border-red-400" : ""}`}
              placeholder={placeholder}
              aria-label="Email address"
              aria-invalid={Boolean(clientError || serverError) || undefined}
            />

            {clientError ? (
              <p className="text-red-500 text-xs font-medium" role="alert">
                {clientError}
              </p>
            ) : null}

            {serverError ? (
              <p className="text-red-500 text-xs font-medium" role="alert">
                {serverError}
              </p>
            ) : null}

            <button
              type="submit"
              disabled={submitting}
              className="w-full bg-primary hover:bg-primary-dark text-white py-3 rounded-full
                         font-semibold transition shadow-glow hover:-translate-y-0.5
                         focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2
                         disabled:opacity-60 disabled:hover:translate-y-0 disabled:cursor-not-allowed"
            >
              {submitting ? "Subscribing…" : buttonLabel}
            </button>
          </div>
        </form>
      ) : (
        <div
          className="flex items-center gap-2 text-green-600 text-sm font-semibold py-1"
        >
          <MaterialSymbol name="check_circle" filled className="text-base" />
          <span>You&apos;re subscribed — welcome to the pack!</span>
        </div>
      )}
    </div>
  );
}
