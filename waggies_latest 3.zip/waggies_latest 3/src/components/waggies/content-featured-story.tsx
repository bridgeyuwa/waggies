/**
 * ContentFeaturedStory — React port of resources/views/components/content/featured-story.blade.php
 *
 * Large dark card with hero image, category badge, title, excerpt, and
 * author/date/reading-time footer. Used by blog/guides index + category pages.
 *
 */

import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type FeaturedStoryProps = {
  href: string;
  heroImageUrl: string;
  category: string;
  title: string;
  excerpt?: string | null;
  author?: string | null;
  publishedAtText?: string;
  readingTime?: string;
  /** "blog" or "guide" — controls badge label + "Read article" vs "Read guide" */
  type?: "blog" | "guide";
};

export function ContentFeaturedStory({
  href,
  heroImageUrl,
  category,
  title,
  excerpt,
  author,
  publishedAtText,
  readingTime,
  type = "blog",
}: FeaturedStoryProps) {
  const badge = type === "guide" ? "Featured Guide" : "Featured";
  const badgeIcon = type === "guide" ? "menu_book" : "star";
  const readLabel = type === "guide" ? "Read guide" : "Read article";
  // category is rendered via `str_replace('-', ' ', $post->category)` then `capitalize`
  // — so we replace dashes with spaces and rely on `capitalize` CSS class.
  const categoryDisplay = category.replace(/-/g, " ");

  return (
    <a
      href={href}
      className="group block mb-10 rounded-2xl overflow-hidden bg-primary-dark relative card-lift focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
    >
      <div
        className="absolute top-0 right-0 w-72 h-72 bg-primary/50 rounded-full blur-3xl pointer-events-none translate-x-1/3 -translate-y-1/3"
        aria-hidden="true"
      />

      <div className="relative z-10 flex flex-col lg:flex-row">
        <div className="lg:w-2/5 aspect-[16/10] lg:aspect-auto lg:min-h-[240px] relative overflow-hidden shrink-0">
          <img
            src={heroImageUrl}
            alt=""
            className="absolute inset-0 w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="eager"
            aria-hidden="true"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-transparent to-primary-dark/90 lg:to-primary-dark" />
        </div>

        <div className="flex flex-col justify-between gap-4 p-8 lg:p-10 flex-1">
          <div>
            <span className="inline-flex items-center gap-1.5 bg-secondary/20 text-secondary text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-4">
              <MaterialSymbol name={badgeIcon} filled className="text-sm" />
              {badge}
            </span>

            <span className="text-xs font-bold uppercase tracking-widest text-white/50 capitalize block mb-2">
              {categoryDisplay}
            </span>

            <h2 className="font-serif font-bold text-white text-2xl md:text-3xl leading-snug group-hover:text-secondary transition-colors">
              {title}
            </h2>

            {excerpt ? (
              <p className="text-white/60 text-sm leading-relaxed max-w-lg mt-3 line-clamp-3">
                {excerpt}
              </p>
            ) : null}
          </div>

          <div className="flex flex-wrap items-center justify-between gap-4">
            <p className="text-white/40 text-xs">
              {author ? author : null}
              {author && publishedAtText ? " · " : null}
              {publishedAtText}
              {readingTime ? ` · ${readingTime}` : null}
            </p>
            <span className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark px-6 py-2.5 rounded-full font-bold text-sm transition shadow-glow group-hover:-translate-y-0.5">
              {readLabel}
              <MaterialSymbol name="arrow_forward" className="text-sm" />
            </span>
          </div>
        </div>
      </div>
    </a>
  );
}
