/**
 * Testimonial card (B5).
 *
 * Faithful React reproduction of resources/views/components/card/testimonial.blade.php.
 */

import { MaterialSymbol } from "./material-symbol";

export type TestimonialCardProps = {
  stars?: number;
  quote?: string;
  authorInitial?: string;
  authorName?: string;
  authorSubtitle?: string;
  /** When used as a slot in Blade — children become the quote text. */
  children?: React.ReactNode;
};

export function TestimonialCard({
  stars = 5,
  quote,
  authorInitial = "A",
  authorName = "",
  authorSubtitle = "",
  children,
}: TestimonialCardProps) {
  const quoteText = quote ?? children;
  return (
    <div className="bg-white p-6 rounded-2xl shadow-sm hover:shadow-soft transition-shadow flex flex-col gap-4">
      {/* Stars */}
      <div className="flex gap-0.5" aria-label={`${stars} out of 5 stars`}>
        {Array.from({ length: 5 }).map((_, i) => (
          <MaterialSymbol
            key={i}
            name={i < stars ? "star" : "star_outline"}
            filled
            className="text-gold text-base"
          />
        ))}
      </div>

      {/* Quote — Laravel Blade uses literal ASCII " characters around the quote,
          NOT smart quotes. Match that exactly. */}
      <p className="italic text-sm leading-relaxed text-primary-dark/70 flex-1">
        {"\""}{quoteText}{"\""}
      </p>

      {/* Author */}
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 rounded-full bg-surface-purple flex items-center justify-center text-primary font-bold text-sm shrink-0">
          {authorInitial.charAt(0).toUpperCase()}
        </div>
        <div>
          <p className="text-sm font-semibold text-primary-dark">{authorName}</p>
          <p className="text-xs text-primary-dark/50">{authorSubtitle}</p>
        </div>
      </div>
    </div>
  );
}
