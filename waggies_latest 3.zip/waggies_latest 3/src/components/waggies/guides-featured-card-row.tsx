/**
 * Pet Guides — Guide Row.
 *
 * Faithful React reproduction of
 * resources/views/components/guides/featured-card-row.blade.php.
 *
 * Horizontal row card with icon, title, meta line, optional badge, and a
 * trailing arrow. The whole row is an <a> (clickable).
 */

import { MaterialSymbol } from "./material-symbol";

export type GuidesFeaturedCardRowProps = {
  href?: string;
  icon?: string;
  title: string;
  meta?: string;
  badge?: string | null;
  badgeVariant?: "success" | "primary";
};

export function GuidesFeaturedCardRow({
  href = "#",
  icon = "article",
  title,
  meta = "",
  badge = null,
  badgeVariant = "primary",
}: GuidesFeaturedCardRowProps) {
  return (
    <a
      href={href}
      className="flex items-center gap-5 px-6 py-5 hover:bg-surface-purple/50 transition-colors group cursor-pointer"
    >
      <div className="w-11 h-11 rounded-xl bg-surface-purple flex items-center justify-center text-primary shrink-0 group-hover:bg-primary group-hover:text-white transition-colors">
        <MaterialSymbol name={icon} className="text-xl" />
      </div>

      <div className="flex-1 min-w-0">
        <p className="font-semibold text-primary-dark text-sm leading-snug mb-0.5 group-hover:text-primary transition-colors">
          {title}
        </p>
        {meta ? <p className="text-primary-dark/45 text-xs">{meta}</p> : null}
      </div>

      <div className="flex items-center gap-3 shrink-0">
        {badge ? (
          badgeVariant === "success" ? (
            <span className="hidden sm:inline-flex items-center gap-1 bg-success-light text-success text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
              <MaterialSymbol name="check_circle" filled className="text-xs" />
              {badge}
            </span>
          ) : (
            <span className="hidden sm:inline-flex items-center gap-1 bg-surface-purple text-primary text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider">
              {badge}
            </span>
          )
        ) : null}
        <MaterialSymbol
          name="arrow_forward"
          className="text-primary-dark/30 group-hover:text-primary transition-colors"
        />
      </div>
    </a>
  );
}
