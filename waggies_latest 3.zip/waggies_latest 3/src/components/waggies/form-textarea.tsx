/**
 * Form textarea — React port of resources/views/components/form/textarea.blade.php
 *
 *
 * DO NOT change class names, label format, or error rendering.
 */

import { forwardRef, type TextareaHTMLAttributes } from "react";
import { cn } from "@/lib/utils";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type FormTextareaProps = {
  label?: string;
  name: string;
  rows?: number;
  placeholder?: string;
  defaultValue?: string;
  error?: string | null;
  required?: boolean;
  className?: string;
} & Omit<TextareaHTMLAttributes<HTMLTextAreaElement>, "name" | "rows" | "placeholder" | "defaultValue">;

export const FormTextarea = forwardRef<HTMLTextAreaElement, FormTextareaProps>(function FormTextarea(
  {
    label,
    name,
    rows = 4,
    placeholder = "",
    defaultValue,
    error,
    required = false,
    className,
    ...rest
  },
  ref,
) {
  return (
    <div className={cn("flex flex-col gap-1.5", className)}>
      {label ? (
        <label
          htmlFor={name}
          className={cn(
            "text-sm font-semibold text-primary-dark",
            required && "after:content-['*'] after:text-error after:ml-0.5",
          )}
        >
          {label}
        </label>
      ) : null}

      <textarea
        ref={ref}
        id={name}
        name={name}
        rows={rows}
        placeholder={placeholder}
        defaultValue={defaultValue}
        required={required}
        aria-required={required || undefined}
        aria-invalid={error ? true : undefined}
        aria-describedby={error ? `${name}-error` : undefined}
        className={cn(
          "w-full px-5 py-4 rounded-2xl border bg-surface/50 resize-none outline-none font-medium text-primary-dark",
          "placeholder:text-primary-dark/50",
          "focus:outline-none focus:ring-2 focus:ring-primary/60 focus:border-primary transition",
          !error && "border-primary/30",
          error && "border-error bg-error-light",
        )}
        {...rest}
      />

      {error ? (
        <div
          id={`${name}-error`}
          className="flex items-center gap-2 text-error text-xs font-medium"
          role="alert"
        >
          <MaterialSymbol name="error" className="text-sm" aria-hidden />
          {error}
        </div>
      ) : null}
    </div>
  );
});
