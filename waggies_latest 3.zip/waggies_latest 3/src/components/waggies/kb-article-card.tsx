/**
 * KbArticleCard — React port of the KB listing card markup.
 *
 * The Laravel Blade renders these inline (no dedicated component). KB cards
 * are horizontal list-style (image-less) — title + category on left, chevron
 * on right. Used by kb/index, kb/category.
 *
 * Source:
 *   - resources/views/pages/kb/index.blade.php (featured + all articles list)
 *   - resources/views/pages/kb/category.blade.php
 *
 * Markup matches dist/knowledge-base/index.html lines ~1130–1200.
 */

import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type KbArticleCardProps = {
  href: string;
  category: string;
  title: string;
  /** Heading element. Defaults to h3 (for featured list); pass "h2" for the
   *  main "All Articles" list (matches Laravel's heading hierarchy). */
  as?: "h2" | "h3";
};

export function KbArticleCard({ href, category, title, as = "h3" }: KbArticleCardProps) {
  const categoryDisplay = category.replace(/-/g, " ");
  const Heading = as;

  return (
    <a
      href={href}
      className="group flex items-center justify-between gap-4 bg-white rounded-2xl px-6 py-5 shadow-sm hover:shadow-soft transition-shadow"
    >
      <div>
        <span className="text-xs font-bold uppercase tracking-widest text-primary/50 block mb-1 capitalize">
          {categoryDisplay}
        </span>
        <Heading className="font-semibold text-primary-dark group-hover:text-primary transition-colors">
          {title}
        </Heading>
      </div>
      <MaterialSymbol
        name="chevron_right"
        className="text-primary-dark/30 group-hover:text-primary transition-colors shrink-0"
      />
    </a>
  );
}
