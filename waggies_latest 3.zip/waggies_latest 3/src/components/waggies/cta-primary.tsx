/**
 * CTA Band — Dark (Split Layout) — primary variant.
 *
 * Faithful React reproduction of resources/views/components/cta/primary.blade.php.
 *
 * Renders a rounded primary-dark panel with decorative blobs, an SVG pattern
 * overlay, left copy block, and right CTA buttons.
 */

import { MaterialSymbol } from "./material-symbol";

export type CtaPrimaryProps = {
  eyebrowIcon?: string | null;
  eyebrowText?: string | null;
  heading?: string;
  headingAccent?: string | null;
  body?: string;
  primaryLabel?: string;
  primaryHref?: string;
  primaryIcon?: string;
  secondaryLabel?: string | null;
  secondaryHref?: string | null;
  secondaryIcon?: string | null;
};

export function CtaPrimary({
  eyebrowIcon = null,
  eyebrowText = null,
  heading = "Give Your Pet the",
  headingAccent = "Care They Deserve",
  body = "Book a consultation today. Our team is ready to create a personalised care plan for your furry family member.",
  primaryLabel = "Book a Consultation",
  primaryHref = "#",
  primaryIcon = "arrow_forward",
  secondaryLabel = null,
  secondaryHref = null,
  secondaryIcon = null,
}: CtaPrimaryProps) {
  return (
    <div className="w-full bg-primary-dark overflow-hidden relative rounded-2xl">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-16 relative">
        {/* Decorative blobs */}
        <div
          className="absolute top-[-20%] right-[-5%] w-72 h-72 bg-primary/40 rounded-full blur-3xl pointer-events-none"
          aria-hidden="true"
        />
        <div
          className="absolute bottom-[-20%] left-[-5%] w-56 h-56 bg-secondary/15 rounded-full blur-3xl pointer-events-none"
          aria-hidden="true"
        />

        {/* Pattern overlay */}
        <div
          className="absolute inset-0 opacity-10 mix-blend-overlay pointer-events-none"
          aria-hidden="true"
          style={{
            backgroundImage:
              "url('data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none'%3E%3Cg fill='%23ffffff'%3E%3Cpath d='M36 34v-4h-2v4h-4v2h4v4h2v-4h4v-2h-4z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E')",
          }}
        />

        <div className="relative z-10 flex flex-col md:flex-row md:items-center md:justify-between gap-10 max-w-5xl mx-auto">
          {/* LEFT: copy */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left gap-5 max-w-xl">
            {eyebrowIcon || eyebrowText ? (
              <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-white/20 bg-white/10 text-secondary text-xs font-bold uppercase tracking-widest backdrop-blur-sm">
                {eyebrowIcon ? (
                  <MaterialSymbol name={eyebrowIcon} filled className="text-sm" />
                ) : null}
                {eyebrowText}
              </div>
            ) : null}

            <h2 className="font-serif text-3xl md:text-4xl font-bold text-white leading-tight">
              {heading}
              {headingAccent ? (
                <>
                  <br />
                  <span className="text-secondary italic">{headingAccent}</span>
                </>
              ) : null}
            </h2>

            <p className="text-white/65 text-base leading-relaxed max-w-sm md:max-w-md">
              {body}
            </p>
          </div>

          {/* RIGHT: CTAs */}
          <div className="flex flex-wrap gap-3 justify-center md:justify-end md:items-center">
            <a
              href={primaryHref}
              className="inline-flex items-center justify-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark px-8 py-3.5 rounded-full font-bold transition-all shadow-glow hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-secondary/60 focus:ring-offset-2"
            >
              {primaryLabel}
              <MaterialSymbol name={primaryIcon} className="text-base" />
            </a>

            {secondaryLabel && secondaryHref ? (
              <a
                href={secondaryHref}
                className="inline-flex items-center justify-center gap-2 border border-white/30 text-white px-8 py-3.5 rounded-full font-semibold hover:bg-white/10 transition-all focus:outline-none focus:ring-2 focus:ring-white/40 focus:ring-offset-2"
              >
                {secondaryIcon ? (
                  <MaterialSymbol name={secondaryIcon} className="text-base" />
                ) : null}
                {secondaryLabel}
              </a>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
