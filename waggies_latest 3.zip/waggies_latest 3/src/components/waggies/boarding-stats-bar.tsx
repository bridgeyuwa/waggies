/**
 * Boarding stats bar — floating white card overlapping hero/next section.
 *
 * Faithful React reproduction of
 * resources/views/components/boarding/stats-bar.blade.php.
 */

export type BoardingStat = { value: string; label: string };

export function BoardingStatsBar({ stats }: { stats: BoardingStat[] }) {
  return (
    <div className="relative z-30 -mt-8 -mb-8 mx-4 sm:mx-10 max-w-[1200px] lg:mx-auto bg-white rounded-2xl shadow-soft border border-surface-purple">
      <div className="px-6 py-8 sm:px-10 grid grid-cols-2 md:grid-cols-4 gap-8 md:divide-x md:divide-primary/10">
        {stats.map((stat, i) => (
          <div key={i} className="flex flex-col items-center text-center">
            <span className="font-serif text-4xl font-bold text-primary mb-1">
              {stat.value}
            </span>
            <span className="text-xs uppercase tracking-widest text-primary-dark/50 font-semibold">
              {stat.label}
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
