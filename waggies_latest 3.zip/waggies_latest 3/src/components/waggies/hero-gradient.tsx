/**
 * Gradient hero — split layout with rating badge and decorative blobs.
 *
 * Faithful React reproduction of resources/views/components/hero/gradient.blade.php.
 *
 * The Blade component supports two layouts (`split` and `centered`); the
 * homepage, /about, and /loyalty all use the `split` layout (the only path
 * the Waggies site actually exercises). We implement only that path.
 */

import { BadgeStat } from "./badge-stat";
import type { HeroCta } from "./hero-image";

export type HeroGradientProps = {
  rating?: string;
  reviewCount?: string;
  imageSrc?: string | null;
  title: string;
  subtitle?: string;
  primaryCta?: HeroCta | null;
  secondaryCta?: HeroCta | null;
  /**
   * The Blade component (hero/gradient.blade.php) accepts but does NOT
   * render an `eyebrow` prop in the split layout — only the centered
   * layout has its own hardcoded "Established 2020" eyebrow. The homepage
   * passes `eyebrow="Experience the Waggies Difference"` to <x-hero.gradient>
   * anyway; we accept it here for prop parity but do not render it, exactly
   * mirroring the Blade source.
   */
  eyebrow?: string;
};

export function HeroGradient({
  rating = "4.9",
  reviewCount = "500+",
  imageSrc = null,
  title,
  subtitle,
  primaryCta,
  secondaryCta,
  // `eyebrow` accepted for Blade parity but not rendered in split layout.
  eyebrow: _eyebrow,
}: HeroGradientProps) {
  // Default: split layout (used by homepage, /about, /loyalty hero gradient sections).
  return (
    <section className="w-full relative bg-surface-purple overflow-hidden">
      {/* Decorative blobs */}
      <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-primary/15 blur-3xl -translate-y-1/2 translate-x-1/3 pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-80 h-80 rounded-full bg-secondary/20 blur-3xl translate-y-1/2 -translate-x-1/4 pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 relative z-10">
        <div className="flex flex-col lg:flex-row items-center gap-12 lg:gap-16 py-16 md:py-24">
          {/* LEFT CONTENT */}
          <div className="flex flex-col gap-6 max-w-md flex-1">
            <BadgeStat rating={rating} reviewCount={reviewCount} />

            <h1
              className="font-serif text-4xl md:text-5xl font-bold text-primary-dark leading-tight"
              dangerouslySetInnerHTML={{ __html: title }}
            />

            {subtitle ? (
              <p className="text-primary-dark/60 text-base leading-relaxed">
                {subtitle}
              </p>
            ) : null}

            {primaryCta || secondaryCta ? (
              <div className="flex flex-col items-start gap-3 ml-1">
                {primaryCta ? (
                  <a
                    href={primaryCta.href}
                    className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-8 py-4 rounded-full font-bold transition shadow-glow hover:-translate-y-1"
                  >
                    {primaryCta.label}
                  </a>
                ) : null}
                {secondaryCta ? (
                  <a
                    href={secondaryCta.href}
                    className="inline-flex items-center gap-2 border border-primary/30 text-primary-dark px-8 py-4 rounded-full font-semibold hover:bg-white/50 transition"
                  >
                    {secondaryCta.label}
                  </a>
                ) : null}
              </div>
            ) : null}
          </div>

          {/* RIGHT SLOT */}
          <div className="flex-1 w-full max-w-lg lg:max-w-none">
            <div className="relative">
              {imageSrc ? (
                 
                <img
                  src={imageSrc}
                  alt={title.replace(/<[^>]*>/g, "")}
                  className="w-full h-full object-cover rounded-2xl shadow-lg"
                  loading="lazy"
                />
              ) : null}
              <div className="absolute inset-0 bg-gradient-to-tr from-surface-purple/40 to-transparent rounded-2xl" />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
