/**
 * Pet Guides — Featured Card.
 *
 * Faithful React reproduction of
 * resources/views/components/guides/featured-card.blade.php.
 *
 * Large dark card with badge, title, description, download/read CTAs, and
 * a PDF-document visual on the right.
 */

import { MaterialSymbol } from "./material-symbol";

export type GuidesFeaturedCardProps = {
  title: string;
  description?: string;
  badge?: string;
  downloadUrl?: string;
  downloadLabel?: string;
  readUrl?: string;
  readLabel?: string;
  pages?: number | null;
};

export function GuidesFeaturedCard({
  title,
  description = "",
  badge = "Free Download",
  downloadUrl = "#",
  downloadLabel = "Download Free PDF",
  readUrl = "#",
  readLabel = "Read online",
  pages = null,
}: GuidesFeaturedCardProps) {
  return (
    <div className="group bg-primary-dark rounded-2xl overflow-hidden mb-6 relative flex flex-col sm:flex-row card-lift cursor-pointer">
      <div className="absolute top-0 right-0 w-56 h-56 bg-primary/50 rounded-full blur-3xl pointer-events-none translate-x-1/3 -translate-y-1/3" />

      <div className="relative z-10 p-8 flex flex-col justify-between flex-1 gap-4">
        <div>
          <span className="inline-flex items-center gap-1.5 bg-secondary/20 text-secondary text-[10px] font-bold px-3 py-1 rounded-full uppercase tracking-wider mb-4">
            <MaterialSymbol name="download" className="text-sm" />
            {badge}
          </span>
          <h3 className="font-serif font-bold text-white text-2xl leading-snug mb-2">
            {title}
          </h3>
          {description ? (
            <p className="text-white/60 text-sm leading-relaxed max-w-sm">
              {description}
            </p>
          ) : null}
        </div>

        <div className="flex flex-wrap gap-3">
          <a
            href={downloadUrl}
            className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark px-6 py-2.5 rounded-full font-bold text-sm transition shadow-glow hover:-translate-y-0.5 focus:outline-none focus:ring-2 focus:ring-secondary/60"
          >
            <MaterialSymbol name="download" className="text-sm" />
            {downloadLabel}
          </a>
          <a
            href={readUrl}
            className="inline-flex items-center gap-2 border border-white/25 text-white px-6 py-2.5 rounded-full font-semibold text-sm hover:bg-white/10 transition-colors focus:outline-none focus:ring-2 focus:ring-white/30"
          >
            {readLabel}
          </a>
        </div>
      </div>

      <div className="hidden sm:flex items-center justify-center p-8 relative z-10 shrink-0">
        <div className="w-32 h-32 rounded-2xl bg-white/10 border border-white/15 flex flex-col items-center justify-center gap-2">
          <MaterialSymbol name="description" className="text-secondary text-4xl" />
          <p className="text-white text-[10px] font-bold uppercase tracking-widest">
            PDF Guide
          </p>
          {pages ? (
            <p className="text-white/40 text-[10px]">{pages} pages</p>
          ) : null}
        </div>
      </div>
    </div>
  );
}
