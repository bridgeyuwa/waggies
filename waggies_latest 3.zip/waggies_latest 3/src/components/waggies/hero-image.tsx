/**
 * Hero — full-bleed background image with gradient overlay.
 *
 * Faithful React reproduction of resources/views/components/hero/image.blade.php.
 *
 * The Blade component accepts both camelCase and snake_case props (legacy
 * aliases); we accept the camelCase form (which is what every page in the
 * Laravel source actually uses) and the most common snake_case aliases.
 */

import { MaterialSymbol } from "./material-symbol";
import { CtaButtons } from "./cta-buttons";

export type HeroCta = {
  label: string;
  href: string;
  icon?: string;
  iconBefore?: string;
};

export type HeroImageProps = {
  imageSrc: string;
  imageAlt?: string | null;
  eyebrow?: string;
  eyebrowIcon?: string;
  title: string;
  subtitle?: string;
  primaryCta?: HeroCta | null;
  secondaryCta?: HeroCta | null;
  minHeight?: string;
  variant?: "bottom" | "center";
  overlay?: "light" | "dark";
  /** Optional children rendered instead of CTAs (matches Blade $slot). */
  children?: React.ReactNode;
};

export function HeroImage({
  imageSrc,
  imageAlt,
  eyebrow,
  eyebrowIcon = "star",
  title,
  subtitle,
  primaryCta,
  secondaryCta,
  minHeight = "560px",
  variant = "bottom",
  overlay = "dark",
  children,
}: HeroImageProps) {
  const gradient =
    overlay === "light"
      ? "linear-gradient(rgba(62,26,87,0.10) 0%, rgba(62,26,87,0.80) 100%)"
      : "linear-gradient(rgba(0,0,0,0.15) 0%, rgba(0,0,0,0.65) 100%)";

  const alt = imageAlt ?? title.replace(/<[^>]*>/g, "");

  return (
    <section
      className={`relative flex flex-col bg-cover bg-center ${variant === "center" ? "justify-center" : "justify-end"}`}
      style={{ minHeight, backgroundImage: `${gradient}, url('${imageSrc}')` }}
      aria-label={title.replace(/<[^>]*>/g, "")}
      role="img"
      aria-roledescription="hero"
    >
      <div className="max-w-7xl mx-auto w-full px-4 md:px-10 lg:px-12 py-12 md:py-16">
        <div className="relative z-10 max-w-xl animate-fade-in-up">
          {eyebrow ? (
            <span className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full mb-4 bg-white/15 border border-white/25 text-white text-xs font-bold uppercase tracking-widest backdrop-blur-sm">
              <MaterialSymbol
                name={eyebrowIcon}
                filled
                className="text-sm text-secondary"
              />
              {eyebrow}
            </span>
          ) : null}

          <h1
            className="font-serif text-4xl md:text-5xl font-bold text-white leading-tight mb-4"
            dangerouslySetInnerHTML={{ __html: title }}
          />

          {subtitle ? (
            <p className="text-white/75 text-base mb-6 leading-relaxed">
              {subtitle}
            </p>
          ) : null}

          {primaryCta || secondaryCta || children ? (
            children ? (
              <div className="flex flex-wrap gap-3">{children}</div>
            ) : (
              <CtaButtons
                primary={primaryCta ?? undefined}
                secondary={secondaryCta ?? undefined}
                variant="overlay"
              />
            )
          ) : null}
        </div>
      </div>
      {/* Hidden alt-text fallback for screen readers when image is decorative */}
      <span className="sr-only">{alt}</span>
    </section>
  );
}
