"use client";

/**
 * FAQ page client component — Alpine tabs reproduced in React.
 *
 * Faithful reproduction of the Alpine `x-data="{ active: '...' }"` tab
 * behaviour in resources/views/pages/faq.blade.php lines 11–67.
 *
 * The first category in insertion order is active by default. Clicking a
 * tab swaps the visible panel. Panel transition uses opacity (matching the
 * Alpine `x-transition.opacity` directive).
 */

import { useState } from "react";
import { FaqAccordion } from "./faq-accordion";
import { MaterialSymbol } from "./material-symbol";
import { getGroupedFaqs } from "@/data/faqs";

export function FaqPageClient() {
  const { grouped, categories } = getGroupedFaqs();
  const [active, setActive] = useState<string>(
    categories.length > 0 ? categories[0].slug : "",
  );

  if (categories.length === 0) {
    return (
      <p className="text-primary-dark/50">No FAQs published yet — check back soon.</p>
    );
  }

  return (
    <>
      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-10" role="tablist">
        {categories.map((cat) => {
          const isActive = active === cat.slug;
          return (
            <button
              key={cat.slug}
              type="button"
              role="tab"
              aria-selected={isActive}
              onClick={() => setActive(cat.slug)}
              className={`px-5 py-2 rounded-full text-sm font-semibold transition ${isActive ? "bg-primary text-white shadow-glow" : "bg-surface-purple text-primary-dark hover:bg-primary/10"}`}
            >
              {cat.label}
            </button>
          );
        })}
      </div>

      {/* FAQ panels */}
      {categories.map((cat) => {
        const faqs = grouped[cat.slug] ?? [];
        const isVisible = active === cat.slug;
        return (
          <div
            key={cat.slug}
            role="tabpanel"
            className="max-w-3xl mx-auto transition-opacity duration-200"
            style={{ display: isVisible ? "block" : "none" }}
          >
            <div className="space-y-3">
              {faqs.map((faq) => (
                <details
                  key={faq.id}
                  className="group bg-white border border-primary/10 rounded-2xl hover:border-primary/30 hover:shadow-sm transition"
                >
                  <summary className="flex w-full cursor-pointer items-center justify-between gap-4 px-6 py-5 font-semibold text-primary-dark hover:text-primary transition-colors list-none [&::-webkit-details-marker]:hidden">
                    {faq.question}
                    <MaterialSymbol
                      name="expand_more"
                      className="text-primary shrink-0 transition-transform duration-200 group-open:rotate-180"
                    />
                  </summary>
                  <div className="px-6 pb-5 pt-3 text-sm text-primary-dark/65 leading-relaxed">
                    {faq.answer}
                  </div>
                </details>
              ))}
            </div>
          </div>
        );
      })}

      {/* CTA */}
      <div className="mt-14 text-center">
        <p className="text-sm text-primary-dark/60 mb-4">
          Still unsure? Talk to our care team before booking.
        </p>
        <a
          href="/contact"
          className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-7 py-3 rounded-full font-bold text-sm transition shadow-glow hover:-translate-y-1"
        >
          Contact Us
          <MaterialSymbol name="arrow_forward" className="text-base" />
        </a>
      </div>
    </>
  );
}

// Re-export FaqAccordion so the page can build FAQ schema from the same dataset.
export { FaqAccordion };
