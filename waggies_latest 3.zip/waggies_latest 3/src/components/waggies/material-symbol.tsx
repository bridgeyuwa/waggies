/**
 * Material Symbols Outlined icon — wraps a <span> with the correct class.
 *
 * Source: resources/views/components/navbar/mobile-link.blade.php and many
 * others use `<span class="material-symbols-outlined">{ligature}</span>`.
 *
 * `filled` prop toggles the `icon-filled` class (FILL axis = 1).
 */

export function MaterialSymbol({
  name,
  filled = false,
  className = "",
  ariaHidden = true,
}: {
  name: string;
  filled?: boolean;
  className?: string;
  ariaHidden?: boolean;
}) {
  return (
    <span
      className={`material-symbols-outlined${filled ? " icon-filled" : ""}${className ? ` ${className}` : ""}`}
      aria-hidden={ariaHidden}
    >
      {name}
    </span>
  );
}
