"use client";

import { usePathname } from "next/navigation";

/**
 * BomSpacer - reproduces the 24px top-of-body gap present in the Laravel dist
 * HTML on most routes.
 *
 * Root cause (Laravel dist artifact): The dist crawler that produced the
 * original Laravel dist HTML files emitted TWO UTF-8 BOMs (U+FEFF) at the
 * start of each file. The HTML parser strips the first BOM but treats the
 * second as content, placing it as a text node directly inside body before
 * the skip-link. Because body has line-height: 24px, this text node creates
 * an anonymous line box that pushes the sticky header (and everything after
 * it) down by 24px.
 *
 * Verified to affect (Phase 2 + Phase 3 routes): /services/*, /relocation/*,
 * /about/*, /contact, /blog/*, /guides/*, /knowledge-base/*, /shop,
 * /privacy-policy, /terms-of-service, /cookies-policy, /loyalty.
 *
 * Routes NOT affected (only ONE BOM in dist, no gap):
 *   - / (homepage)
 *   - /faq
 *
 * To reproduce the visual output faithfully, this client component injects
 * a BOM character as a raw text node at the top of body on affected routes.
 * The BOM is invisible (zero-width no-break space) but creates the same
 * 24px line box in the browser.
 */
export function BomSpacer() {
  const pathname = usePathname();
  // Homepage and /faq have only one BOM in dist → no gap → don't inject.
  if (pathname === "/" || pathname === "/faq") return null;
  // All other routes have the double-BOM gap → inject.
  return <>{String.fromCharCode(0xfeff) + "\n\n\n    "}</>;
}
