/**
 * Breadcrumb navigation.
 *
 * Faithful React reproduction of
 * resources/views/components/breadcrumb.blade.php +
 * resources/views/vendor/breadcrumbs/waggies.blade.php.
 *
 * The Laravel site uses diglactic/laravel-breadcrumbs with route-bound
 * definitions in routes/breadcrumbs.php. We replace that with explicit
 * `crumbs` props per page (Phase 2 pages call <BreadcrumbStrip crumbs={...}/>).
 *
 * Trail rendering matches the Blade template exactly:
 *   - Home icon link first
 *   - Each crumb separated by chevron_right
 *   - Last crumb is non-linked + aria-current="page"
 */

import { MaterialSymbol } from "./material-symbol";

export type Crumb = {
  label: string;
  href?: string | null;
};

export type BreadcrumbProps = {
  crumbs: Crumb[];
};

export function Breadcrumb({ crumbs }: BreadcrumbProps) {
  if (crumbs.length === 0) return null;

  return (
    <nav aria-label="Breadcrumb">
      <ol className="flex items-center flex-wrap gap-2 text-xs font-medium text-primary-dark/50">
        <li>
          <a
            href="/"
            className="hover:text-primary transition-colors flex items-center gap-1"
            aria-label="Home"
          >
            <MaterialSymbol name="home" className="text-sm" />
          </a>
        </li>

        {crumbs.map((crumb, i) => {
          const isLast = i === crumbs.length - 1;
          return (
            <li key={i} className="flex items-center gap-2">
              <MaterialSymbol
                name="chevron_right"
                className="text-xs text-primary-dark/30"
              />
              {crumb.href && !isLast ? (
                <a
                  href={crumb.href}
                  className="hover:text-primary transition-colors"
                >
                  {crumb.label}
                </a>
              ) : (
                <span
                  className="text-primary-dark font-semibold"
                  {...(isLast ? { "aria-current": "page" as const } : {})}
                >
                  {crumb.label}
                </span>
              )}
            </li>
          );
        })}
      </ol>
    </nav>
  );
}

/**
 * Breadcrumb strip — page-width wrapper around <Breadcrumb/>.
 *
 * Faithful reproduction of resources/views/components/breadcrumb/strip.blade.php.
 *
 * The Blade component hides itself on the homepage (`hiddenOnHome` default
 * true). We mirror that with `hiddenOnHome` (defaults to true; suppressed
 * automatically when pathname === "/" in the BreadcrumbStrip usage — caller
 * controls by simply not rendering it on the homepage).
 */
export type BreadcrumbStripProps = {
  crumbs: Crumb[];
  className?: string;
};

export function BreadcrumbStrip({
  crumbs,
  className = "",
}: BreadcrumbStripProps) {
  return (
    <div
      className={`max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-4 ${className}`}
    >
      <Breadcrumb crumbs={crumbs} />
    </div>
  );
}
