/**
 * Skip-to-main-content link for keyboard / screen-reader users.
 *
 * Visually hidden until focused. Reproduces the `<x-skip-link />` Blade
 * component exactly. The CSS rules that control the visual reveal live in
 * globals.css under the `.skip-link` selector — copied verbatim from the
 * Laravel source (resources/css/app.css lines 241–268).
 */
export function SkipLink() {
  return (
    <a href="#main-content" className="skip-link">
      Skip to main content
    </a>
  );
}
