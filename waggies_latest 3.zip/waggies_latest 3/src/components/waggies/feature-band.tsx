/**
 * Feature band — dark CTA section with feature list.
 *
 * Faithful React reproduction of resources/views/components/feature-band.blade.php.
 */

import { MaterialSymbol } from "./material-symbol";

export type FeatureBandFeature = {
  icon: string;
  title: string;
  description: string;
};

export type FeatureBandProps = {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  features?: FeatureBandFeature[];
  cta?: { label: string; href: string };
  /** Optional slot content (replaces features list when present). */
  children?: React.ReactNode;
};

export function FeatureBand({
  eyebrow,
  title,
  subtitle,
  features = [],
  cta,
  children,
}: FeatureBandProps) {
  return (
    <section className="w-full bg-primary-dark relative overflow-hidden text-white py-24">
      {/* Dot grid */}
      <div
        className="absolute inset-0 opacity-10 pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(#E8D5B5 1px, transparent 1px)",
          backgroundSize: "40px 40px",
        }}
      />

      {/* Ambient glow */}
      <div className="absolute top-0 right-0 w-[700px] h-[700px] bg-primary rounded-full blur-[120px] opacity-20 -translate-y-1/2 translate-x-1/3" />

      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* LEFT */}
          <div className="flex flex-col gap-6 max-w-xl">
            {eyebrow ? (
              <p className="text-secondary font-bold tracking-widest uppercase text-xs">
                {eyebrow}
              </p>
            ) : null}

            <h2
              className="font-serif text-3xl md:text-4xl font-bold leading-tight"
              dangerouslySetInnerHTML={{ __html: title }}
            />

            {subtitle ? (
              <p className="text-white/70 leading-relaxed text-base">{subtitle}</p>
            ) : null}

            {cta ? (
              <div className="pt-2">
                <a
                  href={cta.href}
                  className="inline-flex items-center gap-2 bg-secondary hover:bg-secondary-hover text-primary-dark font-bold px-8 py-3.5 rounded-full transition shadow-glow hover:-translate-y-1 focus:outline-none focus:ring-2 focus:ring-secondary/60 focus:ring-offset-2 focus:ring-offset-primary-dark"
                >
                  {cta.label}
                  <MaterialSymbol name="arrow_forward" className="text-base" />
                </a>
              </div>
            ) : null}
          </div>

          {/* RIGHT */}
          <div className="flex flex-col gap-5">
            {children ? (
              children
            ) : (
              features.map((feature, i) => (
                <div
                  key={i}
                  className="flex items-start gap-4 p-5 rounded-2xl bg-white/[0.03] backdrop-blur-sm hover:bg-white/[0.06] border border-white/10 transition-all duration-200"
                >
                  <div className="size-12 rounded-full bg-white/10 flex items-center justify-center text-secondary shrink-0">
                    <MaterialSymbol name={feature.icon} className="text-lg" />
                  </div>
                  <div>
                    <h3 className="font-serif font-bold text-white text-lg">
                      {feature.title}
                    </h3>
                    <p className="text-white/60 text-sm mt-1 leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
