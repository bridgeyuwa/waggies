/**
 * Contact info block — React port of resources/views/components/contact-info.blade.php
 *
 *
 * Renders address, phone, email, hours in icon + text rows.
 * Children are appended after the standard rows (matches Blade `$slot`).
 */

import { type ReactNode } from "react";
import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type ContactInfoProps = {
  address?: string;
  phone?: string;
  email?: string;
  hours?: string;
  children?: ReactNode;
};

export function ContactInfo({
  address = "123 Wuse II, Abuja, Nigeria",
  phone = "+234 800 000 0000",
  email = "hello@waggies.ng",
  hours = "Mon–Sun: 7am – 8pm",
  children,
}: ContactInfoProps) {
  const phoneHref = `tel:${phone.replace(/\s+/g, "")}`;
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-start gap-3">
        <MaterialSymbol
          name="location_on"
          className="text-primary text-xl shrink-0"
          aria-hidden
        />
        <span className="text-sm text-primary-dark/70">{address}</span>
      </div>
      <div className="flex items-start gap-3">
        <MaterialSymbol name="call" className="text-primary text-xl shrink-0" aria-hidden />
        <a
          href={phoneHref}
          className="text-sm text-primary-dark/70 hover:text-primary transition-colors"
        >
          {phone}
        </a>
      </div>
      <div className="flex items-start gap-3">
        <MaterialSymbol name="mail" className="text-primary text-xl shrink-0" aria-hidden />
        <a
          href={`mailto:${email}`}
          className="text-sm text-primary-dark/70 hover:text-primary transition-colors"
        >
          {email}
        </a>
      </div>
      <div className="flex items-start gap-3">
        <MaterialSymbol name="schedule" className="text-primary text-xl shrink-0" aria-hidden />
        <span className="text-sm text-primary-dark/70">{hours}</span>
      </div>
      {children}
    </div>
  );
}
