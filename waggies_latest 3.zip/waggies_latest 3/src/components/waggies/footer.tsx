import Link from "next/link";
import { MaterialSymbol } from "./material-symbol";
import {
  footerCopyright,
  footerLinkColumns,
  footerTagline,
  socialLinks,
} from "@/lib/site";

/**
 * Waggies Footer — faithful React reproduction of
 * resources/views/components/footer.blade.php.
 *
 * The Laravel component accepts a `variant` prop (`light` | `dark`). The
 * public layout (layouts/app.blade.php) renders it with `variant="dark"`.
 * We preserve that as the default here and export a `FooterLight` alias for
 * future use by pages that render the light variant.
 *
 * The light variant differs from the dark variant in one tiny detail: the
 * Facebook SVG path uses `-1.63` vs `-1.62` for the dark vs. light paths.
 * This is preserved verbatim per the Blade source (the original developer
 * left a comment about it on lines 47–56 of footer.blade.php). We render
 * the dark variant's path here; if a future phase needs the light variant,
 * the difference is one character in the Facebook <path>.
 */
export function Footer({ variant = "dark" }: { variant?: "light" | "dark" }) {
  const isDark = variant === "dark";

  const footerBg = isDark
    ? "bg-primary-dark border-t border-white/10"
    : "bg-surface-purple border-t border-primary/10";
  const brandName = isDark ? "text-white" : "text-primary-dark text-xl";
  const tagline = isDark ? "text-white/70" : "text-primary-dark/60";
  const socialBtn = isDark
    ? "bg-white/10 border border-white/10 text-white/70 hover:bg-primary hover:text-white hover:border-primary transition-colors"
    : "bg-white border border-primary/10 text-primary hover:bg-primary hover:text-white transition-colors shadow-sm";
  const heading = isDark ? "text-secondary" : "text-primary-dark";
  const linkText = isDark
    ? "text-white/60 hover:text-white"
    : "text-primary-dark/60 hover:text-primary";
  const bullet = isDark ? "bg-primary-light/80" : "bg-primary/40";
  const legalLink = isDark
    ? "text-white/60 hover:text-white"
    : "text-primary-dark/60 hover:text-primary";
  const bottomBorder = isDark ? "border-white/10" : "border-primary/10";
  const copyright = isDark ? "text-white/50" : "text-primary-dark/60";

  return (
    <footer className={footerBg}>
      <div className="mx-auto max-w-7xl px-6 pt-16 pb-8 sm:pt-24 lg:px-8 lg:pt-32">
        <div className="xl:grid xl:grid-cols-3 xl:gap-8">
          {/* Brand */}
          <div className="space-y-8">
            <Link href="/" className="flex items-center gap-2">
              <div className="w-9 h-9 rounded-xl bg-primary flex items-center justify-center shadow-glow">
                <MaterialSymbol name="pets" filled />
              </div>
              <span className={`font-serif font-bold ${brandName} text-xl`}>Waggies</span>
            </Link>

            <p className={`text-sm ${tagline} max-w-xs`}>{footerTagline}</p>

            <div className="flex gap-x-4">
              {socialLinks.map((social) => (
                <a
                  key={social.label}
                  href={social.href}
                  className={`w-10 h-10 rounded-full ${socialBtn} flex items-center justify-center`}
                >
                  <span className="sr-only">{social.label}</span>
                  <svg
                    className="size-5"
                    fill="currentColor"
                    viewBox={social.label === "TikTok" ? "0 0 32 32" : "0 0 24 24"}
                    aria-hidden="true"
                  >
                    {social.svg}
                  </svg>
                </a>
              ))}
            </div>
          </div>

          {/* Links */}
          <div className="mt-16 grid grid-cols-2 gap-8 xl:col-span-2 xl:mt-0">
            <div className="md:grid md:grid-cols-2 md:gap-8">
              {/* Services column */}
              <div>
                <h3 className={`font-bold ${heading} text-sm uppercase tracking-widest mb-5`}>
                  Services
                </h3>
                <ul className="mt-6 space-y-4">
                  {footerLinkColumns[0].links.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        className={`flex items-center gap-1.5 text-sm ${linkText} transition-colors`}
                      >
                        <span className={`w-1.5 h-1.5 ${bullet} rounded-full`} />
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Company column */}
              <div className="mt-10 md:mt-0">
                <h3 className={`font-bold ${heading} text-sm uppercase tracking-widest mb-5`}>
                  Company
                </h3>
                <ul className="mt-6 space-y-4">
                  {footerLinkColumns[1].links.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        className={`flex items-center gap-1.5 text-sm ${linkText} transition-colors`}
                      >
                        <span className={`w-1.5 h-1.5 ${bullet} rounded-full`} />
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            <div className="md:grid md:grid-cols-2 md:gap-8">
              {/* Support column */}
              <div>
                <h3 className={`font-bold ${heading} text-sm uppercase tracking-widest mb-5`}>
                  Support
                </h3>
                <ul className="mt-6 space-y-4">
                  {footerLinkColumns[2].links.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        className={`flex items-center gap-1.5 text-sm ${linkText} transition-colors`}
                      >
                        <span className={`w-1.5 h-1.5 ${bullet} rounded-full`} />
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Legal column */}
              <div className="mt-10 md:mt-0">
                <h3 className={`font-bold ${heading} text-sm uppercase tracking-widest mb-5`}>
                  Legal
                </h3>
                <ul className="mt-6 space-y-4">
                  {footerLinkColumns[3].links.map((link) => (
                    <li key={link.href}>
                      <Link
                        href={link.href}
                        className={`text-sm ${legalLink} transition-colors`}
                      >
                        {link.label}
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className={`border-t ${bottomBorder}`}>
        <div className="max-w-7xl mx-auto px-6 py-5 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className={`text-sm/6 ${copyright}`}>{footerCopyright}</p>
        </div>
      </div>
    </footer>
  );
}
