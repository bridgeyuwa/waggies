/**
 * LayoutContent — React port of resources/views/components/layouts/content.blade.php
 *
 * Used by blog/guides/kb show pages (single article). Renders hero + breadcrumb +
 * main article body (in `<article><div class="prose">`) + optional sidebar.
 *
 */

import { type ReactNode } from "react";
import { Breadcrumb, BreadcrumbStrip, type Crumb } from "@/components/waggies/breadcrumb";

export type LayoutContentProps = {
  hero?: ReactNode;
  crumbs?: Crumb[];
  children: ReactNode;
  sidebar?: ReactNode;
};

export function LayoutContent({ hero, crumbs, children, sidebar }: LayoutContentProps) {
  return (
    <>
      {hero ? (
        <>
          {/* Laravel's content.blade.php uses <x-breadcrumb.strip class="...">
              which produces ONE div with merged classes. Match that exactly. */}
          <BreadcrumbStrip
            className="bg-white border-b border-primary/5"
            crumbs={crumbs ?? []}
          />
          {hero}
        </>
      ) : (
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 pt-10 md:pt-16">
          <div className="mb-8">
            {crumbs && crumbs.length > 0 ? <Breadcrumb crumbs={crumbs} /> : null}
          </div>
        </div>
      )}

      <div
        className={`max-w-7xl mx-auto px-4 md:px-10 lg:px-12 ${hero ? "py-10 md:py-16" : "pb-10 md:pb-16"}`}
      >
        <div className="flex flex-col lg:flex-row gap-12 xl:gap-16">
          <article className="flex-1 min-w-0">
            <div className="prose max-w-none">{children}</div>
          </article>

          {sidebar ? (
            <aside className="w-full lg:w-80 xl:w-96 shrink-0 flex flex-col gap-6">
              {sidebar}
            </aside>
          ) : null}
        </div>
      </div>
    </>
  );
}
