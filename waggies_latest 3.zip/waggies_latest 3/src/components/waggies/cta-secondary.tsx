/**
 * CtaSecondary — React port of resources/views/components/cta/secondary.blade.php
 *
 * Purple-surface CTA band with split layout: copy left, CTAs right.
 * Used by the About index page.
 *
 */

import { MaterialSymbol } from "@/components/waggies/material-symbol";

export type CtaSecondaryProps = {
  eyebrowIcon?: string | null;
  eyebrowText?: string | null;
  heading?: string;
  headingAccent?: string;
  body?: string;
  primaryLabel?: string;
  primaryHref?: string;
  primaryIcon?: string;
  secondaryLabel?: string | null;
  secondaryHref?: string | null;
  secondaryIcon?: string | null;
};

export function CtaSecondary({
  eyebrowIcon,
  eyebrowText,
  heading = "Ready to Get Started?",
  headingAccent = "",
  body = "Join thousands of pet owners in Abuja who trust Waggies for world-class care. Your first visit is on us.",
  primaryLabel = "Book Now",
  primaryHref = "#",
  primaryIcon = "arrow_forward",
  secondaryLabel,
  secondaryHref,
  secondaryIcon,
}: CtaSecondaryProps) {
  return (
    <div className="w-full bg-surface-purple relative overflow-hidden rounded-2xl">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 py-12 md:py-16 relative">
        {/* Decorative blob */}
        <div
          className="absolute top-[-10%] right-[-5%] w-48 h-48 bg-primary/10 rounded-full blur-3xl pointer-events-none"
          aria-hidden="true"
        />

        <div className="relative z-10 max-w-5xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-10">
          {/* LEFT: copy */}
          <div className="flex flex-col items-center md:items-start text-center md:text-left gap-5 max-w-xl">
            {eyebrowIcon || eyebrowText ? (
              <span
                className="inline-flex items-center gap-2 bg-primary text-white text-xs font-bold
                           px-4 py-1.5 rounded-full uppercase tracking-wider shadow-glow"
              >
                {eyebrowIcon ? (
                  <MaterialSymbol name={eyebrowIcon} filled className="text-sm" />
                ) : null}
                {eyebrowText}
              </span>
            ) : null}

            <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark leading-tight">
              {heading}
              {headingAccent ? (
                <>
                  <br />
                  <span className="text-primary italic">{headingAccent}</span>
                </>
              ) : null}
            </h2>

            <p className="text-primary-dark/65 text-base leading-relaxed max-w-sm md:max-w-md">
              {body}
            </p>
          </div>

          {/* RIGHT: CTAs */}
          <div className="flex flex-wrap gap-3 justify-center md:justify-end md:items-center">
            <a
              href={primaryHref}
              className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-white
                         px-8 py-3.5 rounded-full font-bold transition-all shadow-glow hover:-translate-y-1
                         focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
            >
              {primaryLabel}
              <MaterialSymbol name={primaryIcon} className="text-base" />
            </a>

            {secondaryLabel && secondaryHref ? (
              <a
                href={secondaryHref}
                className="inline-flex items-center justify-center gap-2 border border-primary/30 text-primary
                           px-8 py-3.5 rounded-full font-semibold hover:bg-white transition-all
                           focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
              >
                {secondaryIcon ? (
                  <MaterialSymbol name={secondaryIcon} className="text-base" />
                ) : null}
                {secondaryLabel}
              </a>
            ) : null}
          </div>
        </div>
      </div>
    </div>
  );
}
