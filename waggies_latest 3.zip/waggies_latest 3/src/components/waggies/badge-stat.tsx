/**
 * Hero review stat badge — "4.9 · 500+ Reviews" with pulsing dot.
 *
 * Faithful React reproduction of resources/views/components/badge/stat.blade.php.
 */

import { MaterialSymbol } from "./material-symbol";

export type BadgeStatProps = {
  rating?: string;
  reviewCount?: string;
};

export function BadgeStat({
  rating = "4.9",
  reviewCount = "500+",
}: BadgeStatProps) {
  return (
    <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white border border-surface-purple shadow-sm w-fit">
      <MaterialSymbol name="star" filled className="text-primary text-lg" />
      <span className="text-xs font-bold text-primary-dark">
        {rating} · {reviewCount} Reviews
      </span>
      <span
        className="w-2 h-2 rounded-full bg-primary animate-wag-pulse"
        aria-hidden="true"
      />
    </div>
  );
}
