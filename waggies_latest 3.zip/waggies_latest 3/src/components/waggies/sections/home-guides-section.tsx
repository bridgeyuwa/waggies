/**
 * Homepage guides section — 1 featured card + 4 row cards.
 *
 * Faithful React reproduction of the inline guides section in
 * resources/views/pages/home.blade.php lines 103–154.
 */

import { MaterialSymbol } from "../material-symbol";
import { GuidesFeaturedCard } from "../guides-featured-card";
import { GuidesFeaturedCardRow } from "../guides-featured-card-row";
import { homeFeaturedGuide, homeGuideRowCards } from "@/data/home";

export function HomeGuidesSection() {
  return (
    <section id="guides-section" className="py-20">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        <div className="flex items-end justify-between mb-10">
          <div>
            <span className="text-primary font-bold tracking-widest uppercase text-xs mb-2 block">
              Free Resources
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark leading-tight">
              Pet Care Guides
            </h2>
            <p className="text-primary-dark/50 mt-2 text-sm max-w-md">
              Downloadable checklists, how-to guides, and expert reference material — all free.
            </p>
          </div>
          <a
            href="/guides"
            className="hidden sm:inline-flex items-center gap-1.5 text-primary font-semibold text-sm uppercase tracking-wide hover:text-primary-light transition-colors shrink-0 ml-6"
          >
            Browse all guides <MaterialSymbol name="arrow_forward" className="text-base" />
          </a>
        </div>

        <GuidesFeaturedCard
          title={homeFeaturedGuide.title}
          description={homeFeaturedGuide.description}
          downloadUrl={homeFeaturedGuide.downloadUrl}
          readUrl={homeFeaturedGuide.readUrl}
          pages={homeFeaturedGuide.pages}
        />

        <div className="divide-y divide-surface-purple border border-surface-purple rounded-2xl bg-white overflow-hidden">
          {homeGuideRowCards.map((card, i) => (
            <GuidesFeaturedCardRow
              key={i}
              icon={card.icon}
              title={card.title}
              meta={card.meta}
              href={card.href}
              badge={card.badge}
              badgeVariant={card.badgeVariant}
            />
          ))}
        </div>

        <div className="mt-8 text-center sm:hidden">
          <a
            href="/guides"
            className="inline-flex items-center gap-2 border border-primary text-primary px-7 py-3 rounded-full font-semibold text-sm hover:bg-primary hover:text-white transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
          >
            Browse all guides <MaterialSymbol name="arrow_forward" className="text-base" />
          </a>
        </div>
      </div>
    </section>
  );
}
