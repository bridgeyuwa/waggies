/**
 * Homepage shop teaser section — 4 product cards with various states.
 *
 * Faithful React reproduction of the inline shop section in
 * resources/views/pages/home.blade.php lines 156–360.
 *
 * The 4 product cards have different visual states:
 *   1. Bestseller — purple badge, normal wishlist
 *   2. Sale       — red badge, active wishlist (filled heart), strike-through price
 *   3. New        — green badge, normal wishlist
 *   4. Out of stock — grayscale, opacity-70, "Out of Stock" overlay, "Notify Me" button
 *
 * Plus the category filter pills above and "Visit shop" link below.
 */

import { MaterialSymbol } from "../material-symbol";
import {
  homeShopCategoryPills,
  homeShopProducts,
  type ShopProduct,
} from "@/data/home";

function ProductCard({ product }: { product: ShopProduct }) {
  const isOutOfStock = product.state === "out-of-stock";

  // Badge classes per state
  const badgeClass = (() => {
    switch (product.state) {
      case "bestseller":
        return "bg-primary text-white shadow-glow";
      case "sale":
        return "bg-error text-white";
      case "new":
        return "bg-success text-white";
      default:
        return ""; // out-of-stock: no badge
    }
  })();

  const badgeLabel = (() => {
    switch (product.state) {
      case "bestseller":
        return "Bestseller";
      case "sale":
        return "Sale";
      case "new":
        return "New";
      default:
        return null;
    }
  })();

  return (
    <div
      className={`group bg-white border border-surface-purple rounded-2xl overflow-hidden ${isOutOfStock ? "cursor-not-allowed opacity-70" : "card-lift cursor-pointer"} flex flex-col relative`}
    >
      {/* Badge */}
      {badgeLabel ? (
        <span
          className={`absolute top-3 left-3 z-10 ${badgeClass} text-[10px] font-bold px-2.5 py-1 rounded-full uppercase tracking-wider`}
        >
          {badgeLabel}
        </span>
      ) : null}

      {/* Wishlist */}
      <button
        type="button"
        className={`absolute top-3 right-3 z-10 w-8 h-8 rounded-full bg-white/90 backdrop-blur border border-surface-purple flex items-center justify-center transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 ${isOutOfStock ? "text-primary-dark/40 cursor-not-allowed" : product.wishlistActive ? "text-primary hover:text-error" : "text-primary-dark/40 hover:text-primary hover:border-primary"}`}
        disabled={isOutOfStock}
        aria-label={product.wishlistActive ? "Added to wishlist" : "Add to wishlist"}
      >
        <MaterialSymbol
          name="favorite"
          filled={product.wishlistActive}
          className="text-sm"
        />
      </button>

      {/* Image */}
      <div
        className={`img-zoom h-44 bg-surface-purple relative ${isOutOfStock ? "bg-surface-purple/60" : ""}`}
      >
        <div
          className={`bg-img h-full w-full bg-cover bg-center ${isOutOfStock ? "grayscale" : ""}`}
          style={{ backgroundImage: `url('${product.image}')` }}
        />
        {isOutOfStock ? (
          <div className="absolute inset-0 bg-white/50 flex items-center justify-center">
            <span className="bg-primary-dark/80 text-white text-[10px] font-bold px-3 py-1.5 rounded-full uppercase tracking-widest">
              Out of Stock
            </span>
          </div>
        ) : null}
      </div>

      {/* Body */}
      <div className="p-4 flex flex-col flex-1 gap-3">
        <div>
          <p className="text-[10px] font-bold text-primary/80 uppercase tracking-wider mb-1">
            {product.category}
          </p>
          <h3 className="font-semibold text-primary-dark text-sm leading-snug line-clamp-2">
            {product.title}
          </h3>
        </div>

        {/* Rating */}
        <div className="flex items-center gap-1.5 mt-auto">
          <MaterialSymbol name="star" filled className="text-gold text-sm" />
          <span className="text-xs font-bold text-primary-dark">{product.rating}</span>
          <span className="text-xs text-primary-dark/40">({product.reviewCount})</span>
        </div>

        {/* Price */}
        <div className="flex items-center gap-2">
          <p
            className={`font-serif font-bold text-lg ${product.priceMuted ? "text-primary-dark/40" : "text-primary-dark"}`}
          >
            {product.price}
          </p>
          {product.originalPrice ? (
            <p className="text-sm text-primary-dark/35 line-through font-medium">
              {product.originalPrice}
            </p>
          ) : null}
        </div>

        {/* CTA button */}
        {isOutOfStock ? (
          <button
            type="button"
            disabled
            className="w-full border border-primary-dark/20 text-primary-dark/40 py-2.5 rounded-full font-semibold text-xs flex items-center justify-center gap-1.5 cursor-not-allowed"
          >
            <MaterialSymbol name="notifications" className="text-sm" />
            Notify Me
          </button>
        ) : (
          <button
            type="button"
            className="w-full bg-primary hover:bg-primary-dark text-white py-2.5 rounded-full font-semibold text-xs transition shadow-glow hover:-translate-y-0.5 flex items-center justify-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-1"
          >
            <MaterialSymbol name="add_shopping_cart" className="text-sm" />
            Add to Cart
          </button>
        )}
      </div>
    </div>
  );
}

export function HomeShopSection() {
  return (
    <section id="shop-section" className="bg-surface py-20">
      <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
        {/* Section heading + View All */}
        <div className="flex items-end justify-between mb-8">
          <div>
            <span className="text-primary font-bold tracking-widest uppercase text-xs mb-2 block">
              Waggies Shop
            </span>
            <h2 className="font-serif text-3xl md:text-4xl font-bold text-primary-dark leading-tight">
              Shop for Your Pet
            </h2>
            <p className="text-primary-dark/50 mt-2 text-sm max-w-md">
              Curated products our vets and groomers actually use and recommend.
            </p>
          </div>
          <a
            href="#"
            className="hidden sm:inline-flex items-center gap-1.5 text-primary font-semibold text-sm uppercase tracking-wide hover:text-primary-light transition-colors shrink-0 ml-6"
          >
            Visit shop <MaterialSymbol name="arrow_forward" className="text-base" />
          </a>
        </div>

        {/* Category filter pills */}
        <div className="flex gap-2 mb-8 overflow-x-auto pb-1">
          {homeShopCategoryPills.map((pill, i) => (
            <button
              key={i}
              type="button"
              className={`shrink-0 px-5 py-2 rounded-full text-xs font-bold uppercase tracking-wider transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 ${pill.active ? "bg-primary text-white" : "border border-primary/25 text-primary-dark/70 hover:border-primary hover:text-primary"}`}
            >
              {pill.label}
            </button>
          ))}
        </div>

        {/* Product grid */}
        <div className="grid grid-cols-2 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {homeShopProducts.map((product, i) => (
            <ProductCard key={i} product={product} />
          ))}
        </div>

        {/* Mobile "Visit Shop" */}
        <div className="mt-8 text-center sm:hidden">
          <a
            href="#"
            className="inline-flex items-center gap-2 border border-primary text-primary px-7 py-3 rounded-full font-semibold text-sm hover:bg-primary hover:text-white transition-colors focus:outline-none focus:ring-2 focus:ring-primary/60 focus:ring-offset-2"
          >
            Visit shop <MaterialSymbol name="arrow_forward" className="text-base" />
          </a>
        </div>
      </div>
    </section>
  );
}
