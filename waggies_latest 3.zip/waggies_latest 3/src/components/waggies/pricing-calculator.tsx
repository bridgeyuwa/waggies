"use client";

/**
 * Pricing Calculator — React port of the Alpine `pricingCalculator` state
 * machine in resources/js/waggies.js.
 *
 * ════════════════════════════════════════════════════════════════════════
 *  STATE SHAPE (mirrors Alpine exactly)
 * ════════════════════════════════════════════════════════════════════════
 *
 *   services:        Record<string, PricingService>   (from config/waggies.php)
 *   service:         string                            (selected service key)
 *   variant:         string                            (selected variant key)
 *   tier:            string                            (selected tier key)
 *   quantity:        number                            (default 1)
 *   step:            'form' | 'result'
 *   result:          null | PricingResult
 *   contactBase:     string                            ('/contact')
 *   initialService:  string                            (locks service if preselected)
 *
 * ════════════════════════════════════════════════════════════════════════
 *  COMPUTED PROPERTIES (mirrors Alpine getters)
 * ════════════════════════════════════════════════════════════════════════
 *
 *   lockedService      → Boolean(initialService)
 *   currentService     → services[service] || null
 *   hasVariants        → currentService?.variants && Object.keys(...).length > 0
 *   tierOptions        → variant ? variants[variant].tiers : currentService.tiers
 *   hasTierOptions     → Object.keys(tierOptions).length > 0
 *   currentTier        → tierOptions[tier] || null
 *   showQuantity       → Boolean(currentService?.quantity_label)
 *   quantityMin        → currentService?.quantity_min || 1
 *   quantityMax        → currentService?.quantity_max || 99
 *   canCalculate       → service && tier && (hasVariants ? !!variant : true)
 *   primaryActionLabel → 'Request Consultation' | 'Get Estimate Range' | 'Calculate Price'
 *
 * ════════════════════════════════════════════════════════════════════════
 *  METHODS (mirrors Alpine methods)
 * ════════════════════════════════════════════════════════════════════════
 *
 *   init()             → scrollIntoView if initialService; calculate if tier preselected
 *   onServiceChange()  → variant = '', tier = ''
 *   calculate()        → compute display, summary, primaryCta, primaryIntent;
 *                        step = 'result'; scrollIntoView pricing-decision
 *   buildServiceLabel()→ service.label + ' — ' + variant.label (if variant)
 *   reset()            → step = 'form', result = null
 *   contactUrl(intent) → /contact?intent=&service=&variant=&tier=&quantity=&summary=
 *
 * ════════════════════════════════════════════════════════════════════════
 *  CALCULATION FORMULA (verbatim from waggies.js calculate())
 * ════════════════════════════════════════════════════════════════════════
 *
 *   qty = showQuantity ? max(quantityMin, quantity) : 1
 *
 *   if (type === 'fixed' && amount > 0):
 *     total = amount * qty
 *     display = formatNaira(total)
 *     if qty > 1: display += ` (${qty} × ${formatNaira(amount)})`
 *     summary = `${tier.label}: ${formatNaira(total)}${unit}`
 *     primaryCta = 'Book Now', primaryIntent = 'book'
 *
 *   else if (type === 'estimate'):
 *     low  = amount     * (showQuantity ? qty : 1)
 *     high = amount_max * (showQuantity ? qty : 1)
 *     display = `${formatNaira(low)} – ${formatNaira(high)}`
 *     summary = `${tier.label}: ${formatNaira(low)} – ${formatNaira(high)}`
 *     primaryCta = 'Proceed', primaryIntent = 'book'
 *
 *   else (quote):
 *     display = 'Custom quote required'
 *     summary = `${tier.label}: custom quote`
 *     primaryCta = 'Request Consultation', primaryIntent = 'consult'
 *
 *   result.serviceLabel = buildServiceLabel()
 *   result.tierLabel    = tier.label
 *
 * DO NOT change the calculation formula. DO NOT round differently.
 * DO NOT change Naira formatting. DO NOT change visible wording.
 */

import { useEffect, useMemo, useRef, useState } from "react";
import {
  contactUrl as buildContactUrl,
  formatNaira,
  pricingConfig,
  resolveServiceContext,
  type PricingService,
  type PricingTier,
} from "@/data/pricing";
import { MaterialSymbol } from "./material-symbol";
import { SectionHeading } from "./section-heading";

// ── Types ──────────────────────────────────────────────────────────────────

type TierType = "fixed" | "estimate" | "quote";

type PricingResult = {
  display: string;
  /** May contain HTML (the `(qty × ₦X)` suffix uses a <span>). */
  summary: string;
  type: TierType;
  primaryCta: string;
  primaryIntent: "book" | "consult";
  serviceLabel: string;
  tierLabel: string;
};

// ── Helpers ────────────────────────────────────────────────────────────────

// `formatNaira` from @/data/pricing reproduces Alpine's `formatNaira(amount)
// = '₦' + Number(amount).toLocaleString('en-NG')` exactly. Reused directly
// here so the calculator and the pricing-tier card share one source of truth.

// ── Component ──────────────────────────────────────────────────────────────

export type PricingCalculatorProps = {
  /** Initial query params from the URL (server-side resolved). */
  service?: string | null;
  variant?: string | null;
  tier?: string | null;
};

export function PricingCalculator({
  service: initialServiceParam,
  variant: initialVariantParam,
  tier: initialTierParam,
}: PricingCalculatorProps = {}) {
  // Resolve alias context (e.g. "boarding-dogs" → service="boarding", variant="dogs")
  // exactly like PricingQuote::resolveServiceContext() in the Laravel controller.
  const resolved = useMemo(
    () => resolveServiceContext(initialServiceParam ?? null, initialVariantParam ?? null),
    [initialServiceParam, initialVariantParam],
  );

  // ── Alpine state ────────────────────────────────────────────────────────
  const services = pricingConfig.services;
  const initialService = resolved.service; // empty string = no preselect
  const initialTier = initialTierParam ?? null;

  const [service, setService] = useState<string>(initialService);
  const [variant, setVariant] = useState<string>(resolved.variant ?? "");
  const [tier, setTier] = useState<string>(initialTier ?? "");
  const [quantity, setQuantity] = useState<number>(1);
  const [step, setStep] = useState<"form" | "result">("form");
  const [result, setResult] = useState<PricingResult | null>(null);

  // ── init() — Alpine's init() runs on mount ──────────────────────────────
  const calcSectionRef = useRef<HTMLElement | null>(null);
  const decisionRef = useRef<HTMLDivElement | null>(null);

  // ── Computed getters ────────────────────────────────────────────────────
  const lockedService = Boolean(initialService);
  const currentService: PricingService | null = service ? services[service] : null;
  const hasVariants = Boolean(
    currentService?.variants && Object.keys(currentService.variants).length > 0,
  );

  const tierOptions: Record<string, PricingTier> = useMemo(() => {
    if (!currentService) return {};
    if (hasVariants) {
      return variant && currentService.variants?.[variant]
        ? currentService.variants[variant].tiers
        : {};
    }
    return currentService.tiers ?? {};
  }, [currentService, hasVariants, variant]);

  const hasTierOptions = Object.keys(tierOptions).length > 0;
  const currentTier: PricingTier | null = tier ? tierOptions[tier] : null;
  const showQuantity = Boolean(currentService?.quantity_label);
  const quantityMin = currentService?.quantity_min ?? 1;
  const quantityMax = currentService?.quantity_max ?? 99;

  const canCalc = canCalculate(currentService, service, variant, tier);

  const primaryActionLabel = (() => {
    const type = currentTier?.type;
    if (type === "quote") return "Request Consultation";
    if (type === "estimate") return "Get Estimate Range";
    return "Calculate Price";
  })();

  // ── Methods ─────────────────────────────────────────────────────────────
  function onServiceChange(next: string) {
    setService(next);
    setVariant("");
    setTier("");
  }

  function buildServiceLabel(): string {
    let label = currentService?.label ?? "";
    if (variant && currentService?.variants?.[variant]) {
      label += " — " + currentService.variants[variant].label;
    }
    return label;
  }

  function doCalculate() {
    const t = currentTier;
    if (!t) return;
    const svc = currentService;
    if (!svc) return;

    const qty = showQuantity ? Math.max(quantityMin, quantity) : 1;
    let display = "";
    let summary = "";
    let primaryCta = "Book Now";
    let primaryIntent: "book" | "consult" = "book";

    if (t.type === "fixed" && t.amount > 0) {
      const total = t.amount * qty;
      display = formatNaira(total);
      if (qty > 1) {
        display += ` <span class="text-base font-normal text-primary-dark/50">(${qty} × ${formatNaira(t.amount)})</span>`;
      }
      summary = `${t.label}: ${formatNaira(total)}${svc.unit || ""}`;
      primaryCta = "Book Now";
      primaryIntent = "book";
    } else if (t.type === "estimate") {
      const low = t.amount * (showQuantity ? qty : 1);
      // Match Alpine's `tier.amount_max || tier.amount` (waggies.js line 129):
      // `||` falls back on any falsy value (including 0), `??` would only
      // fall back on null/undefined. No current estimate tier has
      // amount_max=0, but we match Alpine exactly to preserve behavior
      // should the config change.
      const high = (t.amount_max || t.amount) * (showQuantity ? qty : 1);
      display = `${formatNaira(low)} – ${formatNaira(high)}`;
      summary = `${t.label}: ${formatNaira(low)} – ${formatNaira(high)}`;
      primaryCta = "Proceed";
      primaryIntent = "book";
    } else {
      // quote
      display = "Custom quote required";
      summary = `${t.label}: custom quote`;
      primaryCta = "Request Consultation";
      primaryIntent = "consult";
    }

    setResult({
      display,
      summary,
      type: t.type,
      primaryCta,
      primaryIntent,
      serviceLabel: buildServiceLabel(),
      tierLabel: t.label,
    });
    setStep("result");

    // $nextTick: scroll decision into view
    requestAnimationFrame(() => {
      decisionRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  // ── init() effect — runs once on mount ─────────────────────────────────
  // Mirrors Alpine's `init()` method (waggies.js lines 13–27):
  //   - if initialService set, scrollIntoView the calculator
  //   - if initialTier set AND canCalculate, calculate() on nextTick
  //
  // We intentionally pass `[]` as deps so this only runs once on mount.
  // The closure captures the initial render's state, which is exactly the
  // URL-resolved state we want to seed the calculation with.
  useEffect(() => {
    // Alpine init(): scroll to calculator if a service was preselected.
    if (initialService) {
      requestAnimationFrame(() => {
        calcSectionRef.current?.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    }

    // Alpine init(): if a tier was preselected AND we can calculate, do so.
    if (initialTier && tier) {
      const svc = services[service];
      if (svc && canCalculate(svc, service, variant, tier)) {
        requestAnimationFrame(() => {
          doCalculate();
        });
      }
    }
  }, []);

  function reset() {
    setStep("form");
    setResult(null);
  }

  function contactUrl(intent: "book" | "save" | "consult"): string {
    return buildContactUrl(intent, {
      service: service || null,
      variant: variant || null,
      tier: tier || null,
      quantity: showQuantity ? String(quantity) : null,
      summary: result?.summary ?? null,
    });
  }

  // ── Render ──────────────────────────────────────────────────────────────
  return (
    <section
      id="pricing-calculator"
      ref={calcSectionRef}
      className="py-16 bg-surface-purple scroll-mt-24"
    >
      <div className="max-w-3xl mx-auto px-4 md:px-10 lg:px-12">
        <SectionHeading
          eyebrow="Pricing Tool"
          title="Get Your Estimate"
          subtitle="Select your service and package — we'll show a clear price or quote range and next steps."
        />

        {/* FORM STEP */}
        {step === "form" ? (
          <div className="mt-10 bg-white rounded-2xl border border-surface-purple shadow-soft p-6 md:p-8">
            <div className="flex flex-col gap-5">
              {/* Service selector — hidden when locked */}
              {!lockedService ? (
                <div>
                  <label htmlFor="calc-service" className="block text-sm font-semibold text-primary-dark mb-2">
                    Service
                  </label>
                  <select
                    id="calc-service"
                    value={service}
                    onChange={(e) => onServiceChange(e.target.value)}
                    className="w-full rounded-xl border border-surface-purple px-4 py-3 text-primary-dark focus:ring-2 focus:ring-primary/40 focus:border-primary"
                  >
                    <option value="">Choose a service…</option>
                    {Object.entries(services).map(([key, svc]) => (
                      <option key={key} value={key}>
                        {svc.label}
                      </option>
                    ))}
                  </select>
                </div>
              ) : null}

              {/* Locked service display */}
              {lockedService && currentService ? (
                <div>
                  <p className="text-sm font-semibold text-primary-dark/60 mb-1">Service</p>
                  <p className="text-lg font-bold text-primary-dark">{currentService.label}</p>
                </div>
              ) : null}

              {/* Variant selector */}
              {hasVariants ? (
                <div>
                  <label htmlFor="calc-variant" className="block text-sm font-semibold text-primary-dark mb-2">
                    Pet type
                  </label>
                  <select
                    id="calc-variant"
                    value={variant}
                    onChange={(e) => {
                      setVariant(e.target.value);
                      setTier("");
                    }}
                    className="w-full rounded-xl border border-surface-purple px-4 py-3 text-primary-dark focus:ring-2 focus:ring-primary/40 focus:border-primary"
                  >
                    <option value="">Choose…</option>
                    {currentService?.variants
                      ? Object.entries(currentService.variants).map(([key, v]) => (
                          <option key={key} value={key}>
                            {v.label}
                          </option>
                        ))
                      : null}
                  </select>
                </div>
              ) : null}

              {/* Tier selector */}
              {hasTierOptions ? (
                <div>
                  <label htmlFor="calc-tier" className="block text-sm font-semibold text-primary-dark mb-2">
                    Package
                  </label>
                  <select
                    id="calc-tier"
                    value={tier}
                    onChange={(e) => setTier(e.target.value)}
                    className="w-full rounded-xl border border-surface-purple px-4 py-3 text-primary-dark focus:ring-2 focus:ring-primary/40 focus:border-primary"
                  >
                    <option value="">Choose a package…</option>
                    {Object.entries(tierOptions).map(([key, t]) => (
                      <option key={key} value={key}>
                        {t.label}
                      </option>
                    ))}
                  </select>
                </div>
              ) : null}

              {/* Quantity input */}
              {showQuantity ? (
                <div>
                  <label htmlFor="calc-qty" className="block text-sm font-semibold text-primary-dark mb-2">
                    {currentService?.quantity_label}
                  </label>
                  <input
                    id="calc-qty"
                    type="number"
                    value={quantity}
                    min={quantityMin}
                    max={quantityMax}
                    onChange={(e) => setQuantity(Number(e.target.value))}
                    className="w-full rounded-xl border border-surface-purple px-4 py-3 text-primary-dark focus:ring-2 focus:ring-primary/40 focus:border-primary"
                  />
                </div>
              ) : null}

              <button
                type="button"
                onClick={doCalculate}
                disabled={!canCalc}
                className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark disabled:opacity-50 disabled:pointer-events-none text-white px-8 py-4 rounded-full font-bold transition shadow-glow hover:-translate-y-1 w-full sm:w-auto"
              >
                {primaryActionLabel}
                <MaterialSymbol name="calculate" ariaHidden />
              </button>
            </div>
          </div>
        ) : null}

        {/* RESULT STEP */}
        {step === "result" && result ? (
          <div className="mt-10">
            <div
              id="pricing-decision"
              ref={decisionRef}
              className="bg-white rounded-2xl border-2 border-primary shadow-soft p-6 md:p-8"
            >
              <p className="text-xs font-bold uppercase tracking-widest text-primary/60 mb-2">
                Your estimate
              </p>
              <p className="text-sm text-primary-dark/60 mb-1">{result.serviceLabel}</p>
              <p
                className="font-serif text-3xl md:text-4xl font-bold text-primary-dark mb-2"
                dangerouslySetInnerHTML={{ __html: result.display }}
              />
              <p className="text-sm text-primary-dark/50 mb-8">{result.tierLabel}</p>

              <div className="flex flex-col sm:flex-row flex-wrap gap-3">
                <a
                  href={contactUrl(result.primaryIntent || "book")}
                  className="inline-flex items-center justify-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3.5 rounded-full font-bold transition shadow-glow hover:-translate-y-1 flex-1 min-w-[140px]"
                >
                  {result.primaryCta || "Book Now"}
                </a>
                <a
                  href={contactUrl("save")}
                  className="inline-flex items-center justify-center gap-2 border-2 border-primary text-primary hover:bg-primary hover:text-white px-6 py-3.5 rounded-full font-semibold transition flex-1 min-w-[140px]"
                >
                  Save Estimate
                </a>
                <a
                  href={contactUrl("consult")}
                  className="inline-flex items-center justify-center gap-2 bg-surface-purple text-primary-dark hover:bg-primary/10 px-6 py-3.5 rounded-full font-semibold transition flex-1 min-w-[140px]"
                >
                  Talk to Expert
                </a>
              </div>

              <button
                type="button"
                onClick={reset}
                className="mt-6 text-sm text-primary font-medium hover:underline inline-flex items-center gap-1"
              >
                <MaterialSymbol name="arrow_back" className="text-base" />
                Start over
              </button>
            </div>
          </div>
        ) : null}
      </div>
    </section>
  );
}

// ── Pure helpers (mirrors Alpine getter logic, extracted for clarity) ──────

function canCalculate(
  currentService: PricingService | null,
  service: string,
  variant: string,
  tier: string,
): boolean {
  // Match Alpine's `canCalculate` getter exactly (waggies.js lines 74–82):
  //   if (!this.service || !this.tier) return false;
  //   if (this.hasVariants && !this.variant) return false;
  //   return true;
  // Alpine does NOT check `this.currentService` — an invalid service string
  // still satisfies `!!service`, so the button enables. calculate() then
  // returns early because currentTier is null. We mirror that behavior.
  if (!service || !tier) return false;
  const hasVariants = Boolean(
    currentService?.variants && Object.keys(currentService.variants).length > 0,
  );
  if (hasVariants && !variant) return false;
  return true;
}

