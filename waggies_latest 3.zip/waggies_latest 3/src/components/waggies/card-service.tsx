/**
 * Service card (B4).
 *
 * Faithful React reproduction of resources/views/components/card/service.blade.php.
 *
 * Full card is clickable via `.card-link` stretched pseudo-element (defined in
 * globals.css). The "Learn more" link is the actual anchor; the rest of the
 * card is just visual.
 */

import { MaterialSymbol } from "./material-symbol";

export type ServiceCardProps = {
  title: string;
  description: string;
  href: string;
  imageSrc: string;
  icon?: string;
  ctaLabel?: string;
};

export function ServiceCard({
  title,
  description,
  href,
  imageSrc,
  icon = "pets",
  ctaLabel = "Learn more",
}: ServiceCardProps) {
  return (
    <div className="group relative bg-white rounded-2xl overflow-hidden shadow-sm hover:shadow-soft hover:-translate-y-0.5 transition-all duration-300">
      {/* Image with zoom + dark overlay */}
      <div
        className="relative h-48 bg-cover bg-center overflow-hidden transition-transform duration-700 group-hover:scale-105"
        style={{ backgroundImage: `url('${imageSrc}')` }}
      >
        <div className="absolute inset-0 bg-primary-dark/20 group-hover:bg-transparent transition-colors duration-300"></div>
        <div className="absolute top-4 right-4">
          <div className="w-9 h-9 rounded-full bg-white/90 flex items-center justify-center shadow-sm">
            <MaterialSymbol name={icon} filled className="text-primary text-lg" />
          </div>
        </div>
      </div>

      {/* Body */}
      <div className="p-6">
        <h3 className="font-serif text-xl font-bold text-primary-dark mb-2">{title}</h3>
        <p className="text-sm text-primary-dark/60 leading-relaxed line-clamp-2 mb-4">
          {description}
        </p>
        <a
          href={href}
          className="card-link inline-flex items-center gap-1.5 text-sm font-semibold text-primary hover:text-primary-dark transition-colors"
        >
          {ctaLabel}
          <MaterialSymbol name="arrow_forward" className="text-base" />
        </a>
      </div>
    </div>
  );
}
