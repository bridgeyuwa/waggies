import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { HeroGradient } from "@/components/waggies/hero-gradient";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ServiceCard } from "@/components/waggies/card-service";
import { TestimonialCard } from "@/components/waggies/card-testimonial";
import { FeatureBand } from "@/components/waggies/feature-band";
import { CtaPrimary } from "@/components/waggies/cta-primary";
import { BlogSection } from "@/components/waggies/blog-section";
import { HomeGuidesSection } from "@/components/waggies/sections/home-guides-section";
import { HomeShopSection } from "@/components/waggies/sections/home-shop-section";
import { JsonLd, websiteSchema } from "@/components/waggies/json-ld";
import {
  homeHeroImage,
  homeHeroGradient,
  homeServiceCards,
  homeFeatureBandFeatures,
  homeTestimonials,
  homeCtaPrimary,
} from "@/data/home";

export const metadata: Metadata = {
  title: { absolute: "Luxury Pet Care, Abuja — Waggies" },
  description:
    "Waggies is Abuja's most trusted luxury pet boarding, grooming, vet care and relocation specialists.",
  alternates: { canonical: "/" },
  openGraph: {
    title: "Waggies — Luxury Pet Care, Abuja",
    description:
      "Waggies is Abuja's most trusted luxury pet boarding, grooming, vet care and relocation specialists.",
    url: "/",
  },
};

export default function HomePage() {
  return (
    <>
      {/* Hero image — "Abuja's #1 Pet Services" */}
      <HeroImage
        imageSrc={homeHeroImage.imageSrc}
        eyebrow={homeHeroImage.eyebrow}
        title={homeHeroImage.title}
        subtitle={homeHeroImage.subtitle}
        variant={homeHeroImage.variant}
        primaryCta={homeHeroImage.primaryCta}
        secondaryCta={homeHeroImage.secondaryCta}
      />

      {/* Hero gradient — "Where Luxury Meets Compassionate Care" */}
      <HeroGradient
        rating={homeHeroGradient.rating}
        imageSrc={homeHeroGradient.imageSrc}
        eyebrow={homeHeroGradient.eyebrow}
        title={homeHeroGradient.title}
        subtitle={homeHeroGradient.subtitle}
        primaryCta={homeHeroGradient.primaryCta}
        secondaryCta={homeHeroGradient.secondaryCta}
      />

      {/* Services grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow="What We Offer"
            title="World-Class Care<br/>for Every Pet"
            subtitle="From luxury overnight boarding to international relocation — all under one roof."
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {homeServiceCards.map((card, i) => (
              <ServiceCard key={i} {...card} />
            ))}
          </div>
        </div>
      </section>

      {/* Feature band */}
      <FeatureBand
        eyebrow="The Waggies Difference"
        title='Trusted Care<br/><span class="text-secondary italic">Standards</span>'
        subtitle="Certified standards across all services."
        cta={{ label: "Book a Free Consultation", href: "/contact" }}
        features={homeFeatureBandFeatures}
      />

      {/* Testimonials */}
      <section className="py-20 bg-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow="What Clients Say"
            title="Trusted by 500+ Pet Owners"
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {homeTestimonials.map((t, i) => (
              <TestimonialCard key={i} {...t} />
            ))}
          </div>
        </div>
      </section>

      {/* Guides section */}
      <HomeGuidesSection />

      {/* Shop teaser */}
      <HomeShopSection />

      {/* Blog section */}
      <BlogSection label="From the Blog" heading="Pet Care Tips & News" subheading="Expert advice, heartwarming stories, and the latest from Waggies HQ." viewAllUrl="#" />

      {/* CTA primary */}
      <section className="w-full py-20">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <CtaPrimary
            eyebrowIcon={homeCtaPrimary.eyebrowIcon}
            eyebrowText={homeCtaPrimary.eyebrowText}
            heading={homeCtaPrimary.heading}
            headingAccent={homeCtaPrimary.headingAccent}
            body={homeCtaPrimary.body}
            primaryLabel={homeCtaPrimary.primaryLabel}
            primaryHref={homeCtaPrimary.primaryHref}
            primaryIcon={homeCtaPrimary.primaryIcon}
            secondaryLabel={homeCtaPrimary.secondaryLabel}
            secondaryHref={homeCtaPrimary.secondaryHref}
            secondaryIcon={homeCtaPrimary.secondaryIcon}
          />
        </div>
      </section>

      <JsonLd data={websiteSchema()} />
    </>
  );
}
