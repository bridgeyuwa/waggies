/**
 * POST /api/contact — Next.js Route Handler.
 *
 * Reproduces the behaviour of Laravel's ContactController::store:
 *   1. Validates the body with the same rules as StoreContactRequest
 *      (name/email/message required, plus optional pricing context).
 *   2. Runs resolveServiceContext() on service/variant BEFORE validation —
 *      alias keys like "boarding-dogs" are rewritten to "boarding"+"dogs".
 *   3. Returns 422 + { errors: { field: message } } on validation failure.
 *   4. Throttles 5/min per IP (in-memory Map).
 *   5. On success:
 *      - If RESEND_API_KEY + ADMIN_EMAIL env vars are set: sends an admin
 *        notification email via Resend, replicating EnquiryReceivedNotification.
 *      - Otherwise: logs the enquiry payload to console.
 *      - Returns { success: true, message: "..." }.
 *
 * The marketing site is intentionally database-free. The admin email IS the
 * persistence layer. If a DB record is later required, route through an
 * external service (Supabase, Resend Audiences, etc.) — do NOT add Prisma
 * to the marketing repo.
 *
 * Source of truth:
 *   - app/Http/Controllers/ContactController.php
 *   - app/Http/Requests/StoreContactRequest.php
 *   - app/Notifications/EnquiryReceivedNotification.php
 *   - app/Support/PricingQuote.php (resolveServiceContext)
 */

import { NextResponse } from "next/server";
import { z } from "zod";
import { resolveServiceContext, pricingConfig } from "@/data/pricing";

// ── Throttle: 5 / min / IP (in-memory; resets on serverless cold start) ────
const WINDOW_MS = 60_000;
const MAX_HITS = 5;
const hits = new Map<string, number[]>();

function throttle(ip: string): boolean {
  const now = Date.now();
  const recent = (hits.get(ip) ?? []).filter((t) => now - t < WINDOW_MS);
  if (recent.length >= MAX_HITS) return false;
  recent.push(now);
  hits.set(ip, recent);
  return true;
}

// ── Validation (mirrors StoreContactRequest rules) ─────────────────────────
const SERVICE_KEYS = Object.keys(pricingConfig.services) as [string, ...string[]];

const ContactSchema = z.object({
  name: z.string().min(1, "The name field is required.").max(255, "The name may not be greater than 255 characters."),
  email: z.string().min(1, "The email field is required.").email("The email must be a valid email address.").max(255, "The email may not be greater than 255 characters."),
  message: z.string().min(1, "The message field is required.").max(5000, "The message may not be greater than 5000 characters."),
  service: z.enum(SERVICE_KEYS).optional().or(z.literal("")),
  variant: z.string().max(50).optional().or(z.literal("")),
  tier: z.string().max(50).optional().or(z.literal("")),
  intent: z.enum(["book", "save", "consult"]).optional().or(z.literal("")),
  estimate_summary: z.string().max(500).optional().or(z.literal("")),
});

type ContactPayload = z.infer<typeof ContactSchema>;

// ── Email payload (replicates EnquiryReceivedNotification) ─────────────────
function buildEmailBody(enquiry: ContactPayload): string {
  const lines: string[] = [];
  lines.push("New enquiry received");
  lines.push("");
  lines.push(`Name: ${enquiry.name}`);
  lines.push(`Email: ${enquiry.email}`);
  if (enquiry.service) {
    lines.push(`Service: ${enquiry.service}${enquiry.variant ? ` (${enquiry.variant})` : ""}`);
  }
  if (enquiry.tier) {
    lines.push(`Package: ${enquiry.tier}`);
  }
  if (enquiry.intent) {
    lines.push(`Intent: ${enquiry.intent}`);
  }
  if (enquiry.estimate_summary) {
    lines.push(`Estimate: ${enquiry.estimate_summary}`);
  }
  lines.push("");
  lines.push(`Message:`);
  lines.push(enquiry.message);
  return lines.join("\n");
}

function buildEmailHtml(enquiry: ContactPayload): string {
  const rows: string[] = [];
  rows.push(`<p><strong>Name:</strong> ${escapeHtml(enquiry.name)}</p>`);
  rows.push(`<p><strong>Email:</strong> ${escapeHtml(enquiry.email)}</p>`);
  if (enquiry.service) {
    rows.push(
      `<p><strong>Service:</strong> ${escapeHtml(enquiry.service)}${enquiry.variant ? ` (${escapeHtml(enquiry.variant)})` : ""}</p>`,
    );
  }
  if (enquiry.tier) {
    rows.push(`<p><strong>Package:</strong> ${escapeHtml(enquiry.tier)}</p>`);
  }
  if (enquiry.intent) {
    rows.push(`<p><strong>Intent:</strong> ${escapeHtml(enquiry.intent)}</p>`);
  }
  if (enquiry.estimate_summary) {
    rows.push(`<p><strong>Estimate:</strong> ${escapeHtml(enquiry.estimate_summary)}</p>`);
  }
  rows.push(`<p><strong>Message:</strong></p><p>${escapeHtml(enquiry.message).replace(/\n/g, "<br/>")}</p>`);
  return rows.join("");
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

// ── POST handler ───────────────────────────────────────────────────────────
export async function POST(request: Request) {
  const ip =
    request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ??
    request.headers.get("x-real-ip") ??
    "unknown";

  if (!throttle(ip)) {
    return NextResponse.json(
      { message: "Too many requests. Please try again later." },
      { status: 429 },
    );
  }

  let body: unknown;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { message: "Invalid JSON body." },
      { status: 400 },
    );
  }

  // Mirror prepareForValidation(): resolve aliases BEFORE validation.
  if (body && typeof body === "object") {
    const b = body as Record<string, unknown>;
    if (typeof b.service === "string" || b.service === undefined) {
      const resolved = resolveServiceContext(
        typeof b.service === "string" ? b.service : null,
        typeof b.variant === "string" ? b.variant : null,
      );
      b.service = resolved.service || undefined;
      b.variant = resolved.variant ?? undefined;
    }
  }

  const parsed = ContactSchema.safeParse(body);
  if (!parsed.success) {
    const errors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = issue.path[0];
      if (typeof key === "string" && !errors[key]) {
        errors[key] = issue.message;
      }
    }
    return NextResponse.json({ errors }, { status: 422 });
  }

  const enquiry = parsed.data;

  // Send admin email (or log)
  const adminEmail = process.env.ADMIN_EMAIL;
  const resendKey = process.env.RESEND_API_KEY;
  const fromAddress = process.env.RESEND_FROM_ADDRESS ?? "onboarding@resend.dev";

  if (resendKey && adminEmail) {
    try {
      const { Resend } = await import("resend");
      const resend = new Resend(resendKey);
      await resend.emails.send({
        from: `Waggies Contact <${fromAddress}>`,
        to: adminEmail,
        subject: `New contact enquiry from ${enquiry.name}`,
        text: buildEmailBody(enquiry),
        html: buildEmailHtml(enquiry),
      });
    } catch (err) {
      console.error("[contact] Resend send failed:", err);
      // We still return success to the user to avoid leaking email infra state.
      // The error is logged for ops follow-up.
    }
  } else {
    console.log("[contact] Enquiry received (no RESEND_API_KEY/ADMIN_EMAIL configured — logging only):");
    console.log(buildEmailBody(enquiry));
  }

  return NextResponse.json(
    { success: true, message: "Your message has been sent. We'll be in touch soon!" },
    { status: 200 },
  );
}
