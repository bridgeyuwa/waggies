/**
 * /guides/[slug] — React port of resources/views/pages/guides/show.blade.php
 *
 * Single guide article. Same structure as /blog/[slug] but with `eyebrow-icon="menu_book"`
 * and sidebar without newsletter widget (guides sidebar is leaner).
 *
 *         + app/Http/Controllers/Blog/GuidesController.php (show method)
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { LayoutContent } from "@/components/waggies/layout-content";
import { HeroImage } from "@/components/waggies/hero-image";
import { JsonLd, articleSchema } from "@/components/waggies/json-ld";
import { guidePosts, GuideCategoryLabel } from "@/data/guide-posts";

type Params = { slug: string };

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = guidePosts.find((p) => p.slug === slug);
  if (!post) {
    return { title: "Guide Not Found" };
  }
  return {
    title: post.title,
    description: post.excerpt ?? undefined,
    alternates: { canonical: `/guides/${slug}` },
    openGraph: {
      title: post.title,
      description: post.excerpt ?? undefined,
      url: `/guides/${slug}`,
      images: post.heroImageUrl ? [{ url: post.heroImageUrl }] : undefined,
    },
  };
}

export default async function GuidesShowPage({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const post = guidePosts.find((p) => p.slug === slug);

  if (!post) {
    notFound();
  }

  // Use the related slugs extracted verbatim from the Laravel dist sidebar
  // ("More Guides"). This preserves Laravel's exact selection and ordering.
  const related = (post.relatedSlugs ?? [])
    .map((slug) => guidePosts.find((p) => p.slug === slug))
    .filter((p): p is NonNullable<typeof p> => p !== undefined)
    .slice(0, 3);

  const categoryLabel = GuideCategoryLabel(post.categorySlug);

  return (
    <>
      <LayoutContent
        hero={
          <HeroImage
            imageSrc={post.heroImageUrl ?? ""}
            imageAlt={post.title}
            eyebrow={categoryLabel}
            eyebrowIcon="menu_book"
            title={post.title}
            subtitle={post.excerpt ?? undefined}
            minHeight="420px"
          />
        }
        crumbs={[
          { label: "Guides", href: "/guides" },
          { label: categoryLabel, href: `/guides/category/${post.categorySlug}` },
          { label: post.title, href: `/guides/${post.slug}` },
        ]}
        sidebar={
          <div className="bg-surface-purple rounded-2xl p-6">
            <h3 className="font-semibold text-primary-dark mb-3">More Guides</h3>
            {related.length === 0 ? (
              <p className="text-sm text-primary-dark/50">No related guides yet.</p>
            ) : (
              <ul className="flex flex-col gap-3">
                {related.map((r) => (
                  <li key={r.slug}>
                    <a
                      href={`/guides/${r.slug}`}
                      className="text-sm text-primary-dark/70 hover:text-primary transition leading-snug block"
                    >
                      {r.title}
                    </a>
                  </li>
                ))}
              </ul>
            )}
          </div>
        }
      >
        <article>
          <p className="text-sm text-primary-dark/40 mb-8">
            By {post.author}
            {" · "}
            {post.publishedAtText}
            {post.readingTime ? ` · ${post.readingTime}` : ""}
          </p>
          <div
            className="prose max-w-none"
            dangerouslySetInnerHTML={{ __html: post.bodyHtml }}
          />
        </article>
      </LayoutContent>

      <JsonLd
        data={articleSchema({
          headline: post.title,
          description: post.excerpt ?? "",
          url: `/guides/${post.slug}`,
          image: post.heroImageUrl ?? undefined,
        })}
      />
    </>
  );
}
