/**
 * /guides/category/[slug] — React port of resources/views/pages/guides/category.blade.php
 *
 * Lists published guides in a single category. Same structure as
 * /blog/category/[slug] but for guides.
 *
 *         + app/Http/Controllers/Blog/GuidesController.php (category method)
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { LayoutListing } from "@/components/waggies/layout-listing";
import { HeroHub } from "@/components/waggies/hero-hub";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ContentFeaturedStory } from "@/components/waggies/content-featured-story";
import { ArticleCard } from "@/components/waggies/article-card";
import { Pagination } from "@/components/waggies/pagination";
import { JsonLd, collectionPageSchema } from "@/components/waggies/json-ld";
import { guidePosts, GuideCategories, GuideCategoryLabel } from "@/data/guide-posts";

const PAGE_SIZE = 12;

type Params = { slug: string };
type SearchParams = { page?: string };

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const label = GuideCategoryLabel(slug);
  return {
    title: `${label} Guides`,
    description: `${label} guides from Waggies Pet Care.`,
    alternates: { canonical: `/guides/category/${slug}` },
    openGraph: {
      title: `${label} Guides — Waggies`,
      description: `${label} guides from Waggies Pet Care.`,
      url: `/guides/category/${slug}`,
    },
  };
}

export default async function GuidesCategoryPage({
  params,
  searchParams,
}: {
  params: Promise<Params>;
  searchParams: Promise<SearchParams>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  const validSlugs = GuideCategories.map((c) => c.slug);
  if (!validSlugs.includes(slug)) {
    notFound();
  }

  const label = GuideCategoryLabel(slug);
  const eyebrow = "Guides · Category";

  // Data file is already sorted by published_at DESC; preserve that order.
  const sorted = guidePosts.filter((p) => p.categorySlug === slug);
  const featured = sorted[0] ?? null;
  const rest = featured ? sorted.slice(1) : sorted;
  const totalPages = Math.max(1, Math.ceil(rest.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const paged = rest.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  return (
    <>
      <LayoutListing
        hero={
          <HeroHub
            type="guide"
            eyebrow={eyebrow}
            title={label}
            minHeight="420px"
          />
        }
        crumbs={[
          { label: "Guides", href: "/guides" },
          { label: label, href: `/guides/category/${slug}` },
        ]}
        sidebar={
          <div className="bg-surface-purple rounded-2xl p-6">
            <h3 className="font-semibold text-primary-dark mb-4">Topics</h3>
            <ul className="flex flex-col gap-2">
              <li>
                <a href="/guides" className="text-sm text-primary-dark/70 hover:text-primary transition">
                  All Guides
                </a>
              </li>
              {GuideCategories.map((cat) => (
                <li key={cat.slug}>
                  <a
                    href={`/guides/category/${cat.slug}`}
                    className={`text-sm hover:text-primary transition capitalize ${
                      cat.slug === slug
                        ? "text-primary font-semibold"
                        : "text-primary-dark/70"
                    }`}
                  >
                    {cat.label.toLowerCase()}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        }
        pagination={
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            baseUrl={`/guides/category/${slug}`}
            totalItems={rest.length}
            perPage={PAGE_SIZE}
          />
        }
      >
        {featured ? (
          <ContentFeaturedStory
            href={`/guides/${featured.slug}`}
            heroImageUrl={featured.heroImageUrl ?? ""}
            category={featured.category}
            title={featured.title}
            excerpt={featured.excerpt}
            author={featured.author}
            publishedAtText={featured.publishedAtText}
            readingTime={featured.readingTime}
            type="guide"
          />
        ) : null}

        {paged.length === 0 && !featured ? (
          <p className="text-primary-dark/50 text-sm">
            No guides in this category yet — check back soon.
          </p>
        ) : paged.length > 0 ? (
          <>
            {featured ? (
              <SectionHeading
                eyebrow="Topic"
                title="More guides"
                className="mb-8"
              />
            ) : null}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {paged.map((post) => (
                <ArticleCard
                  key={post.slug}
                  href={`/guides/${post.slug}`}
                  // Laravel's $post->image_url is null for seeder-generated
                  // posts. Article cards on listing pages render NO image.
                  imageUrl={null}
                  category={post.category}
                  title={post.title}
                  excerpt={post.excerpt}
                  type="guide"
                />
              ))}
            </div>
          </>
        ) : null}
      </LayoutListing>

      <JsonLd
        data={collectionPageSchema(
          `${label} Guides — Waggies`,
          `/guides/category/${slug}`,
          `${label} guides from Waggies Pet Care.`,
        )}
      />
    </>
  );
}
