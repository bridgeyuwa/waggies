/**
 * /guides index — React port of resources/views/pages/guides/index.blade.php
 *
 * Lists published guides. Same structure as /blog index but for guides.
 * Sidebar = categories list only (no newsletter widget for guides).
 *
 *         + app/Http/Controllers/Blog/GuidesController.php (index method)
 */

import type { Metadata } from "next";
import { LayoutListing } from "@/components/waggies/layout-listing";
import { HeroHub } from "@/components/waggies/hero-hub";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ContentFeaturedStory } from "@/components/waggies/content-featured-story";
import { ArticleCard } from "@/components/waggies/article-card";
import { Pagination } from "@/components/waggies/pagination";
import { JsonLd, collectionPageSchema } from "@/components/waggies/json-ld";
import { guidePosts, GuideCategories } from "@/data/guide-posts";

export const metadata: Metadata = {
  title: "Pet Care Guides",
  description:
    "Comprehensive, expert-written guides to help you make the best decisions for your pet.",
  alternates: { canonical: "/guides" },
  openGraph: {
    title: "In-Depth Pet Care Guides — Waggies",
    description:
      "Comprehensive, expert-written guides to help you make the best decisions for your pet.",
    url: "/guides",
  },
};

const PAGE_SIZE = 12;

type SearchParams = { page?: string };

export default async function GuidesIndexPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const sp = await searchParams;
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  // Data file is already sorted by published_at DESC.
  const sorted = guidePosts;
  const featured = sorted[0] ?? null;
  const rest = featured ? sorted.slice(1) : sorted;
  const totalPages = Math.max(1, Math.ceil(rest.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const paged = rest.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  return (
    <>
      <LayoutListing
        hero={<HeroHub type="guide" />}
        crumbs={[{ label: "Guides", href: "/guides" }]}
        sidebar={
          <div className="bg-surface-purple rounded-2xl p-6">
            <h3 className="font-semibold text-primary-dark mb-4">Topics</h3>
            <ul className="flex flex-col gap-2">
              <li>
                <a href="/guides" className="text-sm font-semibold text-primary">
                  All Guides
                </a>
              </li>
              {GuideCategories.map((cat) => (
                <li key={cat.slug}>
                  <a
                    href={`/guides/category/${cat.slug}`}
                    className="text-sm text-primary-dark/70 hover:text-primary transition capitalize"
                  >
                    {cat.label.toLowerCase()}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        }
        pagination={
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            baseUrl="/guides"
            totalItems={rest.length}
            perPage={PAGE_SIZE}
          />
        }
      >
        {featured ? (
          <ContentFeaturedStory
            href={`/guides/${featured.slug}`}
            heroImageUrl={featured.heroImageUrl ?? ""}
            category={featured.category}
            title={featured.title}
            excerpt={featured.excerpt}
            author={featured.author}
            publishedAtText={featured.publishedAtText}
            readingTime={featured.readingTime}
            type="guide"
          />
        ) : null}

        {paged.length === 0 && !featured ? (
          <p className="text-primary-dark/50 text-sm">
            No guides published yet — check back soon.
          </p>
        ) : paged.length > 0 ? (
          <>
            <SectionHeading
              eyebrow={featured ? "Latest" : undefined}
              title={featured ? "More Guides" : "All Guides"}
              className="mb-8"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {paged.map((post) => (
                <ArticleCard
                  key={post.slug}
                  href={`/guides/${post.slug}`}
                  // Laravel's $post->image_url is null for seeder-generated
                  // posts. Article cards on listing pages render NO image.
                  imageUrl={null}
                  category={post.category}
                  title={post.title}
                  excerpt={post.excerpt}
                  type="guide"
                />
              ))}
            </div>
          </>
        ) : null}
      </LayoutListing>

      <JsonLd
        data={collectionPageSchema(
          "In-Depth Pet Care Guides — Waggies",
          "/guides",
          "Comprehensive, expert-written guides to help you make the best decisions for your pet.",
        )}
      />
    </>
  );
}
