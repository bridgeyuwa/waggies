/**
 * /knowledge-base/category/[slug] — React port of resources/views/pages/kb/category.blade.php
 *
 * Lists KB articles in a single category. Paginates at 20 per page.
 *
 *         + app/Http/Controllers/Blog/KnowledgeBaseController.php (category method)
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { LayoutListing } from "@/components/waggies/layout-listing";
import { HeroHub } from "@/components/waggies/hero-hub";
import { KbArticleCard } from "@/components/waggies/kb-article-card";
import { Pagination } from "@/components/waggies/pagination";
import { JsonLd, collectionPageSchema } from "@/components/waggies/json-ld";
import { kbArticles, kbArticlesCanonicalOrder, KbCategories, KbCategoryLabel } from "@/data/kb-articles";

const PAGE_SIZE = 20;

type Params = { slug: string };
type SearchParams = { page?: string };

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const label = KbCategoryLabel(slug);
  return {
    title: `${label} — Knowledge Base`,
    description: `${label} articles from the Waggies Knowledge Base.`,
    alternates: { canonical: `/knowledge-base/category/${slug}` },
    openGraph: {
      title: `${label} — Waggies Knowledge Base`,
      description: `${label} articles from the Waggies Knowledge Base.`,
      url: `/knowledge-base/category/${slug}`,
    },
  };
}

export default async function KnowledgeBaseCategoryPage({
  params,
  searchParams,
}: {
  params: Promise<Params>;
  searchParams: Promise<SearchParams>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  const validSlugs = KbCategories.map((c) => c.slug);
  if (!validSlugs.includes(slug)) {
    notFound();
  }

  const label = KbCategoryLabel(slug);

  // Use the canonical article order from the Laravel dist category page
  // (reflects Laravel's `latest('published_at')` ordering). Articles beyond
  // page 1 fall back to alphabetical slug order.
  const canonicalCat = kbArticlesCanonicalOrder.categories[slug];
  const canonicalSlugs = canonicalCat ? canonicalCat.articles : [];
  const catSlugsInOrder = [
    ...canonicalSlugs,
    ...kbArticles
      .filter((a) => a.categorySlug === slug)
      .map((a) => a.slug)
      .filter((s) => !canonicalSlugs.includes(s))
      .sort(),
  ];
  const sorted = catSlugsInOrder
    .map((s) => kbArticles.find((a) => a.slug === s))
    .filter((a): a is NonNullable<typeof a> => a !== undefined);
  const totalPages = Math.max(1, Math.ceil(sorted.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const paged = sorted.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  return (
    <>
      <LayoutListing
        hero={
          <HeroHub
            type="kb"
            eyebrow="Knowledge Base · Topic"
            title={label}
            minHeight="420px"
          />
        }
        crumbs={[
          { label: "Knowledge Base", href: "/knowledge-base" },
          { label: label, href: `/knowledge-base/category/${slug}` },
        ]}
        sidebar={
          <div className="bg-surface-purple rounded-2xl p-6">
            <h3 className="font-semibold text-primary-dark mb-4">Topics</h3>
            <ul className="flex flex-col gap-2">
              <li>
                <a
                  href="/knowledge-base"
                  className="text-sm text-primary-dark/70 hover:text-primary transition"
                >
                  All Topics
                </a>
              </li>
              {KbCategories.map((cat) => (
                <li key={cat.slug}>
                  <a
                    href={`/knowledge-base/category/${cat.slug}`}
                    className={`text-sm hover:text-primary transition capitalize ${
                      cat.slug === slug
                        ? "text-primary font-semibold"
                        : "text-primary-dark/70"
                    }`}
                  >
                    {cat.label.toLowerCase()}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        }
        pagination={
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            baseUrl={`/knowledge-base/category/${slug}`}
            totalItems={sorted.length}
            perPage={PAGE_SIZE}
          />
        }
      >
        {paged.length > 0 ? (
          <div className="flex flex-col gap-4">
            {paged.map((article) => (
              <KbArticleCard
                key={article.slug}
                href={`/knowledge-base/${article.slug}`}
                category={article.category}
                title={article.title}
                as="h2"
              />
            ))}
          </div>
        ) : (
          <p className="text-primary-dark/50 text-sm">
            No articles in this topic yet — check back soon.
          </p>
        )}
      </LayoutListing>

      <JsonLd
        data={collectionPageSchema(
          `${label} — Waggies Knowledge Base`,
          `/knowledge-base/category/${slug}`,
          `${label} articles from the Waggies Knowledge Base.`,
        )}
      />
    </>
  );
}
