/**
 * /knowledge-base/[slug] — React port of resources/views/pages/kb/show.blade.php
 *
 * Single KB article. KB articles have NO author, NO date, NO reading_time —
 * the byline is omitted entirely. The hero uses the static KB hero image
 * (since KbArticle has no image field). The sidebar shows up to 5 related
 * articles + "Still need help?" CTA.
 *
 *         + app/Http/Controllers/Blog/KnowledgeBaseController.php (show method)
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { LayoutContent } from "@/components/waggies/layout-content";
import { HeroImage } from "@/components/waggies/hero-image";
import { JsonLd, articleSchema } from "@/components/waggies/json-ld";
import { kbArticles, KbCategoryLabel } from "@/data/kb-articles";
import { heroImages } from "@/data/pricing";

type Params = { slug: string };

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const article = kbArticles.find((a) => a.slug === slug);
  if (!article) {
    return { title: "Article Not Found" };
  }
  // Reproduce KbArticle::show subtitle: Str::limit(strip_tags($article->body), 160)
  const description = article.excerpt ?? "";
  return {
    title: article.title,
    description,
    alternates: { canonical: `/knowledge-base/${slug}` },
    openGraph: {
      title: article.title,
      description,
      url: `/knowledge-base/${slug}`,
    },
  };
}

export default async function KnowledgeBaseShowPage({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const article = kbArticles.find((a) => a.slug === slug);

  if (!article) {
    notFound();
  }

  // Use the related slugs extracted verbatim from the Laravel dist sidebar
  // ("More in this topic"). This preserves Laravel's exact selection and
  // ordering, which is otherwise unreproducible because the related query
  // has no ORDER BY (returns articles in DB-natural order).
  const related = (article.relatedSlugs ?? [])
    .map((slug) => kbArticles.find((a) => a.slug === slug))
    .filter((a): a is NonNullable<typeof a> => a !== undefined)
    .slice(0, 5);

  const categoryLabel = KbCategoryLabel(article.categorySlug);

  return (
    <>
      <LayoutContent
        hero={
          <HeroImage
            imageSrc={heroImages.kb}
            imageAlt={article.title}
            eyebrow={categoryLabel}
            eyebrowIcon="help"
            title={article.title}
            subtitle={article.excerpt ?? undefined}
            minHeight="400px"
          />
        }
        crumbs={[
          { label: "Knowledge Base", href: "/knowledge-base" },
          { label: categoryLabel, href: `/knowledge-base/category/${article.categorySlug}` },
          { label: article.title, href: `/knowledge-base/${article.slug}` },
        ]}
        sidebar={
          <>
            <div className="bg-surface-purple rounded-2xl p-6">
              <h3 className="font-semibold text-primary-dark mb-3">More in this topic</h3>
              {related.length === 0 ? (
                <p className="text-sm text-primary-dark/50">No related articles.</p>
              ) : (
                <ul className="flex flex-col gap-3">
                  {related.map((r) => (
                    <li key={r.slug}>
                      <a
                        href={`/knowledge-base/${r.slug}`}
                        className="text-sm text-primary-dark/70 hover:text-primary transition leading-snug block"
                      >
                        {r.title}
                      </a>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="bg-surface-purple rounded-2xl p-6">
              <h3 className="font-semibold text-primary-dark mb-2">Still need help?</h3>
              <p className="text-sm text-primary-dark/60 mb-3">
                Our team is happy to help with any questions.
              </p>
              <a
                href="/contact"
                className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2.5 rounded-full text-sm font-semibold hover:bg-primary-dark transition"
              >
                Contact Us
              </a>
            </div>
          </>
        }
      >
        <article>
          <div
            className="prose max-w-none"
            dangerouslySetInnerHTML={{ __html: article.bodyHtml }}
          />
        </article>
      </LayoutContent>

      <JsonLd
        data={articleSchema({
          headline: article.title,
          description: article.excerpt ?? "",
          url: `/knowledge-base/${article.slug}`,
        })}
      />
    </>
  );
}
