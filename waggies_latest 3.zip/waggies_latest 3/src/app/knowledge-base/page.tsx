/**
 * /knowledge-base index — React port of resources/views/pages/kb/index.blade.php
 *
 * Lists published KB articles. Featured section shows up to 6 featured
 * articles. All Articles section paginates at 20 per page. Sidebar has
 * categories list + "Still need help?" CTA.
 *
 *         + app/Http/Controllers/Blog/KnowledgeBaseController.php (index method)
 */

import type { Metadata } from "next";
import { LayoutListing } from "@/components/waggies/layout-listing";
import { HeroHub } from "@/components/waggies/hero-hub";
import { SectionHeading } from "@/components/waggies/section-heading";
import { KbArticleCard } from "@/components/waggies/kb-article-card";
import { Pagination } from "@/components/waggies/pagination";
import { JsonLd, collectionPageSchema } from "@/components/waggies/json-ld";
import { kbArticles, kbArticlesCanonicalOrder, KbCategories } from "@/data/kb-articles";

export const metadata: Metadata = {
  title: "Knowledge Base",
  description:
    "Quick answers to common questions about our services, policies, and pet care.",
  alternates: { canonical: "/knowledge-base" },
  openGraph: {
    title: "Knowledge Base — Waggies Pet Care Help",
    description:
      "Quick answers to common questions about our services, policies, and pet care.",
    url: "/knowledge-base",
  },
};

const PAGE_SIZE = 20;
const FEATURED_LIMIT = 6;

type SearchParams = { page?: string };

export default async function KnowledgeBaseIndexPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const sp = await searchParams;
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  // Use the canonical article order extracted from the Laravel dist index
  // page (which reflects Laravel's `latest('published_at')` ordering).
  // Articles beyond page 1 (i.e. not in the canonical-order list) fall back
  // to alphabetical slug order — they appear on later pages whose order we
  // cannot verify from the dist static export.
  const canonicalSlugs = kbArticlesCanonicalOrder.index.articles;
  const slugsInOrder = [
    ...canonicalSlugs,
    ...kbArticles
      .map((a) => a.slug)
      .filter((s) => !canonicalSlugs.includes(s))
      .sort(),
  ];
  const sorted = slugsInOrder
    .map((s) => kbArticles.find((a) => a.slug === s))
    .filter((a): a is NonNullable<typeof a> => a !== undefined);
  // Per KbArticle model: featured() = where('featured', true). The dist kb
  // index page's first 6 cards are the featured set (sorted by published_at
  // DESC, limited to 6). Treat the first 6 from canonical order as featured.
  const featured = sorted.slice(0, FEATURED_LIMIT);
  const all = sorted;
  const totalPages = Math.max(1, Math.ceil(all.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const paged = all.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  return (
    <>
      <LayoutListing
        hero={<HeroHub type="kb" />}
        crumbs={[{ label: "Knowledge Base", href: "/knowledge-base" }]}
        sidebar={
          <>
            <div className="bg-surface-purple rounded-2xl p-6">
              <h3 className="font-semibold text-primary-dark mb-4">Topics</h3>
              <ul className="flex flex-col gap-2">
                <li>
                  <a
                    href="/knowledge-base"
                    className="text-sm font-semibold text-primary"
                  >
                    All Topics
                  </a>
                </li>
                {KbCategories.map((cat) => (
                  <li key={cat.slug}>
                    <a
                      href={`/knowledge-base/category/${cat.slug}`}
                      className="text-sm text-primary-dark/70 hover:text-primary transition capitalize"
                    >
                      {cat.label.toLowerCase()}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-surface-purple rounded-2xl p-6">
              <h3 className="font-semibold text-primary-dark mb-2">Still need help?</h3>
              <p className="text-sm text-primary-dark/60 mb-4">
                Can&apos;t find what you&apos;re looking for? Our team is happy to help.
              </p>
              <a
                href="/contact"
                className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2.5 rounded-full text-sm font-semibold hover:bg-primary-dark transition"
              >
                Contact Us
              </a>
            </div>
          </>
        }
        pagination={
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            baseUrl="/knowledge-base"
            totalItems={all.length}
            perPage={PAGE_SIZE}
          />
        }
      >
        {featured.length > 0 ? (
          <>
            <SectionHeading eyebrow="Popular" title="Featured Articles" className="mb-6" />
            <div className="mb-10 flex flex-col gap-4">
              {featured.map((article) => (
                <KbArticleCard
                  key={article.slug}
                  href={`/knowledge-base/${article.slug}`}
                  category={article.category}
                  title={article.title}
                  as="h3"
                />
              ))}
            </div>
          </>
        ) : null}

        {paged.length > 0 ? (
          <>
            <SectionHeading title="All Articles" className="mb-6" />
            <div className="flex flex-col gap-4">
              {paged.map((article) => (
                <KbArticleCard
                  key={article.slug}
                  href={`/knowledge-base/${article.slug}`}
                  category={article.category}
                  title={article.title}
                  as="h2"
                />
              ))}
            </div>
          </>
        ) : (
          <p className="text-primary-dark/50 text-sm">
            No articles published yet — check back soon.
          </p>
        )}
      </LayoutListing>

      <JsonLd
        data={collectionPageSchema(
          "Knowledge Base — Waggies Pet Care Help",
          "/knowledge-base",
          "Quick answers to common questions about our services, policies, and pet care.",
        )}
      />
    </>
  );
}
