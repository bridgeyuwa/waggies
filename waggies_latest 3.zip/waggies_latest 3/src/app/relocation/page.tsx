import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ServiceCard } from "@/components/waggies/card-service";
import { TestimonialCard } from "@/components/waggies/card-testimonial";
import { FeatureBand } from "@/components/waggies/feature-band";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import {
  relocationIndexHero,
  relocationIndexSectionHeading,
  relocationIndexCards,
  relocationIndexFeatureBand,
  relocationTestimonials,
} from "@/data/relocation";
import { getFaqsForService } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Pet Relocation",
  description:
    "Full-service pet import and export from Abuja — health certificates, import permits, airline coordination, and customs clearance.",
  alternates: { canonical: "/relocation" },
  openGraph: {
    title: "International Pet Relocation Abuja — Waggies",
    description:
      "Full-service pet import and export from Abuja — health certificates, import permits, airline coordination, and customs clearance.",
    url: "/relocation",
  },
};

export default function RelocationIndexPage() {
  const faqs = getFaqsForService("relocation");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Pet Relocation", href: "/relocation" }]}
      />

      <HeroImage {...relocationIndexHero} />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={relocationIndexSectionHeading.eyebrow}
            title={relocationIndexSectionHeading.title}
            subtitle={relocationIndexSectionHeading.subtitle}
          />
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {relocationIndexCards.map((card, i) => (
              <ServiceCard key={i} {...card} />
            ))}
          </div>
        </div>
      </section>

      <FeatureBand {...relocationIndexFeatureBand} />

      {/* Testimonials */}
      <section className="py-20 bg-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow="Client Experiences"
            title="Smooth Moves, Happy Pets"
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {relocationTestimonials.map((t, i) => (
              <TestimonialCard
                key={i}
                stars={t.stars}
                quote={t.quote}
                authorInitial={t.authorInitial}
                authorName={t.authorName}
                authorSubtitle={t.authorSubtitle}
              />
            ))}
          </div>
        </div>
      </section>

      {/* FAQ accordion (relocation category — all subcategories) */}
      {faqs.length > 0 ? (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              spacing="mb-8"
            />
            <FaqAccordion
              faqs={faqs.map((f) => ({ question: f.question, answer: f.answer }))}
            />
            <p className="mt-6 text-sm text-primary-dark/50">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      ) : null}

      <JsonLd
        data={serviceSchema(
          "International Pet Relocation Abuja — Waggies",
          "Full-service pet import and export from Abuja — health certificates, import permits, airline coordination, and customs clearance.",
          "/relocation",
        )}
      />
    </>
  );
}
