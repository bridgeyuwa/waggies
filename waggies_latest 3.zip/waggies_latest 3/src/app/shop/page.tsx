/**
 * /shop — React port of resources/views/pages/shop.blade.php
 *
 * Static "Coming Soon" placeholder page. No e-commerce functionality.
 * 4 product category cards (Premium Pet Food, Grooming Products, Toys &
 * Enrichment, Beds & Accessories) are hardcoded in Blade and reproduced here.
 *
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { PageHeader } from "@/components/waggies/page-header";
import { SectionHeading } from "@/components/waggies/section-heading";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";

export const metadata: Metadata = {
  title: "Shop",
  description:
    "Premium pet food, accessories, and grooming products hand-picked by the Waggies team. Coming soon.",
  alternates: { canonical: "/shop" },
  openGraph: {
    title: "Shop — Waggies Pet Care",
    description:
      "Premium pet food, accessories, and grooming products hand-picked by the Waggies team. Coming soon.",
    url: "/shop",
  },
};

const shopCategories = [
  {
    icon: "restaurant",
    title: "Premium Pet Food",
    desc: "Nutritionist-approved dry, wet, and raw diets from leading brands.",
  },
  {
    icon: "spa",
    title: "Grooming Products",
    desc: "Professional-grade shampoos, conditioners, and styling tools.",
  },
  {
    icon: "toys",
    title: "Toys & Enrichment",
    desc: "Stimulating toys, puzzle feeders, and enrichment items.",
  },
  {
    icon: "hotel",
    title: "Beds & Accessories",
    desc: "Orthopedic beds, travel crates, collars, leads, and more.",
  },
] as const;

export default function ShopPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Shop", href: "/shop" }]}
      />

      <PageHeader
        align="center"
        eyebrow="Coming Soon"
        title="The Waggies Shop"
        subtitle="Premium pet food, accessories, grooming products, and more — hand-picked by the Waggies team. Launching soon."
        variant="purple"
      >
        <a
          href="/contact"
          className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-8 py-4 rounded-full font-bold transition shadow-glow hover:-translate-y-1"
        >
          Notify Me When Live
          <MaterialSymbol name="arrow_forward" />
        </a>
      </PageHeader>

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading eyebrow="What to Expect" title="What We'll Be Stocking" />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-10">
            {shopCategories.map((item) => (
              <div
                key={item.title}
                className="bg-surface-purple rounded-2xl p-6 flex flex-col gap-3"
              >
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center">
                  <MaterialSymbol name={item.icon} filled className="text-primary" />
                </div>
                <h3 className="font-semibold text-primary-dark">{item.title}</h3>
                <p className="text-sm text-primary-dark/60 leading-relaxed">
                  {item.desc}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <JsonLd
        data={webPageSchema(
          "Shop — Waggies Pet Care",
          "Premium pet food, accessories, and grooming products hand-picked by the Waggies team. Coming soon.",
          "/shop",
        )}
      />
    </>
  );
}
