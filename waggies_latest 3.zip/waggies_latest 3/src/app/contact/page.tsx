/**
 * /contact page — React port of resources/views/pages/contact.blade.php
 *
 * GET handler. Reads pricing query params (intent/service/variant/tier/
 * quantity/summary/message), resolves aliases, builds the textarea prefill
 * message via buildPrefillMessage(), and renders the form.
 *
 * The form is a Client Component (`<ContactForm>`) that POSTs JSON to
 * /api/contact. Validation, success, and error states are reproduced
 * identically to the Laravel Blade page.
 *
 * Source of truth:
 *   - resources/views/pages/contact.blade.php
 *   - app/Http/Controllers/ContactController.php (index method)
 *   - app/Support/PricingQuote.php (resolveServiceContext, buildPrefillMessage, estimateUrl)
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { HeroPlain } from "@/components/waggies/hero-plain";
import { ContactInfo } from "@/components/waggies/contact-info";
import { ContactForm } from "@/components/waggies/contact-form";
import { JsonLd, contactPageSchema } from "@/components/waggies/json-ld";
import { resolveServiceContext, buildPrefillMessage, estimateUrl } from "@/data/pricing";

export const metadata: Metadata = {
  title: "Contact Us",
  description:
    "Get in touch with Waggies — book a service, request a quote, or ask a question. We'd love to hear from you.",
  alternates: { canonical: "/contact" },
  openGraph: {
    title: "Contact Waggies — Abuja Pet Care",
    description:
      "Get in touch with Waggies — book a service, request a quote, or ask a question. We'd love to hear from you.",
    url: "/contact",
  },
};

type ContactSearchParams = {
  intent?: string;
  service?: string;
  variant?: string;
  tier?: string;
  quantity?: string;
  summary?: string;
  message?: string;
};

export default async function ContactPage({
  searchParams,
}: {
  searchParams: Promise<ContactSearchParams>;
}) {
  const sp = await searchParams;

  // Reproduce PricingQuote::resolveServiceContext() so an alias like
  // "boarding-dogs" is rewritten to service=boarding + variant=dogs before
  // the form is rendered.
  const resolved = resolveServiceContext(sp.service ?? null, sp.variant ?? null);

  const context = {
    service: resolved.service,
    variant: resolved.variant ?? "",
    tier: sp.tier ?? "",
    intent: sp.intent ?? "consult",
    quantity: sp.quantity ?? "",
    summary: sp.summary ?? "",
  };

  // Reproduce PricingQuote::buildPrefillMessage() — but allow ?message=... to override
  // (matches ContactController::index line 22).
  const prefillMessage =
    sp.message && sp.message.trim() !== ""
      ? sp.message
      : buildPrefillMessage({
          service: context.service,
          variant: context.variant,
          tier: context.tier,
          intent: context.intent,
          summary: context.summary,
        });

  const hasPricingContext = Boolean(context.service || context.summary);

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "Contact Us", href: "/contact" }]}
      />

      <HeroPlain
        eyebrow="Get in Touch"
        eyebrowIcon="mail"
        title="Contact Waggies"
        subtitle="Have a question, want to make a booking, or need a quote? We'd love to hear from you."
      />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            <div>
              <ContactForm
                service={context.service || undefined}
                variant={context.variant || undefined}
                tier={context.tier || undefined}
                intent={context.intent || undefined}
                estimateSummary={context.summary || undefined}
                defaultMessage={prefillMessage}
              />

              {hasPricingContext ? (
                <div className="mt-6 p-4 bg-surface-purple border border-primary/10 rounded-xl text-sm text-primary-dark/80">
                  <p className="font-semibold text-primary-dark mb-1">
                    Your estimate is attached to this message
                  </p>
                  {context.summary ? <p>{context.summary}</p> : null}
                  <p className="mt-2">
                    <a
                      href={estimateUrl(
                        context.service || null,
                        context.variant || null,
                        context.tier || null,
                      )}
                      className="text-primary font-medium hover:underline"
                    >
                      Adjust estimate
                    </a>
                  </p>
                </div>
              ) : null}
            </div>

            <div className="flex flex-col gap-8">
              <h2 className="font-serif text-2xl font-bold text-primary-dark">
                Other Ways to Reach Us
              </h2>
              <ContactInfo />

              <div className="bg-surface-purple rounded-2xl p-6">
                <h3 className="font-semibold text-primary-dark mb-3">Opening Hours</h3>
                <ul className="flex flex-col gap-2 text-sm text-primary-dark/70">
                  <li className="flex justify-between">
                    <span>Monday – Friday</span>
                    <span className="font-medium text-primary-dark">8:00am – 6:00pm</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Saturday</span>
                    <span className="font-medium text-primary-dark">9:00am – 5:00pm</span>
                  </li>
                  <li className="flex justify-between">
                    <span>Sunday</span>
                    <span className="font-medium text-primary-dark">10:00am – 4:00pm</span>
                  </li>
                </ul>
                <p className="mt-4 text-xs text-primary-dark/50">
                  Boarding guests receive 24/7 supervision regardless of office hours.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <JsonLd
        data={contactPageSchema(
          "Contact Waggies — Abuja Pet Care",
          "Get in touch with Waggies — book a service, request a quote, or ask a question. We'd love to hear from you.",
          "/contact",
        )}
      />
    </>
  );
}
