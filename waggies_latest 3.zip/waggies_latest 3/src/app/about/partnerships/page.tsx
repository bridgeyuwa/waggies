/**
 * /about/partnerships — React port of resources/views/pages/about/partnerships.blade.php
 *
 * Static marketing page. All content from src/data/partnerships.ts.
 *
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { PageHeader } from "@/components/waggies/page-header";
import { SectionHeading } from "@/components/waggies/section-heading";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import {
  partnershipsHero,
  partnershipTypes,
  partnershipTypesHeading,
  partnershipsCta,
} from "@/data/partnerships";

export const metadata: Metadata = {
  title: "Partnerships",
  description:
    "Waggies partners with veterinary clinics, pet retailers, breeders, and corporate organisations who share our commitment to animal welfare.",
  alternates: { canonical: "/about/partnerships" },
  openGraph: {
    title: "Partnerships — Waggies Pet Care Abuja",
    description:
      "Waggies partners with veterinary clinics, pet retailers, breeders, and corporate organisations who share our commitment to animal welfare.",
    url: "/about/partnerships",
  },
};

export default function PartnershipsPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "About", href: "/about" },
          { label: "Partnerships", href: "/about/partnerships" },
        ]}
      />

      <PageHeader
        eyebrow={partnershipsHero.eyebrow}
        title={partnershipsHero.title}
        subtitle={partnershipsHero.subtitle}
        variant="white"
        align="center"
      />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={partnershipTypesHeading.eyebrow}
            title={partnershipTypesHeading.title}
            subtitle={partnershipTypesHeading.subtitle}
          />
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mt-10">
            {partnershipTypes.map((p) => (
              <div key={p.title} className="bg-surface-purple rounded-2xl p-6 flex gap-4">
                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <MaterialSymbol name={p.icon} filled className="text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-primary-dark mb-1">{p.title}</h3>
                  <p className="text-sm text-primary-dark/60 leading-relaxed">
                    {p.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="py-16 bg-surface-purple">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="font-serif text-3xl font-bold text-primary-dark mb-3">
            {partnershipsCta.heading}
          </h2>
          <p className="text-primary-dark/60 mb-6">{partnershipsCta.body}</p>
          <a
            href={partnershipsCta.ctaHref}
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-8 py-4 rounded-full font-bold transition shadow-glow hover:-translate-y-1"
          >
            {partnershipsCta.ctaLabel}
            <MaterialSymbol name={partnershipsCta.ctaIcon} />
          </a>
        </div>
      </section>

      <JsonLd
        data={webPageSchema(
          "Partnerships — Waggies Pet Care Abuja",
          "Waggies partners with veterinary clinics, pet retailers, breeders, and corporate organisations who share our commitment to animal welfare.",
          "/about/partnerships",
        )}
      />
    </>
  );
}
