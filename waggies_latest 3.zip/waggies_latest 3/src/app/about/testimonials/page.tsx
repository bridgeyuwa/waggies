/**
 * /about/testimonials — React port of resources/views/pages/about/testimonials.blade.php
 *
 * Static marketing page. All content from src/data/testimonials.ts.
 *
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { HeroSplit } from "@/components/waggies/hero-split";
import { TestimonialCard } from "@/components/waggies/card-testimonial";
import { CtaTertiary } from "@/components/waggies/cta-tertiary";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { testimonialsHero, testimonials, testimonialsBottomCta } from "@/data/testimonials";

export const metadata: Metadata = {
  title: "Client Testimonials",
  description:
    "Read what 500+ satisfied pet owners across Abuja say about their Waggies boarding, grooming, vet care, and relocation experience.",
  alternates: { canonical: "/about/testimonials" },
  openGraph: {
    title: "Client Testimonials — Waggies Pet Care Abuja",
    description:
      "Read what 500+ satisfied pet owners across Abuja say about their Waggies boarding, grooming, vet care, and relocation experience.",
    url: "/about/testimonials",
  },
};

export default function TestimonialsPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "About", href: "/about" },
          { label: "Testimonials", href: "/about/testimonials" },
        ]}
      />

      <HeroSplit
        eyebrow={testimonialsHero.eyebrow}
        eyebrowIcon={testimonialsHero.eyebrowIcon}
        title={testimonialsHero.title}
        subtitle={testimonialsHero.subtitle}
        imageSrc={testimonialsHero.imageSrc}
        imageAlt={testimonialsHero.imageAlt}
        rating={testimonialsHero.rating}
        reviewCount={testimonialsHero.reviewCount}
        primaryLabel={testimonialsHero.primaryLabel}
        primaryHref={testimonialsHero.primaryHref}
        secondaryLabel={testimonialsHero.secondaryLabel}
        secondaryHref={testimonialsHero.secondaryHref}
      />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {testimonials.map((t) => (
              <TestimonialCard
                key={t.authorName}
                stars={t.stars}
                quote={t.quote}
                authorInitial={t.authorInitial}
                authorName={t.authorName}
                authorSubtitle={t.authorSubtitle}
              />
            ))}
          </div>
        </div>
      </section>

      <section className="py-20 bg-surface-purple">
        <div className="max-w-3xl mx-auto px-4 text-center">
          <h2 className="font-serif text-3xl font-bold text-primary-dark mb-3">
            {testimonialsBottomCta.heading}
          </h2>
          <p className="text-primary-dark/60 mb-6">
            {testimonialsBottomCta.body}
          </p>
          <a
            href={testimonialsBottomCta.ctaHref}
            className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-8 py-4 rounded-full font-bold transition shadow-glow hover:-translate-y-1"
          >
            {testimonialsBottomCta.ctaLabel}
            <MaterialSymbol name={testimonialsBottomCta.ctaIcon} />
          </a>
        </div>
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          {/* Laravel passes primaryCta/secondaryCta which the cta.tertiary component
              does not declare — silently swallowed by attribute bag. The component
              therefore renders with its own default heading/body/cta_label/cta_href.
              We reproduce that exact behaviour: pass only the props the component
              actually declares. */}
          <CtaTertiary
            heading={testimonialsBottomCta.tertiary.heading}
            body={testimonialsBottomCta.tertiary.body}
          />
        </div>
      </section>

      <JsonLd
        data={webPageSchema(
          "Client Testimonials — Waggies Pet Care Abuja",
          "Read what 500+ satisfied pet owners across Abuja say about their Waggies boarding, grooming, vet care, and relocation experience.",
          "/about/testimonials",
        )}
      />
    </>
  );
}
