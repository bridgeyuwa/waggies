/**
 * /about/gallery — React port of resources/views/pages/about/gallery.blade.php
 *
 * Static marketing page. All content from src/data/gallery.ts.
 *
 *
 * NOTE: 20 image paths under /images/gallery/*.jpg are referenced but the
 * files do not exist in the Laravel source. They are preserved verbatim per
 * Phase 2 decision (MIGRATION_ASSET_TODO.md). The browser will show broken
 * image icons exactly as on the Laravel site.
 */

import type { Metadata } from "next";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { PageHeader } from "@/components/waggies/page-header";
import { SectionHeading } from "@/components/waggies/section-heading";
import { JsonLd, webPageSchema } from "@/components/waggies/json-ld";
import { galleryHero, galleryGroups } from "@/data/gallery";

export const metadata: Metadata = {
  title: "Photo Gallery",
  description:
    "Browse Waggies' boarding suites, grooming spa, outdoor play areas, and happy guest photos.",
  alternates: { canonical: "/about/gallery" },
  openGraph: {
    title: "Photo Gallery — Waggies Pet Care Abuja",
    description:
      "Browse Waggies' boarding suites, grooming spa, outdoor play areas, and happy guest photos.",
    url: "/about/gallery",
  },
};

export default function GalleryPage() {
  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "About", href: "/about" },
          { label: "Gallery", href: "/about/gallery" },
        ]}
      />

      <PageHeader
        eyebrow={galleryHero.eyebrow}
        title={galleryHero.title}
        subtitle={galleryHero.subtitle}
        variant="white"
        align="center"
      />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          {galleryGroups.map((group) => (
            <div key={group.title} className="mb-16 last:mb-0">
              <SectionHeading
                eyebrow={group.eyebrow}
                title={group.title}
                className="mb-8"
              />
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {group.imagePaths.map((path, i) => (
                  <div
                    key={path}
                    className="aspect-square rounded-2xl bg-surface-purple overflow-hidden"
                  >
                    <img
                      src={path}
                      alt={`${group.title} photo ${i + 1}`}
                      className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                      loading="lazy"
                    />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      <JsonLd
        data={webPageSchema(
          "Photo Gallery — Waggies Pet Care Abuja",
          "Browse Waggies' boarding suites, grooming spa, outdoor play areas, and happy guest photos.",
          "/about/gallery",
        )}
      />
    </>
  );
}
