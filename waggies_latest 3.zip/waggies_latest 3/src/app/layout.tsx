import type { Metadata } from "next";
import { Cormorant_Garamond, DM_Sans } from "next/font/google";
import "./globals.css";
import { SkipLink } from "@/components/waggies/skip-link";
import { Navbar } from "@/components/waggies/navbar";
import { Footer } from "@/components/waggies/footer";
import { CookieBanner } from "@/components/waggies/cookie-banner";
import { WhatsAppFab } from "@/components/waggies/whatsapp-fab";
import { BomSpacer } from "@/components/waggies/bom-spacer";
import { siteConfig } from "@/lib/site";

// ── Fonts ──────────────────────────────────────────────────────────────────
// Reproduces the Google Fonts <link> in layouts/app.blade.php line 33:
//   Cormorant Garamond: weights 400, 600, 700 + italics 400, 600
//   DM Sans:            weights 400, 500, 600, 700
const dmSans = DM_Sans({
  variable: "--font-dm-sans",
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  display: "swap",
});

const cormorantGaramond = Cormorant_Garamond({
  variable: "--font-cormorant-garamond",
  subsets: ["latin"],
  weight: ["400", "600", "700"],
  style: ["normal", "italic"],
  display: "swap",
});

// ── Metadata ───────────────────────────────────────────────────────────────
// Reproduces the <title>, <meta description>, and Open Graph defaults from
// layouts/app.blade.php lines 15–28.
export const metadata: Metadata = {
  metadataBase: new URL(siteConfig.siteUrl),
  title: {
    default: siteConfig.defaultTitle,
    template: "%s — Waggies",
  },
  description: siteConfig.defaultDescription,
  applicationName: siteConfig.name,
  authors: [{ name: siteConfig.name }],
  generator: "Next.js",
  keywords: [
    "pet boarding Abuja",
    "luxury pet care",
    "pet relocation Nigeria",
    "dog grooming Abuja",
    "veterinary care",
    "Waggies",
  ],
  referrer: "origin-when-cross-origin",
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      "max-image-preview": "large",
      "max-snippet": -1,
      "max-video-preview": -1,
    },
  },
  openGraph: {
    type: "website",
    locale: siteConfig.locale,
    url: siteConfig.siteUrl,
    siteName: siteConfig.name,
    title: siteConfig.defaultTitle,
    description: siteConfig.defaultOgDescription,
  },
  twitter: {
    card: "summary_large_image",
    title: siteConfig.defaultTitle,
    description: siteConfig.defaultDescription,
  },
  icons: {
    icon: "/favicon.ico",
  },
  manifest: undefined,
};

// ── JSON-LD: Organization + LocalBusiness ──────────────────────────────────
// Reproduces the base schema emitted on every page by layouts/app.blade.php
// lines 39–56 (Spatie\SchemaOrg). The Laravel site uses Spatie's schema
// package; we emit the same JSON-LD by hand to avoid pulling in a package
// dependency.
const organizationLd = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Waggies",
  description:
    "Abuja's most trusted luxury pet boarding, grooming, vet care and relocation specialists.",
  url: siteConfig.siteUrl,
};

const localBusinessLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Waggies",
  description:
    "Luxury pet boarding, grooming, vet care, training, transport and relocation in Abuja, Nigeria.",
  url: siteConfig.siteUrl,
  address: {
    "@type": "PostalAddress",
    addressLocality: "Abuja",
    addressRegion: "FCT",
    addressCountry: "NG",
  },
};

// ── Root layout ────────────────────────────────────────────────────────────
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${dmSans.variable} ${cormorantGaramond.variable} scroll-smooth`}
      suppressHydrationWarning
    >
      <head>
        {/* Material Symbols Outlined — variable icon font. The Laravel layout
            loads this via a Google Fonts <link> (line 34 of app.blade.php).
            next/font does not handle this font's axes well, so we preserve
            the CDN <link> approach. */}
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200&display=swap"
          rel="stylesheet"
        />

        {/* Base Organization + LocalBusiness structured data — emitted on
            every page, matching the Laravel layout's Spatie schema block. */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessLd) }}
        />
      </head>
      <body className="bg-surface text-primary-dark antialiased">
        <BomSpacer />
        <SkipLink />
        <Navbar />
        <main id="main-content" tabIndex={-1}>
          {children}
        </main>
        <Footer variant="dark" />
        <WhatsAppFab />
        <CookieBanner />
      </body>
    </html>
  );
}
