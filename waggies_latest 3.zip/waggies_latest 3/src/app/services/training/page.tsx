import { SimpleServicePage } from "@/components/waggies/sections/simple-service-page";
import {
  trainingHero,
  trainingSectionHeading,
  trainingFeatures,
  trainingFeatureBand,
} from "@/data/services";

export const metadata = {
  title: "Dog Training",
  description:
    "Science-based, positive-reinforcement dog training in Abuja for puppies and adults — obedience, behaviour modification, and group classes.",
  alternates: { canonical: "/services/training" },
  openGraph: {
    title: "Dog Training Abuja — Waggies",
    description:
      "Science-based, positive-reinforcement dog training in Abuja for puppies and adults — obedience, behaviour modification, and group classes.",
    url: "/services/training",
  },
};

export default function TrainingPage() {
  return (
    <SimpleServicePage
      title="Dog Training"
      description="Science-based, positive-reinforcement dog training in Abuja for puppies and adults — obedience, behaviour modification, and group classes."
      canonical="/services/training"
      ogTitle="Dog Training Abuja — Waggies"
      ogDescription="Science-based, positive-reinforcement dog training in Abuja for puppies and adults — obedience, behaviour modification, and group classes."
      crumbs={[
        { label: "Services", href: "/services" },
        { label: "Dog Training", href: "/services/training" },
      ]}
      hero={trainingHero}
      featureSectionHeading={trainingSectionHeading}
      features={trainingFeatures}
      featureBand={trainingFeatureBand}
      faqCategory="training"
      schemaName="Dog Training Abuja — Waggies"
      schemaDescription="Science-based, positive-reinforcement dog training in Abuja for puppies and adults — obedience, behaviour modification, and group classes."
      schemaUrl="/services/training"
    />
  );
}
