import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ServiceFeatureGrid } from "@/components/waggies/boarding-feature-grid";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import {
  transportHero,
  transportSectionHeading,
  transportFeatures,
  transportCtaBand,
} from "@/data/services";
import { getFaqsForService } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Pet Transport",
  description:
    "Air-conditioned, door-to-door pet transport and pickup across all areas of Abuja by trained, experienced handlers.",
  alternates: { canonical: "/services/transport" },
  openGraph: {
    title: "Pet Transport Abuja — Waggies",
    description:
      "Air-conditioned, door-to-door pet transport and pickup across all areas of Abuja by trained, experienced handlers.",
    url: "/services/transport",
  },
};

export default function TransportPage() {
  const faqs = getFaqsForService("transport");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Pet Transport", href: "/services/transport" },
        ]}
      />

      <HeroImage {...transportHero} />

      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading {...transportSectionHeading} />
          <ServiceFeatureGrid features={transportFeatures} />
        </div>
      </section>

      {/* "Book a transport slot" CTA band */}
      <section className="py-16 bg-white border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12 flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <h2 className="font-serif text-2xl font-bold text-primary-dark mb-1">
              {transportCtaBand.heading}
            </h2>
            <p className="text-primary-dark/60">{transportCtaBand.body}</p>
          </div>
          <div className="flex gap-3 shrink-0">
            <a
              href={transportCtaBand.secondary.href}
              className="inline-flex items-center gap-2 border-2 border-primary text-primary px-6 py-3 rounded-full font-semibold hover:bg-primary hover:text-white transition"
            >
              {transportCtaBand.secondary.label}
            </a>
            <a
              href={transportCtaBand.primary.href}
              className="inline-flex items-center gap-2 bg-primary hover:bg-primary-dark text-white px-6 py-3 rounded-full font-bold transition shadow-glow hover:-translate-y-1"
            >
              {transportCtaBand.primary.label}
              <MaterialSymbol name={transportCtaBand.primary.icon} className="text-base" />
            </a>
          </div>
        </div>
      </section>

      {faqs.length > 0 ? (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              spacing="mb-8"
            />
            <FaqAccordion
              faqs={faqs.map((f) => ({ question: f.question, answer: f.answer }))}
            />
            <p className="mt-6 text-sm text-primary-dark/50">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      ) : null}

      <JsonLd
        data={serviceSchema(
          "Pet Transport Abuja — Waggies",
          "Air-conditioned, door-to-door pet transport and pickup across all areas of Abuja by trained, experienced handlers.",
          "/services/transport",
        )}
      />
    </>
  );
}
