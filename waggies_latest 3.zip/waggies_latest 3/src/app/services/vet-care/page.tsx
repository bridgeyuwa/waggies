import { SimpleServicePage } from "@/components/waggies/sections/simple-service-page";
import {
  vetCareHero,
  vetCareSectionHeading,
  vetCareFeatures,
  vetCareFeatureBand,
} from "@/data/services";

export const metadata = {
  title: "Veterinary Care",
  description:
    "Veterinary consultations, vaccinations, wellness check-ups and minor treatments by a qualified on-site vet — every day at Waggies Abuja.",
  alternates: { canonical: "/services/vet-care" },
  openGraph: {
    title: "On-Site Veterinary Care Abuja — Waggies",
    description:
      "Veterinary consultations, vaccinations, wellness check-ups and minor treatments by a qualified on-site vet — every day at Waggies Abuja.",
    url: "/services/vet-care",
  },
};

export default function VetCarePage() {
  return (
    <SimpleServicePage
      title="Veterinary Care"
      description="Veterinary consultations, vaccinations, wellness check-ups and minor treatments by a qualified on-site vet — every day at Waggies Abuja."
      canonical="/services/vet-care"
      ogTitle="On-Site Veterinary Care Abuja — Waggies"
      ogDescription="Veterinary consultations, vaccinations, wellness check-ups and minor treatments by a qualified on-site vet — every day at Waggies Abuja."
      crumbs={[
        { label: "Services", href: "/services" },
        { label: "Veterinary Care", href: "/services/vet-care" },
      ]}
      hero={vetCareHero}
      featureSectionHeading={vetCareSectionHeading}
      features={vetCareFeatures}
      featureBand={vetCareFeatureBand}
      faqCategory="vet-care"
      schemaName="On-Site Veterinary Care Abuja — Waggies"
      schemaDescription="Veterinary consultations, vaccinations, wellness check-ups and minor treatments by a qualified on-site vet — every day at Waggies Abuja."
      schemaUrl="/services/vet-care"
    />
  );
}
