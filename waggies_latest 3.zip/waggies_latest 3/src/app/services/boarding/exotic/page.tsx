import type { Metadata } from "next";
import { HeroImage } from "@/components/waggies/hero-image";
import { SectionHeading } from "@/components/waggies/section-heading";
import { CardPricing } from "@/components/waggies/card-pricing";
import { BoardingStatsBar } from "@/components/waggies/boarding-stats-bar";
import { BoardingFeatureGrid } from "@/components/waggies/boarding-feature-grid";
import { BoardingDayInLife } from "@/components/waggies/boarding-day-in-life";
import { BoardingSafetyCard } from "@/components/waggies/boarding-safety-card";
import { BoardingSiblingLinks } from "@/components/waggies/boarding-sibling-links";
import { FeatureBand } from "@/components/waggies/feature-band";
import { CtaPrimary } from "@/components/waggies/cta-primary";
import { FaqAccordion } from "@/components/waggies/faq-accordion";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { MaterialSymbol } from "@/components/waggies/material-symbol";
import { JsonLd, serviceSchema } from "@/components/waggies/json-ld";
import {
  exoticHero,
  exoticStats,
  exoticSpecies,
  exoticSpeciesHeading,
  exoticPackageHeading,
  exoticFeaturesHeading,
  exoticFeatures,
  exoticDayInLife,
  exoticSafetyCard,
  exoticFeatureBand,
  exoticCta,
} from "@/data/boarding";
import { estimateUrl } from "@/data/pricing";
import { getFaqsForService } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Exotic Pet Boarding",
  description:
    "Specialist boarding for birds, reptiles, rabbits, guinea pigs, and small mammals in custom enclosures with experienced handlers.",
  alternates: { canonical: "/services/boarding/exotic" },
  openGraph: {
    title: "Exotic Pet Boarding Abuja — Waggies",
    description:
      "Specialist boarding for birds, reptiles, rabbits, guinea pigs, and small mammals in custom enclosures with experienced handlers.",
    url: "/services/boarding/exotic",
  },
};

export default function ExoticBoardingPage() {
  const faqs = getFaqsForService("boarding", "exotic");

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[
          { label: "Services", href: "/services" },
          { label: "Boarding", href: "/services/boarding" },
          { label: "Exotic Pet Boarding", href: "/services/boarding/exotic" },
        ]}
      />

      <HeroImage {...exoticHero} />

      <BoardingStatsBar stats={exoticStats} />

      {/* Species grid */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={exoticSpeciesHeading.eyebrow}
            title={exoticSpeciesHeading.title}
            subtitle={exoticSpeciesHeading.subtitle}
          />
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4 mt-10">
            {exoticSpecies.map((pet, i) => (
              <div
                key={i}
                className="bg-surface-purple rounded-2xl p-5 flex flex-col items-center gap-2 text-center hover:shadow-soft transition-shadow"
              >
                <MaterialSymbol
                  name={pet.icon}
                  filled
                  className="text-3xl text-primary"
                />
                <span className="text-sm font-semibold text-primary-dark">
                  {pet.label}
                </span>
              </div>
            ))}
          </div>
          <p className="mt-8 text-center text-sm text-primary-dark/50 max-w-2xl mx-auto">
            Unsure if we can board your pet? We do not accept venomous species, very large constrictors, or wild/protected animals —{" "}
            <a href="/contact" className="text-primary font-medium hover:underline">
              contact us
            </a>{" "}
            and we&apos;ll advise honestly.
          </p>
        </div>
      </section>

      {/* Pricing packages */}
      <section id="boarding-options" className="py-20 bg-secondary/20 scroll-mt-24">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={exoticPackageHeading.eyebrow}
            title={exoticPackageHeading.title}
            subtitle={exoticPackageHeading.subtitle}
          />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-10 mx-auto">
            {/* Small Mammal */}
            <CardPricing
              variant="standard"
              tierLabel="Small Mammal"
              price="₦6,000"
              unit="/night"
              features={[
                { label: "Rabbits, guinea pigs, hamsters", included: true },
                { label: "Species-appropriate enclosure", included: true },
                { label: "Daily health check", included: true },
                { label: "Climate-controlled reptile setup", included: false },
              ]}
              ctaLabel="Get Estimate"
              ctaHref={estimateUrl("boarding-exotic", null, "small")}
            />
            {/* Specialist */}
            <CardPricing
              variant="featured"
              tierLabel="Specialist"
              badgeLabel="Most Popular"
              price="₦12,000"
              unit="/night"
              features={[
                { label: "Birds or reptiles", included: true },
                { label: "Temp, humidity & UV monitoring", included: true },
                { label: "Custom feeding protocol", included: true },
                { label: "Daily photo updates", included: true },
              ]}
              ctaLabel="Get Estimate"
              ctaHref={estimateUrl("boarding-exotic", null, "specialist")}
            />
            {/* Premium Habitat */}
            <CardPricing
              variant="standard"
              tierLabel="Premium Habitat"
              price="₦18,000"
              unit="/night"
              features={[
                { label: "Complex multi-zone enclosures", included: true },
                { label: "Live/frozen feeder handling", included: true },
                { label: "Exotic vet daily review", included: true },
                { label: "Owner-supplied habitat setup", included: true },
              ]}
              ctaLabel="Get Estimate"
              ctaHref={estimateUrl("boarding-exotic", null, "premium")}
            />
          </div>
        </div>
      </section>

      {/* Feature grid */}
      <section className="py-20 bg-white border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <SectionHeading
            eyebrow={exoticFeaturesHeading.eyebrow}
            title={exoticFeaturesHeading.title}
          />
          <BoardingFeatureGrid features={exoticFeatures} />
        </div>
      </section>

      {/* Day in the life */}
      <BoardingDayInLife {...exoticDayInLife} />

      {/* Safety card */}
      <BoardingSafetyCard {...exoticSafetyCard} />

      {/* Feature band */}
      <FeatureBand {...exoticFeatureBand} />

      {/* CTA */}
      <section className="py-16 bg-surface-purple border-t border-surface-purple">
        <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
          <CtaPrimary
            heading={exoticCta.heading}
            body={exoticCta.body}
            primaryLabel={exoticCta.primaryLabel}
            primaryHref={exoticCta.primaryHref}
            primaryIcon={exoticCta.primaryIcon}
            secondaryLabel={exoticCta.secondaryLabel}
            secondaryHref={exoticCta.secondaryHref}
            secondaryIcon={exoticCta.secondaryIcon}
          />
        </div>
      </section>

      <BoardingSiblingLinks current="exotic" />

      {faqs.length > 0 ? (
        <section className="py-16 bg-surface-purple/40">
          <div className="max-w-7xl mx-auto px-4 md:px-10 lg:px-12">
            <SectionHeading
              eyebrow="FAQs"
              title="Frequently Asked Questions"
              spacing="mb-8"
            />
            <FaqAccordion
              faqs={faqs.map((f) => ({ question: f.question, answer: f.answer }))}
            />
            <p className="mt-6 text-sm text-primary-dark/50">
              More questions?{" "}
              <a href="/faq" className="text-primary font-medium hover:underline">
                View all FAQs
              </a>{" "}
              or{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                contact us
              </a>
              .
            </p>
          </div>
        </section>
      ) : null}

      <JsonLd
        data={serviceSchema(
          "Exotic Pet Boarding Abuja — Waggies",
          "Specialist boarding for birds, reptiles, rabbits, guinea pigs, and small mammals in custom enclosures with experienced handlers.",
          "/services/boarding/exotic",
        )}
      />
    </>
  );
}
