import { SimpleServicePage } from "@/components/waggies/sections/simple-service-page";
import {
  groomingHero,
  groomingSectionHeading,
  groomingFeatures,
  groomingFeatureBand,
} from "@/data/services";

export const metadata = {
  title: "Pet Grooming Spa",
  description:
    "Breed-specific pet grooming in Abuja — luxury baths, precision styling, nail trims, and de-shed treatments by certified groomers.",
  alternates: { canonical: "/services/grooming" },
  openGraph: {
    title: "Pet Grooming Spa Abuja — Waggies",
    description:
      "Breed-specific pet grooming in Abuja — luxury baths, precision styling, nail trims, and de-shed treatments by certified groomers.",
    url: "/services/grooming",
  },
};

export default function GroomingPage() {
  return (
    <SimpleServicePage
      title="Pet Grooming Spa"
      description="Breed-specific pet grooming in Abuja — luxury baths, precision styling, nail trims, and de-shed treatments by certified groomers."
      canonical="/services/grooming"
      ogTitle="Pet Grooming Spa Abuja — Waggies"
      ogDescription="Breed-specific pet grooming in Abuja — luxury baths, precision styling, nail trims, and de-shed treatments by certified groomers."
      crumbs={[
        { label: "Services", href: "/services" },
        { label: "Grooming", href: "/services/grooming" },
      ]}
      hero={groomingHero}
      featureSectionHeading={groomingSectionHeading}
      features={groomingFeatures}
      featureBand={groomingFeatureBand}
      faqCategory="grooming"
      schemaName="Pet Grooming Spa Abuja — Waggies"
      schemaDescription="Breed-specific pet grooming in Abuja — luxury baths, precision styling, nail trims, and de-shed treatments by certified groomers."
      schemaUrl="/services/grooming"
    />
  );
}
