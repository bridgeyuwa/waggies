import type { Metadata } from "next";
import { HeroHub } from "@/components/waggies/hero-hub";
import { BreadcrumbStrip } from "@/components/waggies/breadcrumb";
import { FaqPageClient } from "@/components/waggies/faq-page-client";
import { JsonLd, faqPageSchema } from "@/components/waggies/json-ld";
import { getActiveFaqs } from "@/data/faqs";

export const metadata: Metadata = {
  title: "Frequently Asked Questions",
  description:
    "Quick answers to the questions we hear most often about Waggies pet boarding, grooming, vet care, training, transport and relocation services in Abuja.",
  alternates: { canonical: "/faq" },
  openGraph: {
    title: "Frequently Asked Questions — Waggies",
    description:
      "Quick answers to the questions we hear most often about Waggies pet boarding, grooming, vet care, training, transport and relocation services in Abuja.",
    url: "/faq",
  },
};

/**
 * FAQ page — uses the `utility` layout pattern from Laravel (hero slot +
 * max-w-5xl content slot). We reproduce that here with a hero hub + a
 * max-w-5xl wrapper around the FAQ tabbed accordion.
 */
export default function FaqPage() {
  // Build FAQPage schema from the full active FAQ dataset (all categories).
  const faqs = getActiveFaqs();

  return (
    <>
      <BreadcrumbStrip
        className="bg-white border-b border-primary/5"
        crumbs={[{ label: "FAQ" }]}
      />

      <HeroHub type="faq" />

      <div className="max-w-5xl mx-auto px-4 md:px-10 py-12 md:py-20">
        <FaqPageClient />
      </div>

      <JsonLd
        data={faqPageSchema(
          faqs.map((f) => ({ question: f.question, answer: f.answer })),
        )}
      />
    </>
  );
}
