/**
 * /blog/category/[slug] — React port of resources/views/pages/blog/category.blade.php
 *
 * Lists published blog posts in a single category. Same structure as /blog
 * index but filtered by category. Eyebrow shows "Waggies Blog · Category".
 *
 *         + app/Http/Controllers/Blog/BlogController.php (category method)
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { LayoutListing } from "@/components/waggies/layout-listing";
import { HeroHub } from "@/components/waggies/hero-hub";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ContentFeaturedStory } from "@/components/waggies/content-featured-story";
import { ArticleCard } from "@/components/waggies/article-card";
import { Pagination } from "@/components/waggies/pagination";
import { NewsletterForm } from "@/components/waggies/newsletter-form";
import { JsonLd, collectionPageSchema } from "@/components/waggies/json-ld";
import { blogPosts, BlogCategories, BlogCategoryLabel } from "@/data/blog-posts";

const PAGE_SIZE = 12;

type Params = { slug: string };
type SearchParams = { page?: string };

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const label = BlogCategoryLabel(slug);
  return {
    title: `${label} — Blog`,
    description: `${label} articles from the Waggies Pet Care Blog.`,
    alternates: { canonical: `/blog/category/${slug}` },
    openGraph: {
      title: `${label} — Waggies Blog`,
      description: `${label} articles from the Waggies Pet Care Blog.`,
      url: `/blog/category/${slug}`,
    },
  };
}

export default async function BlogCategoryPage({
  params,
  searchParams,
}: {
  params: Promise<Params>;
  searchParams: Promise<SearchParams>;
}) {
  const { slug } = await params;
  const sp = await searchParams;
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  const validSlugs = BlogCategories.map((c) => c.slug);
  if (!validSlugs.includes(slug)) {
    notFound();
  }

  const label = BlogCategoryLabel(slug);
  const eyebrow = "Waggies Blog · Category";

  // Data file is already sorted by published_at DESC; preserve that order.
  const sorted = blogPosts.filter((p) => p.categorySlug === slug);
  const featured = sorted[0] ?? null;
  const rest = featured ? sorted.slice(1) : sorted;
  const totalPages = Math.max(1, Math.ceil(rest.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const paged = rest.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  return (
    <>
      <LayoutListing
        hero={
          <HeroHub
            type="blog"
            eyebrow={eyebrow}
            title={label}
            minHeight="420px"
          />
        }
        crumbs={[
          { label: "Blog", href: "/blog" },
          { label: label, href: `/blog/category/${slug}` },
        ]}
        sidebar={
          <div className="bg-surface-purple rounded-2xl p-6">
            <h3 className="font-semibold text-primary-dark mb-4">Categories</h3>
            <ul className="flex flex-col gap-2">
              <li>
                <a href="/blog" className="text-sm text-primary-dark/70 hover:text-primary transition">
                  All Posts
                </a>
              </li>
              {BlogCategories.map((cat) => (
                <li key={cat.slug}>
                  <a
                    href={`/blog/category/${cat.slug}`}
                    className={`text-sm hover:text-primary transition capitalize ${
                      cat.slug === slug
                        ? "text-primary font-semibold"
                        : "text-primary-dark/70"
                    }`}
                  >
                    {cat.label.toLowerCase()}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        }
        pagination={
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            baseUrl={`/blog/category/${slug}`}
            totalItems={rest.length}
            perPage={PAGE_SIZE}
          />
        }
      >
        {featured ? (
          <ContentFeaturedStory
            href={`/blog/${featured.slug}`}
            heroImageUrl={featured.heroImageUrl ?? ""}
            category={featured.category}
            title={featured.title}
            excerpt={featured.excerpt}
            author={featured.author}
            publishedAtText={featured.publishedAtText}
            readingTime={featured.readingTime}
            type="blog"
          />
        ) : null}

        {paged.length === 0 && !featured ? (
          <p className="text-primary-dark/50 text-sm">
            No posts in this category yet — check back soon.
          </p>
        ) : paged.length > 0 ? (
          <>
            {featured ? (
              <SectionHeading
                eyebrow="Category"
                title="More in this topic"
                className="mb-8"
              />
            ) : null}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {paged.map((post) => (
                <ArticleCard
                  key={post.slug}
                  href={`/blog/${post.slug}`}
                  // Laravel's $post->image_url is null for seeder-generated
                  // posts. Article cards on listing pages render NO image.
                  imageUrl={null}
                  category={post.category}
                  title={post.title}
                  excerpt={post.excerpt}
                  // Laravel blog/category card footer shows just the published
                  // date (no reading time). Reproduce that by passing empty
                  // readingTime here.
                  publishedAtText={post.publishedAtText}
                  readingTime=""
                  type="blog"
                />
              ))}
            </div>
          </>
        ) : null}
      </LayoutListing>

      <JsonLd
        data={collectionPageSchema(
          `${label} — Waggies Blog`,
          `/blog/category/${slug}`,
          `${label} articles from the Waggies Pet Care Blog.`,
        )}
      />
    </>
  );
}
