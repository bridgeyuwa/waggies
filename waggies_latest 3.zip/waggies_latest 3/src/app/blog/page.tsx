/**
 * /blog index — React port of resources/views/pages/blog/index.blade.php
 *
 * Lists published blog posts. Reproduces Laravel's `Post::published()->blog()`
 * ordering (latest first) with the first post as `$featured`, the next 12
 * paginated. Categories sidebar + newsletter widget.
 *
 *         + app/Http/Controllers/Blog/BlogController.php (index method)
 */

import type { Metadata } from "next";
import { LayoutListing } from "@/components/waggies/layout-listing";
import { HeroHub } from "@/components/waggies/hero-hub";
import { SectionHeading } from "@/components/waggies/section-heading";
import { ContentFeaturedStory } from "@/components/waggies/content-featured-story";
import { ArticleCard } from "@/components/waggies/article-card";
import { Pagination } from "@/components/waggies/pagination";
import { NewsletterForm } from "@/components/waggies/newsletter-form";
import { JsonLd, blogSchema } from "@/components/waggies/json-ld";
import { blogPosts, BlogCategories } from "@/data/blog-posts";

export const metadata: Metadata = {
  title: "Blog",
  description:
    "Expert pet care tips, advice, and stories from the Waggies team in Abuja, Nigeria.",
  alternates: { canonical: "/blog" },
  openGraph: {
    title: "Waggies Pet Care Blog",
    description:
      "Expert pet care tips, advice, and stories from the Waggies team in Abuja, Nigeria.",
    url: "/blog",
  },
};

const PAGE_SIZE = 12;

type SearchParams = { page?: string };

export default async function BlogIndexPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const sp = await searchParams;
  const page = Math.max(1, parseInt(sp.page ?? "1", 10) || 1);

  // The data file is already sorted by published_at DESC (matching Laravel's
  // latest('published_at')). Use the data file's order directly.
  const sorted = blogPosts;
  const featured = sorted[0] ?? null;
  const rest = featured ? sorted.slice(1) : sorted;
  const totalPages = Math.max(1, Math.ceil(rest.length / PAGE_SIZE));
  const currentPage = Math.min(page, totalPages);
  const paged = rest.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

  return (
    <>
      <LayoutListing
        hero={<HeroHub type="blog" />}
        crumbs={[{ label: "Blog", href: "/blog" }]}
        sidebar={
          <>
            <div className="bg-surface-purple rounded-2xl p-6">
              <h3 className="font-semibold text-primary-dark mb-4">Categories</h3>
              <ul className="flex flex-col gap-2">
                <li>
                  <a href="/blog" className="text-sm font-semibold text-primary">
                    All Posts
                  </a>
                </li>
                {BlogCategories.map((cat) => (
                  <li key={cat.slug}>
                    <a
                      href={`/blog/category/${cat.slug}`}
                      className="text-sm text-primary-dark/70 hover:text-primary transition capitalize"
                    >
                      {cat.label.toLowerCase()}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
            <div className="bg-primary rounded-2xl p-6">
              <h3 className="font-semibold text-white mb-2">Stay Updated</h3>
              <p className="text-white/70 text-sm mb-4">
                Get the latest pet care tips delivered to your inbox.
              </p>
              <NewsletterForm title="" subtitle="" buttonLabel="Subscribe" />
            </div>
          </>
        }
        pagination={
          <Pagination
            currentPage={currentPage}
            totalPages={totalPages}
            baseUrl="/blog"
            totalItems={rest.length}
            perPage={PAGE_SIZE}
          />
        }
      >
        {featured ? (
          <ContentFeaturedStory
            href={`/blog/${featured.slug}`}
            heroImageUrl={featured.heroImageUrl ?? ""}
            category={featured.category}
            title={featured.title}
            excerpt={featured.excerpt}
            author={featured.author}
            publishedAtText={featured.publishedAtText}
            readingTime={featured.readingTime}
            type="blog"
          />
        ) : null}

        {paged.length === 0 && !featured ? (
          <p className="text-primary-dark/50 text-sm">
            No posts published yet — check back soon.
          </p>
        ) : paged.length > 0 ? (
          <>
            <SectionHeading
              eyebrow={featured ? "Latest" : undefined}
              title={featured ? "More Articles" : "All Articles"}
              className="mb-8"
            />
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
              {paged.map((post) => (
                <ArticleCard
                  key={post.slug}
                  href={`/blog/${post.slug}`}
                  // Laravel's $post->image_url is null for seeder-generated posts
                  // (PostFactory sets 'image' => null). The article cards on
                  // listing pages render NO image — just the surface-purple
                  // background — when image_url is null. Pass undefined to
                  // match that behaviour.
                  imageUrl={null}
                  category={post.category}
                  title={post.title}
                  excerpt={post.excerpt}
                  publishedAtText={post.publishedAtText}
                  readingTime={post.readingTime}
                  type="blog"
                />
              ))}
            </div>
          </>
        ) : null}
      </LayoutListing>

      <JsonLd
        data={blogSchema(
          "Waggies Pet Care Blog",
          "Expert pet care tips, advice, and stories from the Waggies team in Abuja, Nigeria.",
          "/blog",
        )}
      />
    </>
  );
}
