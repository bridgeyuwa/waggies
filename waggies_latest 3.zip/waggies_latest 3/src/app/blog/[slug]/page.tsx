/**
 * /blog/[slug] — React port of resources/views/pages/blog/show.blade.php
 *
 * Single blog article. Renders the hero with the post's image + title +
 * excerpt, then the article body (already-rendered HTML from dist/) via
 * dangerouslySetInnerHTML. Sidebar shows up to 3 related articles in the
 * same category + a "Get Care Tips" newsletter widget.
 *
 *         + app/Http/Controllers/Blog/BlogController.php (show method)
 */

import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { LayoutContent } from "@/components/waggies/layout-content";
import { HeroImage } from "@/components/waggies/hero-image";
import { NewsletterForm } from "@/components/waggies/newsletter-form";
import { JsonLd, blogPostingSchema } from "@/components/waggies/json-ld";
import { blogPosts, BlogCategoryLabel } from "@/data/blog-posts";

type Params = { slug: string };

export async function generateMetadata({
  params,
}: {
  params: Promise<Params>;
}): Promise<Metadata> {
  const { slug } = await params;
  const post = blogPosts.find((p) => p.slug === slug);
  if (!post) {
    return { title: "Article Not Found" };
  }
  return {
    title: post.title,
    description: post.excerpt ?? undefined,
    alternates: { canonical: `/blog/${slug}` },
    openGraph: {
      title: post.title,
      description: post.excerpt ?? undefined,
      url: `/blog/${slug}`,
      images: post.heroImageUrl ? [{ url: post.heroImageUrl }] : undefined,
    },
  };
}

export default async function BlogShowPage({
  params,
}: {
  params: Promise<Params>;
}) {
  const { slug } = await params;
  const post = blogPosts.find((p) => p.slug === slug);

  if (!post) {
    notFound();
  }

  // Use the related slugs extracted verbatim from the Laravel dist sidebar
  // ("More Articles"). This preserves Laravel's exact selection and ordering.
  const related = (post.relatedSlugs ?? [])
    .map((slug) => blogPosts.find((p) => p.slug === slug))
    .filter((p): p is NonNullable<typeof p> => p !== undefined)
    .slice(0, 3);

  const categoryLabel = BlogCategoryLabel(post.categorySlug);

  return (
    <>
      <LayoutContent
        hero={
          <HeroImage
            imageSrc={post.heroImageUrl ?? ""}
            imageAlt={post.title}
            eyebrow={categoryLabel}
            eyebrowIcon="article"
            title={post.title}
            subtitle={post.excerpt ?? undefined}
            minHeight="420px"
          />
        }
        crumbs={[
          { label: "Blog", href: "/blog" },
          { label: categoryLabel, href: `/blog/category/${post.categorySlug}` },
          { label: post.title, href: `/blog/${post.slug}` },
        ]}
        sidebar={
          <>
            <div className="bg-surface-purple rounded-2xl p-6">
              <h3 className="font-semibold text-primary-dark mb-3">More Articles</h3>
              {related.length === 0 ? (
                <p className="text-sm text-primary-dark/50">No related articles yet.</p>
              ) : (
                <ul className="flex flex-col gap-3">
                  {related.map((r) => (
                    <li key={r.slug}>
                      <a
                        href={`/blog/${r.slug}`}
                        className="text-sm text-primary-dark/70 hover:text-primary transition leading-snug block"
                      >
                        {r.title}
                      </a>
                    </li>
                  ))}
                </ul>
              )}
            </div>
            <div className="bg-primary rounded-2xl p-6">
              <h3 className="font-semibold text-white mb-2">Get Care Tips</h3>
              <p className="text-white/70 text-sm mb-4">
                Subscribe for expert pet care advice from the Waggies team.
              </p>
              <NewsletterForm title="" subtitle="" buttonLabel="Subscribe" />
            </div>
          </>
        }
      >
        <article>
          <p className="text-sm text-primary-dark/40 mb-8">
            By {post.author}
            {" · "}
            {post.publishedAtText}
            {post.readingTime ? ` · ${post.readingTime}` : ""}
          </p>
          <div
            className="prose max-w-none"
            dangerouslySetInnerHTML={{ __html: post.bodyHtml }}
          />
        </article>
      </LayoutContent>

      <JsonLd
        data={blogPostingSchema({
          headline: post.title,
          description: post.excerpt ?? "",
          author: post.author ?? undefined,
          datePublished: post.publishedAtText || undefined,
          url: `/blog/${post.slug}`,
          image: post.heroImageUrl ?? undefined,
        })}
      />
    </>
  );
}
