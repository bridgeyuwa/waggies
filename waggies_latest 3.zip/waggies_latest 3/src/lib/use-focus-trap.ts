"use client";

import { useEffect, useRef } from "react";

/**
 * Focus trap hook — emulates Alpine's `x-trap` directive.
 *
 * When `active` is true:
 *   - The first focusable element inside `containerRef.current` receives focus
 *     (after a tick to allow rendering).
 *   - Tab / Shift+Tab cycles focus among focusable elements within the
 *     container only.
 *   - The element that was focused immediately before activation is remembered
 *     and restored when `active` becomes false.
 *
 * This reproduces the behavior of `x-trap="mobileOpen"` on the Waggies mobile
 * menu in the Laravel/Alpine source (resources/views/components/navbar.blade.php
 * line 302), which relies on `@alpinejs/focus`.
 *
 * Limitations vs. Alpine's x-trap (preserved as-is, since the original
 * behavior is the visual/behavioral source of truth):
 *   - Alpine restores focus on deactivation; this hook does the same.
 *   - Alpine also traps `Tab` natively; this hook implements the same cycle.
 */
export function useFocusTrap<T extends HTMLElement = HTMLElement>(
  active: boolean,
): React.RefObject<T | null> {
  const containerRef = useRef<T | null>(null);
  const previousActiveRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    if (!active) {
      return;
    }

    const container = containerRef.current;
    if (!container) {
      return;
    }

    // Remember the element that had focus before we opened the trap.
    previousActiveRef.current = (document.activeElement as HTMLElement) ?? null;

    const focusableSelectors = [
      "a[href]",
      "button:not([disabled])",
      "textarea:not([disabled])",
      "input:not([disabled])",
      "select:not([disabled])",
      '[tabindex]:not([tabindex="-1"])',
    ];

    const getFocusable = (): HTMLElement[] => {
      if (!container) return [];
      return Array.from(
        container.querySelectorAll<HTMLElement>(focusableSelectors.join(",")),
      ).filter((el) => el.offsetParent !== null || el === document.activeElement);
    };

    // Move focus into the container on the next tick (let layout settle).
    const raf = requestAnimationFrame(() => {
      const items = getFocusable();
      if (items.length > 0) {
        items[0]?.focus();
      } else {
        // No focusable children — focus the container itself so keyboard
        // events still land inside the trap.
        container.focus();
      }
    });

    const handleKeydown = (event: KeyboardEvent) => {
      if (event.key !== "Tab") {
        return;
      }
      const items = getFocusable();
      if (items.length === 0) {
        event.preventDefault();
        return;
      }
      const first = items[0];
      const last = items[items.length - 1];
      if (!first || !last) return;

      if (event.shiftKey) {
        if (document.activeElement === first) {
          event.preventDefault();
          last.focus();
        }
      } else {
        if (document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };

    container.addEventListener("keydown", handleKeydown);

    return () => {
      cancelAnimationFrame(raf);
      container.removeEventListener("keydown", handleKeydown);
      // Restore focus to the previously-focused element on deactivation.
      const prev = previousActiveRef.current;
      if (prev && typeof prev.focus === "function") {
        prev.focus();
      }
      previousActiveRef.current = null;
    };
  }, [active]);

  return containerRef;
}
