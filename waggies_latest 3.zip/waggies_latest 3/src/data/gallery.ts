/**
 * Photo Gallery page content — extracted verbatim from the Laravel Blade
 * source of truth.
 *
 *   - Page header (ui.page-header): lines 5–9
 *   - Gallery section (3 groups):   lines 11–51
 *     · Boarding (8 images):        lines 14–24
 *     · Grooming (4 images):        lines 26–36
 *     · Happy Guests (8 images):    lines 38–48
 *
 * Component defaults referenced:
 *   - components/ui/page-header.blade.php  (variant='purple', align='left')
 *   - components/section-heading.blade.php (spacing='mb-16', but Blade
 *     passes class="mb-8" override on each group heading)
 *
 * NOTE — anomaly preserved verbatim from source:
 *   All 20 image paths (`/images/gallery/boarding-*.jpg`,
 *   `/images/gallery/grooming-*.jpg`, `/images/gallery/guests-*.jpg`)
 *   404 in the live Laravel site (Phase 2 decision: preserve broken
 *   paths verbatim — the next.js migration will continue to surface them
 *   as broken <img> until assets are sourced).
 *
 * The Blade source uses `@foreach(range(1, N) as $i)` to emit
 * `/images/gallery/<prefix>-<i>.jpg`. We reconstruct the same sequence
 * here using a `range(1, N)` helper so the data file mirrors the
 * original generation pattern. The expanded image paths are NOT
 * duplicated by hand — consumers should iterate `galleryGroups[i].imagePaths`.
 *
 * DO NOT paraphrase, modernize, abbreviate, or "improve" this content.
 */

// ── Page header ───────────────────────────────────────────────────────────

export type GalleryHero = {
  eyebrow: string;
  title: string;
  subtitle: string;
};

export const galleryHero: GalleryHero = {
  eyebrow: "Photo Gallery",
  title: "Take a Look Inside",
  subtitle:
    "Our facilities speak for themselves. Browse our boarding suites, grooming spa, play areas, and the happy faces of our guests.",
} as const;

// ── Gallery groups (3) ────────────────────────────────────────────────────

export type GalleryGroup = {
  /** `eyebrow` prop on the `section-heading` component. */
  eyebrow: string;
  /** `title` prop — `Boarding Suites &amp; Play Areas` decoded to `&`. */
  title: string;
  /** Optional `class` override passed to section-heading. */
  headingClass: string;
  /** Image filename prefix — e.g. "boarding", "grooming", "guests". */
  prefix: string;
  /** Number of images in this group (range(1, N) from Blade). */
  count: number;
  /**
   * Expanded image paths — `/images/gallery/<prefix>-<i>.jpg` for i in
   * 1..count. These are the exact strings the Blade `@foreach(range(1, N))`
   * loop would emit.
   */
  imagePaths: string[];
  /** Alt text template — `Boarding facility photo 1`, etc. (index substituted). */
  altTemplate: string;
  /** Grid cell Tailwind classes (preserved verbatim from Blade). */
  cellClassName: string;
  /** <img> Tailwind classes (preserved verbatim from Blade). */
  imgClassName: string;
};

/**
 * Mirrors Laravel's `range(1, N)` helper — returns `[1, 2, ..., N]`.
 * Used only to build the `imagePaths` arrays at module load time.
 */
function range(start: number, end: number): number[] {
  const out: number[] = [];
  for (let i = start; i <= end; i++) out.push(i);
  return out;
}

function buildImagePaths(prefix: string, count: number): string[] {
  return range(1, count).map((i) => `/images/gallery/${prefix}-${i}.jpg`);
}

export const galleryGroups: GalleryGroup[] = [
  {
    eyebrow: "Boarding",
    title: "Boarding Suites & Play Areas",
    headingClass: "mb-8",
    prefix: "boarding",
    count: 8,
    imagePaths: buildImagePaths("boarding", 8),
    altTemplate: "Boarding facility photo {i}",
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },
  {
    eyebrow: "Grooming",
    title: "Grooming Spa",
    headingClass: "mb-8",
    prefix: "grooming",
    count: 4,
    imagePaths: buildImagePaths("grooming", 4),
    altTemplate: "Grooming spa photo {i}",
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },
  {
    eyebrow: "Happy Guests",
    title: "Our Wonderful Guests",
    headingClass: "mb-8",
    prefix: "guests",
    count: 8,
    imagePaths: buildImagePaths("guests", 8),
    altTemplate: "Happy guest photo {i}",
    cellClassName:
      "aspect-square rounded-2xl bg-surface-purple overflow-hidden",
    imgClassName:
      "w-full h-full object-cover hover:scale-105 transition-transform duration-500",
  },
];
