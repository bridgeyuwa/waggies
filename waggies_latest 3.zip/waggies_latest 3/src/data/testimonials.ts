/**
 * Testimonials page content — extracted verbatim from the Laravel Blade
 * source of truth.
 *
 *   - Hero (split):           lines 5–18
 *   - Testimonials grid (9):  lines 20–52
 *   - Bottom CTA section:     lines 54–72
 *     · Inline heading + link: lines 55–63
 *     · cta.tertiary component: lines 66–68 (passed non-standard
 *       `primaryCta` / `secondaryCta` props that the component does NOT
 *       declare — preserved verbatim as data; the component's actual
 *       declared props are `heading`, `body`, `cta_label`, `cta_href`,
 *       `icon`)
 *
 * Component defaults referenced:
 *   - components/hero/split.blade.php  (rating='4.9', review_count='500+',
 *     primary_href='#', primary_icon='arrow_forward')
 *   - components/card/testimonial.blade.php (stars=5, authorInitial='A')
 *
 * Route translations applied:
 *   route('services.boarding.index') → /services/boarding
 *   route('contact')                 → /contact
 *
 * NOTE — anomaly preserved verbatim from source:
 *   The hero image_src `/images/gallery/boarding-1.jpg` 404s in the live
 *   Laravel site (per Phase 2 decision to preserve broken gallery image
 *   paths). The path is preserved here exactly.
 *
 * DO NOT paraphrase, modernize, abbreviate, or "improve" this content.
 */

// ── Hero ──────────────────────────────────────────────────────────────────

export type TestimonialsHero = {
  eyebrow: string;
  eyebrowIcon: string;
  /** Raw HTML — Blade renders via `{!! $title !!}`. Contains <br />. */
  title: string;
  subtitle: string;
  imageSrc: string;
  imageAlt: string;
  rating: string;
  reviewCount: string;
  primaryLabel: string;
  primaryHref: string;
  secondaryLabel: string;
  secondaryHref: string;
};

export const testimonialsHero: TestimonialsHero = {
  eyebrow: "What Clients Say",
  eyebrowIcon: "reviews",
  title: "Trusted by 500+<br />Abuja Pet Owners",
  subtitle:
    "Don't take our word for it — here's what our clients have to say about their Waggies experience.",
  imageSrc: "/images/gallery/boarding-1.jpg",
  imageAlt: "Happy dog at Waggies boarding facility",
  rating: "4.9",
  reviewCount: "500+",
  primaryLabel: "Book a Stay",
  primaryHref: "/services/boarding",
  secondaryLabel: "Contact Us",
  secondaryHref: "/contact",
} as const;

// ── Testimonials grid (9 items) ───────────────────────────────────────────

export type Testimonial = {
  stars: number;
  quote: string;
  authorInitial: string;
  authorName: string;
  authorSubtitle: string;
};

export const testimonials: Testimonial[] = [
  {
    stars: 5,
    quote:
      "Waggies is the only place I'd trust with my dog. The daily photo updates gave me real peace of mind while I was travelling.",
    authorInitial: "A",
    authorName: "Adaeze O.",
    authorSubtitle: "Dog owner · Maitama",
  },
  {
    stars: 5,
    quote:
      "The grooming team transformed my Persian cat. She looked like she'd come straight from a pet show!",
    authorInitial: "E",
    authorName: "Emeka N.",
    authorSubtitle: "Cat owner · Wuse II",
  },
  {
    stars: 5,
    quote:
      "Our relocation from London was seamless. Every document was sorted — zero stress on our end.",
    authorInitial: "F",
    authorName: "Fatima M.",
    authorSubtitle: "Relocation client · Asokoro",
  },
  {
    stars: 5,
    quote:
      "The facilities are genuinely world-class. I've boarded dogs in Dubai and London — Waggies is right up there.",
    authorInitial: "C",
    authorName: "Chukwudi B.",
    authorSubtitle: "Dog owner · Garki",
  },
  {
    stars: 5,
    quote:
      "My puppy finished the training programme a completely different dog. Patient, focused and brilliant with him.",
    authorInitial: "N",
    authorName: "Ngozi T.",
    authorSubtitle: "Training client · Gwarinpa",
  },
  {
    stars: 5,
    quote:
      "Brought my cat in for grooming after she got into a mess outside. Came back looking and smelling amazing. Great service.",
    authorInitial: "S",
    authorName: "Sola A.",
    authorSubtitle: "Cat owner · Jabi",
  },
  {
    stars: 5,
    quote:
      "The vet saw my dog the same day I called. Thorough, professional and really genuinely caring. Exactly what we needed.",
    authorInitial: "K",
    authorName: "Kemi L.",
    authorSubtitle: "Dog owner · Utako",
  },
  {
    stars: 5,
    quote:
      "Transport service is brilliant — on time, air-conditioned and my dogs arrive calm every single time.",
    authorInitial: "Y",
    authorName: "Yemi F.",
    authorSubtitle: "Dog owner · Wuse",
  },
  {
    stars: 5,
    quote:
      "We've used Waggies for boarding, grooming, and transport. Consistently excellent. Our pets love it.",
    authorInitial: "O",
    authorName: "Obiageli R.",
    authorSubtitle: "Multi-service client · Maitama",
  },
];

// ── Bottom CTA ────────────────────────────────────────────────────────────

export type TestimonialsBottomCta = {
  heading: string;
  body: string;
  ctaLabel: string;
  ctaHref: string;
  ctaIcon: string;
  /**
   * The Blade source wraps a `cta.tertiary` component invocation INSIDE
   * the same purple section (lines 66–68). The Blade author passed
   * non-standard props (`primaryCta`, `secondaryCta`) that the
   * `cta.tertiary` component does not actually declare. Preserved here
   * verbatim — note that these would have been silently swallowed by
   * Laravel's attribute bag in the original site.
   */
  tertiary: {
    heading: string;
    body: string;
    primaryCta: string;
    secondaryCta: string;
  };
};

export const testimonialsBottomCta: TestimonialsBottomCta = {
  heading: "Experience it for yourself",
  body: "Join hundreds of satisfied Abuja pet owners who trust Waggies with the animals they love most.",
  ctaLabel: "Get in Touch",
  ctaHref: "/contact",
  ctaIcon: "arrow_forward",
  tertiary: {
    heading: "Experience it for yourself",
    body: "Join hundreds of satisfied Abuja pet owners who trust Waggies with the animals they love most.",
    primaryCta: "Book a Tour",
    secondaryCta: "Get in Touch",
  },
} as const;
