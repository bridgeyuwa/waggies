/**
 * Hardcoded homepage content — extracted verbatim from the Laravel Blade
 * source: resources/views/pages/home.blade.php.
 *
 * The homepage is NOT database-driven. Every section is hardcoded in the
 * Blade template. We mirror that exactly here as typed constants.
 *
 * DO NOT paraphrase or "improve" this content.
 */

// ── Homepage services grid (6 cards) ──────────────────────────────────────
// Source: home.blade.php lines 21–48 (six <x-card.service> invocations)

export type HomeServiceCard = {
  title: string;
  description: string;
  href: string;
  imageSrc: string;
  icon: string;
};

export const homeServiceCards: HomeServiceCard[] = [
  {
    title: "Luxury Boarding",
    description:
      "Premium overnight stays in spacious, climate-controlled suites with 24/7 care.",
    href: "/services/boarding",
    imageSrc:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuA-hFLGUTZfR4o6aEmNZblS2r51j254QMcrSmpvNX3gqf_PRrK4s4gMZDlNMovWT6w3T_GpetAuHCroSsYBK9jakgwd2tcq-ncK3OC3Fa6axI61kTa1IUJICwA8mYBa_rhA2Dh3TV4uIXJb1O0Iw2sQ6qnHppigFgxpAQsDbWg5tzx-r9sNF_2M5pObOb8oTnakgOtF80OU4vK6ClwuKgdFGRmhd6aGpTjFzvD15SopA7DUGZ8JNDxSSDPkN9SlBhE41EDqGmI6Axfm",
    icon: "apartment",
  },
  {
    title: "Grooming Spa",
    description:
      "Breed-specific treatments, luxury baths, and styling by certified pet groomers.",
    href: "/services/grooming",
    imageSrc:
      "https://images.unsplash.com/photo-1516734212186-a967f81ad0d7?w=600&h=400&fit=crop&q=80",
    icon: "spa",
  },
  {
    title: "Vet Care",
    description:
      "On-site veterinary consultations, vaccinations, and wellness check-ups.",
    href: "/services/vet-care",
    imageSrc:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuDTHx-2eTZ7bwYucOWHLo7yqtzUxvxjRdAb4ZpHiWevyYa1KvptQ3f-zghgc_4vKzVAfs5vVlPV2rgs7kI2FCajkWDLoMdjPapYSNyqkdN0kZsErZv9eix2rZBmjWcDSPL6cGjQ_-2weGgk7JKU6Xd6gpDTPlWDn49qUugijUJdlSwBRKd42KKg_9KKij4oO59SWhw0jGlM3Ehw32RTSVkI9bQtSRXzJ1qVFkmRnmqBkOnCjPsogYNb93pTrK6HhXijRWCk7Y3EebHF",
    icon: "medical_services",
  },
  {
    title: "Dog Training",
    description:
      "Positive-reinforcement training programmes for puppies and adult dogs.",
    href: "/services/training",
    imageSrc:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuBmd8xXxW_oQhjGyRngta_b_G0TdAztFfgHUHcn5btMzOIh3q3eQk9tbqth3qPo9CWbuMYp8WpoWcpQM_5jT7uiC9VRtOxUAeYt6LloE-jFSki2BUrXQqQiGy3nTIVvjhj66UOsmWcxUq5Lz30b-5vlokWvpK0FUB897pMCrrNFKH7Tmc9VExw20xfsBZd8dgqysHE0Ig3d3NLp0P9ZGwWT0ZoVW-g6E7l50ZAoj9EAGz6RpKd8IvyX6y5dQBM0AGt2upSp4a0vHE7J",
    icon: "school",
  },
  {
    title: "Pet Relocation",
    description:
      "Stress-free international pet moves with full documentation support.",
    href: "/relocation",
    imageSrc:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuD8zMeLP6ESzVNlEiUIMeqNo39rxSo0QWsdUUPiub856XZD95tgaC9TVYlM5InAGjQF5PBkOieuBiJ2FYOjI8Y7mAz3_5bVSzQ9Q-W4nKTuqrpH_e_V0gh2mznDCDB66JIruUaeX7g4-pF9lQUw9xAqL-ijY2fdaAaAeW_nJ93dvvjroQShmAIefL-FlJGH_2f4x7Tiy67wVdeChUVSQ4xOdWr9ezWlY3DB_Q0spNNoCnO-FbpB9o3e-aMrSGk1wci_fRiv-MzgZAZd",
    icon: "flight_takeoff",
  },
  {
    title: "Local Transport",
    description:
      "Door-to-door pickup and drop-off across Abuja, in air-conditioned vehicles.",
    href: "/services/transport",
    imageSrc: "/images/transport.jpg",
    icon: "local_shipping",
  },
];

// ── Homepage feature band (5 features) ────────────────────────────────────
// Source: home.blade.php lines 54–82 (x-feature-band :features array)

export type Feature = {
  icon: string;
  title: string;
  description: string;
};

export const homeFeatureBandFeatures: Feature[] = [
  {
    icon: "verified",
    title: "PCSA Certified",
    description:
      "Fully licensed by the Pet Care Services Association of Nigeria.",
  },
  {
    icon: "medical_services",
    title: "On-site Vet",
    description: "A qualified veterinarian is on-site every day of the week.",
  },
  {
    icon: "lock_clock",
    title: "24/7 Supervision",
    description:
      "Your pets are monitored around the clock — never left alone.",
  },
  {
    icon: "hotel",
    title: "Luxury Suites",
    description:
      "Spacious, climate-controlled suites with orthopedic bedding.",
  },
  {
    icon: "notifications",
    title: "Daily Photo Updates",
    description: "Receive photos and updates on your pet every single day.",
  },
];

// ── Homepage testimonials (3 cards) ───────────────────────────────────────
// Source: home.blade.php lines 89–98 (also reused on services index & boarding)

export type Testimonial = {
  stars: number;
  quote: string;
  authorInitial: string;
  authorName: string;
  authorSubtitle: string;
};

export const homeTestimonials: Testimonial[] = [
  {
    stars: 5,
    quote:
      "Waggies is the only place I'd trust with my dog. The daily updates give me real peace of mind.",
    authorInitial: "A",
    authorName: "Adaeze O.",
    authorSubtitle: "Dog owner · Maitama",
  },
  {
    stars: 5,
    quote:
      "The grooming team transformed my Persian cat. She looked like she'd come straight from a pet show!",
    authorInitial: "E",
    authorName: "Emeka N.",
    authorSubtitle: "Cat owner · Wuse II",
  },
  {
    stars: 5,
    quote:
      "Our relocation from London was seamless. Every document was sorted — zero stress on our end.",
    authorInitial: "F",
    authorName: "Fatima M.",
    authorSubtitle: "Relocation client · Asokoro",
  },
];

// ── Homepage guides section (1 featured card + 4 row cards) ──────────────
// Source: home.blade.php lines 103–154

export type HomeGuideRowCard = {
  icon: string;
  title: string;
  meta: string;
  href: string;
  badge?: string;
  badgeVariant?: "success" | "primary";
};

/** The single large featured guide card at the top of the section. */
export const homeFeaturedGuide = {
  title: "The Complete Pet Relocation Checklist for Nigeria",
  description:
    "Everything you need to move your pet internationally — documents, timelines, vaccinations, and airline requirements in one place.",
  downloadUrl: "/?relocation-checklist",
  readUrl: "/relocation/checklist?relocation-checklist",
  pages: 12,
} as const;

/** The four smaller guide row cards below the featured card. */
export const homeGuideRowCards: HomeGuideRowCard[] = [
  {
    icon: "vaccines",
    title: "Nigeria Pet Vaccination Schedule 2026",
    meta: "Vet-approved · 8 min read · Vaccination",
    href: "/guides/#",
    badge: "Updated",
    badgeVariant: "success",
  },
  {
    icon: "flight",
    title: "Airline Pet Policies: Which Airlines Fly Pets from Lagos?",
    meta: "Relocation · 10 min read · International Travel",
    href: "/guides/#",
    badge: "Popular",
    badgeVariant: "primary",
  },
  {
    icon: "content_cut",
    title: "Home Grooming Basics: A Step-by-Step Dog Guide",
    meta: "Grooming · 6 min read · Beginner-friendly",
    href: "/guides/#",
  },
  {
    icon: "health_and_safety",
    title: "Signs Your Dog Needs Immediate Vet Attention",
    meta: "Vet Care · 5 min read · Health",
    href: "/guides/#",
  },
];

// ── Homepage shop teaser (4 product cards) ────────────────────────────────
// Source: home.blade.php lines 192–348 (4 hardcoded product cards with
// different states: bestseller, sale, new, out-of-stock)

export type ShopProduct = {
  /** Badge variant. `out-of-stock` renders grayscale + overlay. */
  state: "bestseller" | "sale" | "new" | "out-of-stock";
  wishlistActive?: boolean;
  image: string;
  category: string;
  title: string;
  rating: number;
  reviewCount: number;
  price: string;
  /** Optional strike-through original price (sale state only). */
  originalPrice?: string;
  /** Muted price color (out-of-stock only). */
  priceMuted?: boolean;
};

export const homeShopProducts: ShopProduct[] = [
  {
    state: "bestseller",
    image:
      "https://images.unsplash.com/photo-1535591273668-578e31182c4f?w=400&h=350&fit=crop&q=80",
    category: "Food & Treats",
    title: "Royal Canin Maxi Adult Dog Food 15kg",
    rating: 4.8,
    reviewCount: 124,
    price: "₦28,500",
  },
  {
    state: "sale",
    wishlistActive: true,
    image:
      "https://images.unsplash.com/photo-1601758228041-f3b2795255f1?w=400&h=350&fit=crop&q=80",
    category: "Grooming",
    title: "Professional Deshedding Brush — All Breeds",
    rating: 4.6,
    reviewCount: 89,
    price: "₦6,400",
    originalPrice: "₦8,500",
  },
  {
    state: "new",
    image:
      "https://media.istockphoto.com/id/174843968/photo/a-brown-leather-dog-collar-with-metal-accents.webp?a=1&b=1&s=612x612&w=0&k=20&c=wzpxsd9BdjND9mLiuUe1J_0D2qZxEtNPURKORpYZ_4Q=",
    category: "Accessories",
    title: "Waggies Signature Leather Pet Collar",
    rating: 5.0,
    reviewCount: 17,
    price: "₦12,000",
  },
  {
    state: "out-of-stock",
    image:
      "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=400&h=350&fit=crop&q=80",
    category: "Health & Vet",
    title: "Tick & Flea Prevention Drops — 3 Month",
    rating: 4.9,
    reviewCount: 203,
    price: "₦9,800",
    priceMuted: true,
  },
];

// ── Homepage shop category filter pills ───────────────────────────────────
// Source: home.blade.php lines 176–189

export const homeShopCategoryPills: ReadonlyArray<{
  label: string;
  active?: boolean;
}> = [
  { label: "All", active: true },
  { label: "Food & Treats" },
  { label: "Grooming" },
  { label: "Accessories" },
  { label: "Health & Vet" },
];

// ── Homepage hero sections ─────────────────────────────────────────────────
// Source: home.blade.php lines 2–13

export const homeHeroImage = {
  imageSrc:
    "https://images.unsplash.com/photo-1650454027983-e2b8fe55b30b?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGx1eHVyeSUyMGRvZyUyMGJvYXJkaW5nJTIwZmFjaWxpdHklMjBpbmRvb3IlMjBtb2Rlcm4lMjBjbGVhbiUyMGRvZyUyMHN1aXRlfGVufDB8fDB8fHww",
  eyebrow: "Abuja's #1 Pet Services",
  title: "Premium pet services in the heart of Abuja",
  subtitle:
    "From international relocation to 5-star boarding suites. We provide world-class veterinary and grooming services tailored for the discerning pet owner.",
  primaryCta: { label: "Book a Stay", href: "/services/boarding" },
  secondaryCta: { label: "View Services", href: "/services" },
  variant: "center" as const,
};

export const homeHeroGradient = {
  rating: "4.3",
  imageSrc:
    "https://images.unsplash.com/photo-1650454027983-e2b8fe55b30b?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGx1eHVyeSUyMGRvZyUyMGJvYXJkaW5nJTIwZmFjaWxpdHklMjBpbmRvb3IlMjBtb2Rlcm4lMjBjbGVhbiUyMGRvZyUyMHN1aXRlfGVufDB8fDB8fHww",
  eyebrow: "Experience the Waggies Difference",
  title: "Where Luxury Meets Compassionate Care",
  subtitle:
    "Our state-of-the-art facility in Abuja offers a unique blend of opulence and expert care, ensuring your pet's comfort and well-being at every visit.",
  primaryCta: { label: "Take a Virtual Tour", href: "/contact" },
  secondaryCta: { label: "Meet Our Team", href: "/contact" },
};

// ── Homepage CTA primary section ──────────────────────────────────────────
// Source: home.blade.php lines 369–379

export const homeCtaPrimary = {
  eyebrowIcon: "pets",
  eyebrowText: "Trusted Pet Care",
  heading: "Give Your Pet the",
  headingAccent: "Care They Deserve",
  body: "Book a consultation today and get a tailored care plan from our veterinary team.",
  primaryLabel: "Book Appointment",
  primaryHref: "/services/pricing",
  primaryIcon: "arrow_forward",
  secondaryLabel: "Get Estimate",
  secondaryHref: "/services/pricing",
  secondaryIcon: "calculate",
} as const;
