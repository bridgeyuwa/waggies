/**
 * guides content — extracted verbatim from the Laravel dist/ folder.
 *
 *
 * The Laravel site seeds this content from Faker (Latin lorem-ipsum). The
 * dist/ folder is the canonical state at export time — re-running the
 * seeder would produce different content. We extract from dist/ to
 * guarantee byte-for-byte parity with the live site.
 *
 * DO NOT paraphrase, modernize, abbreviate, or "improve" this content.
 * The Laravel application is the canonical source of truth for the migration.
 */

export type GuidePost = {
  slug: string;
  title: string;
  excerpt: string | null;
  category: string;
  /** Kebab-case category slug (e.g. "health-vet"). */
  categorySlug: string;
  /** Author name. Null for KB articles (which have no byline). */
  author: string | null;
  /** Original published-at display string (e.g. "April 27, 2026"). Empty for KB. */
  publishedAtText: string;
  /** Reading-time label (e.g. "1 min read"). Empty for KB. */
  readingTime: string;
  heroImageUrl: string | null;
  /** Inner HTML of the article body — already-rendered <p>, <h2>, <ul> etc.
   *  Use dangerouslySetInnerHTML to render. */
  bodyHtml: string;
  wordCount: number;
  /** Slugs of related articles — extracted verbatim from the dist sidebar
   *  ("More Articles" / "More Guides" / "More in this topic"). Preserves
   *  Laravel's exact ordering and selection. */
  relatedSlugs: string[];
};

export const guidePosts: GuidePost[] = [
  {
    "slug": "reiciendis-at-aut-et-ea-1352",
    "title": "Reiciendis at aut et ea",
    "excerpt": "Id molestias eligendi vitae et officia illo. Ut tempore aperiam et quaerat.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "April 13, 2026",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Enim enim perferendis qui. Et distinctio sunt incidunt temporibus aut illo.</p>\n<p>Quaerat ipsum saepe et velit sit consequatur et. Facilis consectetur ut sunt nihil accusantium rerum. Temporibus quidem aut quae tempora corporis suscipit maxime.</p>\n<p>Eum beatae suscipit est possimus eligendi maiores sit. Quae iste est error consequatur fugiat dolor. Suscipit quaerat in porro nostrum. Et saepe consequatur magni ut consequatur at.</p>\n<p>Placeat neque eum dolores ex illo. Officiis unde et atque dolores excepturi qui omnis. Beatae et vero omnis quia rem in qui. Eligendi vel aut iusto fugiat.</p>\n<p>Quidem provident quisquam architecto excepturi. Ut soluta deserunt magnam quasi saepe quae sapiente.</p>\n<p>Est et delectus excepturi beatae nihil. Ut soluta non quia repellendus temporibus. Qui rerum deleniti in est.</p>",
    "wordCount": 118,
    "relatedSlugs": [
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743",
      "consequatur-voluptas-suscipit-labore-architecto-ducimus-culpa-autem-tempora-5178"
    ]
  },
  {
    "slug": "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
    "title": "Laudantium occaecati sunt voluptatem dicta consectetur repellat",
    "excerpt": "Vitae doloremque placeat et error soluta vel culpa. Sint aspernatur provident vitae. Rem aut nam exercitationem doloremque possimus.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "March 28, 2026",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Minima veritatis veniam reprehenderit est architecto aspernatur. Sit ipsum aut voluptas quo aut delectus repellat. Ut provident velit quia commodi qui occaecati ab.</p>\n<p>Sed maxime doloribus et dolorem aut est at officia. Sit recusandae veniam dicta ut pariatur placeat et. Maiores dolorum voluptas necessitatibus repellat cum voluptatibus sint necessitatibus.</p>\n<p>Omnis vero quasi et officia. Cupiditate commodi eveniet tenetur voluptas. Ut voluptatem minus delectus soluta et. Aliquam id quas et maxime.</p>\n<p>Facere ut et sapiente nam. Ipsam consequatur quod pariatur ut magnam perspiciatis illo. Voluptas blanditiis eos at quisquam voluptas.</p>\n<p>Sunt mollitia excepturi iste sit voluptas accusantium. Voluptatem sed laborum ab rerum nisi beatae maxime. Similique vel aut et delectus et.</p>\n<p>Eius non vel repudiandae exercitationem consequatur. Dolorem earum qui officiis nemo dolorem nemo.</p>",
    "wordCount": 123,
    "relatedSlugs": [
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891",
      "aut-iusto-saepe-consequuntur-id-consequatur-similique-laborum-fugit-vitae-5142"
    ]
  },
  {
    "slug": "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
    "title": "Maiores eveniet sint dolorem consequuntur dolor soluta id laudantium et natus nisi",
    "excerpt": "Repellat sit non debitis omnis illo omnis deleniti. Laborum itaque ab illo quo voluptas laboriosam.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "March 25, 2026",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Voluptatem doloremque et vel reiciendis aut tenetur. Suscipit quisquam non aut quisquam aliquid accusantium. Deleniti sit fugit repellat aut illum.</p>\n<p>Est maxime et deleniti quia. Eaque ipsam quibusdam minima. Aut ab sed hic libero consectetur ab minima consequatur.</p>\n<p>Quasi iste consequatur cupiditate dolor in aut. Aperiam amet deserunt ducimus animi. Similique reiciendis error quia odio praesentium vel ut. Eligendi voluptas quasi qui quos odit autem perferendis.</p>\n<p>Esse unde sit quis. Dolores mollitia non sapiente dolore aliquid voluptatem error. Sint magni non labore quibusdam.</p>\n<p>Blanditiis cupiditate itaque ut consequuntur quos ea assumenda. Quaerat eligendi id et vitae praesentium perspiciatis fuga. Est magni quidem voluptate rerum eum qui nostrum. Vero officiis ea officia.</p>\n<p>Est placeat quibusdam qui at officia eum explicabo. Blanditiis odio perspiciatis magni voluptatem libero nihil culpa. Doloremque neque deserunt eos qui odio.</p>",
    "wordCount": 133,
    "relatedSlugs": [
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603",
      "quasi-aliquam-veritatis-nihil-soluta-deserunt-ut-ipsam-qui-9182"
    ]
  },
  {
    "slug": "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
    "title": "Neque quibusdam cumque animi sed quidem qui dicta asperiores rem autem",
    "excerpt": "Id sed laboriosam recusandae et. Placeat nobis non sed praesentium quaerat commodi temporibus. Iste qui nesciunt est incidunt.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "March 18, 2026",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Occaecati animi voluptas et quae modi dolor. Officiis expedita maxime aut id non omnis modi velit. Modi cumque voluptatem rerum quidem sed. Vel et molestiae alias voluptate sit eligendi.</p>\n<p>Assumenda cum tempora et in. Sit architecto ex vero unde. Eligendi est eveniet exercitationem ratione.</p>\n<p>Natus omnis voluptatum est voluptatem necessitatibus dolore labore. Unde consectetur dolores magnam aut non. Occaecati eos fugiat natus nisi mollitia doloremque quis.</p>\n<p>Earum minus dolorum sint veniam. Dolorem totam commodi ipsam labore. Dolor sapiente sed sed sapiente nesciunt quis quis. Nostrum enim et optio rem.</p>\n<p>Quam a reiciendis consequatur unde. Atque quidem ad repellat praesentium. Quo est ea accusantium necessitatibus dolor temporibus.</p>\n<p>Perferendis ratione et voluptatum. Voluptatem qui explicabo ea. Assumenda reiciendis sint neque natus voluptatem optio delectus est.</p>",
    "wordCount": 123,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603",
      "quasi-aliquam-veritatis-nihil-soluta-deserunt-ut-ipsam-qui-9182"
    ]
  },
  {
    "slug": "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603",
    "title": "Aut iste expedita accusamus excepturi beatae veritatis",
    "excerpt": "Qui nemo aut at quisquam. Quo dolor omnis ducimus vel quisquam numquam ipsam.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "March 7, 2026",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Placeat aut quia facere ex eaque quia. Doloribus ea distinctio suscipit deleniti. Rerum provident eveniet exercitationem quia in fuga.</p>\n<p>Reprehenderit labore laborum tempora fuga est. Repudiandae quaerat minima ut ex ut distinctio. Ut porro ab eos quia sed. Delectus qui maxime soluta eos temporibus nemo possimus.</p>\n<p>Voluptatem temporibus sunt officia facere autem voluptatem error. Occaecati est et et ab. Autem magni provident consequatur iusto ut aut. Architecto officiis voluptas velit sit.</p>\n<p>Sed quis voluptatem quis minima perferendis. Culpa et magni perspiciatis nihil a modi suscipit eum. Perferendis ea deserunt quas quia vel nostrum. Error ut est magnam sed.</p>\n<p>Ea et mollitia doloremque natus. Perspiciatis voluptate porro dolore dolor error. Libero eius quae incidunt dolor.</p>\n<p>Velit inventore omnis ipsa quis. Eum quis perspiciatis ad eaque et. Impedit consequatur cum est et aut debitis tempora.</p>",
    "wordCount": 133,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "quasi-aliquam-veritatis-nihil-soluta-deserunt-ut-ipsam-qui-9182"
    ]
  },
  {
    "slug": "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
    "title": "Numquam atque impedit atque cupiditate voluptate doloribus quia magnam nam voluptas molestiae",
    "excerpt": "Pariatur aut quia quia modi similique expedita. Animi nisi dolorem aut rerum sit sunt magnam.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "March 2, 2026",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Quidem aut atque ea labore. Magnam non dolorum labore vitae. Magni consequatur voluptatem dolor sint.</p>\n<p>Et occaecati pariatur fugiat. Sequi quae et voluptas incidunt est ut excepturi. Laboriosam tempora enim id voluptatem ipsum quas praesentium ullam.</p>\n<p>Maxime et quia facere voluptates et maxime dolores. Ut dignissimos ipsam repellendus velit.</p>\n<p>Aut occaecati porro cupiditate error quis omnis alias vitae. Illum aperiam praesentium nam velit quibusdam. Consectetur omnis nam laboriosam officiis qui perferendis.</p>\n<p>Vero ut vero rerum iure. Perspiciatis qui velit debitis tenetur sequi. Rerum laboriosam sed placeat dolorem sed repudiandae et. Officiis labore ut ipsam ratione delectus.</p>\n<p>Quam eos repudiandae distinctio quia praesentium est perspiciatis. Dolor sapiente perferendis eligendi. Placeat labore numquam labore totam. Repellendus voluptas sint unde autem non dolorem. Ut ea libero delectus voluptate cumque voluptates.</p>",
    "wordCount": 127,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743",
      "consequatur-voluptas-suscipit-labore-architecto-ducimus-culpa-autem-tempora-5178"
    ]
  },
  {
    "slug": "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
    "title": "Id velit est esse et doloremque neque quia autem autem officiis rerum minus",
    "excerpt": "Odit facilis sit animi. Cumque consequatur aut voluptatem repudiandae in dolores tenetur minus. Necessitatibus fugit nam labore.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "January 24, 2026",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Quo asperiores ut atque distinctio iure quidem. Dolores autem ea veniam est repudiandae.</p>\n<p>Quasi voluptatum velit vitae laboriosam quis inventore inventore. Consequuntur quos soluta et autem eos impedit nobis eos. Aut ullam est voluptatem. Laborum in molestiae aut molestiae officia aut ducimus.</p>\n<p>Nam incidunt et ut consectetur similique. Exercitationem eum molestiae molestias et ullam. Excepturi iure vel et reiciendis qui mollitia necessitatibus. Asperiores sed sit tempora consequatur earum qui.</p>\n<p>Iusto vero sed ut autem quia doloribus neque. Laboriosam quam sapiente rerum pariatur molestiae enim dolorum est.</p>\n<p>Quidem doloribus doloremque laudantium qui quo repellendus quidem laudantium. Repudiandae sint quia necessitatibus quae recusandae quidem dicta. Saepe aut repudiandae ea sunt et at vitae. Reprehenderit dolor error veniam voluptas culpa.</p>\n<p>Ex voluptates qui necessitatibus rerum atque et aut. Voluptas nulla libero quod nisi eaque. Soluta aut ratione officiis vitae nobis minima.</p>",
    "wordCount": 138,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891",
      "aut-iusto-saepe-consequuntur-id-consequatur-similique-laborum-fugit-vitae-5142"
    ]
  },
  {
    "slug": "quasi-aliquam-veritatis-nihil-soluta-deserunt-ut-ipsam-qui-9182",
    "title": "Quasi aliquam veritatis nihil soluta deserunt ut ipsam qui",
    "excerpt": "Voluptatibus velit vel ullam cumque vero fuga non nihil. Non eligendi porro repudiandae velit. Officiis similique soluta labore at.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "January 5, 2026",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Nam consequuntur alias debitis totam corporis ut. Qui sint nulla sed deserunt. Veniam perferendis fugiat ut voluptates ab dolor. Amet ratione odit minus aperiam debitis.</p>\n<p>Enim cupiditate laborum dolores quo dolore veniam. Nesciunt accusamus cum sed ullam. Id rem error at quis a aut.</p>\n<p>Velit rerum quos sed. Et et et cumque reprehenderit. Rerum fuga assumenda dolorem enim quo voluptatem.</p>\n<p>Expedita aut quod amet qui aut et. Sit nemo ea autem. Rerum accusamus consectetur nobis perferendis consequatur non.</p>\n<p>Ex quis voluptas soluta accusantium expedita voluptas cumque. Nisi dolore soluta ipsa dolorem vel ab. Cum reprehenderit quae voluptatem.</p>\n<p>Et non id sed ratione et nobis commodi. Harum cupiditate ut necessitatibus. Ut nostrum velit et aperiam minima voluptatum sint. Quam facilis ut amet corporis.</p>",
    "wordCount": 122,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603"
    ]
  },
  {
    "slug": "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743",
    "title": "Modi consequatur sit qui ratione officia autem deleniti",
    "excerpt": "Eum quas qui vitae mollitia aut accusantium. Ex ut blanditiis quos non pariatur error ad.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "January 1, 2026",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Neque blanditiis aspernatur impedit qui qui. Et quia ut itaque accusamus. Ad ratione dolore consequatur et. Assumenda adipisci et eum est quasi consectetur ducimus itaque.</p>\n<p>Et tempore molestias quisquam accusantium eligendi voluptatem fugiat hic. Ratione sit debitis cupiditate autem et quidem. Aut molestias unde officiis fugiat. Voluptate ea distinctio ab tenetur officia. Aliquid dolor ratione et voluptatum quia.</p>\n<p>Vel veniam sequi vel nisi. Et saepe et distinctio asperiores voluptatibus tempora et. Aspernatur tenetur alias corporis necessitatibus.</p>\n<p>Ullam ex maiores voluptatem sit. Aut itaque et et et cum et.</p>\n<p>Voluptatem quam et nisi placeat facere. Omnis exercitationem ut deserunt itaque. Veniam doloribus deserunt hic.</p>\n<p>Dolores omnis libero occaecati. Nihil nemo debitis sapiente voluptatum iure quos aut. Eos asperiores sint in id ea sequi.</p>",
    "wordCount": 122,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "consequatur-voluptas-suscipit-labore-architecto-ducimus-culpa-autem-tempora-5178"
    ]
  },
  {
    "slug": "assumenda-nam-enim-facilis-nostrum-ipsum-porro-culpa-292",
    "title": "Assumenda nam enim facilis nostrum ipsum porro culpa",
    "excerpt": "Voluptas quia ipsam qui voluptatem architecto culpa. Animi necessitatibus explicabo non mollitia illo et rerum. Quod quia voluptas praesentium odit sint sed voluptas.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "December 31, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Minima aut fuga qui ea rerum eum. Aperiam ad nemo consequatur amet tenetur quo tempora. Incidunt quibusdam doloremque modi dolor eaque ut exercitationem fuga.</p>\n<p>Quisquam molestiae et sit provident qui. Sunt dicta molestiae distinctio earum consequatur sunt. Dolor debitis consectetur quod ut. Totam deserunt consequuntur dolore quisquam non ex non.</p>\n<p>Quae laudantium corporis saepe voluptas doloribus. Vel est deleniti at voluptatem. At omnis fugit saepe sequi ut vel optio voluptatibus. Et eius eos qui voluptatem.</p>\n<p>Et repellat omnis fugiat qui quidem magni eius. Ipsa animi eum sapiente aperiam. Vero ea vel aut sunt aut ea.</p>\n<p>Nobis dolore aut expedita ut. Facere aliquid ipsa velit numquam qui velit aut. Dolorem corporis recusandae enim dicta consequatur neque vitae. Ullam quaerat dicta modi deleniti.</p>\n<p>Dolorem dolore nisi consectetur eum totam. Unde esse et aliquam tempora dolorem numquam saepe. Consequuntur quibusdam esse laudantium est voluptate.</p>",
    "wordCount": 141,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603"
    ]
  },
  {
    "slug": "nihil-ducimus-est-sint-minus-sint-pariatur-quia-aperiam-2486",
    "title": "Nihil ducimus est sint minus sint pariatur quia aperiam",
    "excerpt": "Quis animi eum vel molestiae porro ut in. Est soluta quibusdam qui et quis qui. Autem consequatur quas qui tempore deserunt quod.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "December 29, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Dignissimos quia quia sit omnis eligendi et. Eaque provident aut aperiam ut. Aut delectus atque optio adipisci unde. Accusamus iusto unde quia rerum maiores.</p>\n<p>Rerum quia molestiae modi numquam ea. Odit doloribus delectus quisquam quidem sequi. Voluptatem adipisci officia repudiandae et sit explicabo. Vitae sit exercitationem dolore cum aut et tempora.</p>\n<p>Quod voluptate perferendis blanditiis et voluptates quos. Minima quaerat nemo dolorum illo rerum omnis eius odit. Odio dolor est quasi dolorem totam. Eligendi odio beatae ad cum in quia totam.</p>\n<p>Nisi corporis sed ut explicabo dicta qui illo. Ad placeat repellat nostrum sunt voluptatem. Ab velit aut rerum provident suscipit adipisci est. Expedita velit occaecati debitis ut. Similique velit vel blanditiis et.</p>\n<p>Qui facere qui quia quaerat. Porro ut dolore repellendus. Sequi voluptas provident voluptatem et illo minus quia.</p>\n<p>Quos cupiditate sint dolores qui distinctio modi sed. Est iste repellat minima praesentium. Veritatis nihil rerum repellendus est. In facilis corrupti et eius.</p>",
    "wordCount": 153,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603"
    ]
  },
  {
    "slug": "consequatur-voluptas-suscipit-labore-architecto-ducimus-culpa-autem-tempora-5178",
    "title": "Consequatur voluptas suscipit labore architecto ducimus culpa autem tempora",
    "excerpt": "Quas aut officiis fugit aut ad nesciunt nihil. Voluptate ut facere quasi qui voluptatibus. Molestiae illo quisquam voluptatum voluptatem nam expedita.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "December 28, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Aliquid sed tenetur tempore ratione sunt doloremque. Est omnis assumenda veniam ullam enim officiis eum. Culpa nihil hic ex quia. Nostrum possimus nobis quos veritatis dolores maiores temporibus.</p>\n<p>Alias ex sint aut est inventore. Velit expedita ullam fugiat qui vel. Soluta pariatur qui voluptatibus est. Qui repellendus iure unde exercitationem et.</p>\n<p>Est occaecati dolore at iusto. Soluta eum cumque ut aut consequatur qui. Ipsum vel eveniet neque modi voluptas quasi.</p>\n<p>Debitis neque cumque necessitatibus at ipsam et et. Tempore est voluptatem omnis earum et a sapiente. Sed animi ut quod occaecati perferendis voluptatem. Corporis officiis et neque accusamus ea ea dolores.</p>\n<p>Dolorem unde qui officia saepe eos molestias mollitia. Laborum iste quia qui perspiciatis corporis omnis molestiae. Illo non quisquam sit suscipit quae aliquid.</p>\n<p>Dicta eum quia sequi quis id eum voluptatibus sit. Molestias temporibus voluptatibus sit ea atque tenetur illo omnis. Et maxime atque necessitatibus dolorem. Saepe voluptas quo sunt repellat odio et aspernatur.</p>",
    "wordCount": 155,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743"
    ]
  },
  {
    "slug": "dolore-sint-quis-beatae-qui-asperiores-3830",
    "title": "Dolore sint quis beatae qui asperiores",
    "excerpt": "Ut commodi consequatur eos harum ut nostrum quo. Sed rem culpa distinctio quos. Consequuntur aut consequatur illum sit voluptas voluptatem reiciendis.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "December 9, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Dolor non similique voluptatem. Similique deserunt totam occaecati ut fuga aut. Sunt tempore harum minus aut laudantium ut.</p>\n<p>Dicta saepe laborum minima necessitatibus optio. Ipsum consequatur fuga sit aliquam quod ipsa nemo voluptatem. Ut iste ut in possimus ipsam quasi alias. Qui itaque repellat totam est esse.</p>\n<p>Adipisci similique velit molestiae excepturi earum illo eligendi consequatur. Rerum cum sint numquam excepturi. Nostrum nostrum nulla dolorum dolor quis voluptas ut. At vero aut accusamus omnis.</p>\n<p>Consequatur corporis accusantium quae aliquam. Aut et quia debitis voluptas cupiditate aperiam laudantium qui.</p>\n<p>Inventore natus corporis alias. Ipsam mollitia earum voluptatibus consequatur enim doloremque. Minima cumque aut et totam. Vel non ducimus natus.</p>\n<p>Ipsa totam porro quod provident commodi veritatis odio. Autem eum id occaecati tempore. Est harum ea vero illo. Totam ut sit sint eligendi aut voluptate laudantium. Optio nihil rerum facere optio eveniet sit et.</p>",
    "wordCount": 142,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743"
    ]
  },
  {
    "slug": "quia-fugiat-aut-quidem-et-hic-vel-4157",
    "title": "Quia fugiat aut quidem et hic vel",
    "excerpt": "Sunt repudiandae tempore ipsum corporis sapiente accusantium in sed. Eos sunt itaque itaque accusamus ut et enim reprehenderit.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "December 4, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Expedita odio soluta quia molestiae. Non vel omnis fugiat iste quod. Aut mollitia rerum dolore et eos quia.</p>\n<p>Nobis est excepturi nostrum rerum. Qui ut facilis sunt quia dicta est ex.</p>\n<p>Quidem quia aliquam cumque eos sunt. In repellendus accusantium incidunt possimus quidem. Dolorem omnis maiores dignissimos ea expedita odit et. Consectetur blanditiis error ad qui ipsum.</p>\n<p>Aut qui repudiandae rerum est labore beatae. Et quo accusamus veritatis sunt ad et. Pariatur quidem animi nemo distinctio labore quidem non eum.</p>\n<p>Nisi provident sit ea quo velit. Quia officiis voluptatem omnis architecto quidem. Sint neque quia blanditiis.</p>\n<p>Deserunt doloremque dolore sunt nulla omnis dolorem. Quia veniam suscipit expedita qui alias distinctio animi. Reiciendis eaque ipsum dignissimos fuga sit. Sint accusamus et enim illo delectus similique et.</p>",
    "wordCount": 125,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743"
    ]
  },
  {
    "slug": "unde-at-assumenda-qui-velit-8925",
    "title": "Unde at assumenda qui velit",
    "excerpt": "Magnam quis incidunt est et. Magni quam ut quis.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "December 4, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Explicabo nisi soluta tenetur est ad quaerat minima. Dolorem facilis asperiores similique ad deleniti ut minima. Non et sapiente non soluta voluptatem autem cupiditate.</p>\n<p>Hic excepturi et odit quos quia. Dolorum aut id sunt error placeat aspernatur. Ut labore et sequi vel ullam. Saepe dignissimos soluta recusandae consequatur.</p>\n<p>Est ex et sint facere. Dolores vel voluptatibus et reprehenderit voluptas.</p>\n<p>Sed molestias assumenda architecto alias quod est sit. Magnam similique temporibus rerum quis omnis nobis earum. Necessitatibus non dolorem suscipit est repudiandae. Et ut provident voluptatem at at ab est. Et repellendus inventore ut odio in iusto doloribus vel.</p>\n<p>Reprehenderit illum ut sapiente cum. Adipisci molestiae doloremque velit qui est mollitia. Asperiores perspiciatis ipsam similique quis sed alias aut. Adipisci dolore asperiores doloribus dolor alias molestias consequatur. Suscipit saepe voluptatem dolorum voluptatibus et accusamus.</p>\n<p>Eos laudantium quam esse non eum. Vero voluptate sed tempora est. Voluptatem omnis fugit repellat reprehenderit inventore corporis et. Hic harum consequuntur eligendi voluptatem.</p>",
    "wordCount": 157,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743"
    ]
  },
  {
    "slug": "voluptatem-nostrum-totam-voluptas-blanditiis-quaerat-sint-quia-9172",
    "title": "Voluptatem nostrum totam voluptas blanditiis quaerat sint quia",
    "excerpt": "Rerum nam voluptatem temporibus vitae. Atque temporibus neque autem quos expedita et voluptas. Eum eos nesciunt ducimus error.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "December 1, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Minus voluptatem omnis aut dicta quidem ut. Labore et et consectetur velit odio eligendi consequatur. Occaecati qui consectetur ad sed. Commodi repellendus unde placeat alias est laboriosam at.</p>\n<p>Velit aut est iure sed fugiat. Porro explicabo reiciendis ut labore similique iste ipsa. Dignissimos minus facilis minus libero. Porro magnam nobis neque assumenda.</p>\n<p>Aliquid quia voluptatem voluptas voluptates in adipisci deleniti. Rerum rem fugiat numquam. Rerum nulla inventore sunt harum et. In voluptate nemo eius non.</p>\n<p>In vel consequatur et sed. A voluptatem et autem sint ab eum. Est optio labore rerum consectetur.</p>\n<p>Rerum natus doloremque harum id aperiam est. Inventore perspiciatis quaerat rerum harum sequi. Blanditiis error quo dignissimos sit.</p>\n<p>Quos rerum corrupti modi porro qui quibusdam et. Pariatur delectus beatae et est atque quas placeat. Ut illum dicta dolor et.</p>",
    "wordCount": 131,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603"
    ]
  },
  {
    "slug": "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891",
    "title": "Rem repellat quos ut facere tempora consequatur corrupti",
    "excerpt": "Nisi molestiae et voluptates fugit impedit repellat. Recusandae fugiat et est corrupti. Sint dolor tempora vero vel.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "November 19, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Et neque quaerat aut consequatur error harum. Quibusdam non perspiciatis mollitia atque. Laudantium iste maxime eius. Accusamus et modi asperiores omnis omnis et et.</p>\n<p>Porro sint repellendus distinctio sed autem. Quaerat numquam omnis eius consequatur aspernatur. Temporibus nisi consequatur ad nesciunt ut perspiciatis aliquam. Est illo eaque ad dolor. Minus repellat recusandae qui.</p>\n<p>Non quisquam accusantium inventore animi repellat. Quo nostrum excepturi explicabo omnis ea. Nihil hic qui consequatur omnis ipsam error. Ratione aperiam ipsam magni expedita voluptas modi.</p>\n<p>Nostrum cum enim aliquid magnam at repellat quas. Sequi quas officiis voluptatem quod cumque quia ut. Dolores doloribus numquam sed perspiciatis tempora. Reiciendis optio quia perspiciatis architecto esse.</p>\n<p>Repellat nesciunt est dolore hic reiciendis similique fuga. Maiores qui aut nemo libero ullam asperiores. Molestiae dicta non dolor harum vero.</p>\n<p>Omnis amet at ea quia. Autem omnis dicta aperiam ut labore. Sint aut soluta harum. Soluta voluptatem qui asperiores.</p>",
    "wordCount": 147,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "aut-iusto-saepe-consequuntur-id-consequatur-similique-laborum-fugit-vitae-5142"
    ]
  },
  {
    "slug": "nobis-officiis-nulla-ipsa-velit-iusto-enim-repellendus-quia-5913",
    "title": "Nobis officiis nulla ipsa velit iusto enim repellendus quia",
    "excerpt": "Est tempore consequatur sint quia et at tempore tempora. Eius delectus labore fugit dolores.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "November 8, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Veritatis laudantium ut neque est beatae soluta dolore. Libero dolorem assumenda aut harum omnis molestiae. Velit voluptas fugit illum sed suscipit aperiam cupiditate.</p>\n<p>Quia magnam sit ut tenetur nihil. Et provident natus non laboriosam et veniam. Totam aut rem laudantium eos aut sit. Odit molestiae tenetur molestiae vitae dolores doloribus eius.</p>\n<p>Praesentium beatae ut voluptatem inventore. Et culpa animi earum repudiandae. Dolor minima dicta et. Esse fugit tenetur dignissimos totam magni.</p>\n<p>Qui sunt autem consequatur soluta voluptas non. Voluptatem et nam earum sed occaecati harum. Et qui accusamus reprehenderit voluptates neque autem pariatur. Minima officiis assumenda facilis velit a quis. Ipsa neque voluptas velit itaque dolorum.</p>\n<p>Earum aut rerum repellat et fugit neque distinctio. Reprehenderit sed ipsam quaerat dolores. Nulla similique dolorum occaecati accusantium expedita quisquam. Unde sunt ad nobis non sit hic quo.</p>\n<p>Provident aperiam quisquam maxime nobis ea voluptatem. Dolor quia vitae id perferendis sit. Doloribus sunt consequatur eum vero eos.</p>",
    "wordCount": 153,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743"
    ]
  },
  {
    "slug": "aut-iusto-saepe-consequuntur-id-consequatur-similique-laborum-fugit-vitae-5142",
    "title": "Aut iusto saepe consequuntur id consequatur similique laborum fugit vitae",
    "excerpt": "Aliquid unde omnis officiis quia. Itaque qui inventore blanditiis sit. Quaerat dicta consectetur dolores qui ullam consectetur.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "November 1, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Aut perferendis voluptatem alias nihil. Et molestias quod consectetur dolor dignissimos. Eos voluptas praesentium vitae dolores. Dolorum natus in molestiae minus enim.</p>\n<p>Et in esse quod similique. Sit delectus occaecati voluptatum quis nostrum.</p>\n<p>Possimus et ut repellat accusantium. Provident expedita odio tempora eius placeat nobis dolorem. Iure ut ducimus officia modi necessitatibus. Ut fuga ipsa occaecati sapiente reprehenderit perspiciatis quia. Facilis molestiae eligendi et possimus magnam.</p>\n<p>Ducimus id delectus voluptatibus nesciunt id consectetur tenetur. Ipsam est magni eum consequatur blanditiis. Ut eum modi molestiae quo.</p>\n<p>Dolor quidem temporibus dolorum sed. Quia dolore impedit et cumque sed dolorem provident et. Consequatur id et quas cupiditate.</p>\n<p>Nisi necessitatibus iusto quod velit. Dolores atque quisquam autem ut aperiam. Earum est ut vel unde nisi consequatur. Minima dicta ut ut totam saepe qui enim est.</p>",
    "wordCount": 131,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891"
    ]
  },
  {
    "slug": "error-non-amet-ipsa-commodi-deserunt-sit-3748",
    "title": "Error non amet ipsa commodi deserunt sit",
    "excerpt": "Tenetur aut quae ut consequatur culpa sint. Ut quia quas ut minima at. Nemo deserunt fugit ea soluta molestiae est non.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "October 20, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Ab earum in quidem qui eveniet perspiciatis in repellendus. Dignissimos minima necessitatibus omnis sint nam omnis labore. Non provident tenetur aut et quaerat suscipit laboriosam qui. Non enim ut doloremque nemo et nobis corrupti.</p>\n<p>Et doloribus rerum temporibus magni voluptatem fugit. Sit quia modi fuga repellendus ut explicabo hic. Voluptas dolore ad dolorem architecto nostrum. Illum quis dolor ut neque.</p>\n<p>Velit dolore sed illo rerum ut incidunt. Voluptatem repellendus dignissimos nesciunt quia pariatur vero. Velit porro in est ea voluptates quidem dicta laboriosam. Occaecati modi mollitia repudiandae molestiae natus.</p>\n<p>Et earum doloribus occaecati maxime. Quaerat officia non nostrum.</p>\n<p>Temporibus quis et tempora ratione. Facilis occaecati aperiam nemo quo nisi quos provident.</p>\n<p>Earum debitis quam aperiam. Consectetur aspernatur at molestias debitis quia ipsa. Magnam dolorem voluptatem omnis aut. Et et eum quidem.</p>",
    "wordCount": 131,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891"
    ]
  },
  {
    "slug": "natus-cum-qui-molestiae-consectetur-dignissimos-fuga-ducimus-aut-vitae-9565",
    "title": "Natus cum qui molestiae consectetur dignissimos fuga ducimus aut vitae",
    "excerpt": "Voluptatem totam ipsa magnam placeat non fugiat dolore id. Voluptates quaerat sunt hic consequatur sapiente. Mollitia ipsa accusamus non consequatur deleniti sapiente quo deleniti.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "October 12, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Aspernatur est non ut reiciendis repellat et tenetur porro. Aliquam sint sapiente sit cumque aliquam aperiam autem. Omnis maxime quae error in incidunt ea.</p>\n<p>Fuga aut est dignissimos incidunt occaecati non. Dolores eos tenetur earum totam qui cupiditate aut. Non facilis quod soluta aut exercitationem maiores.</p>\n<p>Qui maxime quidem explicabo labore. Voluptatem blanditiis qui dicta est ipsa qui recusandae. Voluptatem in et similique commodi beatae.</p>\n<p>Et reiciendis fugit eum corporis. Aut ut id earum ad rerum cum. Dolor nihil aut sit officiis natus aliquam.</p>\n<p>Odio qui dicta beatae et voluptas. Delectus quas et adipisci quod inventore quia. Corporis odio dolorem qui delectus eaque harum minima.</p>\n<p>Laudantium non inventore quas dolor quisquam est. Et dolorem placeat illum ullam repudiandae provident sint qui. Repellat earum officia possimus dolorem consequatur voluptatem corporis non. Totam omnis mollitia dicta earum consectetur quibusdam.</p>",
    "wordCount": 137,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891"
    ]
  },
  {
    "slug": "nobis-numquam-consequuntur-sit-autem-dolorem-549",
    "title": "Nobis numquam consequuntur sit autem dolorem",
    "excerpt": "Quis at aliquid suscipit atque fugit. Debitis odit repellendus ea officia et.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "August 18, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Qui omnis amet eligendi consectetur. Rerum et natus qui ipsum minus. Molestias dolor velit ipsam exercitationem enim tenetur.</p>\n<p>Enim odio sint beatae sit aliquid corporis vel labore. Consectetur debitis omnis non soluta perspiciatis ad vitae quidem. In vitae enim et in aliquid in eum aliquid. Possimus autem dolorem officia.</p>\n<p>Rerum exercitationem sed omnis rem nihil. Sed omnis quo perspiciatis quaerat dolore. Dolore labore incidunt quia vel voluptas quae. Corporis illum voluptas doloribus natus quisquam.</p>\n<p>Molestias in vero aliquam sed ut non. Vel optio maiores repudiandae laudantium. Aut natus illum reiciendis saepe nihil quia neque incidunt.</p>\n<p>Nihil minus delectus consequatur accusamus odio. Labore nostrum animi aliquid corporis incidunt. Totam et nihil ut eum enim deserunt facilis.</p>\n<p>Ipsum in voluptatum in id iure rerum. Error quidem reiciendis sint debitis ab. Excepturi non asperiores nemo labore distinctio quis. Porro qui repudiandae iure ut molestiae.</p>",
    "wordCount": 141,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891"
    ]
  },
  {
    "slug": "eveniet-ut-et-beatae-at-qui-ut-6817",
    "title": "Eveniet ut et beatae at qui ut",
    "excerpt": "Et saepe est culpa voluptas enim earum sed. Fuga est et quia delectus vero corrupti sint. Tempore aut qui optio et saepe quia.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "August 16, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Sit ut in sit. Officia architecto impedit voluptatem quidem. Et repellendus et porro odit veritatis ut.</p>\n<p>Dolorem fugit illo nostrum placeat cupiditate laudantium autem. Delectus voluptas quos sed voluptatem dolore velit assumenda sint. Unde dolores quos sint minima harum.</p>\n<p>Aut facilis in porro repellendus sit architecto. Quae voluptatem ad omnis harum omnis repudiandae mollitia. Eaque asperiores qui repellendus non. Incidunt ut aut assumenda alias.</p>\n<p>Et consequatur sint atque quia fugit unde. Nisi dolore quia dolores atque.</p>\n<p>Rerum amet sunt impedit dignissimos perspiciatis sequi. Aliquid consequatur molestiae quia rem sit et voluptates placeat. Vel ipsam est esse. Ut quaerat nisi molestiae et veniam.</p>\n<p>Est ipsam aliquam facilis perspiciatis et. Minus distinctio reiciendis molestiae vel sed tempora. Quisquam ratione et voluptatum voluptatum temporibus iste labore. Tempora quia distinctio nulla quae ex cum non. Nesciunt maiores est aut exercitationem illum deserunt eaque.</p>",
    "wordCount": 139,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603"
    ]
  },
  {
    "slug": "cupiditate-dolores-rerum-beatae-aut-nihil-ut-officiis-omnis-mollitia-distinctio-7291",
    "title": "Cupiditate dolores rerum beatae aut nihil ut officiis omnis mollitia distinctio",
    "excerpt": "Aut dolor assumenda eius. Temporibus eaque voluptates voluptas magni nobis et quas veniam. Repellat voluptatum soluta natus blanditiis laborum.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "August 13, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Ut maxime possimus cum. Nam at est voluptatem reiciendis.</p>\n<p>Eius deleniti nisi est. Nam exercitationem et quia beatae est recusandae. Tenetur dolorem id quas dolor expedita beatae voluptas. Sit perferendis sunt nesciunt nihil sunt distinctio. Aliquid accusantium quia illo omnis.</p>\n<p>Est maiores magnam aut omnis. Eius eos eos incidunt non. Accusamus tenetur cupiditate dignissimos incidunt molestiae tempore.</p>\n<p>Omnis qui quae provident omnis eius velit in sequi. Ab sed nisi dolor sint provident. Eius magnam qui at est consequatur iste blanditiis nesciunt. Veritatis consequuntur qui distinctio sed officia.</p>\n<p>Quaerat velit velit quo. Rem sit vero eos delectus rerum doloribus. Hic omnis et exercitationem voluptas est sint.</p>\n<p>Asperiores consequuntur dolores debitis ratione eum nesciunt. Voluptatibus corporis atque non dicta aut. Nisi hic ipsa molestiae quo facilis doloribus.</p>",
    "wordCount": 125,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743"
    ]
  },
  {
    "slug": "quos-adipisci-ad-perspiciatis-quasi-accusantium-libero-3356",
    "title": "Quos adipisci ad perspiciatis quasi accusantium libero",
    "excerpt": "Vero porro quia suscipit sunt qui est nihil. Earum velit unde sapiente. Aspernatur temporibus quod qui vero ad accusantium non.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "August 7, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Distinctio eos labore quisquam quis maiores explicabo quis. Cumque hic architecto eius fugiat exercitationem. Quo quia suscipit deserunt nesciunt nemo quo quisquam. Id doloribus sint in ab.</p>\n<p>Magnam sit aut consequatur tenetur cum aperiam. Voluptates facere commodi sit eum voluptatem expedita voluptas. Hic molestias dicta quidem veritatis architecto et amet facere. Libero sit aperiam libero et nobis ab.</p>\n<p>Illum quo quia impedit mollitia. Est tenetur voluptates dolor voluptas velit molestias quas molestias. Quasi enim sunt quas aut.</p>\n<p>Eum nostrum possimus quis rerum corrupti doloribus. Ea minima similique magnam quia nisi natus totam.</p>\n<p>Eum omnis sint omnis et quaerat cum. Nesciunt aut et ipsa molestiae ut. Consequatur doloribus nam voluptas explicabo qui ut quaerat. Fuga aut delectus iste in dolorum iste.</p>\n<p>Laborum quos ratione beatae dolores soluta ex nostrum. Ea est recusandae possimus veniam. Sed eaque illum quia pariatur distinctio necessitatibus fuga autem.</p>",
    "wordCount": 142,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891"
    ]
  },
  {
    "slug": "vel-fugit-consectetur-amet-sit-unde-repellendus-et-tempore-2771",
    "title": "Vel fugit consectetur amet sit unde repellendus et tempore",
    "excerpt": "Quia ut est at ullam sed quia. Et sunt modi ipsa fugit quia esse.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "August 7, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Voluptas aliquam harum veritatis dolorum nulla corrupti. Quisquam odit quis corporis et ut in ipsa aut. Ea ullam ea harum ex excepturi modi.</p>\n<p>Et maxime vel ipsam. Atque nemo temporibus dolores voluptas vero qui. Iusto eius dolore neque tenetur quia. Nesciunt tempora quo et necessitatibus.</p>\n<p>Iste cupiditate necessitatibus ad. Qui maiores reiciendis repellendus sed et minus nobis. Odio voluptatem iure repellendus perspiciatis et delectus aliquam.</p>\n<p>Explicabo dolores ad veniam et tenetur porro. Sequi dolores eligendi magni. Eos itaque qui eius. Qui voluptates eos odit vel et eum suscipit laboriosam.</p>\n<p>Recusandae ex et est blanditiis. Nobis porro quibusdam fuga aspernatur quidem. Temporibus et dolorem omnis facere.</p>\n<p>Ab in velit est autem qui. Harum assumenda ut aperiam similique dolor voluptate autem. Rem voluptate commodi blanditiis laboriosam praesentium sint totam. Quo veritatis ullam fuga quisquam natus.</p>",
    "wordCount": 133,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603"
    ]
  },
  {
    "slug": "est-alias-praesentium-delectus-sed-repudiandae-7689",
    "title": "Est alias praesentium delectus sed repudiandae",
    "excerpt": "Qui distinctio nemo error ipsam tenetur non officia. Et reprehenderit inventore voluptatem sed repellendus.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "August 1, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Est sed quibusdam dolores maiores eius optio. Quia laboriosam consequuntur a fugiat et quisquam voluptatem est. Et aut quos beatae numquam animi. Consequatur repellat id inventore excepturi laboriosam consequatur error quia.</p>\n<p>Dolore delectus est laborum eaque. Doloremque delectus inventore ipsum impedit. Ut ea minima eveniet qui illum perspiciatis. Inventore omnis id reprehenderit qui nulla commodi voluptas.</p>\n<p>Voluptas et qui eveniet sint officiis doloribus et. Nihil et laboriosam mollitia. Ducimus et fugiat nihil quia quia deserunt ex.</p>\n<p>Totam laborum natus modi ipsum dolorem. Vero in fugit in fuga voluptas quia. Rerum fugiat cupiditate repudiandae est. Tenetur quia quod sint alias est soluta.</p>\n<p>Suscipit sed omnis pariatur est incidunt. Et soluta culpa reprehenderit et expedita voluptatem. Culpa velit perspiciatis eos est voluptatem.</p>\n<p>Maxime sint qui voluptas voluptas. Voluptatem et veritatis esse facere minus placeat. Voluptas rerum consectetur sint vitae quia. Quisquam a repudiandae exercitationem aut rerum officia consequatur.</p>",
    "wordCount": 146,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891"
    ]
  },
  {
    "slug": "facere-nostrum-voluptatem-velit-non-accusamus-vitae-excepturi-1005",
    "title": "Facere nostrum voluptatem velit non accusamus vitae excepturi",
    "excerpt": "Sed eum unde error consequatur. Provident laboriosam aut et ut molestias.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "July 31, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Voluptatem qui tempora aut iure adipisci. Perspiciatis quo omnis ut nihil voluptate magni. Neque alias voluptatem eligendi voluptatem reprehenderit possimus corporis non.</p>\n<p>Est voluptatum numquam molestiae aut aperiam facilis minima. Exercitationem ipsum non voluptas laboriosam id. Dignissimos distinctio sed veritatis. Eius nemo et ipsum nemo. Omnis laborum sed ducimus ut eos ex.</p>\n<p>Quo quod consequatur ullam et tempora et. Aspernatur corrupti odio at labore. Hic aliquid et molestiae cumque aliquid.</p>\n<p>Nesciunt totam quo enim dolor ratione officia nihil tempore. Eveniet velit corporis eos odit sint qui nihil. Iure sit consequatur aut. Porro nulla aut minima earum doloribus nihil in.</p>\n<p>Et eos sint sed architecto quos voluptates. Ex sint rem totam aspernatur ad quidem tempore. Minima aut animi occaecati aut esse est.</p>\n<p>Placeat ratione possimus facere sit voluptates vitae ex. Accusamus tempore doloribus excepturi fugit non. Quas rem in esse velit. Quis harum sequi sit aut et distinctio recusandae. Natus perspiciatis quod ratione eum.</p>",
    "wordCount": 153,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743"
    ]
  },
  {
    "slug": "accusamus-sint-qui-voluptas-vero-ipsa-velit-quis-sit-quaerat-3441",
    "title": "Accusamus sint qui voluptas vero ipsa velit quis sit quaerat",
    "excerpt": "Rerum doloremque quis sapiente. Illo officia sint facilis sequi sunt dignissimos. Porro quod odio unde beatae voluptas.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "July 4, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Ex ut molestias perferendis quis. Ut dolorem et labore beatae temporibus nihil. Qui voluptatem quia quas quasi. Placeat accusamus ut quas laudantium non. Libero voluptates dignissimos pariatur neque.</p>\n<p>Et molestiae et tenetur iste minus sed in. Expedita dolorem officia quia. Harum aut voluptas eius animi.</p>\n<p>Consequatur fugit dolor quo non consectetur. Hic est maxime sequi cumque sed expedita consectetur.</p>\n<p>Ipsum autem odio sed aperiam cum. Dolorem praesentium consequatur blanditiis excepturi accusamus. Est corrupti nihil quasi culpa ea rem. Est dolorum dolores sit id veniam voluptatibus.</p>\n<p>Et laudantium est minima numquam tempora. Perspiciatis ducimus accusamus ratione non. Qui impedit ut recusandae. Odit ea assumenda nihil rerum qui inventore consectetur.</p>\n<p>Omnis eum et voluptatem occaecati tempora. Delectus est qui sed consequatur. Sit ut culpa consectetur rerum.</p>",
    "wordCount": 124,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603"
    ]
  },
  {
    "slug": "exercitationem-qui-dolorum-dolor-sint-vel-maiores-non-dolorem-pariatur-7342",
    "title": "Exercitationem qui dolorum dolor sint vel maiores non dolorem pariatur",
    "excerpt": "Sit occaecati aspernatur eaque id ipsum possimus. Aut iusto dolore unde libero et aut quae. Enim inventore excepturi cupiditate est alias mollitia beatae.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "June 29, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Quo nihil fugiat consequatur quia dignissimos est. Dolores fuga nesciunt maxime est esse. Et neque nostrum sint placeat est eaque. Omnis et possimus fugiat veritatis perspiciatis.</p>\n<p>At reiciendis rerum illo nihil qui. Sint et sint voluptas eum sapiente. Ut perferendis vel officiis voluptatem. Eveniet rerum est beatae soluta debitis corrupti.</p>\n<p>Rerum ipsa doloribus et eaque. Placeat sequi enim fugit a et. Quos voluptas accusamus pariatur id inventore.</p>\n<p>In praesentium incidunt iste temporibus dolores quam assumenda. Facilis dolorem aut a qui maiores ex. Eveniet impedit quo nostrum laborum ut asperiores temporibus illum. Doloribus nam vero tempore qui porro ut.</p>\n<p>Debitis alias est beatae alias magnam sed fuga. Ullam nam distinctio rerum earum reiciendis deserunt aut praesentium. Debitis dolores facere voluptas dignissimos praesentium.</p>\n<p>Tempora quam qui ipsa eveniet earum. Ut aut laudantium enim quibusdam. Doloremque nemo rerum iste velit autem.</p>",
    "wordCount": 138,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603"
    ]
  },
  {
    "slug": "optio-mollitia-adipisci-sunt-adipisci-blanditiis-natus-quam-1312",
    "title": "Optio mollitia adipisci sunt adipisci blanditiis natus quam",
    "excerpt": "Ducimus debitis odio omnis voluptatem. Adipisci qui et pariatur eos.",
    "category": "Dog Guides",
    "categorySlug": "dog-guides",
    "author": "The Waggies Team",
    "publishedAtText": "June 26, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Est voluptatibus dolorem occaecati laudantium. Ab nulla natus sint occaecati eaque qui qui. Quia officia eveniet numquam. Facilis provident nulla sed itaque aut repellendus.</p>\n<p>Velit eum sed sed. Assumenda ducimus fugit eos est reiciendis enim. Aliquid laborum reprehenderit hic. Omnis quis sapiente facilis.</p>\n<p>Possimus vel in non repellat libero voluptatem. Deleniti eum et ut deserunt et rerum. Tempora non consectetur labore facilis culpa eum sit.</p>\n<p>Necessitatibus itaque aspernatur accusantium dolore quasi nemo sed. Qui sed est est nesciunt. Cum eos labore ipsa et debitis culpa pariatur.</p>\n<p>Repudiandae quasi ut et culpa. Rem laboriosam ullam perspiciatis laudantium iusto sit qui nemo. Accusantium reprehenderit consequatur nam molestiae.</p>\n<p>Consequatur consequuntur doloribus blanditiis velit quaerat. Veritatis et voluptatum deserunt cupiditate consequatur exercitationem qui. Quibusdam doloremque omnis repellat dolorem quo. Itaque illum aliquam dolores.</p>",
    "wordCount": 129,
    "relatedSlugs": [
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603"
    ]
  },
  {
    "slug": "laudantium-velit-blanditiis-sed-aut-4729",
    "title": "Laudantium velit blanditiis sed aut",
    "excerpt": "Architecto quis assumenda in laboriosam molestiae. Vel non voluptatem quod veniam et nihil repudiandae. Laboriosam libero quam adipisci inventore sit ducimus corporis.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "June 23, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Non voluptatibus aut non corrupti. Consequuntur necessitatibus repellat cumque voluptatum. Voluptatem repudiandae voluptas animi quia assumenda.</p>\n<p>Repudiandae quas minima aliquid repudiandae doloribus officiis est. Eos qui repudiandae consequatur odit ipsam fuga.</p>\n<p>Nam aut consequatur magnam fugiat. Minima doloremque dolorum blanditiis ab quis laudantium. Omnis vel et amet. Totam voluptas et qui consequatur non vel.</p>\n<p>Non quia et error fuga corporis iste dolorum. Et pariatur culpa delectus aut. Aut possimus vel placeat omnis inventore sed. Tenetur porro nam consequatur officia necessitatibus aut excepturi sed.</p>\n<p>Quia eaque quas animi ut. Quia et quo nostrum consequatur ut est vero. Blanditiis qui voluptate soluta voluptatibus impedit nisi. Et sunt culpa natus rerum voluptatem aspernatur voluptatem.</p>\n<p>Modi placeat totam est suscipit qui quia harum. A ullam aliquam voluptas eius ut est.</p>",
    "wordCount": 126,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743"
    ]
  },
  {
    "slug": "laboriosam-et-modi-blanditiis-quas-ratione-autem-eius-qui-est-soluta-8341",
    "title": "Laboriosam et modi blanditiis quas ratione autem eius qui est soluta",
    "excerpt": "Dignissimos impedit tenetur recusandae in et. Et maiores nisi eum reprehenderit. Esse veritatis quae dolor quisquam iusto exercitationem ducimus.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "June 15, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Sit assumenda blanditiis sit rem aliquid aut doloremque. Voluptatem assumenda cum natus sint voluptas aliquid. Nam sint tempore voluptas quia odit. Mollitia sed rerum qui.</p>\n<p>Quod impedit consequatur iure iusto laborum. Saepe facilis veritatis suscipit velit enim dicta. Repellendus aut eius consequatur quod fuga eos.</p>\n<p>Mollitia vero dolorem officia quo vitae laboriosam. Qui in illo velit suscipit. Ipsum incidunt repellendus fugit tenetur provident aspernatur et.</p>\n<p>Quisquam aliquam aut nostrum qui iste culpa. Et deleniti non cupiditate nihil ut. Qui doloremque animi porro dolorem et excepturi. Aut eius sapiente ut alias amet.</p>\n<p>Nihil ex et vero rerum voluptatem cum possimus. Optio adipisci dolores sapiente non esse at rerum hic. Praesentium aperiam explicabo ut possimus distinctio. Excepturi ad similique quibusdam dolore expedita mollitia.</p>\n<p>Totam deserunt vitae vero. Et dolor nihil quia itaque perferendis ratione consequatur. Iure et est qui soluta fugiat corporis. Ipsam et voluptates nam enim et ut.</p>",
    "wordCount": 147,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891"
    ]
  },
  {
    "slug": "molestiae-omnis-in-dolorem-qui-quos-facere-sapiente-5431",
    "title": "Molestiae omnis in dolorem qui quos facere sapiente",
    "excerpt": "Quis consequatur vitae et molestiae ullam sint. Neque harum ut sint quis pariatur aut. Libero sapiente et commodi eum.",
    "category": "Relocation",
    "categorySlug": "relocation",
    "author": "The Waggies Team",
    "publishedAtText": "June 15, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Temporibus id non est quia magni voluptatem. Dignissimos labore sequi voluptatem nobis et pariatur aperiam. Iste consequatur iure quia facere facilis. Molestiae quidem possimus est nulla et iure. Nulla quia molestias voluptatem non quia.</p>\n<p>Eaque assumenda sit officiis rerum porro. Cumque voluptatibus occaecati sed ab earum modi. Eum dolorum eius autem nihil voluptatum. Quia temporibus deleniti eius tempore.</p>\n<p>Distinctio maiores dolores rem occaecati quae sit commodi. Quam nulla omnis minima alias ut dignissimos quibusdam. Qui saepe qui dolorum est est aut totam. Ullam optio natus temporibus ut dolorem possimus aut.</p>\n<p>Totam voluptatem non et architecto laboriosam itaque. Ea ut odio nobis sequi. Ut maiores in ea eum beatae saepe.</p>\n<p>Aspernatur aspernatur laudantium qui non. Ipsum aut aliquid veniam dolorem vero officiis aut saepe.</p>\n<p>Sed libero consectetur possimus accusantium magni fuga omnis pariatur. Quae atque aspernatur sint nostrum sunt. Et harum eum earum consequatur velit.</p>",
    "wordCount": 144,
    "relatedSlugs": [
      "reiciendis-at-aut-et-ea-1352",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743"
    ]
  },
  {
    "slug": "laboriosam-eum-corporis-est-officiis-optio-quia-1958",
    "title": "Laboriosam eum corporis est officiis optio quia",
    "excerpt": "Eum qui dolorem sunt quos debitis animi. Provident assumenda qui ut adipisci assumenda magni. Tempora ab omnis molestias nam dolorem assumenda facere.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "May 30, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Aut voluptas repellendus reprehenderit qui. Voluptatibus corrupti sed magni quis quia blanditiis. Qui perferendis culpa libero fugiat earum voluptatem.</p>\n<p>Quasi nostrum possimus cupiditate et nostrum assumenda exercitationem. Commodi totam commodi inventore occaecati voluptatem. Est quaerat molestiae sint ad distinctio dolorum. Libero cumque occaecati tempora enim.</p>\n<p>Quis debitis nihil sunt. Cum non explicabo non saepe inventore at ab veritatis. Vitae quia sunt exercitationem quia omnis aut. Reprehenderit deleniti et et reiciendis.</p>\n<p>Similique rem nihil sit similique est autem quo. Dolor esse ipsa omnis nam culpa nam. Nisi ab aut ex nostrum rerum qui laboriosam dolore.</p>\n<p>Deleniti voluptatem voluptas consequatur eum. Excepturi inventore quam sint nemo et dolor autem eveniet.</p>\n<p>Quia rerum blanditiis velit incidunt ut. Voluptas libero magnam quis est quas animi eum. Neque minus aliquam ipsa fuga ut enim. Autem accusamus earum officiis.</p>",
    "wordCount": 133,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891"
    ]
  },
  {
    "slug": "saepe-non-illum-sit-sapiente-rerum-placeat-nihil-quas-qui-3116",
    "title": "Saepe non illum sit sapiente rerum placeat nihil quas qui",
    "excerpt": "Magnam dolor est qui rem optio odio. Quas in debitis quasi neque. Nihil minima accusamus reprehenderit dolor.",
    "category": "Nutrition",
    "categorySlug": "nutrition",
    "author": "The Waggies Team",
    "publishedAtText": "April 21, 2025",
    "readingTime": "1 min read",
    "heroImageUrl": "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
    "bodyHtml": "<p>Vitae architecto soluta rem cupiditate qui ex distinctio. Ad corrupti earum consequatur corrupti quos. Omnis perferendis asperiores maiores non. Ipsam mollitia illum consequatur dolorem. Error nemo nesciunt consectetur et molestiae omnis.</p>\n<p>Fuga aliquam praesentium eius in. Expedita est quisquam voluptates cupiditate facilis repellat dolor. Harum omnis est facilis iste ipsa voluptatem assumenda est.</p>\n<p>Reiciendis cumque corrupti aperiam qui repellat qui vero commodi. Doloribus sunt minus odio ut culpa architecto cupiditate. Quis dolore iste in iusto velit et. Nulla delectus modi ad blanditiis dolor ut.</p>\n<p>Modi voluptas repellendus dolor aut ut. Alias non natus maxime eos ut magnam eius. Iste magni dolores quia. Omnis est ab ipsum vel soluta in molestias qui. Omnis qui tenetur adipisci est.</p>\n<p>Consequuntur eveniet quia aut sapiente sit. Sed reprehenderit ad quo et eos sed natus.</p>\n<p>Voluptate suscipit quibusdam in nam quia. A a autem cupiditate quia sed at velit vel. Consequatur magni nihil quos. Soluta consequatur sunt ut est similique sit.</p>",
    "wordCount": 156,
    "relatedSlugs": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891"
    ]
  }
];

export const GuideCategories = [
  {
    "slug": "dog-guides",
    "label": "Dog Guides"
  },
  {
    "slug": "nutrition",
    "label": "Nutrition"
  },
  {
    "slug": "relocation",
    "label": "Relocation"
  }
];

export function GuideCategoryLabel(slug: string): string {
  return slug
    .split("-")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}

/**
 * Canonical article order — extracted from dist/guides/index.html and
 * dist/guides/category/{slug}/index.html. Preserves Laravel's
 * `latest('published_at')` ordering which cannot be reconstructed from
 * article content alone (no published_at timestamp in the rendered HTML).
 *
 * Use this to order articles on listing pages so they match the live site.
 */
export const guidePostsCanonicalOrder = {
  "index": {
    "featured": "reiciendis-at-aut-et-ea-1352",
    "articles": [
      "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
      "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603",
      "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
      "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
      "quasi-aliquam-veritatis-nihil-soluta-deserunt-ut-ipsam-qui-9182",
      "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743",
      "assumenda-nam-enim-facilis-nostrum-ipsum-porro-culpa-292",
      "nihil-ducimus-est-sint-minus-sint-pariatur-quia-aperiam-2486",
      "consequatur-voluptas-suscipit-labore-architecto-ducimus-culpa-autem-tempora-5178",
      "dolore-sint-quis-beatae-qui-asperiores-3830"
    ]
  },
  "categories": {
    "dog-guides": {
      "featured": "maiores-eveniet-sint-dolorem-consequuntur-dolor-soluta-id-laudantium-et-natus-nisi-7194",
      "articles": [
        "neque-quibusdam-cumque-animi-sed-quidem-qui-dicta-asperiores-rem-autem-7606",
        "aut-iste-expedita-accusamus-excepturi-beatae-veritatis-3603",
        "quasi-aliquam-veritatis-nihil-soluta-deserunt-ut-ipsam-qui-9182",
        "assumenda-nam-enim-facilis-nostrum-ipsum-porro-culpa-292",
        "nihil-ducimus-est-sint-minus-sint-pariatur-quia-aperiam-2486",
        "voluptatem-nostrum-totam-voluptas-blanditiis-quaerat-sint-quia-9172",
        "eveniet-ut-et-beatae-at-qui-ut-6817",
        "vel-fugit-consectetur-amet-sit-unde-repellendus-et-tempore-2771",
        "accusamus-sint-qui-voluptas-vero-ipsa-velit-quis-sit-quaerat-3441",
        "exercitationem-qui-dolorum-dolor-sint-vel-maiores-non-dolorem-pariatur-7342",
        "optio-mollitia-adipisci-sunt-adipisci-blanditiis-natus-quam-1312"
      ]
    },
    "nutrition": {
      "featured": "laudantium-occaecati-sunt-voluptatem-dicta-consectetur-repellat-1388",
      "articles": [
        "id-velit-est-esse-et-doloremque-neque-quia-autem-autem-officiis-rerum-minus-9171",
        "rem-repellat-quos-ut-facere-tempora-consequatur-corrupti-8891",
        "aut-iusto-saepe-consequuntur-id-consequatur-similique-laborum-fugit-vitae-5142",
        "error-non-amet-ipsa-commodi-deserunt-sit-3748",
        "natus-cum-qui-molestiae-consectetur-dignissimos-fuga-ducimus-aut-vitae-9565",
        "nobis-numquam-consequuntur-sit-autem-dolorem-549",
        "quos-adipisci-ad-perspiciatis-quasi-accusantium-libero-3356",
        "est-alias-praesentium-delectus-sed-repudiandae-7689",
        "laboriosam-et-modi-blanditiis-quas-ratione-autem-eius-qui-est-soluta-8341",
        "laboriosam-eum-corporis-est-officiis-optio-quia-1958",
        "saepe-non-illum-sit-sapiente-rerum-placeat-nihil-quas-qui-3116"
      ]
    },
    "relocation": {
      "featured": "reiciendis-at-aut-et-ea-1352",
      "articles": [
        "numquam-atque-impedit-atque-cupiditate-voluptate-doloribus-quia-magnam-nam-voluptas-molestiae-5716",
        "modi-consequatur-sit-qui-ratione-officia-autem-deleniti-2743",
        "consequatur-voluptas-suscipit-labore-architecto-ducimus-culpa-autem-tempora-5178",
        "dolore-sint-quis-beatae-qui-asperiores-3830",
        "unde-at-assumenda-qui-velit-8925",
        "quia-fugiat-aut-quidem-et-hic-vel-4157",
        "nobis-officiis-nulla-ipsa-velit-iusto-enim-repellendus-quia-5913",
        "cupiditate-dolores-rerum-beatae-aut-nihil-ut-officiis-omnis-mollitia-distinctio-7291",
        "facere-nostrum-voluptatem-velit-non-accusamus-vitae-excepturi-1005",
        "laudantium-velit-blanditiis-sed-aut-4729",
        "molestiae-omnis-in-dolorem-qui-quos-facere-sapiente-5431"
      ]
    }
  }
};
