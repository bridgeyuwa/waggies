/**
 * About page content — extracted verbatim from the Laravel Blade source of
 * truth.
 *
 *   - Hero (gradient + image):  lines 4–7
 *   - Stats band (4):           lines 10–34
 *   - Philosophy section:       lines 38–136  (heading + 3 body paragraphs
 *                                              + 4 feature rows + image
 *                                              mosaic of 2)
 *   - Story section:            lines 139–183 (heading + 4 body paragraphs
 *                                              + 4 stat tiles)
 *   - Operating Standards band: lines 186–217 (feature-band with 4 features
 *                                              + multi-line subtitle)
 *   - Specialists (4 cards):    lines 221–264
 *   - HQ contact card + map:    lines 267–386
 *   - Secondary CTA:            lines 388–397
 *
 * Component defaults referenced:
 *   - components/hero/gradient.blade.php
 *   - components/feature-band.blade.php
 *   - components/about/team-card.blade.php  (badge, roles[], slot text)
 *   - components/cta/secondary.blade.php
 *
 * Route translations applied:
 *   route('contact')         → /contact
 *   route('services.index')  → /services
 *
 * NOTE — anomalies preserved verbatim from source:
 *   1. The "Meet the Specialists" grid (lines 235–262) contains FOUR
 *      identical team-card instances (Dr. Amara Okeke, Head Veterinarian,
 *      same image URL, same roles, same slot text). This is duplicate /
 *      placeholder content in the canonical source — preserved as-is.
 *   2. The "Our Story" body has 4 paragraphs in source (lines 148–169),
 *      not 3 as the brief stated. All 4 are preserved verbatim.
 *   3. Operating Standards `subtitle` in source spans multiple lines with
 *      embedded whitespace; visually collapsed whitespace is preserved here
 *      (HTML collapses multi-line attribute values to single spaces at
 *      render time anyway).
 *
 * DO NOT paraphrase, modernize, abbreviate, or "improve" this content.
 */

// ── Hero ──────────────────────────────────────────────────────────────────

export type AboutHero = {
  title: string;
  subtitle: string;
  primaryCta: { label: string; href: string };
  secondaryCta: { label: string; href: string };
  imageSrc: string;
};

export const aboutHero: AboutHero = {
  title: "Complete Veterinary & Pet Care in Abuja",
  subtitle:
    "A fully integrated veterinary, boarding, grooming, training, relocation, and identification service designed for consistent, professional pet care in one place.",
  primaryCta: { label: "Book a Free Consultation", href: "/contact" },
  secondaryCta: { label: "Explore Services", href: "/services" },
  imageSrc:
    "https://images.unsplash.com/photo-1650454027983-e2b8fe55b30b?w=600&auto=format&fit=crop&q=60&ixlib=rb-4.1.0&ixid=M3wxMjA3fDB8MHxzZWFyY2h8MTR8fGx1eHVyeSUyMGRvZyUyMGJvYXJkaW5nJTIwZmFjaWxpdHklMjBpbmRvb3IlMjBtb2Rlcm4lMjBjbGVhbiUyMGRvZyUyMHN1aXRlfGVufDB8fDB8fHww",
} as const;

// ── Stats band (4) ────────────────────────────────────────────────────────

export type AboutStat = { value: string; label: string };

export const aboutStats: AboutStat[] = [
  { value: "5k+", label: "Premium Clients" },
  { value: "24/7", label: "Concierge Vet Care" },
  { value: "15+", label: "Global Specialists" },
  { value: "100%", label: "Protocol-Based Handling" },
];

// ── Philosophy section ────────────────────────────────────────────────────

export type AboutPhilosophyFeature = {
  icon: string;
  title: string;
  description: string;
};

export type AboutPhilosophy = {
  eyebrow: string;
  title: string;
  body: string[];
  features: AboutPhilosophyFeature[];
};

export const aboutPhilosophy: AboutPhilosophy = {
  eyebrow: "Our Philosophy",
  title: "Redefining Pet Care Standards in West Africa",
  body: [
    "Founded to bridge the gap in luxury pet services, Waggies has evolved into Abuja's most prestigious destination for animal wellness. We believe that unconditional love deserves uncompromising care.",
    "Our facility blends advanced medical technology with the comfort of a 5-star resort. Whether it's a routine check-up, a grooming session, or international relocation, we handle every detail with precision and grace.",
    "Pet Care Should Never Be Reactive: We believe animals deserve the same intentionality and structure as human healthcare. Not rushed decisions. Not inconsistent handling. Not emotional guesswork — but deliberate, thoughtful care built around long-term wellbeing",
  ],
  features: [
    {
      icon: "diamond",
      title: "Luxury Standards",
      description: "Climate-controlled suites & premium amenities.",
    },
    {
      icon: "public",
      title: "Global Mobility",
      description: "Specialized in seamless international pet travel.",
    },
    {
      icon: "verified_user",
      title: "Expert Supervision",
      description: "Qualified vets on site, always.",
    },
    {
      icon: "schedule",
      title: "24/7 Concierge Care",
      description: "We never sleep so they can.",
    },
  ],
};

// ── Image mosaic (2 images) ───────────────────────────────────────────────

export type AboutMosaicImage = {
  src: string;
  alt: string;
  wrapperClass: string;
  imgClass: string;
};

export const aboutMosaicImages: AboutMosaicImage[] = [
  {
    src: "https://lh3.googleusercontent.com/aida-public/AB6AXuDxxpHCeKkAUCKA6_u37LZYgD7eiEysnjMJ1_XhBMszI7ivmpwLXlnqS3L557Cv5skfAwssIbZGT0IceX5KRt_rceRZ89rLsI5pGut0K0r2jdnoqwALENhMXtAo-LrZV8ogODbPQfS7qxO-7aVlUg3TovbZwdqTUuBzu2dPwC0K-3v7NAZQ6FFUCiF3eXuZhVkGKR_iLGr0T6zhuA3b3SV8KAklensa67V92-4sKh9lJwXQxs4ZCoH8TFB0GpR6nX5-AXFKHOmRcVg2",
    alt: "Modern Waggies clinic interior",
    wrapperClass: "img-zoom-wrap rounded-2xl shadow-sm hover:shadow-soft transition mt-8",
    imgClass: "w-full h-64 object-cover rounded-2xl",
  },
  {
    src: "https://lh3.googleusercontent.com/aida-public/AB6AXuAvPqf9jVGR9bPOPiqoaoHk8-YNEWWJ_bY0Zr7q5x44WaVdOGEAaYDKKL2iSl0u8DdIEN8XNkxu0YtXzhkFzgsBRlTmoN6Mf4EK7F2BUgrYKdM-UpH7rmJbQdyMTbtNDQaNjPZZC6stF0JNDLC-rIQHTp3BbyozfmR5EKn8G285B8FaqR59x9Y4nsflOrZIDfugoUzs6SabeAg-UluIt08DVPhlGQrYDP30Ngwh1ek2O6BkIGAyvHWw7UX4T7nRjhSEB_igKwi0EoyP",
    alt: "Pet grooming session",
    wrapperClass: "img-zoom-wrap rounded-2xl shadow-sm hover:shadow-soft transition",
    imgClass: "w-full h-64 object-cover rounded-2xl",
  },
];

// ── Our Story section ─────────────────────────────────────────────────────

export type AboutStoryStat = { value: string; label: string };

export type AboutStory = {
  eyebrow: string;
  /** Raw HTML — Blade renders via `{!! $title !!}`. Contains <br />. */
  title: string;
  paragraphs: string[];
  stats: AboutStoryStat[];
};

export const aboutStory: AboutStory = {
  eyebrow: "Our Story",
  title: "Built by Pet Lovers,<br />for Pet Owners",
  paragraphs: [
    "Waggies was born from a personal experience — a pet owner in Abuja struggling to find a boarding facility that matched the standard of care they gave their own dog at home. What started as a small dog hotel has grown into Abuja's most comprehensive luxury pet care centre.",
    "Today, we offer boarding, grooming, vet care, training, transport, and international relocation — all under one roof, all to the same uncompromising standard.",
    "Every member of our team is an animal lover first. We believe the best pet care comes from genuine passion — not just process.",
    "Built From a Gap in Real Veterinary Care Waggies began with a simple but frustrating reality — pet owners in Abuja had to choose between basic boarding facilities or expensive, fragmented services with no continuity of care. The idea wasn’t to “start a pet business.” It was to remove the inconsistency between grooming, boarding, and veterinary handling by putting everything under one controlled system. What exists today is not a collection of services — but a unified care environment designed to eliminate risk created by fragmentation.",
  ],
  stats: [
    { value: "500+", label: "Happy Clients" },
    { value: "7", label: "Years in Business" },
    { value: "4.9", label: "Average Rating" },
    { value: "15+", label: "Team Members" },
  ],
};

// ── Operating Standards (feature-band) ────────────────────────────────────

export type AboutOperatingStandard = {
  icon: string;
  title: string;
  description: string;
};

export type AboutOperatingStandards = {
  eyebrow: string;
  /** Raw HTML — Blade renders via `{!! $title !!}`. Contains <br/> + <span>. */
  title: string;
  subtitle: string;
  features: AboutOperatingStandard[];
};

export const aboutOperatingStandards: AboutOperatingStandards = {
  eyebrow: "Operating Standards",
  title:
    'Our Standard of Handling<br/><span class="text-secondary italic">Across All Services</span>',
  subtitle:
    "We hold ourselves to a higher standard — because your pets deserve nothing less. Whether it’s boarding, grooming, veterinary care, training, or relocation — our decisions follow one standard: what is best for the animal always comes first.",
  features: [
    {
      icon: "volunteer_activism",
      title: "Supervised Pet-First Care",
      description:
        "Every service is designed around comfort, safety, and wellbeing — never convenience or speed.",
    },
    {
      icon: "sync",
      title: "Consistency Across Services",
      description:
        "Boarding, grooming, and medical care follow the same documented handling standards and staff procedures.",
    },
    {
      icon: "shield",
      title: "Controlled Safety Protocols",
      description:
        "Pets are separated by risk level, monitored during movement, and handled under strict safety procedures.",
    },
    {
      icon: "visibility",
      title: "Transparent Owner Communication",
      description:
        "Owners receive clear updates on condition, progress, and any incidents — with no hidden details.",
    },
  ],
};

// ── Meet the Specialists (team cards) ─────────────────────────────────────

export type AboutTeamMember = {
  name: string;
  role: string;
  image: string;
  badge: string;
  roles: string[];
  /** Slot text — the team-card component renders this as the body copy. */
  bio: string;
};

/**
 * NOTE: All four entries below are byte-identical duplicates in the Blade
 * source (lines 237–261 of about/index.blade.php). This is placeholder
 * content in the canonical Laravel site — preserved here verbatim.
 */
export const aboutTeamMembers: AboutTeamMember[] = [
  {
    name: "Dr. Amara Okeke",
    role: "Head Veterinarian",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAgWoocAfd8dbeiglF8t-YP3DrZ9K05COA2RiovxrhAO-TUUngB1JpLH6jTxb5iRiV3TXGzHWkZpkC6i5XPSDPGBHqQ6nrrauWhu8_vY_rlKNbWr0oAbVbJ8PhvCpeDTVwH2MlWYtJZZfKP5korMPIhPeEaPLjUd1yQc2P776NsK6BEkLYGE1PPRYDUnttzIX94gLA9gJ2nKsuBHbgg4NHn9ImoG3LF2oz9sTz78dL4-P-Ge6az336MMDYSi46u3gMq3-Dc4Kx0ewRl",
    badge: "Vet",
    roles: ["DVM", "Surgery Cert"],
    bio: "Board-certified specialist in small animal surgery with over a decade of clinical experience.",
  },
  {
    name: "Dr. Amara Okeke",
    role: "Head Veterinarian",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAgWoocAfd8dbeiglF8t-YP3DrZ9K05COA2RiovxrhAO-TUUngB1JpLH6jTxb5iRiV3TXGzHWkZpkC6i5XPSDPGBHqQ6nrrauWhu8_vY_rlKNbWr0oAbVbJ8PhvCpeDTVwH2MlWYtJZZfKP5korMPIhPeEaPLjUd1yQc2P776NsK6BEkLYGE1PPRYDUnttzIX94gLA9gJ2nKsuBHbgg4NHn9ImoG3LF2oz9sTz78dL4-P-Ge6az336MMDYSi46u3gMq3-Dc4Kx0ewRl",
    badge: "Vet",
    roles: ["DVM", "Surgery Cert"],
    bio: "Board-certified specialist in small animal surgery with over a decade of clinical experience.",
  },
  {
    name: "Dr. Amara Okeke",
    role: "Head Veterinarian",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAgWoocAfd8dbeiglF8t-YP3DrZ9K05COA2RiovxrhAO-TUUngB1JpLH6jTxb5iRiV3TXGzHWkZpkC6i5XPSDPGBHqQ6nrrauWhu8_vY_rlKNbWr0oAbVbJ8PhvCpeDTVwH2MlWYtJZZfKP5korMPIhPeEaPLjUd1yQc2P776NsK6BEkLYGE1PPRYDUnttzIX94gLA9gJ2nKsuBHbgg4NHn9ImoG3LF2oz9sTz78dL4-P-Ge6az336MMDYSi46u3gMq3-Dc4Kx0ewRl",
    badge: "Vet",
    roles: ["DVM", "Surgery Cert"],
    bio: "Board-certified specialist in small animal surgery with over a decade of clinical experience.",
  },
  {
    name: "Dr. Amara Okeke",
    role: "Head Veterinarian",
    image:
      "https://lh3.googleusercontent.com/aida-public/AB6AXuAgWoocAfd8dbeiglF8t-YP3DrZ9K05COA2RiovxrhAO-TUUngB1JpLH6jTxb5iRiV3TXGzHWkZpkC6i5XPSDPGBHqQ6nrrauWhu8_vY_rlKNbWr0oAbVbJ8PhvCpeDTVwH2MlWYtJZZfKP5korMPIhPeEaPLjUd1yQc2P776NsK6BEkLYGE1PPRYDUnttzIX94gLA9gJ2nKsuBHbgg4NHn9ImoG3LF2oz9sTz78dL4-P-Ge6az336MMDYSi46u3gMq3-Dc4Kx0ewRl",
    badge: "Vet",
    roles: ["DVM", "Surgery Cert"],
    bio: "Board-certified specialist in small animal surgery with over a decade of clinical experience.",
  },
];

// ── Specialists section header ────────────────────────────────────────────

export const aboutSpecialistsHeading = {
  eyebrow: "Expertise",
  title: "Meet the Specialists",
  intro:
    "Our team is composed of passionate professionals, certified internationally to ensure your pet receives the highest standard of care.",
} as const;

// ── HQ contact card ───────────────────────────────────────────────────────

export type AboutHqTrustBadge = { icon: string; label: string };

export type AboutHqContact = {
  title: string;
  trustBadges: AboutHqTrustBadge[];
  address: { label: string; /** Raw HTML — contains <br>. */ lines: string };
  hours: {
    label: string;
    lines: string[];
    openNowBadge: { label: string; className: string };
  };
  contact: {
    label: string;
    phone: { href: string; label: string; className: string };
    email: { href: string; label: string; className: string };
  };
  actions: {
    primary: {
      href: string;
      icon: string;
      label: string;
      className: string;
      /** Original `target="_blank"` on the Blade anchor. */
      targetBlank: boolean;
    };
    call: { href: string; ariaLabel: string; icon: string; className: string };
    whatsapp: { href: string; ariaLabel: string; className: string };
  };
  /** Google Maps embed iframe `src`. */
  mapIframeSrc: string;
};

export const aboutHqContact: AboutHqContact = {
  title: "Waggies HQ",
  trustBadges: [
    { icon: "star", label: "4.9 Rating" },
    { icon: "verified", label: "Certified Care" },
    { icon: "schedule", label: "Open Today" },
  ],
  address: {
    label: "Address",
    lines: "Plot 1234, Ahmadu Bello Way,<br>Garki 2, Abuja, Nigeria",
  },
  hours: {
    label: "Hours",
    lines: ["Mon–Fri: 9AM – 5PM", "Sat–Sun: 10AM – 2PM"],
    openNowBadge: {
      label: "Open Now",
      className: "inline-block mt-2 text-xs font-semibold px-2 py-1 rounded bg-success-light text-success",
    },
  },
  contact: {
    label: "Contact",
    phone: {
      href: "tel:+2348009244437",
      label: "+234 800 WAGGIES",
      className: "block font-semibold text-primary-dark",
    },
    email: {
      href: "mailto:hello@waggies.ng",
      label: "hello@waggies.ng",
      className: "text-sm text-primary underline",
    },
  },
  actions: {
    primary: {
      href: "https://maps.google.com/?q=Garki+2+Abuja+Nigeria",
      icon: "directions",
      label: "Get Directions",
      className:
        "flex-1 px-5 py-3 rounded-full bg-primary hover:bg-primary-dark text-white text-sm font-semibold flex items-center justify-center gap-2 transition-colors",
      targetBlank: true,
    },
    call: {
      href: "tel:+2348009244437",
      ariaLabel: "Call",
      icon: "call",
      className:
        "w-11 h-11 flex items-center justify-center rounded-full border border-primary/30 text-primary-dark hover:bg-surface-purple transition-colors",
    },
    whatsapp: {
      href: "https://wa.me/2348009244437",
      ariaLabel: "WhatsApp",
      className:
        "w-11 h-11 flex items-center justify-center rounded-full bg-whatsapp text-white hover:bg-whatsapp-hover transition-colors",
    },
  },
  mapIframeSrc:
    "https://maps.google.com/maps?q=Garki+2+Abuja+Nigeria&output=embed",
};

// ── Secondary CTA ─────────────────────────────────────────────────────────

export type AboutCtaSecondary = {
  heading: string;
  body: string;
  primaryLabel: string;
  primaryHref: string;
  primaryIcon: string;
};

export const aboutCtaSecondary: AboutCtaSecondary = {
  heading: "Explore Our Pet Care Services",
  body: "From grooming to veterinary care and boarding, discover everything we offer to keep your pet healthy and happy.",
  primaryLabel: "View Services",
  primaryHref: "/services",
  primaryIcon: "arrow_forward",
} as const;
