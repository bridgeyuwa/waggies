/**
 * Careers page content — extracted verbatim from the Laravel Blade source
 * of truth.
 *
 *   - Hero (hero.image):    lines 5–12
 *   - Perks grid (4):       lines 14–38
 *   - Open Roles list (5):  lines 40–64
 *   - Speculative note:     line 62
 *
 * Component defaults referenced:
 *   - components/hero/image — NOT in the supplied component list, but the
 *     page passes `image-src`, `eyebrow`, `title`, `subtitle`,
 *     `primary-cta`, `secondary-cta`. These are preserved verbatim as data.
 *   - components/section-heading.blade.php (spacing='mb-16')
 *
 * Route translations applied:
 *   route('contact')    → /contact
 *   route('about.index')→ /about
 *
 * NOTE — anomaly preserved verbatim from source:
 *   The hero image path `/images/careers.jpg` is a placeholder that 404s
 *   in the live Laravel site (Phase 2 decision: preserve broken image
 *   paths verbatim). The primary CTA target `#open-roles` is an in-page
 *   anchor that matches the `id="open-roles"` on the Open Roles section
 *   (line 40 of source).
 *
 * DO NOT paraphrase, modernize, abbreviate, or "improve" this content.
 */

// ── Hero ──────────────────────────────────────────────────────────────────

export type CareersHero = {
  imageSrc: string;
  eyebrow: string;
  /** Raw HTML — Blade renders via `{!! $title !!}`. Contains <br/>. */
  title: string;
  subtitle: string;
  primaryCta: { label: string; href: string };
  secondaryCta: { label: string; href: string };
};

export const careersHero: CareersHero = {
  imageSrc: "/images/careers.jpg",
  eyebrow: "Join Our Team",
  title: "Work With Animals<br/>You Love Every Day",
  subtitle:
    "We're always looking for passionate, qualified people to join the Waggies family. If you love animals and care about doing things properly, we'd love to hear from you.",
  primaryCta: { label: "See Open Roles", href: "#open-roles" },
  secondaryCta: { label: "About Waggies", href: "/about" },
} as const;

// ── "Why Work at Waggies?" section heading ────────────────────────────────

export const careersPerksHeading = {
  eyebrow: "Why Work at Waggies?",
  title: "A Place Where<br/>Passion Meets Purpose",
  subtitle:
    "We offer a supportive environment, continuous training, and the satisfaction of making a real difference to animals every single day.",
} as const;

// ── Perks grid (4) ────────────────────────────────────────────────────────

export type CareersPerk = {
  icon: string;
  title: string;
  desc: string;
};

export const careersPerks: CareersPerk[] = [
  {
    icon: "school",
    title: "Paid Training",
    desc: "Fully funded professional development and certification for all team members.",
  },
  {
    icon: "favorite",
    title: "Do What You Love",
    desc: "Spend your working day doing something that genuinely matters to you.",
  },
  {
    icon: "groups",
    title: "Great Team Culture",
    desc: "A tight-knit, supportive team that looks out for each other.",
  },
  {
    icon: "trending_up",
    title: "Room to Grow",
    desc: "We promote from within and invest in the long-term careers of our staff.",
  },
];

// ── Open Roles section heading ────────────────────────────────────────────

export const careersOpenRolesHeading = {
  eyebrow: "Open Roles",
  title: "Current Vacancies",
} as const;

// ── Open Roles (5) ────────────────────────────────────────────────────────

export type CareersOpenRole = {
  role: string;
  type: string;
  dept: string;
};

export type CareersOpenRoleWithCta = CareersOpenRole & {
  applyHref: string;
  applyLabel: string;
  applyIcon: string;
  applyClassName: string;
};

export const careersOpenRoles: CareersOpenRoleWithCta[] = [
  {
    role: "Pet Care Attendant",
    type: "Full-time",
    dept: "Boarding",
    applyHref: "/contact",
    applyLabel: "Apply Now",
    applyIcon: "arrow_forward",
    applyClassName:
      "inline-flex items-center gap-2 border-2 border-primary text-primary px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-primary hover:text-white transition shrink-0",
  },
  {
    role: "Certified Pet Groomer",
    type: "Full-time",
    dept: "Grooming Spa",
    applyHref: "/contact",
    applyLabel: "Apply Now",
    applyIcon: "arrow_forward",
    applyClassName:
      "inline-flex items-center gap-2 border-2 border-primary text-primary px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-primary hover:text-white transition shrink-0",
  },
  {
    role: "Veterinary Assistant",
    type: "Full-time",
    dept: "Vet Care",
    applyHref: "/contact",
    applyLabel: "Apply Now",
    applyIcon: "arrow_forward",
    applyClassName:
      "inline-flex items-center gap-2 border-2 border-primary text-primary px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-primary hover:text-white transition shrink-0",
  },
  {
    role: "Dog Trainer",
    type: "Full-time",
    dept: "Training",
    applyHref: "/contact",
    applyLabel: "Apply Now",
    applyIcon: "arrow_forward",
    applyClassName:
      "inline-flex items-center gap-2 border-2 border-primary text-primary px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-primary hover:text-white transition shrink-0",
  },
  {
    role: "Pet Transport Driver",
    type: "Part-time",
    dept: "Transport",
    applyHref: "/contact",
    applyLabel: "Apply Now",
    applyIcon: "arrow_forward",
    applyClassName:
      "inline-flex items-center gap-2 border-2 border-primary text-primary px-5 py-2.5 rounded-full text-sm font-semibold hover:bg-primary hover:text-white transition shrink-0",
  },
];

// ── Speculative application note ──────────────────────────────────────────

export const careersSpeculativeNote =
  "Don't see a role that fits? Send us a speculative application — we love meeting passionate people." as const;
