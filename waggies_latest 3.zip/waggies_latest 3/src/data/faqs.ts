/**
 * Waggies FAQ dataset — extracted verbatim from the Laravel source.
 *
 *
 * The seeder defines the canonical FAQ content for the site. The Laravel
 * `Faq` model exposes three query scopes (see app/Models/Faq.php):
 *
 *   scopeActive         — where is_active = true
 *   scopeOrdered        — orderBy(sort_order).orderBy(id)   ← id is the
 *                          insertion order in this file (preserved as `id`)
 *   scopeForSubcategory — subcategory IS NULL OR subcategory = ?
 *
 * We reproduce those exact semantics here in TypeScript. `id` is assigned
 * sequentially in source order so `orderBy(id)` produces the same ordering as
 * a fresh MySQL AUTO_INCREMENT after seeding.
 *
 * DO NOT paraphrase, modernize, or "clean up" this content. The Laravel
 * application is the source of truth for the migration.
 */

export type Faq = {
  /** Stable ID (preserves seeder insertion order — equivalent to MySQL
   *  AUTO_INCREMENT id after `php artisan db:seed`). */
  id: number;
  category: FaqCategory;
  subcategory?: FaqSubcategory;
  sort_order: number;
  question: string;
  answer: string;
  is_active: boolean;
};

export type FaqCategory =
  | "boarding"
  | "grooming"
  | "relocation"
  | "vet-care"
  | "general"
  | "training"
  | "transport";

export type FaqSubcategory =
  | "dogs"
  | "cats"
  | "exotic"
  | "import"
  | "export"
  | "local";

/**
 * The full FAQ dataset — every entry from FaqSeeder.php, in source order.
 * `id` is assigned in source order so the `orderBy('id')` tiebreaker in
 * `scopeOrdered` produces identical results to a freshly-seeded MySQL DB.
 */
const faqs: Faq[] = [
  // ── Boarding ────────────────────────────────────────────────────────────
  { id: 1,  category: "boarding", sort_order: 1, question: "What do I need to bring for check-in?", answer: "Your pet's vaccination records, any regular medication, their usual food if preferred, and a comfort item such as a blanket or toy.", is_active: true },
  { id: 2,  category: "boarding", sort_order: 2, question: "How often will I receive updates on my pet?", answer: "We send a photo update every day, along with a brief note on how your pet is doing. You can also message us directly at any time.", is_active: true },
  { id: 3,  category: "boarding", sort_order: 3, question: "Can my dogs stay together?", answer: "Yes — if your dogs are known to each other and you request shared boarding, we can accommodate this. Otherwise, pets are housed individually.", is_active: true },
  { id: 4,  category: "boarding", sort_order: 4, question: "What happens if my pet becomes unwell during their stay?", answer: "Our on-site vet will assess your pet immediately. We will contact you as soon as possible and follow your instructions on next steps.", is_active: true },
  { id: 5,  category: "boarding", sort_order: 5, question: "What are your minimum and maximum stay durations?", answer: "We accommodate stays from a single overnight to several weeks. For extended stays, we schedule weekly check-in calls with owners.", is_active: true },

  // ── Grooming ───────────────────────────────────────────────────────────
  { id: 6,  category: "grooming", sort_order: 1, question: "Do you groom cats as well as dogs?", answer: "Yes, we groom both dogs and cats. We also offer grooming for rabbits and some other small animals — contact us to discuss your pet's needs.", is_active: true },
  { id: 7,  category: "grooming", sort_order: 2, question: "How long does a full groom take?", answer: "A full groom typically takes 2–4 hours depending on the breed, coat condition, and the specific services booked.", is_active: true },
  { id: 8,  category: "grooming", sort_order: 3, question: "Do I need to book grooming in advance?", answer: "Yes — we recommend booking at least 48 hours in advance to secure your preferred time slot. Weekend slots fill up quickly.", is_active: true },
  { id: 9,  category: "grooming", sort_order: 4, question: "What grooming services do you offer?", answer: "We offer full baths, breed-specific haircuts, nail trimming, ear cleaning, teeth brushing, de-shedding treatments, and more. Ask us about a bespoke package.", is_active: true },

  // ── Relocation ─────────────────────────────────────────────────────────
  { id: 10, category: "relocation", sort_order: 1, question: "How early should I start planning a pet relocation?", answer: "We recommend contacting us at least 3 months before your travel date. Some import permits can take 6–8 weeks to process.", is_active: true },
  { id: 11, category: "relocation", sort_order: 2, question: "Do you handle both import and export?", answer: "Yes — we manage both importing pets into Nigeria and exporting them to destinations worldwide.", is_active: true },
  { id: 12, category: "relocation", sort_order: 3, question: "What documents are required to import a pet?", answer: "At minimum: a valid health certificate, proof of vaccinations, and an import permit from the Nigerian NAQS. Requirements vary by species and country of origin.", is_active: true },
  { id: 13, category: "relocation", sort_order: 4, question: "Do you provide airport pickup and drop-off for pets?", answer: "Yes — we offer full door-to-door relocation including airport pickup/drop-off, customs clearance handling, and post-arrival monitoring.", is_active: true },

  // ── Vet Care ───────────────────────────────────────────────────────────
  { id: 14, category: "vet-care", sort_order: 1, question: "Do I need an appointment to see the vet?", answer: "Routine check-ups require an appointment. For emergencies, we see all pets as quickly as possible — call us immediately and we will triage your case.", is_active: true },
  { id: 15, category: "vet-care", sort_order: 2, question: "What vaccinations do you administer?", answer: "We administer all core vaccines for dogs and cats (rabies, parvovirus, distemper, etc.) as well as lifestyle vaccines. We will advise the right schedule for your pet.", is_active: true },
  { id: 16, category: "vet-care", sort_order: 3, question: "Do you offer pet microchipping?", answer: "Yes — microchipping is available at the clinic and takes just a few minutes. It is also a legal requirement for certain types of travel.", is_active: true },

  // ── General ────────────────────────────────────────────────────────────
  { id: 17, category: "general", sort_order: 1, question: "Where are you located?", answer: "We are based in Abuja, Nigeria. Contact us for our exact address and directions.", is_active: true },
  { id: 18, category: "general", sort_order: 2, question: "What are your opening hours?", answer: "Our facility is open 7 days a week. Office hours are 8am–6pm. Boarding guests receive 24/7 supervision.", is_active: true },
  { id: 19, category: "general", sort_order: 3, question: "How do I make a booking?", answer: "Contact us via phone, WhatsApp, or the contact form on this website. We'll confirm availability and send all the details you need.", is_active: true },
  { id: 20, category: "general", sort_order: 4, question: "Do you accept all dog breeds?", answer: "Yes — we welcome all breeds. For very large or high-energy breeds, please mention this when booking so we can ensure the right space and staffing.", is_active: true },

  // ── Boarding — Dogs specific (subcategory) ────────────────────────────
  { id: 21, category: "boarding", subcategory: "dogs", sort_order: 10, question: "How much exercise will my dog get each day?", answer: "Dogs receive at least two structured outdoor exercise sessions per day, plus free-play time. High-energy breeds receive additional activity tailored to their needs.", is_active: true },
  { id: 22, category: "boarding", subcategory: "dogs", sort_order: 11, question: "Can my dog socialise with other dogs?", answer: "Yes — we run carefully supervised group play sessions for dogs that enjoy company, matched by size and temperament. You can opt your dog out of group play if you prefer individual sessions only.", is_active: true },
  { id: 23, category: "boarding", subcategory: "dogs", sort_order: 12, question: "What if my dog has a special diet or health condition?", answer: "Please let us know at booking. We follow all dietary instructions precisely and can administer medication if required. Our on-site vet is available daily for any health concerns.", is_active: true },

  // ── Boarding — Cats specific ──────────────────────────────────────────
  { id: 24, category: "boarding", subcategory: "cats", sort_order: 10, question: "Is the cat area completely separate from the dogs?", answer: "Yes — our cat wing is a fully separate, dog-free zone. Cats never share corridors or outdoor areas with dogs, reducing stress significantly.", is_active: true },
  { id: 25, category: "boarding", subcategory: "cats", sort_order: 11, question: "My cat is very shy — will she be okay?", answer: "Absolutely. Shy cats are given extra time to settle at their own pace. We never force interaction and provide plenty of hiding spots and elevated perches in every condo.", is_active: true },
  { id: 26, category: "boarding", subcategory: "cats", sort_order: 12, question: "Can I bring my cat's own bedding and toys?", answer: "Yes — we encourage it. Familiar scents are very comforting for cats in a new environment. Label all items with your cat's name.", is_active: true },

  // ── Boarding — Exotic specific ────────────────────────────────────────
  { id: 27, category: "boarding", subcategory: "exotic", sort_order: 10, question: "Do you have experience with reptiles?", answer: "Yes — our exotic team includes staff trained specifically in reptile care. We maintain correct temperature gradients, humidity, and UV lighting for each species.", is_active: true },
  { id: 28, category: "boarding", subcategory: "exotic", sort_order: 11, question: "Can you handle live feeding for my snake or reptile?", answer: "Yes — if your pet requires live or frozen feeders, please bring sufficient supply and provide feeding instructions. We follow your routine precisely.", is_active: true },
  { id: 29, category: "boarding", subcategory: "exotic", sort_order: 12, question: "What species do you NOT board?", answer: "We do not board venomous species, large constrictors over 3m, or wild/protected animals. Please contact us if you are unsure about your specific pet — we will advise honestly.", is_active: true },

  // ── Relocation — Import specific ──────────────────────────────────────
  { id: 30, category: "relocation", subcategory: "import", sort_order: 10, question: "What is the Nigerian import permit process?", answer: "An import permit must be obtained from the Nigerian Agricultural Quarantine Service (NAQS) before your pet travels. This typically takes 3–6 weeks. We apply on your behalf once you engage our services.", is_active: true },
  { id: 31, category: "relocation", subcategory: "import", sort_order: 11, question: "Is quarantine required when bringing a pet to Nigeria?", answer: "Nigeria does not mandate a fixed quarantine period, but all arriving pets undergo an inspection at the airport by NAQS officials. Having correct documentation ensures this is straightforward.", is_active: true },
  { id: 32, category: "relocation", subcategory: "import", sort_order: 12, question: "Can you collect my pet directly from the airport cargo terminal?", answer: "Yes — airport collection from Nnamdi Azikiwe International Airport is included in our full import service. We handle all customs and NAQS clearance on arrival.", is_active: true },

  // ── Relocation — Export specific ──────────────────────────────────────
  { id: 33, category: "relocation", subcategory: "export", sort_order: 10, question: "What health certificate do I need to export my pet from Nigeria?", answer: "An official veterinary health certificate endorsed by NAQS is required. Our on-site vet completes the examination and paperwork. The certificate is typically valid for 10 days from issue, so timing with your travel date is important.", is_active: true },
  { id: 34, category: "relocation", subcategory: "export", sort_order: 11, question: "Do entry requirements vary by destination country?", answer: "Yes — requirements vary significantly. The EU, UK, US, and other countries each have different rules on vaccinations, titre tests, and waiting periods. We research your specific destination and build a compliance plan.", is_active: true },
  { id: 35, category: "relocation", subcategory: "export", sort_order: 12, question: "Can my pet travel in the cabin with me?", answer: "This depends entirely on the airline and the size of your pet. Small pets may qualify for cabin travel on some airlines. We liaise with your airline to identify the best and safest option.", is_active: true },

  // ── Relocation — Local specific ───────────────────────────────────────
  { id: 36, category: "relocation", subcategory: "local", sort_order: 10, question: "Do you help with moving pets to other Nigerian cities?", answer: "Yes — we coordinate domestic pet relocation across Nigeria including Lagos, Port Harcourt, Kano, and other major cities, by road or domestic air cargo.", is_active: true },
  { id: 37, category: "relocation", subcategory: "local", sort_order: 11, question: "What documents are needed for domestic pet travel in Nigeria?", answer: "A veterinary health certificate and up-to-date vaccination record are recommended for domestic travel, and required by most domestic airlines for cargo shipment.", is_active: true },
  { id: 38, category: "relocation", subcategory: "local", sort_order: 12, question: "Can you handle door-to-door domestic relocation?", answer: "Yes — we offer end-to-end domestic relocation including collection, health certification, transport or flight coordination, and delivery to the destination address.", is_active: true },

  // ── Training ───────────────────────────────────────────────────────────
  { id: 39, category: "training", sort_order: 1, question: "What age can I start training my puppy?", answer: "Puppies can begin gentle, positive training from 8 weeks old. Early socialisation and foundation skills are the most important investment you can make in your puppy.", is_active: true },
  { id: 40, category: "training", sort_order: 2, question: "How many sessions will my dog need?", answer: "It depends on your goals and your dog's starting point. Most dogs see clear progress after 4–6 sessions. Behaviour modification cases may take longer — we'll give you an honest assessment at the start.", is_active: true },
  { id: 41, category: "training", sort_order: 3, question: "Do you use punishment or aversive tools?", answer: "Never. We use exclusively reward-based, force-free methods. No shock collars, prong collars, or intimidation-based techniques.", is_active: true },
  { id: 42, category: "training", sort_order: 4, question: "Can I be present during training sessions?", answer: "Yes — and for most programmes we strongly encourage owner participation. Training works best when you understand the techniques and can reinforce them consistently at home.", is_active: true },

  // ── Transport ──────────────────────────────────────────────────────────
  { id: 43, category: "transport", sort_order: 1, question: "Which areas of Abuja do you cover?", answer: "We cover all major districts including Maitama, Wuse, Asokoro, Garki, Gwarinpa, Jabi, Life Camp, and surrounding areas. Contact us if you are unsure whether your location is covered.", is_active: true },
  { id: 44, category: "transport", sort_order: 2, question: "How far in advance should I book transport?", answer: "We recommend booking at least 24 hours in advance to secure your preferred time slot. Same-day bookings are subject to availability.", is_active: true },
  { id: 45, category: "transport", sort_order: 3, question: "Are the vehicles air-conditioned?", answer: "Yes — all our transport vehicles are fully air-conditioned and fitted with approved pet crates and harnesses for your pet's safety and comfort during transit.", is_active: true },
  { id: 46, category: "transport", sort_order: 4, question: "Can I track my pet during transport?", answer: "Yes — our drivers send a WhatsApp update when they collect your pet and again on arrival at the destination. You can also call our team at any point during transit.", is_active: true },
];

/**
 * Reproduce Laravel's `Faq::scopeActive` — return only FAQs with is_active=true.
 * (All seeded FAQs are active; the filter is preserved for fidelity.)
 */
export function getActiveFaqs(): Faq[] {
  return faqs.filter((f) => f.is_active);
}

/**
 * Reproduce Laravel's `Faq::scopeOrdered` — sort by (sort_order ASC, id ASC).
 *
 * The id tiebreaker matters because several FAQs share sort_order=1, 2, 3...
 * across different categories, AND because the seeder pushes subcategory FAQs
 * (sort_order 10, 11, 12) AFTER the category-level FAQs (1..5). MySQL would
 * tiebreak on AUTO_INCREMENT id, which we mirror here via the source-order id.
 */
export function sortFaqs(list: Faq[]): Faq[] {
  return [...list].sort((a, b) => {
    if (a.sort_order !== b.sort_order) return a.sort_order - b.sort_order;
    return a.id - b.id;
  });
}

/**
 * Reproduce Laravel's `Faq::scopeForSubcategory` — when subcategory is null,
 * return the list unchanged; otherwise filter to FAQs whose subcategory is
 * null OR equals the requested subcategory.
 *
 * This is the exact query used by BoardingController::dogs() etc.
 *
 *   Faq::active()->ordered()
 *     ->where('category', 'boarding')
 *     ->forSubcategory('dogs')
 *     ->get();
 *
 * → returns boarding FAQs that are EITHER general (subcategory IS NULL) OR
 *   dog-specific (subcategory = 'dogs'). Cat- and exotic-specific FAQs are
 *   excluded.
 */
export function filterBySubcategory(list: Faq[], subcategory: string | null): Faq[] {
  if (subcategory === null) return list;
  return list.filter((f) => f.subcategory === undefined || f.subcategory === subcategory);
}

/**
 * Reproduce FaqController::index() — all active FAQs, grouped by category,
 * with categories list in insertion order.
 *
 * The Laravel controller does:
 *
 *   $faqs = Faq::active()->ordered()->get();
 *   $grouped = $faqs->groupBy('category');
 *   $categories = $grouped->keys()->map(fn ($slug) => [
 *       'slug'  => $slug,
 *       'label' => ucwords(str_replace('-', ' ', $slug)),
 *   ])->values();
 *
 * `groupBy` in Laravel preserves first-insertion order of keys. We mirror
 * that by tracking category order via the source `faqs` array.
 */
export function getGroupedFaqs(): {
  grouped: Record<string, Faq[]>;
  categories: ReadonlyArray<{ slug: string; label: string }>;
} {
  const ordered = sortFaqs(getActiveFaqs());
  const grouped: Record<string, Faq[]> = {};
  const categoryOrder: string[] = [];
  for (const f of ordered) {
    if (!(f.category in grouped)) {
      grouped[f.category] = [];
      categoryOrder.push(f.category);
    }
    grouped[f.category].push(f);
  }
  const categories = categoryOrder.map((slug) => ({
    slug,
    label: ucwords(slug.replace(/-/g, " ")),
  }));
  return { grouped, categories };
}

/**
 * Reproduce the FAQ query used by service & relocation controllers, e.g.:
 *
 *   Faq::active()->ordered()
 *     ->where('category', 'boarding')
 *     ->forSubcategory('dogs')
 *     ->get();
 */
export function getFaqsForService(
  category: FaqCategory,
  subcategory: string | null = null,
): Faq[] {
  const filtered = getActiveFaqs().filter((f) => f.category === category);
  return sortFaqs(filterBySubcategory(filtered, subcategory));
}

/** PHP `ucwords(str_replace('-', ' ', $slug))` — title-case with spaces. */
function ucwords(s: string): string {
  return s
    .split(" ")
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
    .join(" ");
}
