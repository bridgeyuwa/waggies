/**
 * Services index + per-service page content — extracted verbatim from the
 * Laravel Blade source.
 *
 * Sources of truth:
 *   - resources/views/pages/services/index.blade.php
 *   - resources/views/pages/services/boarding/index.blade.php
 *   - resources/views/pages/services/boarding/{dogs,cats,exotic}.blade.php
 *   - resources/views/pages/services/{grooming,vet-care,training,transport}.blade.php
 *
 * DO NOT paraphrase or "improve" this content.
 */

// ── Services index hero & cards ───────────────────────────────────────────
// Source: services/index.blade.php lines 5–33

export type ServiceCard = {
  title: string;
  description: string;
  href: string;
  imageSrc: string;
  icon: string;
};

export const servicesIndexHero = {
  imageSrc: "/images/services.jpg",
  eyebrow: "Everything Your Pet Needs",
  title: "Luxury Pet Care,<br/>All Under One Roof",
  subtitle:
    "From overnight boarding to international relocation — Waggies offers a full suite of premium services tailored to your pet.",
  primaryCta: { label: "View Our Services", href: "/services#services" },
  variant: "center" as const,
};

export const servicesIndexCards: ServiceCard[] = [
  {
    title: "Luxury Boarding",
    description:
      "Spacious, climate-controlled suites with 24/7 supervision and daily photo updates.",
    href: "/services/boarding",
    imageSrc: "/images/boarding.jpg",
    icon: "apartment",
  },
  {
    title: "Grooming Spa",
    description:
      "Breed-specific baths, trims, and styling by certified groomers in a calm spa environment.",
    href: "/services/grooming",
    imageSrc: "/images/grooming.jpg",
    icon: "spa",
  },
  {
    title: "Vet Care",
    description:
      "On-site veterinary consultations, vaccinations, and routine wellness check-ups.",
    href: "/services/vet-care",
    imageSrc: "/images/vetcare.jpg",
    icon: "medical_services",
  },
  {
    title: "Dog Training",
    description:
      "Positive-reinforcement programmes for puppies and adult dogs of all breeds.",
    href: "/services/training",
    imageSrc: "/images/training.jpg",
    icon: "school",
  },
  {
    title: "Pet Transport",
    description:
      "Air-conditioned door-to-door pickup and drop-off anywhere across Abuja.",
    href: "/services/transport",
    imageSrc: "/images/transport.jpg",
    icon: "local_shipping",
  },
  {
    title: "Pet Relocation",
    description:
      "Stress-free international moves with full documentation and airline coordination.",
    href: "/relocation",
    imageSrc: "/images/relocation.jpg",
    icon: "flight_takeoff",
  },
];

// ── Services index "standards" stat band ──────────────────────────────────
// Source: services/index.blade.php lines 39–71

export type ServiceStatItem = {
  icon: string;
  title: string;
  subtitle: string;
};

export const servicesIndexStats: ServiceStatItem[] = [
  { icon: "verified", title: "Vet-Supervised Care", subtitle: "Health-first handling" },
  { icon: "schedule", title: "24/7 Monitoring", subtitle: "Constant supervision" },
  { icon: "pets", title: "500+ Pets Served", subtitle: "Across Abuja & beyond" },
  { icon: "star", title: "4.9 Average Rating", subtitle: "Trusted by pet owners" },
];

// ── Services index "Waggies Standard" dark band ───────────────────────────
// Source: services/index.blade.php lines 73–115

export const servicesIndexStandards = {
  eyebrow: "The Waggies Standard",
  title: "Why Our Care System<br><span class=\"text-secondary italic\">Works So Well</span>",
  body: "Every pet is handled through structured care protocols designed to ensure safety, comfort, and emotional wellbeing.",
  cards: [
    { title: "Structured Daily Routines", desc: "Professionally trained handlers and protocols." },
    { title: "24/7 Supervision", desc: "Continuous monitoring, day and night." },
    { title: "Daily Updates", desc: "Owners receive real-time pet updates." },
  ],
} as const;

// ── Services index inline FAQ (6 hardcoded items) ────────────────────────
// Source: services/index.blade.php lines 154–274 — note these are HARDCODED
// in the Blade, not pulled from the FAQ database. Preserved verbatim.

export type InlineFaqItem = { question: string; answer: string };

export const servicesIndexInlineFaqs: InlineFaqItem[] = [
  {
    question: "How do I know which service my pet needs?",
    answer:
      "If you're unsure, start with a consultation or contact us. Our team will recommend the right service based on your pet’s age, health, and behavior.",
  },
  {
    question: "Are all services safe for my pet?",
    answer:
      "Yes. Every service follows strict vet-supervised safety standards and trained handlers.",
  },
  {
    question: "Are all services safe for my pet?",
    answer:
      "Yes. Every service follows strict vet-supervised safety standards and trained handlers. Safety is built into every part of our system.",
  },
  {
    question: "Can I switch or combine services later?",
    answer:
      "Yes. Many clients combine grooming, boarding, and vet care depending on their pet’s needs. We can adjust plans anytime.",
  },
  {
    question: "Do I need a consultation before booking?",
    answer:
      "Not always. Some services can be booked directly, but consultations help us recommend the safest and most effective care plan.",
  },
  {
    question: "How do I get updates about my pet?",
    answer:
      "You receive regular updates including photos and status reports depending on the service you choose.",
  },
  {
    question: "What happens after I book a service?",
    answer:
      "Our team contacts you to confirm details, prepare your pet’s care plan, and guide you through the next steps.",
  },
];

// ── Boarding index page ───────────────────────────────────────────────────
// Source: services/boarding/index.blade.php

export const boardingIndexHero = {
  imageSrc: "/images/boarding.jpg",
  imageAlt: "Luxury pet boarding suites at Waggies",
  eyebrow: "Abuja's #1 Pet Boarding",
  eyebrowIcon: "pets",
  title: "A Home Away From Home",
  subtitle:
    "Spacious, climate-controlled suites with 24/7 supervision, orthopedic bedding, and daily updates for total peace of mind.",
  primaryCta: {
    label: "Book Appointment",
    href: "/contact?intent=book&service=boarding",
    icon: "arrow_forward",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=boarding",
    icon: "calculate",
  },
  variant: "center" as const,
};

export const boardingIndexCards: ServiceCard[] = [
  {
    title: "Dog Boarding",
    description:
      "Private suites with outdoor play areas, socialisation sessions, and daily grooming.",
    href: "/services/boarding/dogs",
    imageSrc: "/images/boarding-dogs.jpg",
    icon: "pets",
  },
  {
    title: "Cat Boarding",
    description:
      "Calm, quiet cat condos away from dogs — with enrichment toys and cosy resting nooks.",
    href: "/services/boarding/cats",
    imageSrc: "/images/boarding-cats.jpg",
    icon: "heart_plus",
  },
  {
    title: "Exotic Boarding",
    description:
      "Specialist care for birds, reptiles, rabbits and small mammals in custom enclosures.",
    href: "/services/boarding/exotic",
    imageSrc: "/images/boarding-exotic.jpg",
    icon: "nest_eco_leaf",
  },
];

/** Boarding index "What's Included" feature list (6 items). */
export const boardingIncludedFeatures: ReadonlyArray<{
  icon: string;
  title: string;
  desc: string;
}> = [
  { icon: "hotel", title: "Luxury Suites", desc: "Climate-controlled rooms with orthopedic bedding." },
  { icon: "restaurant", title: "Premium Meals", desc: "Nutritious food served on your pet's usual schedule." },
  { icon: "directions_run", title: "Daily Exercise", desc: "Structured play and exercise sessions every day." },
  { icon: "medical_services", title: "Vet on Site", desc: "A qualified vet monitors all boarding guests daily." },
  { icon: "notifications", title: "Daily Photo Updates", desc: "Photo and report sent to you every single day." },
  { icon: "lock_clock", title: "24/7 Supervision", desc: "Staff present around the clock — never unsupervised." },
];

/** Boarding index "Certified Safe Space" floating card content. */
export const boardingSafeSpaceCard = {
  imageSrc:
    "https://images.unsplash.com/photo-1631248055855-a0f3d5f3ece5?w=800&h=600&fit=crop&q=80",
  imageAlt: "Modern pet boarding facility interior",
  title: "Certified Safe Space",
  happyGuests: "1,000+",
} as const;

/** Boarding index testimonials (3). */
export const boardingTestimonials = [
  {
    stars: 5,
    quote:
      "My dog came back happy and healthy. The daily photos made it so easy to relax while I was away.",
    authorInitial: "C",
    authorName: "Chidi A.",
    authorSubtitle: "Dog owner · Gwarinpa",
  },
  {
    stars: 5,
    quote:
      "Excellent facilities — clean, spacious and clearly well-managed. My cat was in great spirits on pickup.",
    authorInitial: "N",
    authorName: "Ngozi E.",
    authorSubtitle: "Cat owner · Maitama",
  },
  {
    stars: 5,
    quote:
      "I was nervous leaving my rabbit but the team clearly knew exactly how to care for him. Will return.",
    authorInitial: "T",
    authorName: "Tunde B.",
    authorSubtitle: "Rabbit owner · Wuse II",
  },
] as const;

// ── Generic "service feature grid" (used on grooming/vet-care/training/ ──
// ── transport/import/export pages — purple cards with icon+title+desc) ──

export type ServiceFeatureItem = {
  icon: string;
  title: string;
  desc: string;
};

// ── Grooming page ─────────────────────────────────────────────────────────
// Source: services/grooming.blade.php

export const groomingHero = {
  imageSrc: "/images/grooming.jpg",
  eyebrow: "Grooming Spa · Abuja",
  title: "The Grooming Spa<br/>Your Pet Deserves",
  subtitle:
    "Breed-specific treatments, luxury baths, and precision styling by certified groomers in a calm, purpose-built spa.",
  primaryCta: {
    label: "Book a Groom",
    href: "/contact?intent=book&service=grooming",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=grooming",
    icon: "calculate",
  },
};

export const groomingSectionHeading = {
  eyebrow: "Our Grooming Services",
  title: "A Full Menu of<br/>Grooming Treatments",
  subtitle:
    "Whether it's a quick bath and brush or a full breed-standard groom, we have a treatment to suit every pet.",
};

export const groomingFeatures: ServiceFeatureItem[] = [
  { icon: "water_drop", title: "Luxury Bath & Dry", desc: "Premium shampoo and conditioner suited to your pet's coat type, followed by a professional blow-dry." },
  { icon: "content_cut", title: "Breed-Standard Styling", desc: "Full cuts and styling to breed standard by certified groomers with years of experience." },
  { icon: "spa", title: "De-shed Treatment", desc: "A deep deshedding treatment that dramatically reduces loose fur and keeps coats healthy." },
  { icon: "face", title: "Facial & Eye Clean", desc: "Gentle face wash, eye cleaning, and ear inspection to keep your pet fresh and comfortable." },
  { icon: "back_hand", title: "Nail Trim & Grind", desc: "Safe nail trimming and grinding to a comfortable, healthy length." },
  { icon: "star", title: "Full Groom Package", desc: "Bath, dry, cut, nails, ears, and a light spritz — the complete luxury treatment." },
];

export const groomingFeatureBand = {
  eyebrow: "Our Standards",
  title: "Grooming Done Right,<br/><span class=\"text-secondary italic\">Every Time</span>",
  subtitle:
    "We use only premium, pet-safe products and handle every animal with patience and care.",
  cta: { label: "Book a Groom", href: "/contact" },
  features: [
    { icon: "verified", title: "Certified Groomers", description: "All groomers are professionally trained and certified." },
    { icon: "eco", title: "Pet-Safe Products", description: "We use only premium, non-toxic, pet-safe shampoos and conditioners." },
    { icon: "psychology", title: "Calm Handling", description: "Patient, low-stress handling techniques — especially for nervous pets." },
    { icon: "schedule", title: "Punctual Service", description: "We respect your time. Drop-off and collection slots run to schedule." },
  ],
};

// ── Vet Care page ─────────────────────────────────────────────────────────
// Source: services/vet-care.blade.php

export const vetCareHero = {
  imageSrc: "/images/vetcare.jpg",
  eyebrow: "On-Site Vet Care · Abuja",
  title: "On-Site Veterinary Care<br/>You Can Rely On",
  subtitle:
    "Consultations, vaccinations, wellness checks, and minor treatments — delivered by our qualified on-site veterinarian every day of the week.",
  primaryCta: {
    label: "Book a Consultation",
    href: "/contact?intent=book&service=vet-care",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=vet-care",
    icon: "calculate",
  },
};

export const vetCareSectionHeading = {
  eyebrow: "Vet Services",
  title: "Comprehensive Care<br/>for Every Pet",
  subtitle:
    "From routine check-ups to treatment and advice, our vet is here to keep your pet healthy and thriving.",
};

export const vetCareFeatures: ServiceFeatureItem[] = [
  { icon: "stethoscope", title: "General Consultations", desc: "Full nose-to-tail wellness examinations and health consultations for all species." },
  { icon: "vaccines", title: "Vaccinations", desc: "Core and non-core vaccinations administered on a personalised schedule." },
  { icon: "monitor_heart", title: "Wellness Check-Ups", desc: "Routine health assessments to catch issues early and keep your pet in peak condition." },
  { icon: "medication", title: "Prescription & Treatment", desc: "Diagnosis, prescriptions, and minor treatment for common health conditions." },
  { icon: "pest_control", title: "Parasite Prevention", desc: "Flea, tick, and worm treatments and prevention advice tailored to your pet's lifestyle." },
  { icon: "science", title: "Lab & Diagnostics", desc: "In-clinic diagnostic tests and coordination with external labs for detailed results." },
];

export const vetCareFeatureBand = {
  eyebrow: "Why Our Vet Care?",
  title: "Qualified, Caring,<br/><span class=\"text-secondary italic\">On-Site Daily</span>",
  subtitle:
    "Having a vet on-site every day means your pet gets professional care without the stress of a separate vet visit.",
  cta: { label: "Book a Consultation", href: "/contact" },
  features: [
    { icon: "medical_services", title: "Qualified Vet Daily", description: "Our vet is present on-site every day of the week, including weekends." },
    { icon: "verified", title: "PCSA Registered", description: "All vet services are delivered to certified professional standards." },
    { icon: "lock_clock", title: "Immediate Response", description: "Boarding guests receive immediate veterinary attention if any concern arises." },
    { icon: "psychology", title: "Low-Stress Environment", description: "Consultations in a calm, familiar setting — less anxiety for your pet." },
  ],
};

// ── Training page ─────────────────────────────────────────────────────────
// Source: services/training.blade.php

export const trainingHero = {
  imageSrc: "/images/training.jpg",
  eyebrow: "Dog Training · Abuja",
  title: "Positive Training for<br/>a Better-Behaved Dog",
  subtitle:
    "Science-based, positive-reinforcement training programmes for puppies and adult dogs — building confidence, manners, and a stronger bond.",
  primaryCta: {
    label: "Enquire About Training",
    href: "/contact?intent=consult&service=training",
  },
  secondaryCta: {
    label: "Get Estimate",
    href: "/services/pricing?service=training",
    icon: "calculate",
  },
};

export const trainingSectionHeading = {
  eyebrow: "Training Programmes",
  title: "A Programme for<br/>Every Dog",
  subtitle:
    "We offer structured training programmes to suit puppies, adolescent dogs, and adults at any stage of their learning.",
};

export const trainingFeatures: ServiceFeatureItem[] = [
  { icon: "child_care", title: "Puppy Foundation", desc: "Essential early socialisation, toilet training, recall, and bite inhibition for puppies 8–16 weeks." },
  { icon: "school", title: "Basic Obedience", desc: "Sit, stay, come, heel, and leash manners — the core commands every dog should know." },
  { icon: "workspace_premium", title: "Advanced Obedience", desc: "Off-lead reliability, distance commands, and polished behaviour in real-world environments." },
  { icon: "psychology", title: "Behaviour Modification", desc: "Tailored programmes for reactivity, anxiety, aggression, or other specific behavioural concerns." },
  { icon: "groups", title: "Group Classes", desc: "Sociable small-group sessions to practise skills around other dogs and people." },
  { icon: "person", title: "1-to-1 Private Sessions", desc: "Focused one-on-one sessions with a trainer, tailored to your dog's specific needs and goals." },
];

export const trainingFeatureBand = {
  eyebrow: "Our Approach",
  title: "Positive Methods,<br/><span class=\"text-secondary italic\">Lasting Results</span>",
  subtitle:
    "We use only reward-based, force-free training methods that build trust and produce long-lasting behavioural change.",
  cta: { label: "Start Training", href: "/contact" },
  features: [
    { icon: "thumb_up", title: "Reward-Based Only", description: "We never use aversive tools or punishment-based techniques." },
    { icon: "verified", title: "Certified Trainers", description: "All trainers are formally certified in canine behaviour and training." },
    { icon: "favorite", title: "Bond-Building Focus", description: "Training that strengthens the relationship between you and your dog." },
    { icon: "trending_up", title: "Measurable Progress", description: "Clear goals set at the outset and tracked throughout the programme." },
  ],
};

// ── Transport page ────────────────────────────────────────────────────────
// Source: services/transport.blade.php

export const transportHero = {
  imageSrc: "/images/transport.jpg",
  eyebrow: "Pet Transport · Abuja",
  title: "Safe, Comfortable<br/>Door-to-Door Transport",
  subtitle:
    "Air-conditioned, purpose-fitted vehicles for stress-free pet pickup and drop-off anywhere across Abuja.",
  primaryCta: { label: "Book a Transfer", href: "/contact" },
  secondaryCta: { label: "View Pricing", href: "/services/pricing" },
};

export const transportSectionHeading = {
  eyebrow: "Transport Services",
  title: "We Go Where<br/>Your Pet Needs to Go",
  subtitle:
    "Whether it's a trip to Waggies for boarding or grooming, or a vet visit, we'll collect and return your pet safely.",
};

export const transportFeatures: ServiceFeatureItem[] = [
  { icon: "local_shipping", title: "Pickup & Drop-Off", desc: "Door-to-door collection and return for boarding, grooming, or vet appointments at Waggies." },
  { icon: "air", title: "Air-Conditioned Vehicles", desc: "Climate-controlled vehicles to keep your pet comfortable whatever the Abuja weather." },
  { icon: "lock", title: "Secure Crating", desc: "Approved travel crates and harnesses to keep pets safe and secure during transit." },
  { icon: "person", title: "Experienced Handlers", desc: "Drivers trained in animal handling and pet first aid." },
  { icon: "map", title: "All Areas of Abuja", desc: "We cover all major districts — Maitama, Wuse, Asokoro, Garki, Gwarinpa, and beyond." },
  { icon: "schedule", title: "Punctual & Reliable", desc: "Time slots booked in advance so you can plan around your schedule." },
];

export const transportCtaBand = {
  heading: "Book a transport slot",
  body: "Contact us with your pickup address, destination, and preferred time.",
  primary: { label: "Book Now", href: "/contact", icon: "arrow_forward" },
  secondary: { label: "View Pricing", href: "/services/pricing" },
} as const;
