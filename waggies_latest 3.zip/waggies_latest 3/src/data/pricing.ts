/**
 * Waggies pricing configuration — extracted verbatim from the Laravel source.
 *
 * Original Laravel sources (no longer present in this repository):
 *   - config/waggies.php  (pricing data)
 *   - app/Support/PricingQuote.php  (helper functions: resolveServiceContext,
 *     contactUrl, estimateUrl, calculatorPayload, formatNaira, findTier)
 *   - resources/js/waggies.js  (Alpine pricingCalculator state machine —
 *     ported in src/components/waggies/pricing-calculator.tsx)
 *
 * The data in this file is the single source of truth for the pricing
 * calculator and for every "Get Estimate" / "Book Now" link on the site.
 *
 * DO NOT change the calculation formula. DO NOT round differently.
 * DO NOT change Naira formatting. DO NOT change visible wording.
 */

// ── Types ──────────────────────────────────────────────────────────────────

export type TierType = "fixed" | "estimate" | "quote";

export type PricingFeature = {
  label: string;
  included: boolean;
};

export type PricingTier = {
  label: string;
  type: TierType;
  amount: number;
  amount_max?: number;
  featured: boolean;
  badge?: string;
  features: PricingFeature[];
};

export type PricingVariant = {
  label: string;
  tiers: Record<string, PricingTier>;
};

export type PricingService = {
  label: string;
  unit: string;
  quantity_label: string | null;
  quantity_min?: number;
  quantity_max?: number;
  /** Either `tiers` (flat) or `variants` (grouped by pet type). */
  tiers?: Record<string, PricingTier>;
  variants?: Record<string, PricingVariant>;
};

export type PricingConfig = {
  aliases: Record<string, { service: string; variant?: string }>;
  services: Record<string, PricingService>;
};

// ── Data (verbatim from config/waggies.php) ────────────────────────────────

export const pricingConfig: PricingConfig = {
  aliases: {
    "boarding-dogs": { service: "boarding", variant: "dogs" },
    "boarding-cats": { service: "boarding", variant: "cats" },
    "boarding-exotic": { service: "boarding", variant: "exotic" },
    vet: { service: "vet-care" },
  },

  services: {
    boarding: {
      label: "Boarding",
      unit: "/night",
      quantity_label: "Nights",
      quantity_min: 1,
      quantity_max: 30,
      variants: {
        dogs: {
          label: "Dogs",
          tiers: {
            basic: {
              label: "Basic",
              type: "fixed",
              amount: 10000,
              featured: false,
              features: [
                { label: "1 dog boarding", included: true },
                { label: "Daily walks", included: true },
                { label: "24/7 supervision", included: false },
              ],
            },
            premium: {
              label: "Premium",
              type: "fixed",
              amount: 18000,
              featured: true,
              badge: "Most Popular",
              features: [
                { label: "2 dogs boarding", included: true },
                { label: "Daily walks", included: true },
                { label: "24/7 supervision", included: true },
              ],
            },
            deluxe: {
              label: "Deluxe",
              type: "fixed",
              amount: 25000,
              featured: false,
              features: [
                { label: "3+ dogs boarding", included: true },
                { label: "Grooming + spa", included: true },
                { label: "24/7 supervision", included: true },
              ],
            },
          },
        },
        cats: {
          label: "Cats",
          tiers: {
            cozy: {
              label: "Cozy",
              type: "fixed",
              amount: 8000,
              featured: false,
              features: [
                { label: "Quiet cat condo", included: true },
                { label: "Daily enrichment", included: true },
              ],
            },
            premium: {
              label: "Premium",
              type: "fixed",
              amount: 14000,
              featured: true,
              badge: "Most Popular",
              features: [
                { label: "Private suite", included: true },
                { label: "Daily photo updates", included: true },
              ],
            },
            luxury: {
              label: "Luxury",
              type: "fixed",
              amount: 22000,
              featured: false,
              features: [
                { label: "Luxury suite", included: true },
                { label: "Daily vet check", included: true },
              ],
            },
          },
        },
        exotic: {
          label: "Exotic Pets",
          tiers: {
            small: {
              label: "Small Mammal",
              type: "estimate",
              amount: 6000,
              amount_max: 8000,
              featured: false,
              features: [
                { label: "Rabbits, guinea pigs, hamsters", included: true },
              ],
            },
            specialist: {
              label: "Specialist",
              type: "estimate",
              amount: 12000,
              amount_max: 15000,
              featured: true,
              badge: "Most Popular",
              features: [
                { label: "Birds or reptiles", included: true },
                { label: "Climate monitoring", included: true },
              ],
            },
            premium: {
              label: "Premium Habitat",
              type: "quote",
              amount: 18000,
              featured: false,
              features: [
                { label: "Complex multi-zone enclosures", included: true },
              ],
            },
          },
        },
      },
    },

    grooming: {
      label: "Grooming",
      unit: "/session",
      quantity_label: "Sessions",
      quantity_min: 1,
      quantity_max: 12,
      tiers: {
        bath: {
          label: "Bath & Brush",
          type: "fixed",
          amount: 8000,
          featured: false,
          features: [
            { label: "Luxury bath", included: true },
            { label: "Blow-dry & brush", included: true },
          ],
        },
        full: {
          label: "Full Groom",
          type: "fixed",
          amount: 18000,
          featured: true,
          badge: "Best Value",
          features: [
            { label: "Breed-standard cut", included: true },
            { label: "Nail trim & ear clean", included: true },
          ],
        },
        spa: {
          label: "Luxury Spa",
          type: "fixed",
          amount: 28000,
          featured: false,
          features: [
            { label: "Premium bath & mask", included: true },
            { label: "De-shed treatment", included: true },
          ],
        },
      },
    },

    "vet-care": {
      label: "Veterinary Care",
      unit: "",
      quantity_label: null,
      tiers: {
        consultation: {
          label: "General Consultation",
          type: "fixed",
          amount: 12000,
          featured: true,
          badge: "From",
          features: [
            { label: "Wellness examination", included: true },
            { label: "Health advice", included: true },
          ],
        },
        vaccination: {
          label: "Vaccination Visit",
          type: "estimate",
          amount: 15000,
          amount_max: 35000,
          featured: false,
          features: [
            { label: "Vaccines priced per schedule", included: true },
          ],
        },
        treatment: {
          label: "Treatment Plan",
          type: "quote",
          amount: 0,
          featured: false,
          features: [
            { label: "Diagnosis & prescriptions", included: true },
          ],
        },
      },
    },

    training: {
      label: "Dog Training",
      unit: "/programme",
      quantity_label: null,
      tiers: {
        puppy: {
          label: "Puppy Foundation",
          type: "estimate",
          amount: 80000,
          amount_max: 120000,
          featured: false,
          features: [
            { label: "6-week foundation programme", included: true },
          ],
        },
        obedience: {
          label: "Basic Obedience",
          type: "estimate",
          amount: 100000,
          amount_max: 150000,
          featured: true,
          badge: "Popular",
          features: [
            { label: "Structured weekly sessions", included: true },
          ],
        },
        behaviour: {
          label: "Behaviour Modification",
          type: "quote",
          amount: 0,
          featured: false,
          features: [
            { label: "Tailored plan after assessment", included: true },
          ],
        },
      },
    },

    relocation: {
      label: "Pet Relocation",
      unit: "",
      quantity_label: null,
      tiers: {
        local: {
          label: "Local Transport",
          type: "estimate",
          amount: 25000,
          amount_max: 75000,
          featured: false,
          features: [
            { label: "Abuja & surrounding routes", included: true },
          ],
        },
        import: {
          label: "Import to Nigeria",
          type: "quote",
          amount: 0,
          featured: true,
          badge: "Custom quote",
          features: [
            { label: "Permits, health certs & airport collection", included: true },
          ],
        },
        export: {
          label: "Export from Nigeria",
          type: "quote",
          amount: 0,
          featured: false,
          features: [
            { label: "Export permits & airline coordination", included: true },
          ],
        },
      },
    },
  },
};

// ── Hero image fallbacks (config/waggies.php hero_images) ──────────────────

export const heroImages = {
  default:
    "https://images.unsplash.com/photo-1650454027983-e2b8fe55b30b?w=1600&auto=format&fit=crop&q=80",
  blog: "https://images.unsplash.com/photo-1587300003388-59208cc962cb?w=1600&auto=format&fit=crop&q=80",
  guide:
    "https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1600&auto=format&fit=crop&q=80",
  kb: "https://images.unsplash.com/photo-1628009365291-4e3c4b2e1b1e?w=1600&auto=format&fit=crop&q=80",
  faq: "https://images.unsplash.com/photo-1628009365291-4e3c4b2e1b1e?w=1600&auto=format&fit=crop&q=80",
  checklist:
    "https://images.unsplash.com/photo-1436491865332-7a61a109cc05?w=1600&auto=format&fit=crop&q=80",
  services:
    "https://images.unsplash.com/photo-1650454027983-e2b8fe55b30b?w=1600&auto=format&fit=crop&q=80",
} as const;

// ── PricingQuote helpers (verbatim ports from app/Support/PricingQuote.php) ─

/**
 * Reproduce `PricingQuote::formatNaira()` — `'₦'.number_format($amount)`.
 *
 * Note: PHP `number_format` defaults to 2 decimals; the Laravel source calls
 * it with NO second argument, so it uses 0 decimals. We match exactly with
 * `toLocaleString('en-NG')` which also produces 0 decimals by default for
 * whole numbers.
 *
 *   ₦10,000   ₦18,000   ₦100,000
 */
export function formatNaira(amount: number): string {
  return "₦" + Number(amount).toLocaleString("en-NG");
}

/**
 * Reproduce `PricingQuote::resolveServiceContext()`.
 *
 * If $service matches an alias key (e.g. "boarding-dogs" → boarding/dogs),
 * expand it to (service, variant). Otherwise pass through as-is, with
 * empty-string normalization for null.
 */
export function resolveServiceContext(
  service: string | null | undefined,
  variant: string | null | undefined,
): { service: string; variant: string | null } {
  const aliases = pricingConfig.aliases;
  if (service && service in aliases) {
    return {
      service: aliases[service].service,
      variant: aliases[service].variant ?? variant ?? null,
    };
  }
  return {
    service: service ?? "",
    variant: variant ?? null,
  };
}

/**
 * Reproduce `PricingQuote::contactUrl($intent, $context)`.
 *
 * Builds `/contact?intent=...&service=...&variant=...&tier=...&quantity=...&summary=...`
 * with empty/null values filtered out — exactly matching Laravel's
 * `array_filter(..., fn ($value) => $value !== null && $value !== '')`.
 */
export function contactUrl(
  intent: "book" | "save" | "consult",
  context: {
    service?: string | null;
    variant?: string | null;
    tier?: string | null;
    quantity?: string | number | null;
    summary?: string | null;
  } = {},
): string {
  const params = new URLSearchParams();
  params.set("intent", intent);
  for (const [key, value] of Object.entries(context)) {
    if (value !== null && value !== undefined && value !== "") {
      params.set(key, String(value));
    }
  }
  return `/contact?${params.toString()}`;
}

/**
 * Reproduce `PricingQuote::estimateUrl($service, $variant, $tier)`.
 *
 * Builds `/services/pricing?service=...&variant=...&tier=...` with empty
 * values filtered out.
 */
export function estimateUrl(
  service?: string | null,
  variant?: string | null,
  tier?: string | null,
): string {
  const params = new URLSearchParams();
  if (service) params.set("service", service);
  if (variant) params.set("variant", variant);
  if (tier) params.set("tier", tier);
  const qs = params.toString();
  return qs ? `/services/pricing?${qs}` : "/services/pricing";
}

/**
 * Reproduce `PricingQuote::findTier($service, $variantKey, $tierKey)`.
 */
export function findTier(
  service: PricingService,
  variantKey: string | null,
  tierKey: string,
): PricingTier | null {
  if (variantKey && service.variants?.[variantKey]?.tiers?.[tierKey]) {
    return service.variants[variantKey].tiers[tierKey];
  }
  if (service.tiers?.[tierKey]) {
    return service.tiers[tierKey];
  }
  return null;
}

/**
 * Reproduce `PricingQuote::service($key)`.
 */
export function getService(key: string): PricingService | null {
  return pricingConfig.services[key] ?? null;
}

/**
 * Reproduce `PricingQuote::serviceOptions()` — returns `{ key: label }` map.
 *
 * Kept exported for the Phase 2.5 pricing-equivalence audit
 * (scripts/audit-pricing.mjs) which compares the React port's helpers
 * against the Alpine reference implementation. Not used at runtime.
 */
export function serviceOptions(): Record<string, string> {
  const opts: Record<string, string> = {};
  for (const [key, svc] of Object.entries(pricingConfig.services)) {
    opts[key] = svc.label;
  }
  return opts;
}

/**
 * Reproduce `PricingQuote::calculatorPayload($service, $variant, $tier)`.
 *
 * Returns the shape consumed by the Alpine `pricingCalculator(...)` init:
 *
 *   {
 *     services:        config('waggies.pricing.services'),
 *     selectedService: resolved.service  || '',
 *     selectedVariant: resolved.variant  || null,
 *     selectedTier:    $tier             || null,
 *     contactUrls:     { book: 'book', save: 'save', consult: 'consult' },
 *   }
 *
 * In the React port, `contactUrls` is unused (we build URLs on the client via
 * `contactUrl()`), but we keep the field for shape parity with the Laravel
 * payload that gets `@js()`-encoded into the Alpine initialiser.
 *
 * Kept exported for the Phase 2.5 pricing-equivalence audit
 * (scripts/audit-pricing.mjs). Not used at runtime by the Next.js app —
 * the pricing page passes URL params directly to the client component
 * rather than going through this payload shape.
 */
export function calculatorPayload(
  service?: string | null,
  variant?: string | null,
  tier?: string | null,
): {
  services: Record<string, PricingService>;
  selectedService: string;
  selectedVariant: string | null;
  selectedTier: string | null;
  contactUrls: { book: "book"; save: "save"; consult: "consult" };
} {
  const resolved = resolveServiceContext(service ?? null, variant ?? null);
  return {
    services: pricingConfig.services,
    selectedService: resolved.service,
    selectedVariant: resolved.variant,
    selectedTier: tier ?? null,
    contactUrls: { book: "book", save: "save", consult: "consult" },
  };
}

/**
 * Reproduce `PricingQuote::buildPrefillMessage($input)`.
 *
 * Composes the textarea default message for the Contact form when the user
 * arrives via a pricing-calculator CTA. The message lists service label,
 * variant label, package (tier) label, estimate summary, and the intent
 * sentence — joined by newlines.
 *
 * Used by the Contact page (GET /contact) when pricing context is present
 * in the query string.
 *
 * Source: app/Support/PricingQuote.php lines 99–138.
 */
export function buildPrefillMessage(input: {
  service?: string | null;
  variant?: string | null;
  tier?: string | null;
  intent?: string | null;
  summary?: string | null;
}): string {
  const serviceKey = input.service ?? "";
  const service = getService(serviceKey);
  const variantKey = input.variant ?? null;
  const tierKey = input.tier ?? "";
  const intent = input.intent ?? "consult";
  const summary = input.summary ?? "";

  const lines: string[] = [];

  if (service) {
    let label = service.label;
    if (variantKey && service.variants?.[variantKey]?.label) {
      label += " — " + service.variants[variantKey].label;
    }
    lines.push(`Service: ${label}`);
  }

  if (tierKey !== "" && service) {
    const tier = findTier(service, variantKey, tierKey);
    if (tier) {
      lines.push("Package: " + tier.label);
    }
  }

  if (summary !== "") {
    lines.push("Estimate: " + summary);
  }

  const intentLabel =
    intent === "book"
      ? "I would like to book this service."
      : intent === "save"
        ? "Please save this estimate and follow up with next steps."
        : "I would like to speak with a specialist about this.";

  lines.push(intentLabel);

  return lines.join("\n");
}
