/**
 * Partnerships page content — extracted verbatim from the Laravel Blade
 * source of truth.
 *
 *   - Page header (ui.page-header): lines 5–9
 *   - Partnership Types grid (6):   lines 11–39
 *   - Bottom CTA section:           lines 41–49
 *
 * Component defaults referenced:
 *   - components/ui/page-header.blade.php  (variant='purple', align='left')
 *   - components/section-heading.blade.php (spacing='mb-16')
 *
 * Route translations applied:
 *   route('contact') → /contact
 *
 * DO NOT paraphrase, modernize, abbreviate, or "improve" this content.
 */

// ── Hero (page-header) ────────────────────────────────────────────────────

export type PartnershipsHero = {
  eyebrow: string;
  title: string;
  subtitle: string;
};

export const partnershipsHero: PartnershipsHero = {
  eyebrow: "Partnerships",
  title: "Better Together",
  subtitle:
    "We partner with aligned organisations — vets, breeders, pet retailers, and businesses — who share our commitment to animal welfare and quality care.",
} as const;

// ── Partnership Types section heading ─────────────────────────────────────

export const partnershipTypesHeading = {
  eyebrow: "Partnership Types",
  title: "How We Work<br/>With Partners",
  subtitle:
    "Whether you're a veterinary clinic, a pet shop, or a corporate with pet-owning employees, we have a partnership model that works.",
} as const;

// ── Partnership Types grid (6) ────────────────────────────────────────────

export type PartnershipType = {
  icon: string;
  title: string;
  desc: string;
};

export const partnershipTypes: PartnershipType[] = [
  {
    icon: "local_hospital",
    title: "Veterinary Clinics",
    desc: "Cross-referral partnerships with vet clinics across Abuja — ensuring continuity of care for shared patients.",
  },
  {
    icon: "storefront",
    title: "Pet Retailers",
    desc: "Partner with pet shops and suppliers to offer our clients exclusive product discounts and bundled services.",
  },
  {
    icon: "pets",
    title: "Breeders",
    desc: "We work with licensed breeders to provide early socialisation and health checks for new litters.",
  },
  {
    icon: "business",
    title: "Corporate Partners",
    desc: "Corporate employee benefit packages — discounted Waggies services for your pet-owning staff.",
  },
  {
    icon: "apartment",
    title: "Property Developers",
    desc: "Partner with residential developers to offer Waggies services to residents as a premium amenity.",
  },
  {
    icon: "diversity_3",
    title: "NGOs & Rescue Orgs",
    desc: "We support animal rescue and welfare NGOs with discounted services and pro bono care where we can.",
  },
];

// ── Bottom CTA ────────────────────────────────────────────────────────────

export type PartnershipsCta = {
  heading: string;
  body: string;
  ctaLabel: string;
  ctaHref: string;
  ctaIcon: string;
};

export const partnershipsCta: PartnershipsCta = {
  heading: "Interested in partnering with us?",
  body: "We'd love to explore how we can work together. Get in touch to start the conversation.",
  ctaLabel: "Get in Touch",
  ctaHref: "/contact",
  ctaIcon: "arrow_forward",
} as const;
