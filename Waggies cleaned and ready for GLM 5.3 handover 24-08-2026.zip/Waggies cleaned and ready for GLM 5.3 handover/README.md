# Waggies

Pet boarding, grooming, veterinary care, training, relocation and local transport in Abuja, Nigeria.

## Stack

| Layer | Technology |
|-------|-----------|
| Framework | Next.js 16.1.1 (App Router) |
| Language | TypeScript 5 |
| Styling | Tailwind CSS 4 + shadcn/ui (New York) |
| Icons | Phosphor Icons (primary), Material Symbols (legacy) |
| Fonts | DM Sans (body), Cormorant Garamond (headings) |
| State | Zustand (cart) |
| Animation | Framer Motion |
| Database | Prisma ORM (SQLite, deferred) |
| Package Manager | bun |

## Quick Start

```bash
bun install
cp .env.example .env   # then fill in values
bun run db:push
cd mini-services && bun install && cd ..
bun run dev             # http://localhost:3000
```

## Development Commands

| Command | Purpose |
|---------|---------|
| `bun run dev` | Start dev server (port 3000) |
| `bun run build` | Production build |
| `bun run lint` | ESLint |
| `bun run db:push` | Push Prisma schema to SQLite |
| `bun run db:generate` | Generate Prisma client |

## Key Directories

```
src/
  app/              # Next.js App Router pages
  components/
    ui/              # shadcn/ui primitives (do not edit)
    waggies/         # Waggies application components
  data/              # Static content data
  hooks/             # React hooks
  lib/               # Utilities, business-info, site config, icons
  store/             # Zustand stores
public/              # Static assets (hero images, favicon, logo)
prisma/              # Database schema
db/                  # SQLite database file
mini-services/       # Standalone backend services
```

## Authoritative Documentation

All product documentation lives at the project root:

- `WAGGIES_MASTER_PRODUCT_SPECIFICATION.md` — single source of truth for product
- `WAGGIES_USER_DECISIONS.md` — explicit user decisions
- `WAGGIES_GOLDEN_REFERENCE.md` — quick-reference for features, routes, business facts
- `WAGGIES_FEATURE_INVENTORY.md` — complete feature matrix
- `WAGGIES_ROUTE_MAP.md` — all routes, redirects, navigation
- `WAGGIES_DESIGN_SYSTEM.md` — OKLCH palette, typography, spacing, components
- `WAGGIES_GOLDEN_ASSET_INVENTORY.md` — every image slot and its status
- `WAGGIES_WHATSAPP_REQUEST_SCHEMA.md` — WhatsApp message composer spec
- `WAGGIES_DATABASE_SCHEMA.md` — current + future Prisma schema
- `WAGGIES_CHATBOT_ARCHITECTURE.md` — current + future chatbot
- `WAGGIES_ACCESSIBILITY_STATE.md` — WCAG 2.2 AA status
- `WAGGIES_RESPONSIVE_STATE.md` — responsive breakpoint status
- `WAGGIES_SEO_STATE.md` — SEO implementation status
- `WAGGIES_BUILD_STATUS.md` — build/run status

## Business Information

**Authoritative source:** `src/lib/business-info.ts`

| Field | Value |
|-------|-------|
| Name | Waggies |
| Address | Life Camp, Efab City Estate, 65 1st Ave, Abuja 900108, FCT, Nigeria |
| Phone | 0908 081 1902 |
| International | +234 908 081 1902 |
| WhatsApp | 2349080811902 |
| Email | hello@waggies.ng |
| Hours | Mon–Fri 9–5, Sat–Sun 10–2 |

## Current Backend Status

**Frontend-only.** No production backend is connected.

- Contact form: logs to console when no `RESEND_API_KEY` is set
- Newsletter: logs to console when no `RESEND_API_KEY` is set
- Shop cart: client-side only (Zustand + localStorage)
- Booking: WhatsApp-first (composes a WhatsApp message, no server booking)
- Chatbot: deterministic keyword-matching, no LLM
- Database: Prisma schema is template-only (User + Post)

## Routes (46 pages)

- `/` — Homepage
- `/services` — Services hub (Boarding, Grooming, Vet Care, Training)
- `/services/boarding` — Boarding hub
- `/services/boarding/{dogs,cats,exotic}` — Boarding detail pages
- `/services/grooming` — Grooming
- `/services/vet-care` — Veterinary Care
- `/services/training` — Training
- `/services/pricing` — Pricing calculator
- `/services/transport` → 301 redirect to `/relocation/transport`
- `/relocation` — Relocation hub
- `/relocation/import` — Pet Import
- `/relocation/export` — Pet Export
- `/relocation/transport` — Local Transport
- `/relocation/checklist` — Relocation Checklist
- `/about` — About Waggies
- `/about/testimonials` — Testimonials
- `/about/gallery` — Photo Gallery
- `/about/careers` — Careers
- `/about/partnerships` — Partnerships
- `/tools` — Tools hub (11 tools)
- `/blog` — Blog
- `/guides` — Guides
- `/knowledge-base` — Knowledge Base
- `/faq` — FAQ
- `/shop` — Pet Shop
- `/shop/[id]` — Product Detail
- `/contact` — Contact
- `/loyalty` — Loyalty Programme
- Legal: `/privacy-policy`, `/terms-of-service`, `/cookies-policy`

## Known Limitations

- All images are temporary stock/Unsplash — await client-supplied photography
- 3 of 8 team profiles are verified; 5 are placeholders
- No production authentication system
- No production database backend
- Pre-existing TypeScript errors in `phosphor-icons.ts` (126 weight-type mismatches)
- Pre-existing TypeScript error in `cart-store.ts` (1 selector type)
- Social media URLs in `business-info.ts` are placeholder handles

## Environment Variables

See `.env.example` for all expected variables.

## Deferred

- Production database backend
- Authentication / user accounts
- LLM-powered chatbot
- Email delivery (requires `RESEND_API_KEY`)
- Production deployment
- Analytics integration
